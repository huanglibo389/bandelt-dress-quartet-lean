# Lean 4 supplementary material

This archive contains the Lean 4 formalisation accompanying the manuscript

> Stefan Grünewald and Libo Huang, *A Sum-of-Squares Decomposition for Quartet
> Covariance: Bivariate Independence and Quartet Distance*.

**Target journal:** *Probability Theory and Related Fields*  
**Corresponding author:** Stefan Grünewald, Shanghai Institute of Nutrition
and Health, Chinese Academy of Sciences, Shanghai, China;
`stefan@picb.ac.cn`.

The package is source-only: it contains the proof files, pinned toolchain and
dependency metadata, a paper-to-Lean correspondence table, a reproducible
axiom audit, an MIT licence for the author-written source, and the required
notice for vendored third-party code.  Generated build caches and editor files
are deliberately excluded.

## Reproduce the check

Install `elan` (which supplies Lean and Lake), unpack the archive, enter this
directory, and run:

```text
lake exe cache get
lake build
lake env lean BernoulliSupplementAudit.lean
```

The included `lean-toolchain` selects Lean `v4.32.0`; `lakefile.toml` selects
mathlib `v4.32.0`; and `lake-manifest.json` records the exact resolved commits.
The cache command fetches the dependencies recorded in the included manifest
and downloads matching precompiled mathlib files; it is an efficiency step,
not part of the proof.  `lake update` is intentionally omitted from the reader
workflow because it is a maintainer command for deliberately refreshing the
dependency lock.

The default target is `BernoulliSupplementAudit`.  This historical internal
module name is retained to avoid mechanically changing the already verified
Lean source closure; it does not identify the target journal.  The target
imports `QDFull`, so a single `lake build` checks the complete local import
closure and the audit module.  To display the axiom report directly, run:

```text
lake env lean BernoulliSupplementAudit.lean
```

The result of the release check is recorded in `BUILD_AND_AUDIT.md`.

## Contents

- `QDFull.lean` and `QDFull/`: the main finite-tree, quartet-covariance,
  reconstruction, compatibility, correlation, and weighted-tree development.
- `QDTauStar.lean` and `QDTauStar/`: finite approximation, quantisation,
  measure-theoretic limits, the BKR inequality, and the arbitrary-law
  zero-characterisation of tau-star.
- `QuartetV060.lean` and `QuartetV060/`: the bridge-ledger quartet proof used
  by the main development.
- `QuartetDistance.lean` and `QuartetDistance/`: the selected vendored
  quartet-distance infrastructure.
- `BernoulliSupplementAudit.lean`: `#print axioms` checks for representative terminal
  results.
- `THEOREM_CORRESPONDENCE.md`: v8 manuscript numbering, PDF/TeX locations, and
  exact Lean declarations.
- `MANUSCRIPT_LOCK.md`: hashes of the manuscript files against which the
  correspondence table was checked.
- `SUPPLEMENT_DESCRIPTION.txt`: a short description ready to paste into the
  journal submission system.
- `LICENSE`: the MIT licence for the author-written files in this archive.
- `SHA256SUMS`: integrity hashes for every other file in the source archive.
- `THIRD_PARTY_NOTICES.md`, `VENDORED_MODULES.md`, and `third_party/`: source,
  commit, and licence information for vendored code.

There are 142 local Lean source files in this release: the exact 140-module
proof closure, the `QuartetDistance` import index, and the unified axiom-audit
module.  Development scratch files, superseded audit modules, compiled files,
PDF reports, and historical manuscript notes are not included.

## Scope of the formalisation

The first 2026-09-05 supplementary-source update added
`QDFull/WeightedDrawBridge.lean`. It formalises the equivalence between the
manuscript's ordered-four-draw, partial-quartet-length weighting description
and its explicit weighted edge-pair sum. At that stage the original manuscript
PDF, TeX, bibliography, mathematical statements, and dependency lock were unchanged.
See `WEIGHTED_DRAW_COMPLETION.md` for the exact added definitions, theorem
interfaces, validation, and scope. This is a source supplement update, not a
new manuscript version or a claim that any journal upload has been replaced.

This package subsequently updates the manuscript lock for the single
zero-mass-cell copyedit of 2026-09-05. Only that requested manuscript phrase
was changed; the recompiled PDF remains 27 pages and all 142 Lean sources
are identical to the completed weighted-draw package. The current hashes
are in `MANUSCRIPT_LOCK.md`; the exact update is documented in
`MANUSCRIPT_COPYEDIT_20260905.md`. No journal upload was changed.

Lean's successful build checks the formal declarations and their dependency
chains.  `THEOREM_CORRESPONDENCE.md` separately records how the numbered
statements in the manuscript are represented.  Bibliographic, historical,
editorial, and authorship assertions are outside the formal scope.

Some internal filenames and declaration names retain historical development
labels, in particular `LemmaThree.lean` and identifiers beginning with
`lemma3`.  In the final manuscript these declarations support **Lemma 6**; the
names are retained to avoid changing a verified dependency graph.

## Licence

Except for the files identified in `THIRD_PARTY_NOTICES.md`, the
author-written files in this archive are licensed under the MIT licence in the
root `LICENSE` file.  Vendored files remain subject to their recorded upstream
copyright and licence.

## Third-party code

Ten files under `QuartetDistance/` are vendored from
`rvazdev-ex/quartet_distance_bandelt_dress` at commit
`e0bcc79c179a571c9b3f6485eb666a790c73c228` under the MIT licence.  See
`THIRD_PARTY_NOTICES.md` and the full licence text under `third_party/`.
