import QDFull

/-!
# Axiom audit for the Bernoulli Lean supplement

This file introduces no definitions, assumptions, or theorems.  Each command
asks Lean to report the transitive axioms used by a representative terminal
claim from the accompanying manuscript.  The theorem names retain a few
historical development labels (notably `lemma3`) even where the final
manuscript numbering has changed; `THEOREM_CORRESPONDENCE.md` gives the current
mapping.
-/

-- Lemma 1, Theorems 1--2, and Lemma 2.
#print axioms QDFull.edgeDisplayCount_sub_pathDisplayCount_eq_one
#print axioms QDFull.treeQuartetCovariance_eq_six_mul_inclusionExclusionCovariance
#print axioms QDFull.sumOfSquaresRhs_eq_inclusionExclusionCovariance
#print axioms QDTauStar.matrix_identity

-- Reconstruction, bounds, counting, and the quartet-distance consequence.
#print axioms QDFull.XTree.displays_compl_split_of_all_partialQuartet_restrictions
#print axioms QDFull.XTree.isBinaryPhylogenetic_of_all_three_and_four_partialQuartets_displayed
#print axioms QDFull.vertexVariablesIndependent_iff_treesIndependent
#print axioms QDFull.exists_positive_vertex_side_witness_of_not_treesIndependent
#print axioms QDFull.treeQuartetCovariance_eq_universal_bound_iff_identical
#print axioms QDFull.treeQuartetCovariance_eq_quartetCounts
#print axioms QDFull.quartetDistance_le_twoThirds_bound
#print axioms QDFull.lemma3_global_split_covariance_lower_bound

-- Compatibility, correlation, weighted trees, and arbitrary bivariate laws.
#print axioms QDFull.quartetCompatibilityIndex_eq_one_iff
#print axioms QDFull.quartetCompatibilityIndex_eq_one_iff_splitUnionCompatible_of_nontrivial
#print axioms QDFull.quartetCorrelation_bounds
#print axioms QDFull.positive_equal_quartet_indices_iff_labelPreservingIso_and_positive
#print axioms QDFull.WeightedApplications.treeDistanceCovariance_eq_threeHalves_empirical
#print axioms QDTauStar.finiteTable_tauStar_gt_two_bkr_of_delta_ne_zero
#print axioms QDTauStar.finiteTable_tauStar_eq_two_bkr_implies_delta_eq_zero
#print axioms QDTauStar.two_bkrDiscrepancy_le_populationTauStar
#print axioms QDTauStar.bkrDiscrepancy_eq_zero_iff_coordinatesIndependent
#print axioms QDTauStar.populationTauStar_pos_of_not_coordinatesIndependent
#print axioms QDTauStar.populationTauStar_eq_zero_iff_coordinatesIndependent

-- Separate asymptotic quartet-distance consequence.
#print axioms QDFull.PhyloSyntaxBridge.realizedNormalizedMaximum_tendsto_two_thirds

-- Ordered-four-draw length weighting and the explicit edge-pair definition.
#print axioms QDFull.WeightedApplications.weightedTreeDrawContribution_eq_edgePairSum
#print axioms QDFull.WeightedApplications.weightedFourDrawCovariance_eq_treeDistanceCovariance
#print axioms QDFull.WeightedApplications.weightedFourDrawCovariance_eq_threeHalves_empirical
