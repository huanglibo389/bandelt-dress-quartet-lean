import QDFull.Preliminaries
import QDFull.PreliminaryFacts
import QDFull.LocalMasses
import QDFull.BranchPartition
import QDFull.SplitCovariance
import QDFull.QuartetEvents
import QDFull.FourDrawCounting
import QDFull.EventClassification
import QDFull.EventCovariance
import QDFull.FiniteIndexSets
import QDFull.MassPartitionIdentities
import QDFull.CoefficientPartitions
import QDFull.MixedCovariance
import QDFull.PathEdgeCovariance
import QDFull.PathPathCovariance
import QDFull.TheoremTwoCounterexample
import QDFull.SquareExpansion
import QDFull.GlobalSquareAssembly
import QDFull.RawQuadraticAssembly
import QDFull.InclusionExclusionGeometry
import QDFull.InclusionExclusionPath
import QDFull.InclusionExclusionCounting
import QDFull.InclusionExclusionCoefficient
import QDFull.TreeQuartetUniqueness
import QDFull.TreeEventClassification
import QDFull.PointwiseInclusionExclusion
import QDFull.TheoremOne
import QDFull.CoefficientLowerBound
import QDFull.LemmaThree
import QDFull.WeightedApplications
import QDFull.WeightedDrawBridge
import QDFull.PhylogeneticNonindependence
import QDFull.QuartetCountIdentity
import QDFull.GlobalQuartetCounts
import QDFull.BinaryPhylogeneticQuartets
import QDFull.BinaryPhylogeneticQuartetCounts
import QDFull.CorollaryOne
import QDFull.CorollaryOneCounterexample
import QDFull.RootedClusterReconstruction
import QDFull.CorollaryOneReconstruction
import QDFull.QuartetCompatibility
import QDFull.QuartetCorrelation
import QDFull.QuartetCorrelationEquality
import QDFull.GeneralPartialQuartetReconstruction
import QDFull.CurrentLemmaThreeWrapper
import QDFull.JointVertexLaw
import QDFull.PaperClaims
import QDFull.NegativeType
import QDFull.PhyloSyntaxBridge
import QDTauStar
import QuartetV060

/-!
# Formalization accompanying the sign-covariance manuscript

This root deliberately imports the earlier machine-checked developments but
does not treat them as substitutes for the statements in the paper.  Exact
paper-to-theorem correspondence is recorded in `THEOREM_CORRESPONDENCE.md`.
-/
