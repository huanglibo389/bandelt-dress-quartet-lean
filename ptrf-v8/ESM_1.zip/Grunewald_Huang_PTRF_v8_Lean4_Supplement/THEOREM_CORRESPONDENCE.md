# Manuscript-to-Lean correspondence

This table refers to the manuscript locked in `MANUSCRIPT_LOCK.md`.  PDF page
numbers and TeX line numbers are supplied only to make human checking easier;
the manuscript labels and mathematical statements are controlling.

The current lock includes the single zero-mass-cell copyedit dated
2026-09-05. All TeX line locations and the page locations of the listed
statements remain unchanged; no numbered statement or displayed formula
was edited.

“Direct theorem” means that one terminal Lean declaration has the paper's
statement after the notational translation described by its definitions.
“Exact theorem chain” means that several named declarations jointly establish
the printed statement.  Build success and manuscript correspondence are
separate checks.

Lean declarations whose names contain `lemma3` retain an earlier development
label and correspond to **Lemma 6** in the present manuscript.

| Manuscript item | PDF / TeX location | Lean declaration(s) | Coverage |
|---|---|---|---|
| Lemma 1 (displaying edges and length-two paths) | p. 7; label `lem:display-path`; lines 439--445 | `QDFull.XTree.edge_mem_quartetPathSubgraph_iff_displays`, `quartetPathSubgraph_connected_of_edge`, `quartetPathLineGraph_isTree_of_edge`, `displayingLengthTwoPathFinset_eq_quartetPathPaths`, `card_displayingLengthTwoPathFinset_add_one_eq_edges` | Exact theorem chain, including the path and `k-1` count assertions |
| Theorem 1 (edge/path inclusion--exclusion) | p. 7; label `thm:inclusion-exclusion`; lines 458--468 | `QDFull.treeQuartetCovariance_eq_six_mul_inclusionExclusionCovariance` | Direct theorem; Lean's four blocks use the normalised `1/6` convention |
| Theorem 2 (four-family sum of squares) | p. 8; label `thm:sum-of-squares`; lines 494--514 | `QDFull.sumOfSquaresRhs_eq_treeQuartetCovariance_div_six`, with `qSquareFamily`, `sSquareFamily`, `bSquareFamily`, `pSquareFamily` | Direct theorem; the manuscript's `P_i` and Lean's canonical path finset both select one representative from each reversal orbit |
| Lemma 2 (matrix identity) | p. 8; label `lem:matrix-identity`; lines 520--547 | `QDTauStar.matrix_identity` | Direct theorem |
| Lemma 3 (partial-quartet reconstruction) | p. 13; label `lem:partial-reconstruction`; lines 981--994 | `QDFull.XTree.displays_compl_split_of_all_partialQuartet_restrictions`, `edgeSplitSet_eq_of_same_partialQuartet_system`, `labelPreservingXTreeIsoOfSamePartialQuartetSystem`, `isBinaryPhylogenetic_of_all_three_and_four_partialQuartets_displayed` | Exact theorem chain; the last declaration packages the printed three- and four-taxon hypotheses into the binary-phylogenetic conclusion |
| Lemma 4 (vertex--side independence bridge) | p. 14; label `lem:vertex-side-bridge`; lines 1035--1048 | `QDFull.vertexJointMass_eq_printed_cardinality`, `QDFull.vertexVariablesIndependent_iff_treesIndependent`, `QDFull.exists_positive_vertex_side_witness_of_not_treesIndependent` | Exact theorem chain |
| Corollary 1 (bounds and equality cases for `Q`) | p. 14; label `cor:Q-bounds`; lines 1090--1099 | `QDFull.treeQuartetCovariance_nonneg`, `treeQuartetCovariance_le_universal_bound`, `treeQuartetCovariance_eq_zero_iff_treesIndependent`, `treeQuartetCovariance_eq_universal_bound_iff_identical` | Exact theorem chain for the manuscript's `|X| >= 4` equality statement |
| Lemma 5 (quartet-count formula) | p. 15; label `lem:Q-counts`; lines 1133--1142 | `QDFull.treeQuartetCovariance_eq_quartetCounts` | Direct theorem |
| Corollary 2 (finite two-thirds bound) | p. 15; label `cor:two-thirds`; lines 1158--1164 | `QDFull.quartetDistance_le_twoThirds_bound` | Direct theorem |
| Lemma 6 (coefficient and global lower bounds) | p. 16; label `lem:coefficient-lower-bound`; lines 1198--1212 | `QDFull.lemma3_coefficient_lower_bound`, `lemma3GlobalLowerBound`, `lemma3ScaledLowerBound_le_qSquareFamily`, `lemma3_global_split_covariance_lower_bound` | Exact theorem chain; the `lemma3` identifiers are legacy names |
| Proposition 1 (quartet compatibility index) | p. 17; label `prop:compatibility`; lines 1336--1342 | `QDFull.XTree.IsNontrivial`, `commonDisplayedPartialQuartets_two_nonempty_of_adj`, `quartetCompatibilityDenominator_pos_of_nontrivial`, `quartetCompatibilityIndex_mem_unitInterval`, `quartetCompatibilityIndex_eq_zero_iff_treesIndependent`, `quartetCompatibilityIndex_eq_one_iff_splitUnionCompatible_of_nontrivial` | Exact theorem chain in the manuscript's non-trivial-tree domain; the positivity proof formalises the common support-two partial-quartet argument |
| Proposition 2 (quartet correlation) | p. 18; label `prop:correlation`; lines 1364--1372 | `QDFull.quartetCorrelation_bounds`, `quartetCorrelation_eq_zero_iff_treesIndependent`, `positive_equal_quartet_indices_iff_labelPreservingIso_and_positive`, `quartetCorrelation_eq_one_of_labelPreservingIso_and_positive` | Exact theorem chain |
| Theorem 3 (tree and empirical distance covariance) | p. 20; label `thm:tree-distance-covariance`; lines 1492--1499 | `QDFull.WeightedApplications.treeDistanceCovariance_eq_threeHalves_empirical` | Direct theorem |
| Ordered-four-draw length weighting equals the explicit edge-pair definition | p. 19; verbal definition, lines 1439--1442, and displayed definition, lines 1444--1448 | `QDFull.WeightedApplications.weightedTreeDrawContribution_eq_of_sameWitness`, `weightedTreeDrawContribution_eq_of_differentWitness`, `weightedTreeDrawContribution_eq_zero_of_noTreeEvent`, `weightedTreeDrawContribution_eq_edgePairSum`, `weightedFourDrawCovariance_eq_treeDistanceCovariance` | Added 2026-09-05: the source independently defines the weighted draw contribution, verifies all event cases, and proves pointwise edge expansion followed by finite averaging; repeated taxa and absent displayed patterns are included |
| Theorem 3 starting from the ordered-four-draw definition | p. 19 definition through p. 20 Theorem 3 | `QDFull.WeightedApplications.weightedFourDrawCovariance_eq_threeHalves_empirical` | Added 2026-09-05: the weighted draw definition equals three halves of empirical distance covariance squared, through the newly proved bridge |
| Corollary 3 (strict positivity under dependence) | p. 21; label `cor:tau-star`; lines 1619--1622 | `QDTauStar.populationTauStar_pos_of_not_coordinatesIndependent` | Direct theorem for every Borel probability law on `Real × Real` |
| Quantitative inequality `tau-star >= 2 BKR` | p. 22; equation (9), label `eq:tau-star-BKR-lower-bound`; lines 1636--1638 | `QDTauStar.two_bkrDiscrepancy_le_populationTauStar` | Direct theorem for every Borel probability law on `Real × Real` |
| Finite-support strictness from a nonzero interior CDF discrepancy | equation (11): p. 23, lines 1728--1734; strictness conclusion: p. 23, lines 1737--1741 | `QDTauStar.finiteTable_tauStar_gt_two_bkr_of_delta_ne_zero`, `finiteTable_tauStar_eq_two_bkr_implies_delta_eq_zero` | Direct finite-table theorems: a nonzero interior CDF discrepancy makes the inequality strict, and equality forces every interior discrepancy to vanish |
| `tau-star = 0` if and only if independence | abstract p. 1, lines 42--47; introductory summary p. 2, lines 86--99; Corollary 3 p. 21, lines 1619--1622; final conclusion p. 24, lines 1843--1855; no separate equivalence label, with the forward direction stated as Corollary 3 (`cor:tau-star`) | `QDTauStar.populationTauStar_eq_zero_iff_coordinatesIndependent` | Direct theorem at the level of the joint law; `CoordinatesIndependent` means equality of the joint law and the product of its marginals |
| Asymptotic two-thirds conclusion | abstract p. 1, lines 34--40; introductory summary p. 2, lines 77--84; Corollary 2 and proof p. 15, lines 1155--1177; comparison/sharpness discussion pp. 15--16, lines 1179--1192 | `QDFull.quartetDistance_le_twoThirds_bound`; `QDFull.PhyloSyntaxBridge.realizedNormalizedMaximum_tendsto_two_thirds` | Exact finite upper bound for binary phylogenetic `XTree`s, plus a sharp-limit theorem for the explicitly realised syntax-tree model |

## Formal scope boundary

The supplementary-source completion dated 2026-09-05 closes the previously
not-separately-formalised equivalence between the verbal weighted-draw
description and the explicit edge-sum definition. That completion did not
change the manuscript. The subsequent single-phrase zero-mass-cell copyedit
preserves the page and line locations above.

For the copyedit at p. 23, TeX lines 1773--1774, the manuscript now chooses
zero on unoccupied marginal cells. The existing Lean development uses a
globally measurable full-partition rank (`measurable_dyadicRank` in
`QDTauStar/WeakOrderQuantization.lean`) and proves that draws almost surely
lie in positive-mass cells (`ae_dyadicCellMass_pos` in
`QDTauStar/DyadicQuantization.lean`). This is not the same pointwise function
as the manuscript's occupied-cell rank with zero extension; on positive-mass
cells the ranks differ only by a strictly increasing relabelling. The
weak-order and distribution-function arguments are unaffected. This update
adds no new theorem or claim of a new pointwise rank-identification theorem.

The correspondence concerns mathematical statements and the definitions on
which they depend.  It does not claim that Lean checks the manuscript's prose,
bibliography, historical attribution, formatting, or authorship information.
The finite-support strictness result is stated in the formal code through the
finite-table witness used in the manuscript: a nonzero interior CDF
discrepancy.  The population theorem is the non-strict inequality
`tau-star >= 2 BKR`; the finite strictness assertion is not used to derive
Corollary 3.
