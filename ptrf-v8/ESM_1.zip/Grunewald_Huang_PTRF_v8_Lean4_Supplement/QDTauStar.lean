import QDTauStar.Algebra
import QDTauStar.Kernel
import QDTauStar.FiniteSymmetrization
import QDTauStar.Lemma3
import QDTauStar.FinitePath
import QDTauStar.OrderedPathTree
import QDTauStar.FiniteTable
import QDTauStar.FinitePathTree
import QDTauStar.FinitePathTau
import QDTauStar.RationalEncoding
import QDTauStar.RationalApproximation
import QDTauStar.DyadicQuantization
import QDTauStar.WeakOrderQuantization
import QDTauStar.TauQuantizationLimit
import QDTauStar.CDFQuantizationLimit
import QDTauStar.FiniteMassInequality
import QDTauStar.FiniteSupportStrictness
import QDTauStar.FiniteLawBridge
import QDTauStar.QuantizedFiniteInequality
import QDTauStar.IndependentZero
import QDTauStar.Population
import QDTauStar.Variation
import QDTauStar.ZeroCharacterization
import QDTauStar.Limits
import QDTauStar.Corollary3Bridge

/-!
# Machine-checked tau-star supplement

This root includes the finite path-tree inequality, rational and dyadic
approximation, both dominated-convergence limits, the population inequality,
the exact BKR zero characterization for arbitrary Borel laws on `Real × Real`,
and the strict-positivity conclusion of Corollary 3.  Exact correspondence to
the manuscript is recorded in `THEOREM_CORRESPONDENCE.md`.
-/
