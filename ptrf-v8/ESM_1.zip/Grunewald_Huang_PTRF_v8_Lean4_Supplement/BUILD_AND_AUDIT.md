# Release build and audit: weighted four-draw completion

This record preserves the weighted-draw supplementary-source build checked
on 2026-09-05. The subsequent manuscript-only copyedit does not change any
Lean source; its current alignment check is recorded at the end of this file.
The original 2026-09-01 supplement is preserved separately.

## Locked environment and offline procedure

- Lean: `4.32.0`, commit `8c9756b28d64dab099da31a4c09229a9e6a2ef35`.
- Lake: the executable bundled with that exact toolchain.
- mathlib: `81a5d257c8e410db227a6665ed08f64fea08e997` (`v4.32.0`).
- Inherited dependencies: exact commits in the unchanged `lake-manifest.json`.

All dependency Git HEADs were checked against the manifest, with no tracked
source modifications. Existing pinned external dependency caches were used.
No web search, dependency download, `lake update`, or `lake exe cache get`
was run during this completion and audit.

For the final build the local project's `.lake/build` was moved to a
separate development-cache directory. The final check therefore reused no
old compiled local proof module. Using the absolute pinned Lake executable:

```text
lake --no-cache build BernoulliSupplementAudit QuartetDistance
```

Result: **exit 0; Build completed successfully (8798 jobs).** All 142 local
Lean modules were freshly rebuilt, with no local module replayed. The build
took about 239 seconds. It reported 332 non-fatal style/linter warnings from
existing sources, no warnings from the new bridge module, and no errors.

`BernoulliSupplementAudit` is the historical default-target name. It imports
the proof closure and new bridge. The explicit second target also checks
the separately distributed `QuartetDistance` import index.

## Historical manuscript identity at the weighted-draw completion stage

The manuscript remains the 27-page PTRF v8 text, *A Sum-of-Squares
Decomposition for Quartet Covariance: Bivariate Independence and Quartet
Distance*. These hashes were rechecked against the user's original files:

```text
Grunewald_Huang_PTRF_v8.tex
f80c8c2211abdddf1086d8fb98f7edb863400e9f6bf6b2dff7357ee9333ea4c5

Grunewald_Huang_PTRF_v8.pdf
871945cd30a7c349adc846c149cfd18de02710bf0a354914804bad1d14854060

Grunewald_Huang_PTRF_v8_References.bib
9082a66ab956dc4abed7c2a478127cb1ea274d9dc0a7eebca674f0e091e18df8

Original submitted ESM_1.zip (unchanged)
f847fdd5f8eeb19ed3201c5927b465a80f569247e2f60f0487ea2eacc906f3fb
```

Compared byte-for-byte with that original ZIP, 139 existing Lean files are
unchanged. `QDFull.lean` gains one import; `BernoulliSupplementAudit.lean`
gains three terminal axiom checks. One new proof file is added,
`QDFull/WeightedDrawBridge.lean`, 346 lines, SHA-256:

```text
0790c9ed66bf20c1a69b86d399a38c41949e3df8987c3c8b02f437a377d8d7e6
```

No manuscript text, existing mathematical proof, dependency lock, or licence
was changed. `THEOREM_CORRESPONDENCE.md` and `WEIGHTED_DRAW_COMPLETION.md`
describe the new manuscript-to-Lean correspondence separately from build
success.

## Transitive axiom checks

The distributed audit contains 27 `#print axioms` checks: the existing 24
checks plus the three new weighted-draw bridge terminals. All reported only:

```text
propext
Classical.choice
Quot.sound
```

A separate audit enumerated all declarations originating in local proof
modules, including private and generated declarations, and collected their
transitive axiom dependencies. Its observed result was:

```text
AUDIT_TOTAL declarations=6226 theorems=4507 declaration_bearing_modules=137 unexpected=0
```

That audit returned exit 0 in about 72 seconds. No dependency outside the
standard allowed set was found. This is not a claim that Lean is
foundationally axiom-free. The audit source, full dependency table and logs
are retained in the separate completion-evidence directory.

## Placeholder and unsafe-code checks

All 142 local Lean sources were scanned after removing nested comments and
string literals. No active occurrence of the following was found:

```text
axiom, constant, opaque, sorry, admit, sorryAx, unsafe, native_decide
```

The all-declarations transitive axiom audit complements this source scan.

## Historical weighted-draw distribution integrity

- Local Lean source files: 142.
- Local Lean source lines: 53,709.
- Distributed files: 156, including `SHA256SUMS`.
- Checksum entries: 155, covering every other distributed file.

The new ZIP was reopened, tested for archive integrity, compared byte-for-byte
with the selected sources, and checked against every checksum entry. It
contains no `.lake`, external dependencies, compiled objects, symbolic links,
editor metadata or scratch files. Its final digest is recorded outside the
archive to avoid a self-referential archive hash.

The checked ZIP is a new local supplementary-source deliverable. No journal
submission was changed or uploaded by this work.

## Current manuscript-only copyedit and package verification

The single requested change at TeX lines 1773--1774 chooses `g_k(x)=0` on
zero-mass cells instead of arbitrary values. The manuscript was recompiled
with the original class/style and bibliography; the resulting PDF remains
27 pages. All 115 display blocks, 14 numbered-statement environments, label
line locations and other source text are unchanged. New and old PDF pages
were rendered at 96 dpi: only pages 23 and 24 differ, due to this wording and
local paragraph reflow; the other 25 page images are byte-for-byte identical.
Pages 23 and 24 were visually inspected. Current manuscript hashes are in
`MANUSCRIPT_LOCK.md`.

All 142 Lean files are byte-for-byte identical to the source set used by the
fresh build and axiom checks recorded above. The Lean toolchain, dependency
lock and licences are also unchanged. This phase verifies source identity
and manuscript correspondence; it does not claim a second fresh Lean rebuild.

The current source-only ZIP has 157 files, including `SHA256SUMS`, with 156
checksum entries. It includes the new `MANUSCRIPT_COPYEDIT_20260905.md`
record and retains the completed weighted-draw proof. Archive CRC and every
distributed checksum are verified after packaging. No journal upload is
performed by this local update.
