# Manuscript lock

The paper-to-Lean correspondence in this archive uses the following final
PTRF v8 manuscript files, including the single zero-mass-cell copyedit dated
2026-09-05, after the weighted-draw supplementary-source completion. The manuscript itself
is submitted separately and is not duplicated in this source archive.

## Manuscript

**Title:** *A Sum-of-Squares Decomposition for Quartet Covariance: Bivariate
Independence and Quartet Distance*

**Authors:** Stefan Grünewald and Libo Huang

**Rendered length:** 27 A4 pages

| File | SHA-256 |
|---|---|
| `Grunewald_Huang_PTRF_v8.tex` | `b691af256df8edb11503ddcc47c01bc88977d97af3b4447b814105517cf9b1ce` |
| `Grunewald_Huang_PTRF_v8.pdf` | `3853df09723be17bfdd2e4709c44ff40e10f84f0c8d5f430013bbbdf28f5c069` |
| `Grunewald_Huang_PTRF_v8_References.bib` | `9082a66ab956dc4abed7c2a478127cb1ea274d9dc0a7eebca674f0e091e18df8` |

## Historical mathematical-content provenance, before the zero-mass copyedit

The v8 revision changes the title, abstract, Introduction, section headings,
keywords, MSC classifications, Discussion, and bibliographic presentation.  It
does not change the mathematical definitions, labelled statements, displayed
formulas, proof steps, normalisation conventions, or conclusions formalised in
this archive.  Before a final cross-location copyedit, a byte-for-byte
comparison with the coauthor-reviewed 27-page PTRF baseline produced the
following frozen mathematical streams:

| Frozen stream | SHA-256 |
|---|---|
| Theorem, lemma, proposition, and corollary statements | `016be62dfe4221310a806cb2dce8f1fd3852b036594c9935877ae42a9b23c3d3` |
| Displayed mathematics | `23c0dd9b7b47a23a33cffab4db579bb21316aa97d16875f79944e0b595d4bd17` |

The final copyedit replaces only `title` by `abstract` in the sentence saying
where the zero characterisation is stated.  An exact source diff confirms that
this is the sole change after the frozen comparison.  It changes no mathematical
statement, formula, inference, or Lean correspondence.

For the original 2026-09-01 v8 release, all 141 Lean source files were retained
byte-for-byte from the preceding verified supplement; only the manuscript
lock, the human-readable location table, and release metadata were updated.

## Historical weighted-draw supplementary-source completion, 2026-09-05

At that stage the original manuscript hashes remained unchanged. That supplementary-source
update adds `QDFull/WeightedDrawBridge.lean` to formalise the equivalence of
the ordered-four-draw length-weighting description (TeX lines 1439--1442)
and the explicit edge-pair definition (lines 1444--1448). The root import
`QDFull.lean` and `BernoulliSupplementAudit.lean` are updated to include the
new proof. The other 139 pre-existing Lean files remain byte-for-byte
unchanged. The release now has 142 Lean files.

The change adds a proved interface between two existing manuscript
descriptions. It changes neither the paper's mathematical statements nor
the definitions or proof terms in the existing 139 unchanged source files.
The dependency versions and MIT licence are retained.

## Current zero-mass-cell copyedit, 2026-09-05

The current hashes are those in the Manuscript table above. Relative to the
manuscript used for the weighted-draw completion, the only source change is
at TeX lines 1773--1774: replace arbitrary values on zero-mass cells by the
explicit choice `g_k(x)=0`, with the analogous convention for `h_k`.
All other source text is unchanged. TeX line count remains 1945 and the
recompiled PDF remains 27 pages. All 115 displayed-math blocks, all 14
theorem/lemma/corollary/proposition statement environments, and all label
line locations are unchanged. The bibliography, compiled `.bbl`, class and
bibliography-style files are byte-for-byte unchanged.

All 142 Lean source files and all dependency locks are byte-for-byte
identical to the completed weighted-draw supplement; no Lean comment or
proof was modified. See `MANUSCRIPT_COPYEDIT_20260905.md` for the exact
replacement and its correspondence to the existing measurable quantizers.

If any locked manuscript file changes, the hashes, theorem numbering, PDF page
locations, TeX line locations, and statement correspondence must be checked
again before the supplement is submitted.
