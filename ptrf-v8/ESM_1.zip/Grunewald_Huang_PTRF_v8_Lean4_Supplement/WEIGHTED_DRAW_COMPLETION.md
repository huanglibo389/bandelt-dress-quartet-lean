# Weighted four-draw semantics: completion of the manuscript bridge

Date: 2026-09-05. Historical record of the weighted-draw proof completion.
The later manuscript-only zero-mass-cell copyedit is documented separately
in `MANUSCRIPT_COPYEDIT_20260905.md`. References below to an unchanged
manuscript describe the earlier weighted-draw completion stage.

## Scope and manuscript location

The locked PTRF v8 manuscript, PDF page 19, TeX lines 1439–1448, first
describes weighting each ordered four-draw contribution by the lengths of
its two induced partial quartets, and then gives a weighted edge-pair sum.
The earlier supplement defined the edge-pair sum and proved its relation to
empirical squared distance covariance. It did not separately define the
samplewise object and prove the equivalence of these descriptions.

`QDFull/WeightedDrawBridge.lean` fills exactly that gap. The manuscript,
its mathematical statements, and the pinned Lean/mathlib dependencies have
not been changed.

## Independent definition

For an ordered draw `d : Fin 4 → X`, let

`E_T(d,P) := Induces d P ∧ T.DisplaysPartialSplit P`.

Let `L_W(P)` be the existing partial-quartet length: the sum of the positive
lengths of all canonical unoriented tree edges whose splits display `P`.
Let `k(P,Q)` equal `1` if `P = Q` and `-1/2` otherwise. The new definition is

```text
w(d) = sum over P,Q of
       indicator(E_T1(d,P)) * indicator(E_T2(d,Q)) *
       k(P,Q) * L_W1(P) * L_W2(Q).
```

The sum is over `PartialSplit X`, not over edges and not over permutation
witnesses. A partial split is an unordered pair of finite sets. Thus side
reversal is not counted twice, and different permutation witnesses for
`Induces` do not create multiplicity. Repeated taxa are permitted because
the draw is any function `Fin 4 → X`, not an injection.

The existing tree-quartet uniqueness theorem proves that each tree has at
most one eligible partial quartet for a fixed draw. Consequently:

- A common eligible quartet contributes `L_W1(P) * L_W2(P)`.
- Distinct eligible quartets contribute `(-1/2) * L_W1(P) * L_W2(Q)`.
- If at least one tree has no eligible quartet, the contribution is zero.

The new `weightedFourDrawCovariance` is `fourDrawAverage w`, with the
existing uniform ordered-draw normalization `sum(w(d)) / |X|^4`.

## Checked proof chain

All names below are in `QDFull.WeightedApplications`.

1. `drawDisplaysPartialQuartet_unique`:
   at most one eligible partial quartet for a fixed tree and draw.
2. `weightedTreeDrawContribution_eq_of_sameWitness`,
   `weightedTreeDrawContribution_eq_of_differentWitness`, and
   `weightedTreeDrawContribution_eq_zero_of_noTreeEvent`:
   the three samplewise cases above.
3. `weightedTreeDrawContribution_eq_edgePairSum`:
   the independently defined samplewise quantity equals the sum of
   `splitDrawContribution(S_e,S_f,d) * length(e) * length(f)` over edge pairs.
4. `weightedFourDrawCovariance_eq_treeDistanceCovariance`:
   finite averaging and interchange of finite sums give exactly the
   previously defined weighted edge-pair covariance.
5. `weightedFourDrawCovariance_eq_threeHalves_empirical`:
   composition with the existing Theorem 3 endpoint gives `3/2` times
   empirical distance covariance squared for the two tree pseudometrics.

The new theorems do not assume the desired equality, nonnegativity,
independence, or a supplied sum-of-squares certificate. They apply to the
existing finite `EdgeWeightedXTree` type, including nonbinary trees and
noninjective taxon maps, without a caterpillar or lower-size restriction.
The vertex linear orders only select canonical representatives of
unoriented edges. Edge-length positivity is inherited from the paper's
definition of an edge-weighted tree.

## Validation and provenance

The main authoring agent and a separate read-only reviewing agent checked
the source definitions against the quoted manuscript passage, including
repeated labels, missing patterns, orientation multiplicity, coefficients,
and normalization. The module was then included in the full source build
and transitive axiom audit. Exact observed results are recorded in
`BUILD_AND_AUDIT.md`; file integrity is recorded in `SHA256SUMS`.

Of the original 141 Lean files, 139 are byte-for-byte unchanged. Only
`QDFull.lean` (one import) and `BernoulliSupplementAudit.lean` (three terminal
axiom checks) are extended; one new Lean file is added, giving 142 files.
The original manuscript files and original submitted `ESM_1.zip` remain
unchanged. This package has not been uploaded to or substituted in a
journal submission system by this update.

This closes the specific samplewise-weighting-to-edge-sum formalization
gap, not a claim that historical, bibliographic, or every prose assertion
in the manuscript is a formal theorem.
