import QDFull.WeightedApplications

/-!
# Phylogenetic trees cannot be independent

This file formalizes the observation following Corollary 2 in the locked
paper.  A labelled leaf determines a pendant edge whose taxon side is a
singleton.  Taking the pendant edge at the same taxon in two phylogenetic
trees gives a strictly positive normalized `2 x 2` determinant as soon as the
taxon set has at least two elements.  Hence the two trees cannot satisfy the
paper's edge-by-edge independence condition.
-/

open SimpleGraph

namespace QDFull

universe uX uV uV₁ uV₂

namespace XTree

variable {X : Type uX} {V : Type uV}
  [Fintype X] [Fintype V]

/-- A labelled leaf of a phylogenetic tree has a unique graph neighbour. -/
theorem IsPhylogenetic.exists_unique_neighbor_label
    (T : XTree X V) (hphy : T.IsPhylogenetic) (x : X) :
    ∃! t : V, T.graph.Adj (T.label x) t := by
  have hleaf : Nat.card (T.graph.neighborSet (T.label x)) = 1 :=
    hphy.2.1 x
  rw [Nat.card_coe_set_eq, Set.ncard_eq_one] at hleaf
  obtain ⟨t, ht⟩ := hleaf
  refine ⟨t, ?_, ?_⟩
  · change t ∈ T.graph.neighborSet (T.label x)
    rw [ht]
    simp
  · intro z hz
    have hzmem : z ∈ T.graph.neighborSet (T.label x) := hz
    rw [ht] at hzmem
    simpa using hzmem

/-- Deleting the pendant edge at a labelled leaf isolates that leaf. -/
theorem IsPhylogenetic.neighborSet_delete_pendant_eq_empty
    (T : XTree X V) (hphy : T.IsPhylogenetic) (x : X) {t : V}
    (ht : T.graph.Adj (T.label x) t) :
    (T.graph.deleteEdges {s(t, T.label x)}).neighborSet (T.label x) = ∅ := by
  classical
  obtain ⟨t₀, ht₀, ht₀uniq⟩ := hphy.exists_unique_neighbor_label T x
  have htt₀ : t = t₀ := ht₀uniq t ht
  subst t₀
  ext z
  simp only [Set.mem_empty_iff_false, iff_false]
  intro hz
  have hzparts := SimpleGraph.deleteEdges_adj.mp hz
  have hzt : z = t := ht₀uniq z hzparts.1
  subst z
  exact hzparts.2 (by simp [Sym2.eq_swap])

/-- The component of a labelled leaf after deleting its pendant edge carries
exactly that one taxon. -/
theorem IsPhylogenetic.edgeSide_pendant_eq_singleton
    (T : XTree X V) (hphy : T.IsPhylogenetic) (x : X) {t : V}
    (ht : T.graph.Adj (T.label x) t) :
    T.edgeSide t (T.label x) = {x} := by
  classical
  have hempty := hphy.neighborSet_delete_pendant_eq_empty T x ht
  ext y
  rw [T.mem_edgeSide]
  simp only [Finset.mem_singleton]
  constructor
  · intro hy
    by_contra hyx
    have hlabel : T.label x ≠ T.label y := by
      intro hxy
      exact hyx (hphy.1 hxy.symm)
    exact (SimpleGraph.not_reachable_of_neighborSet_left_eq_empty
      hlabel hempty) hy
  · intro hyx
    subst y
    exact SimpleGraph.Reachable.refl (T.label x)

end XTree

/-- For a finite type with at least two elements, the normalized determinant
of the singleton split with itself is strictly positive. -/
theorem orientedSplitDeterminant_singleton_compl_self_pos
    {X : Type uX} [Fintype X] [Nonempty X] [DecidableEq X]
    (hcard : 2 ≤ Fintype.card X) (x : X) :
    0 < orientedSplitDeterminant {x} ({x} : Finset X)ᶜ
      {x} ({x} : Finset X)ᶜ := by
  classical
  have hsingle : 0 < normalizedCard ({x} : Finset X) :=
    normalizedCard_pos (by simp)
  obtain ⟨y, hyx⟩ := Fintype.exists_ne_of_one_lt_card (by omega) x
  have hcompl_nonempty : (({x} : Finset X)ᶜ).Nonempty := by
    refine ⟨y, ?_⟩
    simp [hyx]
  have hcompl : 0 < normalizedCard (({x} : Finset X)ᶜ) :=
    normalizedCard_pos hcompl_nonempty
  unfold orientedSplitDeterminant
  simpa [normalizedCard] using mul_pos hsingle hcompl

/-- Any two phylogenetic `X`-trees fail the paper's independence condition
when there are at least two taxa.  The proof uses the two pendant edges at one
common taxon and exhibits their strictly positive determinant coefficient. -/
theorem phylogenetic_trees_not_independent
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (hcard : 2 ≤ Fintype.card X)
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hphy₁ : T₁.IsPhylogenetic) (hphy₂ : T₂.IsPhylogenetic) :
    ¬ TreesIndependent T₁ T₂ := by
  classical
  letI : Nonempty X := T₁.taxon_nonempty
  let x : X := Classical.choice (inferInstance : Nonempty X)
  obtain ⟨t₁, ht₁, _⟩ := hphy₁.exists_unique_neighbor_label T₁ x
  obtain ⟨t₂, ht₂, _⟩ := hphy₂.exists_unique_neighbor_label T₂ x
  intro hind
  have hzero := (treesIndependent_iff_xCoefficient_eq_zero T₁ T₂).1 hind
    (T₁.label x) t₁ (T₂.label x) t₂ ht₁ ht₂
  rw [xCoefficient_eq_edge_determinant T₁ T₂ ht₁ ht₂,
    T₁.edgeSide_reverse_eq_compl ht₁.symm,
    T₂.edgeSide_reverse_eq_compl ht₂.symm,
    hphy₁.edgeSide_pendant_eq_singleton T₁ x ht₁,
    hphy₂.edgeSide_pendant_eq_singleton T₂ x ht₂] at hzero
  exact (ne_of_gt
    (orientedSplitDeterminant_singleton_compl_self_pos hcard x)) hzero

end QDFull
