import QDFull.InclusionExclusionGeometry

/-!
# The common displaying path of one four-draw pairing

For a pairing `q₁ q₂ | q₃ q₄`, an edge displays the represented partial
split exactly when it belongs to all four cross paths.  Their common subgraph
is therefore the precise graph represented by the phrase "the displaying
edges form a path" in the proof of Theorem 1.
-/

open SimpleGraph

namespace QDFull

universe uX uV

namespace XTree

variable {X : Type uX} {V : Type uV}
  [Fintype X] [Fintype V] [DecidableEq X] [DecidableEq V]

/-- The subgraph traced by the unique path between two labelled taxa. -/
noncomputable def crossPathSubgraph
    (T : XTree X V) (a b : X) : T.graph.Subgraph :=
  (T.taxonPath a b).toSubgraph

/-- The common edge-and-vertex segment of the four cross paths associated
with the ordered pairing `q₁ q₂ | q₃ q₄`. -/
noncomputable def quartetPathSubgraph
    (T : XTree X V) (q₁ q₂ q₃ q₄ : X) : T.graph.Subgraph :=
  (((T.crossPathSubgraph q₁ q₃ ⊓ T.crossPathSubgraph q₁ q₄) ⊓
      T.crossPathSubgraph q₂ q₃) ⊓
    T.crossPathSubgraph q₂ q₄)

/-- An actual tree edge belongs to the common quartet path exactly when its
edge split displays the paired partial split. -/
theorem edge_mem_quartetPathSubgraph_iff_displays
    (T : XTree X V) {u v : V} (huv : T.graph.Adj u v)
    (q₁ q₂ q₃ q₄ : X) :
    s(u, v) ∈ (T.quartetPathSubgraph q₁ q₂ q₃ q₄).edgeSet ↔
      Displays (T.edgeSplit u v)
        s(({q₁, q₂} : Finset X), ({q₃, q₄} : Finset X)) := by
  classical
  rw [T.displays_edgeSplit_iff_mem_all_cross_paths huv
    {q₁, q₂} {q₃, q₄} (by simp) (by simp)]
  simp only [quartetPathSubgraph, crossPathSubgraph,
    SimpleGraph.Subgraph.edgeSet_inf, Set.mem_inter_iff,
    SimpleGraph.Walk.mem_edges_toSubgraph,
    Finset.mem_insert, Finset.mem_singleton]
  aesop

/-- A witness edge in two connected subgraphs of a tree supplies the common
vertex needed to show that their intersection is connected. -/
private theorem connected_inf_of_common_edge
    (T : XTree X V) {H K : T.graph.Subgraph} {u v : V}
    (hH : H.Connected) (hK : K.Connected)
    (heH : H.Adj u v) (heK : K.Adj u v) :
    (H ⊓ K).Connected :=
  PathGeometry.connected_inf_of_isTree T.isTree hH hK
    ⟨u, heH.fst_mem, heK.fst_mem⟩

/-- A nonempty common quartet path is connected.  The same witness edge is
retained through each of the three intersections. -/
theorem quartetPathSubgraph_connected_of_edge
    (T : XTree X V) {u v : V}
    (q₁ q₂ q₃ q₄ : X)
    (he : s(u, v) ∈ (T.quartetPathSubgraph q₁ q₂ q₃ q₄).edgeSet) :
    (T.quartetPathSubgraph q₁ q₂ q₃ q₄).Connected := by
  have hpaths :
      (((s(u, v) ∈ (T.taxonPath q₁ q₃).edges ∧
          s(u, v) ∈ (T.taxonPath q₁ q₄).edges) ∧
        s(u, v) ∈ (T.taxonPath q₂ q₃).edges) ∧
        s(u, v) ∈ (T.taxonPath q₂ q₄).edges) := by
    simpa only [quartetPathSubgraph, crossPathSubgraph,
      SimpleGraph.Subgraph.edgeSet_inf, Set.mem_inter_iff,
      SimpleGraph.Walk.mem_edges_toSubgraph] using he
  have h13 : (T.crossPathSubgraph q₁ q₃).Adj u v :=
    (SimpleGraph.Walk.adj_toSubgraph_iff_mem_edges).2 hpaths.1.1.1
  have h14 : (T.crossPathSubgraph q₁ q₄).Adj u v :=
    (SimpleGraph.Walk.adj_toSubgraph_iff_mem_edges).2 hpaths.1.1.2
  have h23 : (T.crossPathSubgraph q₂ q₃).Adj u v :=
    (SimpleGraph.Walk.adj_toSubgraph_iff_mem_edges).2 hpaths.1.2
  have h24 : (T.crossPathSubgraph q₂ q₄).Adj u v :=
    (SimpleGraph.Walk.adj_toSubgraph_iff_mem_edges).2 hpaths.2
  have h12 :
      (T.crossPathSubgraph q₁ q₃ ⊓
        T.crossPathSubgraph q₁ q₄).Connected :=
    connected_inf_of_common_edge T
      (T.taxonPath q₁ q₃).toSubgraph_connected
      (T.taxonPath q₁ q₄).toSubgraph_connected h13 h14
  have h123 :
      ((T.crossPathSubgraph q₁ q₃ ⊓
          T.crossPathSubgraph q₁ q₄) ⊓
        T.crossPathSubgraph q₂ q₃).Connected :=
    connected_inf_of_common_edge T h12
      (T.taxonPath q₂ q₃).toSubgraph_connected
      ⟨h13, h14⟩ h23
  exact connected_inf_of_common_edge T h123
    (T.taxonPath q₂ q₄).toSubgraph_connected
    ⟨⟨h13, h14⟩, h23⟩ h24

theorem quartetPathSubgraph_le_crossPath13
    (T : XTree X V) (q₁ q₂ q₃ q₄ : X) :
    T.quartetPathSubgraph q₁ q₂ q₃ q₄ ≤
      T.crossPathSubgraph q₁ q₃ := by
  unfold quartetPathSubgraph
  exact inf_le_left.trans (inf_le_left.trans inf_le_left)

/-- The line graph of the common segment is acyclic because it embeds in the
line graph of the simple path from `q₁` to `q₃`. -/
theorem quartetPathLineGraph_isAcyclic
    (T : XTree X V) (q₁ q₂ q₃ q₄ : X) :
    (T.quartetPathSubgraph q₁ q₂ q₃ q₄).coe.lineGraph.IsAcyclic := by
  let hle :
      T.quartetPathSubgraph q₁ q₂ q₃ q₄ ≤
        T.crossPathSubgraph q₁ q₃ :=
    T.quartetPathSubgraph_le_crossPath13 q₁ q₂ q₃ q₄
  let f :
      (T.quartetPathSubgraph q₁ q₂ q₃ q₄).coe →g
        (T.crossPathSubgraph q₁ q₃).coe :=
    SimpleGraph.Subgraph.inclusion hle
  exact PathGeometry.lineGraph_isAcyclic_of_injectiveHom f
    (SimpleGraph.Subgraph.inclusion.injective hle)
    (PathGeometry.lineGraph_toSubgraph_isAcyclic
      (T.taxonPath_isPath q₁ q₃))

/-- Once it contains an edge, the line graph of the displaying segment is a
finite tree.  This is the exact graph-theoretic form used in the `k-1` count. -/
theorem quartetPathLineGraph_isTree_of_edge
    (T : XTree X V) {u v : V}
    (q₁ q₂ q₃ q₄ : X)
    (he : s(u, v) ∈ (T.quartetPathSubgraph q₁ q₂ q₃ q₄).edgeSet) :
    (T.quartetPathSubgraph q₁ q₂ q₃ q₄).coe.lineGraph.IsTree := by
  refine ⟨?_, T.quartetPathLineGraph_isAcyclic q₁ q₂ q₃ q₄⟩
  apply PathGeometry.lineGraph_connected
  · exact (T.quartetPathSubgraph_connected_of_edge q₁ q₂ q₃ q₄ he).coe
  · let e : (T.quartetPathSubgraph q₁ q₂ q₃ q₄).edgeSet := ⟨s(u, v), he⟩
    let e' := (PathGeometry.coeEdgeEquiv
      (T.quartetPathSubgraph q₁ q₂ q₃ q₄)).symm e
    exact ⟨e'.1, e'.2⟩

end XTree

end QDFull
