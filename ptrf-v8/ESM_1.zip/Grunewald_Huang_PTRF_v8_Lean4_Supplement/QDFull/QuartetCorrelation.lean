import QDFull.QuartetCompatibility

/-!
# Quartet correlation

This file formalizes the quartet-correlation definition and the event-level
inequalities used in Proposition 2.  The manuscript's short proof passes from
displayed-quartet counts to two quotient inequalities.  Here the underlying
fact is proved first on every ordered four-draw sample: the common and
conflicting events are disjoint, and their union is contained in either
self-comparison event.
-/

namespace QDFull

universe uX uV₁ uV₂

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂] [DecidableEq X]

/-- The quartet correlation `rho_Q(T₁,T₂)` from the manuscript. -/
noncomputable def quartetCorrelation
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  treeQuartetCovariance T₁ T₂ /
    Real.sqrt
      (treeQuartetCovariance T₁ T₁ *
        treeQuartetCovariance T₂ T₂)

/-- A common displayed quartet for two trees is a displayed quartet in the
self-comparison of the first tree. -/
theorem SameTreeQuartetEvent.self_left
    {T₁ : XTree X V₁} {T₂ : XTree X V₂} {draw : Fin 4 → X}
    (h : SameTreeQuartetEvent T₁ T₂ draw) :
    SameTreeQuartetEvent T₁ T₁ draw := by
  rcases h with ⟨R, hindR, hT₁R, _hT₂R⟩
  exact ⟨R, hindR, hT₁R, hT₁R⟩

/-- A common displayed quartet for two trees is a displayed quartet in the
self-comparison of the second tree. -/
theorem SameTreeQuartetEvent.self_right
    {T₁ : XTree X V₁} {T₂ : XTree X V₂} {draw : Fin 4 → X}
    (h : SameTreeQuartetEvent T₁ T₂ draw) :
    SameTreeQuartetEvent T₂ T₂ draw := by
  rcases h with ⟨R, hindR, _hT₁R, hT₂R⟩
  exact ⟨R, hindR, hT₂R, hT₂R⟩

/-- A conflicting pair still supplies a displayed quartet to the first
tree's self-comparison. -/
theorem DifferentTreeQuartetEvent.self_left
    {T₁ : XTree X V₁} {T₂ : XTree X V₂} {draw : Fin 4 → X}
    (h : DifferentTreeQuartetEvent T₁ T₂ draw) :
    SameTreeQuartetEvent T₁ T₁ draw := by
  rcases h with ⟨R, _S, hindR, _hindS, hT₁R, _hT₂S, _hRS⟩
  exact ⟨R, hindR, hT₁R, hT₁R⟩

/-- A conflicting pair still supplies a displayed quartet to the second
tree's self-comparison. -/
theorem DifferentTreeQuartetEvent.self_right
    {T₁ : XTree X V₁} {T₂ : XTree X V₂} {draw : Fin 4 → X}
    (h : DifferentTreeQuartetEvent T₁ T₂ draw) :
    SameTreeQuartetEvent T₂ T₂ draw := by
  rcases h with ⟨_R, S, _hindR, hindS, _hT₁R, hT₂S, _hRS⟩
  exact ⟨S, hindS, hT₂S, hT₂S⟩

/-- One tree cannot display two distinct partial quartets induced by the same
ordered four-draw sample. -/
theorem not_differentTreeQuartetEvent_self
    (T : XTree X V₁) (draw : Fin 4 → X) :
    ¬ DifferentTreeQuartetEvent T T draw := by
  classical
  rintro ⟨R, S, hindR, hindS, hTR, hTS, hRS⟩
  exact hRS
    (T.induced_displayed_partialQuartet_unique draw
      hindR hindS hTR hTS)

/-- The common and conflicting event sets are disjoint. -/
theorem sameTreeQuartetEventSet_disjoint_differentTreeQuartetEventSet
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    Disjoint
      (fourDrawEventSet (SameTreeQuartetEvent T₁ T₂))
      (fourDrawEventSet (DifferentTreeQuartetEvent T₁ T₂)) := by
  classical
  rw [Finset.disjoint_left]
  intro draw hsame hdiff
  have hsame' : SameTreeQuartetEvent T₁ T₂ draw := by
    simpa [fourDrawEventSet] using hsame
  have hdiff' : DifferentTreeQuartetEvent T₁ T₂ draw := by
    simpa [fourDrawEventSet] using hdiff
  rcases hsame' with ⟨R, hindR, hT₁R, hT₂R⟩
  exact (not_differentTreeQuartetEvent_of_sameWitness
    T₁ T₂ hindR hT₁R hT₂R) hdiff'

/-- The union of the common and conflicting event sets is contained in the
first tree's self-comparison event set. -/
theorem same_union_different_eventSet_subset_self_left
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    fourDrawEventSet (SameTreeQuartetEvent T₁ T₂) ∪
        fourDrawEventSet (DifferentTreeQuartetEvent T₁ T₂) ⊆
      fourDrawEventSet (SameTreeQuartetEvent T₁ T₁) := by
  classical
  intro draw hdraw
  rcases Finset.mem_union.mp hdraw with hsame | hdiff
  · have hsame' : SameTreeQuartetEvent T₁ T₂ draw := by
      simpa [fourDrawEventSet] using hsame
    simpa [fourDrawEventSet] using hsame'.self_left
  · have hdiff' : DifferentTreeQuartetEvent T₁ T₂ draw := by
      simpa [fourDrawEventSet] using hdiff
    simpa [fourDrawEventSet] using hdiff'.self_left

/-- The analogous containment in the second tree's self-comparison event. -/
theorem same_union_different_eventSet_subset_self_right
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    fourDrawEventSet (SameTreeQuartetEvent T₁ T₂) ∪
        fourDrawEventSet (DifferentTreeQuartetEvent T₁ T₂) ⊆
      fourDrawEventSet (SameTreeQuartetEvent T₂ T₂) := by
  classical
  intro draw hdraw
  rcases Finset.mem_union.mp hdraw with hsame | hdiff
  · have hsame' : SameTreeQuartetEvent T₁ T₂ draw := by
      simpa [fourDrawEventSet] using hsame
    simpa [fourDrawEventSet] using hsame'.self_right
  · have hdiff' : DifferentTreeQuartetEvent T₁ T₂ draw := by
      simpa [fourDrawEventSet] using hdiff
    simpa [fourDrawEventSet] using hdiff'.self_right

/-- Exact finite cardinal inequality behind the first self-covariance bound. -/
theorem card_same_add_different_le_self_left
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    (fourDrawEventSet (SameTreeQuartetEvent T₁ T₂)).card +
        (fourDrawEventSet (DifferentTreeQuartetEvent T₁ T₂)).card ≤
      (fourDrawEventSet (SameTreeQuartetEvent T₁ T₁)).card := by
  classical
  rw [← Finset.card_union_of_disjoint
    (sameTreeQuartetEventSet_disjoint_differentTreeQuartetEventSet T₁ T₂)]
  exact Finset.card_le_card
    (same_union_different_eventSet_subset_self_left T₁ T₂)

/-- Exact finite cardinal inequality behind the second self-covariance bound. -/
theorem card_same_add_different_le_self_right
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    (fourDrawEventSet (SameTreeQuartetEvent T₁ T₂)).card +
        (fourDrawEventSet (DifferentTreeQuartetEvent T₁ T₂)).card ≤
      (fourDrawEventSet (SameTreeQuartetEvent T₂ T₂)).card := by
  classical
  rw [← Finset.card_union_of_disjoint
    (sameTreeQuartetEventSet_disjoint_differentTreeQuartetEventSet T₁ T₂)]
  exact Finset.card_le_card
    (same_union_different_eventSet_subset_self_right T₁ T₂)

/-- The conflicting-quartet probability of a self-comparison is zero. -/
theorem differentTreeQuartetProbability_self_eq_zero
    (T : XTree X V₁) :
    fourDrawProbability (DifferentTreeQuartetEvent T T) = 0 := by
  rw [fourDrawProbability_eq]
  have hempty : fourDrawEventSet (DifferentTreeQuartetEvent T T) = ∅ := by
    classical
    ext draw
    simp [fourDrawEventSet, not_differentTreeQuartetEvent_self T draw]
  rw [hempty]
  simp

/-- Self quartet covariance is exactly the probability of drawing a partial
quartet displayed by that tree. -/
theorem treeQuartetCovariance_self_eq_sameProbability
    (T : XTree X V₁) :
    treeQuartetCovariance T T =
      fourDrawProbability (SameTreeQuartetEvent T T) := by
  simp [treeQuartetCovariance,
    differentTreeQuartetProbability_self_eq_zero T]

/-- Probability form of the first event-set containment. -/
theorem same_add_different_probability_le_self_left
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    fourDrawProbability (SameTreeQuartetEvent T₁ T₂) +
        fourDrawProbability (DifferentTreeQuartetEvent T₁ T₂) ≤
      fourDrawProbability (SameTreeQuartetEvent T₁ T₁) := by
  rw [fourDrawProbability_eq, fourDrawProbability_eq,
    fourDrawProbability_eq]
  have hcard := card_same_add_different_le_self_left T₁ T₂
  have hcardReal :
      ((fourDrawEventSet (SameTreeQuartetEvent T₁ T₂)).card : ℝ) +
          ((fourDrawEventSet
            (DifferentTreeQuartetEvent T₁ T₂)).card : ℝ) ≤
        ((fourDrawEventSet (SameTreeQuartetEvent T₁ T₁)).card : ℝ) := by
    exact_mod_cast hcard
  calc
    ((fourDrawEventSet (SameTreeQuartetEvent T₁ T₂)).card : ℝ) /
          (Fintype.card X : ℝ) ^ 4 +
        ((fourDrawEventSet
          (DifferentTreeQuartetEvent T₁ T₂)).card : ℝ) /
          (Fintype.card X : ℝ) ^ 4 =
      (((fourDrawEventSet
          (SameTreeQuartetEvent T₁ T₂)).card : ℝ) +
        ((fourDrawEventSet
          (DifferentTreeQuartetEvent T₁ T₂)).card : ℝ)) /
          (Fintype.card X : ℝ) ^ 4 := by ring
    _ ≤ ((fourDrawEventSet
          (SameTreeQuartetEvent T₁ T₁)).card : ℝ) /
          (Fintype.card X : ℝ) ^ 4 :=
      div_le_div_of_nonneg_right hcardReal (by positivity)

/-- Probability form of the second event-set containment. -/
theorem same_add_different_probability_le_self_right
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    fourDrawProbability (SameTreeQuartetEvent T₁ T₂) +
        fourDrawProbability (DifferentTreeQuartetEvent T₁ T₂) ≤
      fourDrawProbability (SameTreeQuartetEvent T₂ T₂) := by
  rw [fourDrawProbability_eq, fourDrawProbability_eq,
    fourDrawProbability_eq]
  have hcard := card_same_add_different_le_self_right T₁ T₂
  have hcardReal :
      ((fourDrawEventSet (SameTreeQuartetEvent T₁ T₂)).card : ℝ) +
          ((fourDrawEventSet
            (DifferentTreeQuartetEvent T₁ T₂)).card : ℝ) ≤
        ((fourDrawEventSet (SameTreeQuartetEvent T₂ T₂)).card : ℝ) := by
    exact_mod_cast hcard
  calc
    ((fourDrawEventSet (SameTreeQuartetEvent T₁ T₂)).card : ℝ) /
          (Fintype.card X : ℝ) ^ 4 +
        ((fourDrawEventSet
          (DifferentTreeQuartetEvent T₁ T₂)).card : ℝ) /
          (Fintype.card X : ℝ) ^ 4 =
      (((fourDrawEventSet
          (SameTreeQuartetEvent T₁ T₂)).card : ℝ) +
        ((fourDrawEventSet
          (DifferentTreeQuartetEvent T₁ T₂)).card : ℝ)) /
          (Fintype.card X : ℝ) ^ 4 := by ring
    _ ≤ ((fourDrawEventSet
          (SameTreeQuartetEvent T₂ T₂)).card : ℝ) /
          (Fintype.card X : ℝ) ^ 4 :=
      div_le_div_of_nonneg_right hcardReal (by positivity)

/-- The permanent denominator is bounded by the first self covariance. -/
theorem quartetCompatibilityDenominator_le_self_left
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    quartetCompatibilityDenominator T₁ T₂ ≤
      treeQuartetCovariance T₁ T₁ := by
  have hsum := same_add_different_probability_le_self_left T₁ T₂
  have hdiff := fourDrawProbability_nonneg
    (DifferentTreeQuartetEvent T₁ T₂)
  rw [treeQuartetCovariance_self_eq_sameProbability]
  unfold quartetCompatibilityDenominator
  linarith

/-- The permanent denominator is bounded by the second self covariance. -/
theorem quartetCompatibilityDenominator_le_self_right
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    quartetCompatibilityDenominator T₁ T₂ ≤
      treeQuartetCovariance T₂ T₂ := by
  have hsum := same_add_different_probability_le_self_right T₁ T₂
  have hdiff := fourDrawProbability_nonneg
    (DifferentTreeQuartetEvent T₁ T₂)
  rw [treeQuartetCovariance_self_eq_sameProbability]
  unfold quartetCompatibilityDenominator
  linarith

/-- Every self quartet covariance is nonnegative, directly from its event
interpretation. -/
theorem treeQuartetCovariance_self_nonneg (T : XTree X V₁) :
    0 ≤ treeQuartetCovariance T T := by
  rw [treeQuartetCovariance_self_eq_sameProbability]
  exact fourDrawProbability_nonneg _

/-- The compatibility denominator is at most the geometric mean of the two
self covariances.  This is the square-root step suppressed in the paper. -/
theorem quartetCompatibilityDenominator_le_sqrt_self_product
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    quartetCompatibilityDenominator T₁ T₂ ≤
      Real.sqrt
        (treeQuartetCovariance T₁ T₁ *
          treeQuartetCovariance T₂ T₂) := by
  have hD : 0 ≤ quartetCompatibilityDenominator T₁ T₂ :=
    quartetCompatibilityDenominator_nonneg T₁ T₂
  have hQ₁ : 0 ≤ treeQuartetCovariance T₁ T₁ :=
    treeQuartetCovariance_self_nonneg T₁
  have hQ₂ : 0 ≤ treeQuartetCovariance T₂ T₂ :=
    treeQuartetCovariance_self_nonneg T₂
  have hleft := quartetCompatibilityDenominator_le_self_left T₁ T₂
  have hright := quartetCompatibilityDenominator_le_self_right T₁ T₂
  have hsquare :
      (quartetCompatibilityDenominator T₁ T₂) ^ 2 ≤
        treeQuartetCovariance T₁ T₁ *
          treeQuartetCovariance T₂ T₂ := by
    simpa [pow_two] using mul_le_mul hleft hright hD hQ₁
  exact (Real.le_sqrt hD (mul_nonneg hQ₁ hQ₂)).2 hsquare

/-- Quartet correlation is nonnegative. -/
theorem quartetCorrelation_nonneg
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    0 ≤ quartetCorrelation T₁ T₂ := by
  unfold quartetCorrelation
  exact div_nonneg
    (treeQuartetCovariance_nonneg T₁ T₂)
    (Real.sqrt_nonneg _)

/-- Proposition 2's comparison `rho_Q ≤ c_Q`. -/
theorem quartetCorrelation_le_compatibilityIndex
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    quartetCorrelation T₁ T₂ ≤
      quartetCompatibilityIndex T₁ T₂ := by
  let Q := treeQuartetCovariance T₁ T₂
  let D := quartetCompatibilityDenominator T₁ T₂
  let S := Real.sqrt
    (treeQuartetCovariance T₁ T₁ *
      treeQuartetCovariance T₂ T₂)
  have hQ : 0 ≤ Q := treeQuartetCovariance_nonneg T₁ T₂
  have hQD : Q ≤ D :=
    treeQuartetCovariance_le_compatibilityDenominator T₁ T₂
  have hDS : D ≤ S :=
    quartetCompatibilityDenominator_le_sqrt_self_product T₁ T₂
  by_cases hQzero : Q = 0
  · simp [quartetCorrelation, quartetCompatibilityIndex, Q, hQzero]
  · have hQpos : 0 < Q := lt_of_le_of_ne hQ (Ne.symm hQzero)
    have hDpos : 0 < D := lt_of_lt_of_le hQpos hQD
    have hSpos : 0 < S := lt_of_lt_of_le hDpos hDS
    change Q / S ≤ Q / D
    exact (div_le_div_iff₀ hSpos hDpos).2
      (mul_le_mul_of_nonneg_left hDS hQ)

/-- The quartet correlation vanishes exactly when the covariance numerator
vanishes, including all zero-denominator boundary cases. -/
theorem quartetCorrelation_eq_zero_iff_covariance_eq_zero
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    quartetCorrelation T₁ T₂ = 0 ↔
      treeQuartetCovariance T₁ T₂ = 0 := by
  constructor
  · intro hrho
    rcases (div_eq_zero_iff.mp hrho) with hQzero | hsqrtZero
    · exact hQzero
    · have hQ₁ : 0 ≤ treeQuartetCovariance T₁ T₁ :=
        treeQuartetCovariance_self_nonneg T₁
      have hQ₂ : 0 ≤ treeQuartetCovariance T₂ T₂ :=
        treeQuartetCovariance_self_nonneg T₂
      have hprod :
          treeQuartetCovariance T₁ T₁ *
              treeQuartetCovariance T₂ T₂ = 0 :=
        (Real.sqrt_eq_zero (mul_nonneg hQ₁ hQ₂)).1 hsqrtZero
      have hQ : 0 ≤ treeQuartetCovariance T₁ T₂ :=
        treeQuartetCovariance_nonneg T₁ T₂
      have hQD := treeQuartetCovariance_le_compatibilityDenominator T₁ T₂
      rcases mul_eq_zero.mp hprod with hself | hself
      · have hDle := quartetCompatibilityDenominator_le_self_left T₁ T₂
        linarith
      · have hDle := quartetCompatibilityDenominator_le_self_right T₁ T₂
        linarith
  · intro hQzero
    simp [quartetCorrelation, hQzero]

/-- Proposition 2's exact zero characterization. -/
theorem quartetCorrelation_eq_zero_iff_treesIndependent
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    quartetCorrelation T₁ T₂ = 0 ↔
      TreesIndependent T₁ T₂ := by
  rw [quartetCorrelation_eq_zero_iff_covariance_eq_zero,
    treeQuartetCovariance_eq_zero_iff_treesIndependent]

/-- The two numerical inequalities in Proposition 2. -/
theorem quartetCorrelation_bounds
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    0 ≤ quartetCorrelation T₁ T₂ ∧
      quartetCorrelation T₁ T₂ ≤
        quartetCompatibilityIndex T₁ T₂ :=
  ⟨quartetCorrelation_nonneg T₁ T₂,
    quartetCorrelation_le_compatibilityIndex T₁ T₂⟩

/-! ## Self-comparison equality and the degenerate boundary regression -/

/-- For a self-comparison, the compatibility denominator is exactly the self
quartet covariance. -/
theorem quartetCompatibilityDenominator_self_eq_covariance
    (T : XTree X V₁) :
    quartetCompatibilityDenominator T T = treeQuartetCovariance T T := by
  rw [treeQuartetCovariance_self_eq_sameProbability]
  simp [quartetCompatibilityDenominator,
    differentTreeQuartetProbability_self_eq_zero T]

/-- A tree with nonzero self covariance has self compatibility index one. -/
theorem quartetCompatibilityIndex_self_eq_one_of_covariance_ne_zero
    (T : XTree X V₁) (hQ : treeQuartetCovariance T T ≠ 0) :
    quartetCompatibilityIndex T T = 1 := by
  rw [quartetCompatibilityIndex,
    quartetCompatibilityDenominator_self_eq_covariance]
  exact div_self hQ

/-- A tree with nonzero self covariance has self quartet correlation one. -/
theorem quartetCorrelation_self_eq_one_of_covariance_ne_zero
    (T : XTree X V₁) (hQ : treeQuartetCovariance T T ≠ 0) :
    quartetCorrelation T T = 1 := by
  have hnonneg : 0 ≤ treeQuartetCovariance T T :=
    treeQuartetCovariance_self_nonneg T
  rw [quartetCorrelation]
  have hsqrt :
      Real.sqrt
          (treeQuartetCovariance T T * treeQuartetCovariance T T) =
        treeQuartetCovariance T T := by
    rw [← pow_two, Real.sqrt_sq_eq_abs, abs_of_nonneg hnonneg]
  rw [hsqrt]
  exact div_self hQ

/-- Exact positive self-comparison form of Proposition 2. -/
theorem quartetCorrelation_self_eq_compatibilityIndex_of_covariance_pos
    (T : XTree X V₁) (hQ : 0 < treeQuartetCovariance T T) :
    0 < quartetCorrelation T T ∧
      quartetCorrelation T T = quartetCompatibilityIndex T T := by
  have hQne : treeQuartetCovariance T T ≠ 0 := ne_of_gt hQ
  rw [quartetCorrelation_self_eq_one_of_covariance_ne_zero T hQne,
    quartetCompatibilityIndex_self_eq_one_of_covariance_ne_zero T hQne]
  norm_num

/-- The one-taxon self correlation is zero. -/
theorem oneTaxonTree_correlation_eq_zero :
    quartetCorrelation oneTaxonTree oneTaxonTree = 0 := by
  exact (quartetCorrelation_eq_zero_iff_treesIndependent
    oneTaxonTree oneTaxonTree).2 oneTaxonTree_treesIndependent

/-- Regression test confirming the positivity condition in Proposition 2: a
one-taxon self-pair has both normalized indices equal to zero. -/
theorem printed_identical_imp_positive_equal_indices_fails :
    ∃ T : XTree Unit Unit,
      ¬ (0 < quartetCorrelation T T ∧
        quartetCorrelation T T = quartetCompatibilityIndex T T) := by
  refine ⟨oneTaxonTree, ?_⟩
  rw [oneTaxonTree_correlation_eq_zero,
    oneTaxonTree_compatibilityIndex_eq_zero]
  norm_num

end QDFull
