import QDFull.CorollaryOne

/-!
# The one-taxon boundary of Corollary 1

An earlier draft of the upper-equality characterization omitted a cardinality
hypothesis.  For one taxon the numerical upper bound is zero and is attained,
but no `XTree` on the one-vertex graph is phylogenetic under the paper's
definition of a leaf as a degree-one vertex.  The current locked manuscript
therefore states the equality characterization only for `|X| >= 4`; this file
retains the exact boundary regression test.
-/

namespace QDFull

/-- The unique one-vertex, one-taxon `XTree`. -/
def oneTaxonTree : XTree Unit Unit where
  graph := ⊥
  isTree := SimpleGraph.IsTree.of_subsingleton
  label := id
  lowDegree_labelled := by
    intro v _hv
    exact ⟨(), Subsingleton.elim () v⟩

/-- The one-taxon tree attains the numerical upper bound. -/
theorem oneTaxonTree_attains_universal_upper_bound :
    treeQuartetCovariance oneTaxonTree oneTaxonTree =
      1 - (4 * (Fintype.card Unit : ℝ) - 3) /
        (Fintype.card Unit : ℝ) ^ 3 := by
  have hnonneg : 0 ≤ treeQuartetCovariance oneTaxonTree oneTaxonTree :=
    treeQuartetCovariance_nonneg oneTaxonTree oneTaxonTree
  have hupper :=
    treeQuartetCovariance_le_universal_bound oneTaxonTree oneTaxonTree
  norm_num at hupper ⊢
  exact le_antisymm hupper hnonneg

/-- Nevertheless the one-taxon tree is not phylogenetic, hence not binary
phylogenetic. -/
theorem oneTaxonTree_not_binaryPhylogenetic :
    ¬ oneTaxonTree.IsBinaryPhylogenetic := by
  intro hbin
  have hleaf := hbin.1.2.1 ()
  change Nat.card ((⊥ : SimpleGraph Unit).neighborSet ()) = 1 at hleaf
  simpa using hleaf

/-- Regression test refuting the superseded unqualified implication "upper
equality implies binary phylogenetic". -/
theorem printed_upper_equality_imp_binary_fails :
    ∃ T : XTree Unit Unit,
      treeQuartetCovariance T T =
          1 - (4 * (Fintype.card Unit : ℝ) - 3) /
            (Fintype.card Unit : ℝ) ^ 3 ∧
        ¬ T.IsBinaryPhylogenetic := by
  exact ⟨oneTaxonTree, oneTaxonTree_attains_universal_upper_bound,
    oneTaxonTree_not_binaryPhylogenetic⟩

end QDFull
