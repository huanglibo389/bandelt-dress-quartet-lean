import QDFull.LocalMasses

/-!
# The row and column branch partitions

The paper repeatedly invokes the row and column partitions without spelling
out their graph-theoretic proof.  Here a unique simple path from the centre to
each labelled vertex selects either the centre block or the first outgoing
edge.  The resulting branch blocks cover every taxon exactly once.
-/

open scoped BigOperators
open SimpleGraph

namespace QDFull

universe uX uV

namespace XTree

variable {X : Type uX} {V : Type uV} [Fintype X] [Fintype V]

/-- A vertex different from `centre` lies in the branch selected by the first
edge of the unique path from `centre` to that vertex. -/
theorem exists_outgoing_branch (T : XTree X V) {centre y : V}
    (hy : y ≠ centre) :
    ∃ z : V, T.graph.Adj centre z ∧ y ∈ T.vertexSide centre z := by
  classical
  obtain ⟨p, hp⟩ := (T.isTree.connected centre y).exists_isPath
  have hnil : ¬p.Nil := Walk.not_nil_of_ne hy.symm
  let z : V := p.snd
  have hadj : T.graph.Adj centre z := p.adj_snd hnil
  have hcentre_not_tail : centre ∉ p.tail.support := by
    have hnodup : p.support.Nodup := hp.support_nodup
    rw [← p.cons_tail_support, List.nodup_cons] at hnodup
    rw [p.support_tail_of_not_nil hnil]
    exact hnodup.1
  have hedge_not_tail : s(centre, z) ∉ p.tail.edges := by
    intro hedge
    exact hcentre_not_tail (p.tail.fst_mem_support_of_mem_edges hedge)
  refine ⟨z, hadj, ?_⟩
  change (T.graph.deleteEdges {s(centre, z)}).Reachable z y
  exact (p.tail.toDeleteEdge s(centre, z) hedge_not_tail).reachable

/-- Every taxon belongs to one of the centre's extended-neighbourhood branch
blocks. -/
theorem exists_mem_branchBlock (T : XTree X V) (centre : V) (x : X) :
    ∃ z : V, z ∈ T.neighborsPlus centre ∧ x ∈ T.branchBlock centre z := by
  classical
  by_cases hx : T.label x = centre
  · refine ⟨centre, by simp, ?_⟩
    simp [branchBlock_self, mem_labelFiber, hx]
  · obtain ⟨z, hcz, hy⟩ := T.exists_outgoing_branch hx
    refine ⟨z, by simp [hcz], ?_⟩
    rw [T.branchBlock_of_adj hcz]
    exact (T.mem_edgeSide centre z x).mpr hy

/-- Labels at the centre lie on the reverse side of every incident edge. -/
theorem labelFiber_subset_reverse_edgeSide (T : XTree X V)
    {centre z : V} (hcz : T.graph.Adj centre z) :
    T.labelFiber centre ⊆ T.edgeSide z centre := by
  intro x hx
  rw [T.mem_labelFiber] at hx
  rw [T.mem_edgeSide]
  simpa [hx] using
    (SimpleGraph.Reachable.refl :
      (T.graph.deleteEdges {s(z, centre)}).Reachable centre centre)

/-- The centre-label block is disjoint from every genuine outgoing branch. -/
theorem labelFiber_disjoint_branch (T : XTree X V)
    {centre z : V} (hcz : T.graph.Adj centre z) :
    Disjoint (T.labelFiber centre) (T.edgeSide centre z) := by
  classical
  rw [Finset.disjoint_left]
  intro x hxc hxz
  have hxrev : x ∈ T.edgeSide z centre :=
    T.labelFiber_subset_reverse_edgeSide hcz hxc
  exact (Finset.disjoint_left.mp
    (T.edgeSide_disjoint_reverse_of_adj hcz)) hxz hxrev

/-- Distinct members of `N_+(centre)` index disjoint branch blocks. -/
theorem branchBlock_disjoint (T : XTree X V) {centre z₁ z₂ : V}
    (hz₁ : z₁ ∈ T.neighborsPlus centre)
    (hz₂ : z₂ ∈ T.neighborsPlus centre) (hne : z₁ ≠ z₂) :
    Disjoint (T.branchBlock centre z₁) (T.branchBlock centre z₂) := by
  classical
  rw [T.mem_neighborsPlus] at hz₁ hz₂
  rcases hz₁ with rfl | hz₁
  · rcases hz₂ with rfl | hz₂
    · exact (hne rfl).elim
    · rw [T.branchBlock_self, T.branchBlock_of_adj hz₂]
      exact T.labelFiber_disjoint_branch hz₂
  · rcases hz₂ with rfl | hz₂
    · rw [T.branchBlock_self, T.branchBlock_of_adj hz₁]
      exact (T.labelFiber_disjoint_branch hz₁).symm
    · rw [T.branchBlock_of_adj hz₁, T.branchBlock_of_adj hz₂]
      exact T.edgeSide_disjoint_sidePair hz₁.symm hz₂ hne

/-- Finite index set representing `N_+(centre)`. -/
noncomputable def branchIndices (T : XTree X V) (centre : V) : Finset V := by
  classical
  exact Finset.univ.filter fun z => z ∈ T.neighborsPlus centre

@[simp] theorem mem_branchIndices (T : XTree X V) (centre z : V) :
    z ∈ T.branchIndices centre ↔ z ∈ T.neighborsPlus centre := by
  classical
  simp [branchIndices]

/-- The branch blocks around a centre cover all taxa. -/
theorem biUnion_branchBlock_eq_univ [DecidableEq X]
    (T : XTree X V) (centre : V) :
    (T.branchIndices centre).biUnion (T.branchBlock centre) = Finset.univ := by
  classical
  ext x
  simp only [Finset.mem_biUnion, Finset.mem_univ, iff_true]
  obtain ⟨z, hz, hx⟩ := T.exists_mem_branchBlock centre x
  exact ⟨z, (T.mem_branchIndices centre z).mpr hz, hx⟩

/-- Pairwise-disjoint form required by `Finset.card_biUnion`. -/
theorem branchIndices_pairwiseDisjoint (T : XTree X V) (centre : V) :
    ((T.branchIndices centre : Finset V) : Set V).PairwiseDisjoint
      (T.branchBlock centre) := by
  intro z₁ hz₁ z₂ hz₂ hne
  exact T.branchBlock_disjoint
    ((T.mem_branchIndices centre z₁).mp hz₁)
    ((T.mem_branchIndices centre z₂).mp hz₂) hne

/-- The normalized masses of all centre branches sum to one. -/
theorem sum_normalizedCard_branchBlock (T : XTree X V) (centre : V) :
    ∑ z ∈ T.branchIndices centre, normalizedCard (T.branchBlock centre z) = 1 := by
  classical
  letI : Nonempty X := T.taxon_nonempty
  have hcard :
      ∑ z ∈ T.branchIndices centre, (T.branchBlock centre z).card =
        Fintype.card X := by
    calc
      ∑ z ∈ T.branchIndices centre, (T.branchBlock centre z).card =
          ((T.branchIndices centre).biUnion (T.branchBlock centre)).card :=
        (Finset.card_biUnion (T.branchIndices_pairwiseDisjoint centre)).symm
      _ = (Finset.univ : Finset X).card := by
        rw [T.biUnion_branchBlock_eq_univ]
      _ = Fintype.card X := Finset.card_univ
  unfold normalizedCard
  rw [← Finset.sum_div]
  norm_cast at hcard ⊢
  rw [hcard]
  exact div_self (by positivity)

end XTree

end QDFull
