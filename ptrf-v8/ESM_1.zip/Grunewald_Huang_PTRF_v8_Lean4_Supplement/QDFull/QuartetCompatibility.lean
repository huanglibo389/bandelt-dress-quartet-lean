import QDFull.CorollaryOneCounterexample

/-!
# Quartet compatibility normalization

This file formalizes the corresponding part of the manuscript.  The
compatibility denominator is defined first from the two four-draw events, so
its probabilistic meaning is not replaced by the later counting formula.
-/

namespace QDFull

universe uX uV₁ uV₂

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]

namespace XTree

/-- An `X`-tree is non-trivial when its underlying graph has an edge. -/
def IsNontrivial (T : XTree X V₁) : Prop :=
  ∃ u v : V₁, T.graph.Adj u v

end XTree

/-- Every four-draw event has nonnegative probability. -/
theorem fourDrawProbability_nonneg (E : (Fin 4 → X) → Prop) :
    0 ≤ fourDrawProbability E := by
  unfold fourDrawProbability
  exact normalizedCard_nonneg _

/-- The denominator in the paper's quartet compatibility index: the common
partial-quartet probability plus one half of the conflicting-quartet
probability. -/
noncomputable def quartetCompatibilityDenominator
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  fourDrawProbability (SameTreeQuartetEvent T₁ T₂) +
    (1 / 2 : ℝ) * fourDrawProbability (DifferentTreeQuartetEvent T₁ T₂)

/-- The quartet compatibility index `c_Q(T₁,T₂)` from the manuscript. -/
noncomputable def quartetCompatibilityIndex
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  treeQuartetCovariance T₁ T₂ /
    quartetCompatibilityDenominator T₁ T₂

/-- The compatibility denominator is nonnegative, directly from its event
definition. -/
theorem quartetCompatibilityDenominator_nonneg
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    0 ≤ quartetCompatibilityDenominator T₁ T₂ := by
  unfold quartetCompatibilityDenominator
  exact add_nonneg
    (fourDrawProbability_nonneg _)
    (mul_nonneg (by norm_num) (fourDrawProbability_nonneg _))

/-- The covariance numerator never exceeds the compatibility denominator.
This is the exact algebraic difference between changing the sign of the
conflicting event from minus to plus. -/
theorem treeQuartetCovariance_le_compatibilityDenominator
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    treeQuartetCovariance T₁ T₂ ≤
      quartetCompatibilityDenominator T₁ T₂ := by
  unfold treeQuartetCovariance quartetCompatibilityDenominator
  have h := fourDrawProbability_nonneg
    (DifferentTreeQuartetEvent T₁ T₂)
  linarith

/-- Exact `6/12/24` count formula for the compatibility denominator. -/
theorem quartetCompatibilityDenominator_eq_quartetCounts
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    quartetCompatibilityDenominator T₁ T₂ =
      (1 / (Fintype.card X : ℝ) ^ 4) *
        (24 * ((commonDisplayedPartialQuartets T₁ T₂ 4).card : ℝ) +
         12 * ((commonDisplayedPartialQuartets T₁ T₂ 3).card : ℝ) +
          6 * ((commonDisplayedPartialQuartets T₁ T₂ 2).card : ℝ) +
         12 * (quartetDistance T₁ T₂ : ℝ)) := by
  classical
  rw [quartetCompatibilityDenominator, fourDrawProbability_eq,
    fourDrawProbability_eq, card_sameTreeQuartetEvent,
    card_differentTreeQuartetEvent]
  push_cast
  ring

/-- Two actual edges, one in each tree, separate a common pair of taxa.
Equivalently, the two trees display a common support-two partial quartet. -/
theorem commonDisplayedPartialQuartets_two_nonempty_of_adj
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w) :
    (commonDisplayedPartialQuartets T₁ T₂ 2).Nonempty := by
  classical
  have hcover₁ (z : X) :
      z ∈ T₁.edgeSide t u ∨ z ∈ T₁.edgeSide u t := by
    have hz : z ∈ (T₁.edgeSide t u : Set X) ∪
        (T₁.edgeSide u t : Set X) := by
      rw [T₁.edgeSide_set_union_reverse_of_adj htu]
      exact Set.mem_univ z
    simpa only [Set.mem_union, Finset.mem_coe] using hz
  have hcover₂ (z : X) :
      z ∈ T₂.edgeSide v w ∨ z ∈ T₂.edgeSide w v := by
    have hz : z ∈ (T₂.edgeSide v w : Set X) ∪
        (T₂.edgeSide w v : Set X) := by
      rw [T₂.edgeSide_set_union_reverse_of_adj hvw]
      exact Set.mem_univ z
    simpa only [Set.mem_union, Finset.mem_coe] using hz
  obtain ⟨a, ha⟩ := T₁.edgeSide_nonempty_of_adj htu
  obtain ⟨b, hb⟩ := T₁.edgeSide_nonempty_of_adj htu.symm
  have hsep : ∃ x y : X,
      x ∈ T₁.edgeSide t u ∧ y ∈ T₁.edgeSide u t ∧
        ((x ∈ T₂.edgeSide v w ∧ y ∈ T₂.edgeSide w v) ∨
         (x ∈ T₂.edgeSide w v ∧ y ∈ T₂.edgeSide v w)) := by
    rcases hcover₂ a with haC | haD
    · rcases hcover₂ b with hbC | hbD
      · obtain ⟨c, hcD⟩ := T₂.edgeSide_nonempty_of_adj hvw.symm
        rcases hcover₁ c with hcA | hcB
        · exact ⟨c, b, hcA, hb, Or.inr ⟨hcD, hbC⟩⟩
        · exact ⟨a, c, ha, hcB, Or.inl ⟨haC, hcD⟩⟩
      · exact ⟨a, b, ha, hb, Or.inl ⟨haC, hbD⟩⟩
    · rcases hcover₂ b with hbC | hbD
      · exact ⟨a, b, ha, hb, Or.inr ⟨haD, hbC⟩⟩
      · obtain ⟨c, hcC⟩ := T₂.edgeSide_nonempty_of_adj hvw
        rcases hcover₁ c with hcA | hcB
        · exact ⟨c, b, hcA, hb, Or.inl ⟨hcC, hbD⟩⟩
        · exact ⟨a, c, ha, hcB, Or.inr ⟨haD, hcC⟩⟩
  obtain ⟨x, y, hxA, hyB, hxy₂⟩ := hsep
  have hxy : x ≠ y := by
    intro h
    subst y
    exact (Finset.disjoint_left.mp
      (T₁.edgeSide_disjoint_reverse_of_adj htu)) hxA hyB
  let P : PartialSplit X := s(({x} : Finset X), ({y} : Finset X))
  have hpartial : IsPartialSplit P := by
    refine ⟨{x}, {y}, rfl, by simp, by simp, ?_⟩
    simp [hxy]
  have hquartet : IsPartialQuartet P := by
    exact ⟨hpartial, {x}, {y}, rfl, by simp, by simp⟩
  have hdisplay₁ : T₁.DisplaysPartialSplit P := by
    refine ⟨t, u, htu, ?_⟩
    rw [XTree.edgeSplit, displays_comm_representative]
    exact Or.inl ⟨by simpa [P] using hxA, by simpa [P] using hyB⟩
  have hdisplay₂ : T₂.DisplaysPartialSplit P := by
    refine ⟨v, w, hvw, ?_⟩
    rw [XTree.edgeSplit, displays_comm_representative]
    rcases hxy₂ with h | h
    · exact Or.inl ⟨by simpa [P] using h.1, by simpa [P] using h.2⟩
    · exact Or.inr ⟨by simpa [P] using h.1, by simpa [P] using h.2⟩
  refine ⟨P, (mem_commonDisplayedPartialQuartets T₁ T₂ 2 P).2 ?_⟩
  exact ⟨hquartet, hdisplay₁, hdisplay₂, by
    simp [P, partialSplitSupport_mk, hxy]⟩

/-- For two non-trivial `X`-trees, the compatibility denominator is strictly
positive. -/
theorem quartetCompatibilityDenominator_pos_of_nontrivial
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hT₁ : T₁.IsNontrivial) (hT₂ : T₂.IsNontrivial) :
    0 < quartetCompatibilityDenominator T₁ T₂ := by
  rcases hT₁ with ⟨t, u, htu⟩
  rcases hT₂ with ⟨v, w, hvw⟩
  have htwoNat : 0 < (commonDisplayedPartialQuartets T₁ T₂ 2).card :=
    Finset.card_pos.mpr
      (commonDisplayedPartialQuartets_two_nonempty_of_adj T₁ T₂ htu hvw)
  have htwo : 0 < ((commonDisplayedPartialQuartets T₁ T₂ 2).card : ℝ) := by
    exact_mod_cast htwoNat
  letI : Nonempty X := T₁.taxon_nonempty
  rw [quartetCompatibilityDenominator_eq_quartetCounts]
  positivity

/-- For two non-trivial `X`-trees, the compatibility denominator is nonzero. -/
theorem quartetCompatibilityDenominator_ne_zero_of_nontrivial
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hT₁ : T₁.IsNontrivial) (hT₂ : T₂.IsNontrivial) :
    quartetCompatibilityDenominator T₁ T₂ ≠ 0 :=
  ne_of_gt (quartetCompatibilityDenominator_pos_of_nontrivial
    T₁ T₂ hT₁ hT₂)

/-- The count-ratio display for `c_Q` in Section 3.  Cancellation of the
common sampling factor is valid even when the count denominator is zero,
because the factor itself is nonzero for every `XTree`. -/
theorem quartetCompatibilityIndex_eq_quartetCounts
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    quartetCompatibilityIndex T₁ T₂ =
      (24 * ((commonDisplayedPartialQuartets T₁ T₂ 4).card : ℝ) +
          12 * ((commonDisplayedPartialQuartets T₁ T₂ 3).card : ℝ) +
          6 * ((commonDisplayedPartialQuartets T₁ T₂ 2).card : ℝ) -
          12 * (quartetDistance T₁ T₂ : ℝ)) /
        (24 * ((commonDisplayedPartialQuartets T₁ T₂ 4).card : ℝ) +
          12 * ((commonDisplayedPartialQuartets T₁ T₂ 3).card : ℝ) +
          6 * ((commonDisplayedPartialQuartets T₁ T₂ 2).card : ℝ) +
          12 * (quartetDistance T₁ T₂ : ℝ)) := by
  letI : Nonempty X := T₁.taxon_nonempty
  let N : ℝ := Fintype.card X
  have hN : N ≠ 0 := by
    change (Fintype.card X : ℝ) ≠ 0
    exact_mod_cast (Fintype.card_ne_zero : Fintype.card X ≠ 0)
  have hf : (1 / N ^ 4 : ℝ) ≠ 0 := one_div_ne_zero (pow_ne_zero 4 hN)
  unfold quartetCompatibilityIndex
  rw [treeQuartetCovariance_eq_quartetCounts,
    quartetCompatibilityDenominator_eq_quartetCounts]
  exact mul_div_mul_left _ _ hf

/-- Proposition 1's two numerical bounds.  No nonzero-denominator assumption
is hidden: in the zero-denominator case the quotient is definitionally zero. -/
theorem quartetCompatibilityIndex_mem_unitInterval
    [DecidableEq X] [DecidableEq V₁] [DecidableEq V₂]
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    0 ≤ quartetCompatibilityIndex T₁ T₂ ∧
      quartetCompatibilityIndex T₁ T₂ ≤ 1 := by
  have hQ : 0 ≤ treeQuartetCovariance T₁ T₂ :=
    treeQuartetCovariance_nonneg T₁ T₂
  have hD : 0 ≤ quartetCompatibilityDenominator T₁ T₂ :=
    quartetCompatibilityDenominator_nonneg T₁ T₂
  have hQD : treeQuartetCovariance T₁ T₂ ≤
      quartetCompatibilityDenominator T₁ T₂ :=
    treeQuartetCovariance_le_compatibilityDenominator T₁ T₂
  constructor
  · unfold quartetCompatibilityIndex
    exact div_nonneg hQ hD
  · by_cases hzero : quartetCompatibilityDenominator T₁ T₂ = 0
    · simp [quartetCompatibilityIndex, hzero]
    · have hpos : 0 < quartetCompatibilityDenominator T₁ T₂ :=
        lt_of_le_of_ne hD (Ne.symm hzero)
      unfold quartetCompatibilityIndex
      exact (div_le_one hpos).2 hQD

/-- Proposition 1's exact zero characterization. -/
theorem quartetCompatibilityIndex_eq_zero_iff_treesIndependent
    [DecidableEq X] [DecidableEq V₁] [DecidableEq V₂]
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    quartetCompatibilityIndex T₁ T₂ = 0 ↔
      TreesIndependent T₁ T₂ := by
  rw [← treeQuartetCovariance_eq_zero_iff_treesIndependent T₁ T₂]
  constructor
  · intro hindex
    have hQ : 0 ≤ treeQuartetCovariance T₁ T₂ :=
      treeQuartetCovariance_nonneg T₁ T₂
    have hQD : treeQuartetCovariance T₁ T₂ ≤
        quartetCompatibilityDenominator T₁ T₂ :=
      treeQuartetCovariance_le_compatibilityDenominator T₁ T₂
    rcases (div_eq_zero_iff.mp hindex) with hQzero | hDzero
    · exact hQzero
    · exact le_antisymm (hDzero ▸ hQD) hQ
  · intro hQzero
    simp [quartetCompatibilityIndex, hQzero]

/-! ## Compatibility of the union of the two edge-split systems -/

/-- Standard compatibility of two (represented) partial splits: at least one
of the four cross-intersections of their sides is empty.  The explicit
representatives also retain the within-split disjointness needed by the
four-draw event classification. -/
def PartialSplitsCompatible (P Q : PartialSplit X) : Prop :=
  ∃ A B C D : Finset X,
    P = s(A, B) ∧ Q = s(C, D) ∧
      Disjoint A B ∧ Disjoint C D ∧
      (Disjoint A C ∨ Disjoint A D ∨
        Disjoint B C ∨ Disjoint B D)

/-- The set of all full splits supplied by actual edges of a tree. -/
def XTree.edgeSplitSet (T : XTree X V₁) : Set (PartialSplit X) :=
  {P | ∃ u v : V₁, T.graph.Adj u v ∧ P = T.edgeSplit u v}

/-- The exact meaning of “the union of their splits is compatible”: every
split in the union of the two edge-split systems is compatible with every
other split in that union. -/
def TreeSplitUnionCompatible (T₁ : XTree X V₁) (T₂ : XTree X V₂) : Prop :=
  ∀ P, P ∈ T₁.edgeSplitSet ∪ T₂.edgeSplitSet →
    ∀ Q, Q ∈ T₁.edgeSplitSet ∪ T₂.edgeSplitSet →
      PartialSplitsCompatible P Q

/-- Compatible source splits cannot produce two different induced partial
quartets from the same ordered four-draw sample. -/
theorem not_differentSplitQuartetEvent_of_compatible
    {P Q : PartialSplit X} (hcompat : PartialSplitsCompatible P Q)
    (draw : Fin 4 → X) :
    ¬ DifferentSplitQuartetEvent P Q draw := by
  classical
  rcases hcompat with
    ⟨A, B, C, D, rfl, rfl, hAB, hCD, hcross⟩
  intro hevent
  have hmem : draw ∈ fourDrawEventSet
      (DifferentSplitQuartetEvent s(A, B) s(C, D)) := by
    simp [fourDrawEventSet, hevent]
  have hcard := card_differentSplitQuartetEvent A B C D hAB hCD
  have hzero :
      (fourDrawEventSet
        (DifferentSplitQuartetEvent s(A, B) s(C, D))).card = 0 := by
    rw [hcard]
    rcases hcross with hAC | hAD | hBC | hBD
    · simp [Finset.disjoint_iff_inter_eq_empty.mp hAC]
    · simp [Finset.disjoint_iff_inter_eq_empty.mp hAD]
    · simp [Finset.disjoint_iff_inter_eq_empty.mp hBC]
    · simp [Finset.disjoint_iff_inter_eq_empty.mp hBD]
  exact (Finset.card_ne_zero.mpr ⟨draw, hmem⟩) hzero

/-- If the union of the two edge-split systems is compatible, the negative
tree event is impossible for every ordered four-draw sample. -/
theorem not_differentTreeQuartetEvent_of_splitUnionCompatible
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hcompat : TreeSplitUnionCompatible T₁ T₂)
    (draw : Fin 4 → X) :
    ¬ DifferentTreeQuartetEvent T₁ T₂ draw := by
  rintro ⟨R, S, hindR, hindS, hT₁R, hT₂S, hRS⟩
  rcases hT₁R with ⟨t, u, htu, hER⟩
  rcases hT₂S with ⟨v, w, hvw, hFS⟩
  have hEF : PartialSplitsCompatible
      (T₁.edgeSplit t u) (T₂.edgeSplit v w) :=
    hcompat (T₁.edgeSplit t u)
      (Or.inl ⟨t, u, htu, rfl⟩)
      (T₂.edgeSplit v w)
      (Or.inr ⟨v, w, hvw, rfl⟩)
  exact (not_differentSplitQuartetEvent_of_compatible hEF draw)
    ⟨R, S, hindR, hindS, hER, hFS, hRS⟩

/-- Compatibility of the union makes the conflicting-quartet probability
exactly zero. -/
theorem differentTreeQuartetProbability_eq_zero_of_splitUnionCompatible
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hcompat : TreeSplitUnionCompatible T₁ T₂) :
    fourDrawProbability (DifferentTreeQuartetEvent T₁ T₂) = 0 := by
  rw [fourDrawProbability_eq]
  have hempty : fourDrawEventSet (DifferentTreeQuartetEvent T₁ T₂) = ∅ := by
    classical
    ext draw
    simp [fourDrawEventSet,
      not_differentTreeQuartetEvent_of_splitUnionCompatible
        T₁ T₂ hcompat draw]
  rw [hempty]
  simp

/-- General form underlying the final implication in Proposition 1.  Compatibility
forces `c_Q = 1` provided the normalization denominator is nonzero. -/
theorem quartetCompatibilityIndex_eq_one_of_splitUnionCompatible
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hcompat : TreeSplitUnionCompatible T₁ T₂)
    (hden : quartetCompatibilityDenominator T₁ T₂ ≠ 0) :
    quartetCompatibilityIndex T₁ T₂ = 1 := by
  have hdiff :=
    differentTreeQuartetProbability_eq_zero_of_splitUnionCompatible
      T₁ T₂ hcompat
  have hQ : treeQuartetCovariance T₁ T₂ =
      fourDrawProbability (SameTreeQuartetEvent T₁ T₂) := by
    simp [treeQuartetCovariance, hdiff]
  have hD : quartetCompatibilityDenominator T₁ T₂ =
      fourDrawProbability (SameTreeQuartetEvent T₁ T₂) := by
    simp [quartetCompatibilityDenominator, hdiff]
  rw [quartetCompatibilityIndex, hQ, hD]
  rw [hD] at hden
  exact div_self hden

/-! ## Earlier-draft boundary regression for the denominator condition -/

/-- The one-taxon tree has no edge split, so the union of its two split
systems is vacuously compatible. -/
theorem oneTaxonTree_splitUnionCompatible :
    TreeSplitUnionCompatible oneTaxonTree oneTaxonTree := by
  intro P hP
  rcases hP with hP | hP
  all_goals
    rcases hP with ⟨u, v, huv, _⟩
    simpa [oneTaxonTree] using huv

/-- The one-taxon tree is independent of itself because it has no edges. -/
theorem oneTaxonTree_treesIndependent :
    TreesIndependent oneTaxonTree oneTaxonTree := by
  intro t u v w htu _hvw
  simpa [oneTaxonTree] using htu

/-- Despite compatible split union, the one-taxon compatibility index is zero
rather than one. -/
theorem oneTaxonTree_compatibilityIndex_eq_zero :
    quartetCompatibilityIndex oneTaxonTree oneTaxonTree = 0 := by
  exact (quartetCompatibilityIndex_eq_zero_iff_treesIndependent
    oneTaxonTree oneTaxonTree).2 oneTaxonTree_treesIndependent

/-- Regression test for an earlier draft of Proposition 1 that omitted the
nonzero-denominator condition.  The current locked manuscript restricts the
proposition to non-trivial trees. -/
theorem printed_compatible_union_imp_index_one_fails :
    ∃ T : XTree Unit Unit,
      TreeSplitUnionCompatible T T ∧
        quartetCompatibilityIndex T T ≠ 1 := by
  refine ⟨oneTaxonTree, oneTaxonTree_splitUnionCompatible, ?_⟩
  rw [oneTaxonTree_compatibilityIndex_eq_zero]
  norm_num

/-! ## Converse: index one forces split-union compatibility -/

/-- If two legal partial splits never induce different partial quartets on an
ordered four-draw sample, then one of their four cross-intersections is empty,
so the splits are compatible. -/
theorem partialSplitsCompatible_of_no_differentSplitQuartetEvent
    {P Q : PartialSplit X}
    (hP : IsPartialSplit P) (hQ : IsPartialSplit Q)
    (hno : ∀ draw : Fin 4 → X,
      ¬ DifferentSplitQuartetEvent P Q draw) :
    PartialSplitsCompatible P Q := by
  classical
  rcases hP with ⟨A, B, hP, _hA, _hB, hAB⟩
  rcases hQ with ⟨C, D, hQ, _hC, _hD, hCD⟩
  refine ⟨A, B, C, D, hP, hQ, hAB, hCD, ?_⟩
  by_contra hcross
  push_neg at hcross
  rcases hcross with ⟨hAC, hAD, hBC, hBD⟩
  have hACpos : 0 < (A ∩ C).card :=
    Finset.card_pos.mpr
      (Finset.not_disjoint_iff_nonempty_inter.mp hAC)
  have hADpos : 0 < (A ∩ D).card :=
    Finset.card_pos.mpr
      (Finset.not_disjoint_iff_nonempty_inter.mp hAD)
  have hBCpos : 0 < (B ∩ C).card :=
    Finset.card_pos.mpr
      (Finset.not_disjoint_iff_nonempty_inter.mp hBC)
  have hBDpos : 0 < (B ∩ D).card :=
    Finset.card_pos.mpr
      (Finset.not_disjoint_iff_nonempty_inter.mp hBD)
  have hcard :
      0 < (fourDrawEventSet
        (DifferentSplitQuartetEvent s(A, B) s(C, D))).card := by
    rw [card_differentSplitQuartetEvent A B C D hAB hCD]
    positivity
  obtain ⟨draw, hdraw⟩ := Finset.card_pos.mp hcard
  have hevent :
      DifferentSplitQuartetEvent s(A, B) s(C, D) draw := by
    simpa [fourDrawEventSet] using hdraw
  exact hno draw (by simpa [hP, hQ] using hevent)

/-- Two actual edge splits of the same tree are compatible.  The proof uses
uniqueness of the partial quartet induced and displayed by one tree, rather
than importing a separate split-system theorem. -/
theorem edgeSplitsCompatible_same_tree
    (T : XTree X V₁) {t u v w : V₁}
    (htu : T.graph.Adj t u) (hvw : T.graph.Adj v w) :
    PartialSplitsCompatible (T.edgeSplit t u) (T.edgeSplit v w) := by
  classical
  apply partialSplitsCompatible_of_no_differentSplitQuartetEvent
      (T.edgeSplit_isFullSplit htu).1
      (T.edgeSplit_isFullSplit hvw).1
  intro draw
  rintro ⟨R, S, hindR, hindS, hER, hFS, hRS⟩
  have hTR : T.DisplaysPartialSplit R := ⟨t, u, htu, hER⟩
  have hTS : T.DisplaysPartialSplit S := ⟨v, w, hvw, hFS⟩
  exact hRS
    (T.induced_displayed_partialQuartet_unique draw
      hindR hindS hTR hTS)

/-- Compatibility of represented partial splits is symmetric. -/
theorem PartialSplitsCompatible.symm
    {P Q : PartialSplit X} (h : PartialSplitsCompatible P Q) :
    PartialSplitsCompatible Q P := by
  rcases h with
    ⟨A, B, C, D, hP, hQ, hAB, hCD, hAC | hAD | hBC | hBD⟩
  · exact ⟨C, D, A, B, hQ, hP, hCD, hAB,
      Or.inl hAC.symm⟩
  · exact ⟨C, D, A, B, hQ, hP, hCD, hAB,
      Or.inr (Or.inr (Or.inl hAD.symm))⟩
  · exact ⟨C, D, A, B, hQ, hP, hCD, hAB,
      Or.inr (Or.inl hBC.symm)⟩
  · exact ⟨C, D, A, B, hQ, hP, hCD, hAB,
      Or.inr (Or.inr (Or.inr hBD.symm))⟩

/-- Index one forces the conflicting-quartet probability to vanish. -/
theorem differentTreeQuartetProbability_eq_zero_of_compatibilityIndex_eq_one
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hindex : quartetCompatibilityIndex T₁ T₂ = 1) :
    fourDrawProbability (DifferentTreeQuartetEvent T₁ T₂) = 0 := by
  have hDne : quartetCompatibilityDenominator T₁ T₂ ≠ 0 := by
    intro hD
    rw [quartetCompatibilityIndex, hD, div_zero] at hindex
    norm_num at hindex
  have hQD : treeQuartetCovariance T₁ T₂ =
      quartetCompatibilityDenominator T₁ T₂ :=
    (div_eq_one_iff_eq hDne).1 hindex
  unfold treeQuartetCovariance quartetCompatibilityDenominator at hQD
  linarith

/-- Index one excludes the conflicting tree event pointwise. -/
theorem not_differentTreeQuartetEvent_of_compatibilityIndex_eq_one
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hindex : quartetCompatibilityIndex T₁ T₂ = 1)
    (draw : Fin 4 → X) :
    ¬ DifferentTreeQuartetEvent T₁ T₂ draw := by
  intro hevent
  have hzero :=
    differentTreeQuartetProbability_eq_zero_of_compatibilityIndex_eq_one
      T₁ T₂ hindex
  have hmem : draw ∈
      fourDrawEventSet (DifferentTreeQuartetEvent T₁ T₂) := by
    simp [fourDrawEventSet, hevent]
  have hcardPos :
      0 < (fourDrawEventSet
        (DifferentTreeQuartetEvent T₁ T₂)).card :=
    Finset.card_pos.mpr ⟨draw, hmem⟩
  letI : Nonempty X := T₁.taxon_nonempty
  have hprobPos :
      0 < fourDrawProbability
        (DifferentTreeQuartetEvent T₁ T₂) := by
    rw [fourDrawProbability_eq]
    have hcardPosReal :
        0 < ((fourDrawEventSet
          (DifferentTreeQuartetEvent T₁ T₂)).card : ℝ) := by
      exact_mod_cast hcardPos
    exact div_pos hcardPosReal (by positivity)
  linarith

/-- The missing converse in Proposition 1: if the compatibility index is
one, then every pair of edge splits in the union is compatible. -/
theorem splitUnionCompatible_of_quartetCompatibilityIndex_eq_one
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hindex : quartetCompatibilityIndex T₁ T₂ = 1) :
    TreeSplitUnionCompatible T₁ T₂ := by
  intro P hP Q hQ
  rcases hP with hP₁ | hP₂
  · rcases hP₁ with ⟨t, u, htu, rfl⟩
    rcases hQ with hQ₁ | hQ₂
    · rcases hQ₁ with ⟨v, w, hvw, rfl⟩
      exact edgeSplitsCompatible_same_tree T₁ htu hvw
    · rcases hQ₂ with ⟨v, w, hvw, rfl⟩
      apply partialSplitsCompatible_of_no_differentSplitQuartetEvent
          (T₁.edgeSplit_isFullSplit htu).1
          (T₂.edgeSplit_isFullSplit hvw).1
      intro draw hsplit
      rcases hsplit with ⟨R, S, hindR, hindS, hER, hFS, hRS⟩
      exact (not_differentTreeQuartetEvent_of_compatibilityIndex_eq_one
        T₁ T₂ hindex draw)
        ⟨R, S, hindR, hindS,
          ⟨t, u, htu, hER⟩, ⟨v, w, hvw, hFS⟩, hRS⟩
  · rcases hP₂ with ⟨t, u, htu, rfl⟩
    rcases hQ with hQ₁ | hQ₂
    · rcases hQ₁ with ⟨v, w, hvw, rfl⟩
      apply PartialSplitsCompatible.symm
      apply partialSplitsCompatible_of_no_differentSplitQuartetEvent
          (T₁.edgeSplit_isFullSplit hvw).1
          (T₂.edgeSplit_isFullSplit htu).1
      intro draw hsplit
      rcases hsplit with ⟨R, S, hindR, hindS, hER, hFS, hRS⟩
      exact (not_differentTreeQuartetEvent_of_compatibilityIndex_eq_one
        T₁ T₂ hindex draw)
        ⟨R, S, hindR, hindS,
          ⟨v, w, hvw, hER⟩, ⟨t, u, htu, hFS⟩, hRS⟩
    · rcases hQ₂ with ⟨v, w, hvw, rfl⟩
      exact edgeSplitsCompatible_same_tree T₂ htu hvw

/-- Exact general equality characterization underlying Proposition 1.  The split
union is compatible and the normalizing denominator is nonzero exactly when
the compatibility index is one. -/
theorem quartetCompatibilityIndex_eq_one_iff
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    quartetCompatibilityIndex T₁ T₂ = 1 ↔
      TreeSplitUnionCompatible T₁ T₂ ∧
        quartetCompatibilityDenominator T₁ T₂ ≠ 0 := by
  constructor
  · intro hindex
    refine ⟨splitUnionCompatible_of_quartetCompatibilityIndex_eq_one
      T₁ T₂ hindex, ?_⟩
    intro hD
    rw [quartetCompatibilityIndex, hD, div_zero] at hindex
    norm_num at hindex
  · rintro ⟨hcompat, hD⟩
    exact quartetCompatibilityIndex_eq_one_of_splitUnionCompatible
      T₁ T₂ hcompat hD

/-- Proposition 1 in the manuscript's non-trivial-tree domain: the quartet
compatibility index equals one exactly when the union of the two edge-split
systems is compatible. -/
theorem quartetCompatibilityIndex_eq_one_iff_splitUnionCompatible_of_nontrivial
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hT₁ : T₁.IsNontrivial) (hT₂ : T₂.IsNontrivial) :
    quartetCompatibilityIndex T₁ T₂ = 1 ↔
      TreeSplitUnionCompatible T₁ T₂ := by
  constructor
  · intro hindex
    exact (quartetCompatibilityIndex_eq_one_iff T₁ T₂).1 hindex |>.1
  · intro hcompat
    exact (quartetCompatibilityIndex_eq_one_iff T₁ T₂).2
      ⟨hcompat, quartetCompatibilityDenominator_ne_zero_of_nontrivial
        T₁ T₂ hT₁ hT₂⟩

end QDFull
