import QDFull.UpperEqualityReconstruction
import QDFull.QuartetCompatibility
import QDFull.WeightedApplications

/-!
# Reconstruction of a labelled binary tree from its quartet system

This file closes the graph-theoretic reconstruction step in the upper
equality case of Corollary 1.  No appeal is made to an unformalized version of
the Buneman reconstruction theorem.  We first prove directly that the edge
split system of a binary phylogenetic tree is maximal among compatible full
splits.  The proof chooses a mixed oriented edge side of minimum cardinality
and uses the exact three-branch partition at its internal endpoint.
-/

open SimpleGraph

namespace QDFull

universe uX uV uV₁ uV₂

variable {X : Type uX} {V : Type uV} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V] [Fintype V₁] [Fintype V₂]
  [DecidableEq X]

/-! ## Compatibility in fixed representatives -/

/-- The representative-free compatibility predicate reduces to the usual
four cross-intersection test for any fixed disjoint representatives. -/
theorem partialSplitsCompatible_mk_iff
    {A B C D : Finset X} (hAB : Disjoint A B) (hCD : Disjoint C D) :
    PartialSplitsCompatible s(A, B) s(C, D) ↔
      Disjoint A C ∨ Disjoint A D ∨
        Disjoint B C ∨ Disjoint B D := by
  constructor
  · rintro ⟨A', B', C', D', hP, hQ, _hA'B', _hC'D', hcross⟩
    rw [Sym2.eq_iff] at hP hQ
    rcases hP with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ <;>
      rcases hQ with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ <;>
      aesop
  · intro hcross
    exact ⟨A, B, C, D, rfl, rfl, hAB, hCD, hcross⟩

/-- A finite set is monochromatic for the bipartition `A | Aᶜ` when it is
contained in one of the two colors. -/
def IsMonochromatic (A S : Finset X) : Prop :=
  S ⊆ A ∨ S ⊆ Finset.univ \ A

/-- A finite set is mixed for `A | Aᶜ` when it is contained in neither side. -/
def IsMixed (A S : Finset X) : Prop :=
  ¬S ⊆ A ∧ ¬S ⊆ Finset.univ \ A

theorem not_isMixed_iff_isMonochromatic (A S : Finset X) :
    ¬IsMixed A S ↔ IsMonochromatic A S := by
  simp only [IsMixed, IsMonochromatic, not_and_or, Classical.not_not]

theorem isMixed_iff_not_isMonochromatic (A S : Finset X) :
    IsMixed A S ↔ ¬IsMonochromatic A S := by
  rw [← not_isMixed_iff_isMonochromatic]
  tauto

private theorem subset_compl_of_disjoint
    {A S : Finset X} (h : Disjoint A S) : S ⊆ Finset.univ \ A := by
  intro x hxS
  simp only [Finset.mem_sdiff, Finset.mem_univ, true_and]
  exact fun hxA => (Finset.disjoint_left.mp h) hxA hxS

private theorem disjoint_of_subset_compl
    {A S : Finset X} (h : S ⊆ Finset.univ \ A) : Disjoint A S := by
  rw [Finset.disjoint_left]
  intro x hxA hxS
  exact (Finset.mem_sdiff.mp (h hxS)).2 hxA

/-- Compatibility with `A | Aᶜ` says that at least one side of the other
split is monochromatic. -/
theorem compatible_compl_split_imp_one_side_monochromatic
    {A E F : Finset X} (hEF : Disjoint E F)
    (hcompat : PartialSplitsCompatible s(A, Finset.univ \ A) s(E, F)) :
    IsMonochromatic A E ∨ IsMonochromatic A F := by
  have hAAc : Disjoint A (Finset.univ \ A) := by
    rw [Finset.disjoint_left]
    simp
  have hcross :=
    (partialSplitsCompatible_mk_iff hAAc hEF).1 hcompat
  rcases hcross with hAE | hAF | hAcE | hAcF
  · exact Or.inl (Or.inr (subset_compl_of_disjoint hAE))
  · exact Or.inr (Or.inr (subset_compl_of_disjoint hAF))
  · exact Or.inl (Or.inl (by
      intro x hxE
      by_contra hxA
      exact (Finset.disjoint_left.mp hAcE)
        (Finset.mem_sdiff.mpr ⟨Finset.mem_univ x, hxA⟩) hxE))
  · exact Or.inr (Or.inl (by
      intro x hxF
      by_contra hxA
      exact (Finset.disjoint_left.mp hAcF)
        (Finset.mem_sdiff.mpr ⟨Finset.mem_univ x, hxA⟩) hxF))

namespace XTree

variable (T : XTree X V)

/-- The two oriented taxon sides of an actual edge cover every taxon. -/
theorem mem_edgeSide_or_mem_edgeSide_reverse_of_adj
    {u v : V} (huv : T.graph.Adj u v) (x : X) :
    x ∈ T.edgeSide u v ∨ x ∈ T.edgeSide v u := by
  rcases T.mem_vertexSide_or_mem_vertexSide_reverse_of_adj huv (T.label x) with h | h
  · exact Or.inl ((T.mem_edgeSide u v x).2 h)
  · exact Or.inr ((T.mem_edgeSide v u x).2 h)

/-- The two oriented taxon sides of an actual edge form a finite partition of
the whole taxon type. -/
theorem edgeSides_union_eq_univ {u v : V} (huv : T.graph.Adj u v) :
    T.edgeSide u v ∪ T.edgeSide v u = Finset.univ := by
  ext x
  simp only [Finset.mem_union, Finset.mem_univ, iff_true]
  exact T.mem_edgeSide_or_mem_edgeSide_reverse_of_adj huv x

/-- The reverse taxon side is the complement, inside the finite taxon
universe, of the forward side. -/
theorem edgeSide_reverse_eq_sdiff_univ {u v : V} (huv : T.graph.Adj u v) :
    T.edgeSide v u = Finset.univ \ T.edgeSide u v := by
  ext x
  constructor
  · intro hx
    refine Finset.mem_sdiff.mpr ⟨Finset.mem_univ x, ?_⟩
    exact fun hx' => (Finset.disjoint_left.mp
      (T.edgeSide_disjoint_reverse_of_adj huv)) hx' hx
  · intro hx
    exact (T.mem_edgeSide_or_mem_edgeSide_reverse_of_adj huv x).resolve_left
      (Finset.mem_sdiff.mp hx).2

/-- If both sides of an actual edge are monochromatic for `A | Aᶜ`, then
that edge displays the target split.  The covering property of the two edge
components upgrades the two inclusions to the required opposite inclusions. -/
theorem displays_compl_split_of_both_edgeSides_monochromatic
    {A : Finset X} (hA : A.Nonempty) (hAc : (Finset.univ \ A).Nonempty)
    {u v : V} (huv : T.graph.Adj u v)
    (huvMono : IsMonochromatic A (T.edgeSide u v))
    (hvuMono : IsMonochromatic A (T.edgeSide v u)) :
    T.DisplaysPartialSplit s(A, Finset.univ \ A) := by
  classical
  rcases huvMono with huvA | huvAc <;>
    rcases hvuMono with hvuA | hvuAc
  · obtain ⟨x, hxAc⟩ := hAc
    have hcover := T.mem_edgeSide_or_mem_edgeSide_reverse_of_adj huv x
    exact False.elim (hcover.elim
      (fun hx => (Finset.mem_sdiff.mp hxAc).2 (huvA hx))
      (fun hx => (Finset.mem_sdiff.mp hxAc).2 (hvuA hx)))
  · have hAuv : A ⊆ T.edgeSide u v := by
      intro x hxA
      have hcover := T.mem_edgeSide_or_mem_edgeSide_reverse_of_adj huv x
      exact hcover.resolve_right (fun hx => (Finset.mem_sdiff.mp (hvuAc hx)).2 hxA)
    have hAcvu : Finset.univ \ A ⊆ T.edgeSide v u := by
      intro x hxAc
      have hcover := T.mem_edgeSide_or_mem_edgeSide_reverse_of_adj huv x
      exact hcover.resolve_left (fun hx => (Finset.mem_sdiff.mp hxAc).2 (huvA hx))
    refine ⟨u, v, huv, ?_⟩
    rw [XTree.edgeSplit, displays_comm_representative]
    exact Or.inl ⟨hAuv, hAcvu⟩
  · have hAvu : A ⊆ T.edgeSide v u := by
      intro x hxA
      have hcover := T.mem_edgeSide_or_mem_edgeSide_reverse_of_adj huv x
      exact hcover.resolve_left (fun hx => (Finset.mem_sdiff.mp (huvAc hx)).2 hxA)
    have hAcuv : Finset.univ \ A ⊆ T.edgeSide u v := by
      intro x hxAc
      have hcover := T.mem_edgeSide_or_mem_edgeSide_reverse_of_adj huv x
      exact hcover.resolve_right (fun hx => (Finset.mem_sdiff.mp hxAc).2 (hvuA hx))
    refine ⟨u, v, huv, ?_⟩
    rw [XTree.edgeSplit, displays_comm_representative]
    exact Or.inr ⟨hAvu, hAcuv⟩
  · obtain ⟨x, hxA⟩ := hA
    have hcover := T.mem_edgeSide_or_mem_edgeSide_reverse_of_adj huv x
    exact False.elim (hcover.elim
      (fun hx => (Finset.mem_sdiff.mp (huvAc hx)).2 hxA)
      (fun hx => (Finset.mem_sdiff.mp (hvuAc hx)).2 hxA))

/-- Finite set of oriented graph edges whose far component is mixed for the
target split `A | Aᶜ`. -/
noncomputable def mixedOrientedEdges (A : Finset X) : Finset (V × V) := by
  classical
  exact (Finset.univ ×ˢ Finset.univ).filter fun e =>
    T.graph.Adj e.1 e.2 ∧ IsMixed A (T.edgeSide e.1 e.2)

@[simp] theorem mem_mixedOrientedEdges (A : Finset X) (u v : V) :
    (u, v) ∈ T.mixedOrientedEdges A ↔
      T.graph.Adj u v ∧ IsMixed A (T.edgeSide u v) := by
  classical
  simp [mixedOrientedEdges]

/-- Maximality of the edge-split system of a binary phylogenetic tree.

Every nontrivial full split compatible with every edge split of `T` is itself
displayed by an edge of `T`.  This is the exact reconstruction lemma needed
below; it is proved from the paper's graph axioms rather than imported. -/
theorem IsBinaryPhylogenetic.displays_compl_split_of_compatible
    (hbin : T.IsBinaryPhylogenetic)
    {A : Finset X} (hA : A.Nonempty) (hAc : (Finset.univ \ A).Nonempty)
    (hcompat : ∀ u v : V, T.graph.Adj u v →
      PartialSplitsCompatible s(A, Finset.univ \ A) (T.edgeSplit u v)) :
    T.DisplaysPartialSplit s(A, Finset.univ \ A) := by
  classical
  letI : Nonempty X := ⟨hA.choose⟩
  by_contra hnotDisplay
  have oneMixed : ∀ {u v : V}, T.graph.Adj u v →
      IsMixed A (T.edgeSide u v) ∨ IsMixed A (T.edgeSide v u) := by
    intro u v huv
    have hmono := compatible_compl_split_imp_one_side_monochromatic
      (T.edgeSide_disjoint_reverse_of_adj huv)
      (by simpa [XTree.edgeSplit] using hcompat u v huv)
    by_cases hmixUV : IsMixed A (T.edgeSide u v)
    · exact Or.inl hmixUV
    · have hmonoUV : IsMonochromatic A (T.edgeSide u v) :=
        (not_isMixed_iff_isMonochromatic A _).1 hmixUV
      by_cases hmixVU : IsMixed A (T.edgeSide v u)
      · exact Or.inr hmixVU
      · have hmonoVU : IsMonochromatic A (T.edgeSide v u) :=
          (not_isMixed_iff_isMonochromatic A _).1 hmixVU
        exact False.elim (hnotDisplay
          (T.displays_compl_split_of_both_edgeSides_monochromatic
            hA hAc huv hmonoUV hmonoVU))
  have hVnontrivial : Nontrivial V := by
    obtain ⟨a, ha⟩ := hA
    obtain ⟨b, hb⟩ := hAc
    have hab : a ≠ b := by
      intro hab
      subst b
      exact (Finset.mem_sdiff.mp hb).2 ha
    letI : Nontrivial X := ⟨⟨a, b, hab⟩⟩
    exact Function.Injective.nontrivial hbin.1.1
  letI : Nontrivial V := hVnontrivial
  obtain ⟨u₀, hu₀degree⟩ := T.isTree.exists_vert_degree_one_of_nontrivial
  have hu₀pos : 0 < T.graph.degree u₀ := by omega
  obtain ⟨v₀, huv₀⟩ := (T.graph.degree_pos_iff_exists_adj u₀).1 hu₀pos
  have hMixedNonempty : (T.mixedOrientedEdges A).Nonempty := by
    rcases oneMixed huv₀ with hmix | hmix
    · exact ⟨(u₀, v₀), (T.mem_mixedOrientedEdges A u₀ v₀).2
        ⟨huv₀, hmix⟩⟩
    · exact ⟨(v₀, u₀), (T.mem_mixedOrientedEdges A v₀ u₀).2
        ⟨huv₀.symm, hmix⟩⟩
  obtain ⟨e, heM, hminimal⟩ :=
    Finset.exists_min_image (T.mixedOrientedEdges A)
      (fun e : V × V => (T.edgeSide e.1 e.2).card) hMixedNonempty
  rcases e with ⟨u, v⟩
  have heData := (T.mem_mixedOrientedEdges A u v).1 heM
  have huv : T.graph.Adj u v := heData.1
  have hmix : IsMixed A (T.edgeSide u v) := heData.2
  have hvNotLeaf : ¬T.IsLeaf v := by
    intro hvLeaf
    obtain ⟨x, hxv⟩ := hbin.1.2.2 v hvLeaf
    have hpendant : T.edgeSide u v = {x} := by
      have hlabelAdj : T.graph.Adj (T.label x) u := by
        simpa [hxv] using huv.symm
      simpa [hxv] using hbin.1.edgeSide_pendant_eq_singleton T x hlabelAdj
    have hmonoSingleton : IsMonochromatic A ({x} : Finset X) := by
      by_cases hxA : x ∈ A
      · exact Or.inl (by simpa using hxA)
      · exact Or.inr (by simpa using hxA)
    exact (isMixed_iff_not_isMonochromatic A _).1
      (by simpa [hpendant] using hmix) hmonoSingleton
  have hdeg : Nat.card (T.graph.neighborSet v) = 3 := hbin.2 v hvNotLeaf
  let J : Finset V := (T.neighborFinset v).erase u
  have hJcard : J.card = 2 := by
    simpa [J] using T.card_neighborFinset_erase_of_degree_three huv hdeg
  obtain ⟨z₁, z₂, hz₁₂, hJ⟩ := Finset.card_eq_two.mp hJcard
  have hz₁J : z₁ ∈ J := by rw [hJ]; simp
  have hz₂J : z₂ ∈ J := by rw [hJ]; simp
  have hz₁N : z₁ ∈ T.neighborFinset v := Finset.mem_of_mem_erase hz₁J
  have hz₂N : z₂ ∈ T.neighborFinset v := Finset.mem_of_mem_erase hz₂J
  have hvz₁ : T.graph.Adj v z₁ := (T.mem_neighborFinset v z₁).1 hz₁N
  have hvz₂ : T.graph.Adj v z₂ := (T.mem_neighborFinset v z₂).1 hz₂N
  have huz₁ : u ≠ z₁ := (Finset.mem_erase.mp hz₁J).1.symm
  have huz₂ : u ≠ z₂ := (Finset.mem_erase.mp hz₂J).1.symm
  have childMono : ∀ z ∈ J, IsMonochromatic A (T.edgeSide v z) := by
    intro z hzJ
    have hzN : z ∈ T.neighborFinset v := Finset.mem_of_mem_erase hzJ
    have hvz : T.graph.Adj v z := (T.mem_neighborFinset v z).1 hzN
    have huz : u ≠ z := (Finset.mem_erase.mp hzJ).1.symm
    by_contra hnotMono
    have hchildMixed : IsMixed A (T.edgeSide v z) :=
      (isMixed_iff_not_isMonochromatic A _).2 hnotMono
    have hzM : (v, z) ∈ T.mixedOrientedEdges A :=
      (T.mem_mixedOrientedEdges A v z).2 ⟨hvz, hchildMixed⟩
    have hmin := hminimal (v, z) hzM
    have hstrict := T.edgeSide_ssubset_parentSide huv hvz huz
    exact (Nat.not_lt_of_ge hmin) (Finset.card_lt_card hstrict)
  have hz₁Mono := childMono z₁ hz₁J
  have hz₂Mono := childMono z₂ hz₂J
  have hparentMono : IsMonochromatic A (T.edgeSide v u) := by
    have hmono := compatible_compl_split_imp_one_side_monochromatic
      (T.edgeSide_disjoint_reverse_of_adj huv)
      (by simpa [XTree.edgeSplit] using hcompat u v huv)
    rcases hmono with hmonoUV | hmonoVU
    · exact False.elim ((isMixed_iff_not_isMonochromatic A _).1 hmix hmonoUV)
    · exact hmonoVU
  have hcenterEmpty : T.labelFiber v = ∅ :=
    hbin.1.labelFiber_eq_empty_of_not_leaf T hvNotLeaf
  have neighbor_cases : ∀ z : V, T.graph.Adj v z →
      z = u ∨ z = z₁ ∨ z = z₂ := by
    intro z hvz
    by_cases hzu : z = u
    · exact Or.inl hzu
    · have hzJ' : z ∈ J := by
        exact Finset.mem_erase.mpr ⟨hzu, (T.mem_neighborFinset v z).2 hvz⟩
      rw [hJ] at hzJ'
      simpa only [Finset.mem_insert, Finset.mem_singleton] using Or.inr hzJ'
  have branch_cover : ∀ x : X,
      x ∈ T.edgeSide v u ∨ x ∈ T.edgeSide v z₁ ∨
        x ∈ T.edgeSide v z₂ := by
    intro x
    obtain ⟨z, hzPlus, hxBlock⟩ := T.exists_mem_branchBlock v x
    rw [T.mem_neighborsPlus] at hzPlus
    rcases hzPlus with rfl | hvz
    · rw [T.branchBlock_self, hcenterEmpty] at hxBlock
      simp at hxBlock
    · rcases neighbor_cases z hvz with rfl | rfl | rfl
      · rw [T.branchBlock_of_adj huv.symm] at hxBlock
        exact Or.inl hxBlock
      · rw [T.branchBlock_of_adj hvz₁] at hxBlock
        exact Or.inr (Or.inl hxBlock)
      · rw [T.branchBlock_of_adj hvz₂] at hxBlock
        exact Or.inr (Or.inr hxBlock)
  have child_union_mixed :
      ¬(IsMonochromatic A (T.edgeSide v z₁) ∧
        IsMonochromatic A (T.edgeSide v z₂) ∧
        ((T.edgeSide v z₁ ⊆ A ∧ T.edgeSide v z₂ ⊆ A) ∨
          (T.edgeSide v z₁ ⊆ Finset.univ \ A ∧
            T.edgeSide v z₂ ⊆ Finset.univ \ A))) := by
    rintro ⟨_h1, _h2, hsame⟩
    have hEsubset : T.edgeSide u v ⊆ A ∨
        T.edgeSide u v ⊆ Finset.univ \ A := by
      rcases hsame with ⟨h1, h2⟩ | ⟨h1, h2⟩
      · left
        intro x hx
        have hxNotParent : x ∉ T.edgeSide v u := by
          exact fun hxp => (Finset.disjoint_left.mp
            (T.edgeSide_disjoint_reverse_of_adj huv)) hx hxp
        rcases branch_cover x with hxp | hx1 | hx2
        · exact False.elim (hxNotParent hxp)
        · exact h1 hx1
        · exact h2 hx2
      · right
        intro x hx
        have hxNotParent : x ∉ T.edgeSide v u := by
          exact fun hxp => (Finset.disjoint_left.mp
            (T.edgeSide_disjoint_reverse_of_adj huv)) hx hxp
        rcases branch_cover x with hxp | hx1 | hx2
        · exact False.elim (hxNotParent hxp)
        · exact h1 hx1
        · exact h2 hx2
    exact (isMixed_iff_not_isMonochromatic A _).1 hmix
      (show IsMonochromatic A (T.edgeSide u v) from hEsubset)
  rcases hz₁Mono with hz₁A | hz₁Ac <;>
    rcases hz₂Mono with hz₂A | hz₂Ac <;>
    rcases hparentMono with hpuA | hpuAc
  · exact False.elim (child_union_mixed
      ⟨Or.inl hz₁A, Or.inl hz₂A, Or.inl ⟨hz₁A, hz₂A⟩⟩)
  · exact False.elim (child_union_mixed
      ⟨Or.inl hz₁A, Or.inl hz₂A, Or.inl ⟨hz₁A, hz₂A⟩⟩)
  · have hreverseMono : IsMonochromatic A (T.edgeSide z₂ v) := by
      left
      intro x hx
      rcases branch_cover x with hxp | hx1 | hx2
      · exact hpuA hxp
      · exact hz₁A hx1
      · exact False.elim ((Finset.disjoint_left.mp
          (T.edgeSide_disjoint_reverse_of_adj hvz₂)) hx2 hx)
    exact False.elim (hnotDisplay
      (T.displays_compl_split_of_both_edgeSides_monochromatic
        hA hAc hvz₂ (Or.inr hz₂Ac) hreverseMono))
  · have hreverseMono : IsMonochromatic A (T.edgeSide z₁ v) := by
      right
      intro x hx
      rcases branch_cover x with hxp | hx1 | hx2
      · exact hpuAc hxp
      · exact False.elim ((Finset.disjoint_left.mp
          (T.edgeSide_disjoint_reverse_of_adj hvz₁)) hx1 hx)
      · exact hz₂Ac hx2
    exact False.elim (hnotDisplay
      (T.displays_compl_split_of_both_edgeSides_monochromatic
        hA hAc hvz₁ (Or.inl hz₁A) hreverseMono))
  · have hreverseMono : IsMonochromatic A (T.edgeSide z₁ v) := by
      left
      intro x hx
      rcases branch_cover x with hxp | hx1 | hx2
      · exact hpuA hxp
      · exact False.elim ((Finset.disjoint_left.mp
          (T.edgeSide_disjoint_reverse_of_adj hvz₁)) hx1 hx)
      · exact hz₂A hx2
    exact False.elim (hnotDisplay
      (T.displays_compl_split_of_both_edgeSides_monochromatic
        hA hAc hvz₁ (Or.inr hz₁Ac) hreverseMono))
  · have hreverseMono : IsMonochromatic A (T.edgeSide z₂ v) := by
      right
      intro x hx
      rcases branch_cover x with hxp | hx1 | hx2
      · exact hpuAc hxp
      · exact hz₁Ac hx1
      · exact False.elim ((Finset.disjoint_left.mp
          (T.edgeSide_disjoint_reverse_of_adj hvz₂)) hx2 hx)
    exact False.elim (hnotDisplay
      (T.displays_compl_split_of_both_edgeSides_monochromatic
        hA hAc hvz₂ (Or.inl hz₂A) hreverseMono))
  · exact False.elim (child_union_mixed
      ⟨Or.inr hz₁Ac, Or.inr hz₂Ac, Or.inr ⟨hz₁Ac, hz₂Ac⟩⟩)
  · exact False.elim (child_union_mixed
      ⟨Or.inr hz₁Ac, Or.inr hz₂Ac, Or.inr ⟨hz₁Ac, hz₂Ac⟩⟩)

end XTree

/-! ## From common quartets to a common full split system -/

/-- If two disjoint represented splits both cover the finite universe, then
display of the second by the first is equality of the corresponding unordered
splits.  This is the precise place where full-split coverage is used. -/
theorem displays_mk_eq_of_disjoint_cover
    {A B C D : Finset X}
    (hAB : Disjoint A B) (hCD : Disjoint C D)
    (hABcover : A ∪ B = Finset.univ)
    (hCDcover : C ∪ D = Finset.univ)
    (hdisplay : Displays s(A, B) s(C, D)) :
    s(A, B) = s(C, D) := by
  rw [displays_comm_representative] at hdisplay
  rw [Sym2.eq_iff]
  rcases hdisplay with ⟨hCA, hDB⟩ | ⟨hCB, hDA⟩
  · left
    constructor
    · apply Finset.Subset.antisymm
      · intro x hxA
        have hxCD : x ∈ C ∨ x ∈ D := by
          have hx : x ∈ C ∪ D := by rw [hCDcover]; simp
          simpa only [Finset.mem_union] using hx
        rcases hxCD with hxC | hxD
        · exact hxC
        · exact False.elim ((Finset.disjoint_left.mp hAB) hxA (hDB hxD))
      · exact hCA
    · apply Finset.Subset.antisymm
      · intro x hxB
        have hxCD : x ∈ C ∨ x ∈ D := by
          have hx : x ∈ C ∪ D := by rw [hCDcover]; simp
          simpa only [Finset.mem_union] using hx
        rcases hxCD with hxC | hxD
        · exact False.elim ((Finset.disjoint_left.mp hAB) (hCA hxC) hxB)
        · exact hxD
      · exact hDB
  · right
    constructor
    · apply Finset.Subset.antisymm
      · intro x hxA
        have hxCD : x ∈ C ∨ x ∈ D := by
          have hx : x ∈ C ∪ D := by rw [hCDcover]; simp
          simpa only [Finset.mem_union] using hx
        rcases hxCD with hxC | hxD
        · exact False.elim ((Finset.disjoint_left.mp hAB) hxA (hCB hxC))
        · exact hxD
      · exact hDA
    · apply Finset.Subset.antisymm
      · intro x hxB
        have hxCD : x ∈ C ∨ x ∈ D := by
          have hx : x ∈ C ∪ D := by rw [hCDcover]; simp
          simpa only [Finset.mem_union] using hx
        rcases hxCD with hxC | hxD
        · exact hxC
        · exact False.elim ((Finset.disjoint_left.mp hAB) (hDA hxD) hxB)
      · exact hCB

/-- Pointwise equality of the two displayed full-quartet systems forces every
edge split of the first tree to be compatible with every edge split of the
second tree.  A hypothetical incompatibility supplies two distinct induced
quartets on one four-draw sample.  Their common support then has cardinality
four, so the first quartet transfers to the second tree and violates quartet
uniqueness there. -/
theorem edgeSplitsCompatible_of_same_full_quartets
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hsame : ∀ P : PartialSplit X, IsQuartet P →
      (T₁.DisplaysPartialSplit P ↔ T₂.DisplaysPartialSplit P))
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w) :
    PartialSplitsCompatible (T₁.edgeSplit t u) (T₂.edgeSplit v w) := by
  classical
  apply partialSplitsCompatible_of_no_differentSplitQuartetEvent
    (T₁.edgeSplit_isFullSplit htu).1
    (T₂.edgeSplit_isFullSplit hvw).1
  intro draw
  rintro ⟨R, S, hindR, hindS, hdisplayR, hdisplayS, hRS⟩
  have hdrawCard : (fourDrawSupport draw).card = 4 :=
    fourDrawSupport_card_four_of_distinct_induced hindR hindS hRS
  have hRquartet : IsQuartet R :=
    hindR.isPartialQuartet.isQuartet_of_support_card_four (by
      rw [partialSplitSupport_eq_fourDrawSupport_of_induces hindR]
      exact hdrawCard)
  have hT₁R : T₁.DisplaysPartialSplit R := ⟨t, u, htu, hdisplayR⟩
  have hT₂R : T₂.DisplaysPartialSplit R := (hsame R hRquartet).1 hT₁R
  have hT₂S : T₂.DisplaysPartialSplit S := ⟨v, w, hvw, hdisplayS⟩
  exact hRS (T₂.induced_displayed_partialQuartet_unique
    draw hindR hindS hT₂R hT₂S)

/-- Under common full-quartet systems, maximality of the second binary tree's
compatible split system forces every edge split of the first tree to occur as
an edge split of the second. -/
theorem edgeSplitSet_subset_of_same_full_quartets
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hbin₂ : T₂.IsBinaryPhylogenetic)
    (hsame : ∀ P : PartialSplit X, IsQuartet P →
      (T₁.DisplaysPartialSplit P ↔ T₂.DisplaysPartialSplit P)) :
    T₁.edgeSplitSet ⊆ T₂.edgeSplitSet := by
  classical
  rintro P ⟨u, v, huv, rfl⟩
  let A : Finset X := T₁.edgeSide u v
  have hA : A.Nonempty := by
    simpa [A] using T₁.edgeSide_nonempty_of_adj huv
  have hAc : (Finset.univ \ A).Nonempty := by
    simpa [A, T₁.edgeSide_reverse_eq_sdiff_univ huv] using
      T₁.edgeSide_nonempty_of_adj huv.symm
  have htarget : s(A, Finset.univ \ A) = T₁.edgeSplit u v := by
    rw [XTree.edgeSplit]
    simp only [A, T₁.edgeSide_reverse_eq_sdiff_univ huv]
  have hcompat : ∀ p q : V₂, T₂.graph.Adj p q →
      PartialSplitsCompatible s(A, Finset.univ \ A) (T₂.edgeSplit p q) := by
    intro p q hpq
    have hcross := edgeSplitsCompatible_of_same_full_quartets
      T₁ T₂ hsame huv hpq
    simpa only [htarget] using hcross
  have hdisplayTarget :=
    hbin₂.displays_compl_split_of_compatible T₂ hA hAc hcompat
  rw [htarget] at hdisplayTarget
  rcases hdisplayTarget with ⟨p, q, hpq, hdisplay⟩
  have heq : T₂.edgeSplit p q = T₁.edgeSplit u v := by
    apply displays_mk_eq_of_disjoint_cover
      (T₂.edgeSide_disjoint_reverse_of_adj hpq)
      (T₁.edgeSide_disjoint_reverse_of_adj huv)
      (T₂.edgeSides_union_eq_univ hpq)
      (T₁.edgeSides_union_eq_univ huv)
    simpa only [XTree.edgeSplit] using hdisplay
  exact ⟨p, q, hpq, heq.symm⟩

/-- Two binary phylogenetic trees with the same displayed full quartets have
exactly the same edge-split system. -/
theorem edgeSplitSet_eq_of_same_full_quartets
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hbin₁ : T₁.IsBinaryPhylogenetic)
    (hbin₂ : T₂.IsBinaryPhylogenetic)
    (hsame : ∀ P : PartialSplit X, IsQuartet P →
      (T₁.DisplaysPartialSplit P ↔ T₂.DisplaysPartialSplit P)) :
    T₁.edgeSplitSet = T₂.edgeSplitSet := by
  apply Set.Subset.antisymm
  · exact edgeSplitSet_subset_of_same_full_quartets T₁ T₂ hbin₂ hsame
  · exact edgeSplitSet_subset_of_same_full_quartets T₂ T₁ hbin₁
      (fun P hP => (hsame P hP).symm)

end QDFull
