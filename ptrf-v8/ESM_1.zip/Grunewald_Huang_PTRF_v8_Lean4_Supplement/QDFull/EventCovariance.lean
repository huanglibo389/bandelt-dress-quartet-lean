import QDFull.EventClassification

/-!
# From the four-draw events to the determinant formula

The two finite event classifications are substituted into the paper's verbal
definition of split quartet covariance.  The remaining identity is the exact
`2 × 2` determinant square, including the common sample-space denominator.
-/

namespace QDFull

universe uX

/-- For two represented partial splits with disjoint sides, the ordered-four-
draw event definition is exactly six times the square of the normalized
intersection determinant. -/
theorem splitQuartetCovarianceEvent_mk
    {X : Type uX} [Fintype X] [Nonempty X]
    (A B C D : Finset X) (hAB : Disjoint A B) (hCD : Disjoint C D) :
    splitQuartetCovarianceEvent s(A, B) s(C, D) =
      orientedSplitCovariance A B C D := by
  classical
  unfold splitQuartetCovarianceEvent
  rw [fourDrawProbability_eq, fourDrawProbability_eq,
    card_sameSplitQuartetEvent A B C D hAB hCD,
    card_differentSplitQuartetEvent A B C D hAB hCD]
  simp only [Nat.cast_add, Nat.cast_mul, Nat.cast_ofNat, Nat.cast_pow]
  unfold orientedSplitCovariance orientedSplitDeterminant normalizedCard
  have hN : (Fintype.card X : ℝ) ≠ 0 := by
    exact_mod_cast Fintype.card_ne_zero
  field_simp [hN]
  ring

/-- Representative-independent form of the event/determinant identity for
unordered partial splits. -/
theorem splitQuartetCovarianceEvent_eq_splitQuartetCovariance
    {X : Type uX} [Fintype X] [Nonempty X]
    (P Q : PartialSplit X) (hP : IsPartialSplit P) (hQ : IsPartialSplit Q) :
    splitQuartetCovarianceEvent P Q = splitQuartetCovariance P Q := by
  rcases hP with ⟨A, B, rfl, _hA, _hB, hAB⟩
  rcases hQ with ⟨C, D, rfl, _hC, _hD, hCD⟩
  rw [splitQuartetCovarianceEvent_mk A B C D hAB hCD,
    splitQuartetCovariance_mk]

/-- Independence of two partial splits, using the paper's four-draw event
definition of quartet covariance. -/
def SplitIndependent {X : Type uX} [Fintype X]
    (P Q : PartialSplit X) : Prop :=
  splitQuartetCovarianceEvent P Q = 0

/-- Two vertex-labelled `X`-trees are independent when every pair of actual
tree-edge splits is independent. -/
def TreesIndependent
    {X : Type uX} {V₁ : Type*} {V₂ : Type*}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : Prop :=
  ∀ t u v w, T₁.graph.Adj t u → T₂.graph.Adj v w →
    SplitIndependent (T₁.edgeSplit t u) (T₂.edgeSplit v w)

/-- For represented partial splits, independence is exactly vanishing of the
normalized `2 × 2` determinant. -/
theorem splitIndependent_mk_iff_determinant_eq_zero
    {X : Type uX} [Fintype X] [Nonempty X]
    (A B C D : Finset X) (hAB : Disjoint A B) (hCD : Disjoint C D) :
    SplitIndependent s(A, B) s(C, D) ↔
      orientedSplitDeterminant A B C D = 0 := by
  unfold SplitIndependent
  rw [splitQuartetCovarianceEvent_mk A B C D hAB hCD]
  simp [orientedSplitCovariance]

/-- Edge-split version of the paper identity, now stated for the original
ordered-four-draw event covariance rather than only its closed formula. -/
theorem edgeSplit_quartetCovarianceEvent_eq
    {X : Type uX} {V₁ : Type*} {V₂ : Type*}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w) :
    splitQuartetCovarianceEvent
        (T₁.edgeSplit t u) (T₂.edgeSplit v w) =
      6 * xCoefficient T₁ T₂ t u v w ^ 2 := by
  letI : Nonempty X := T₁.taxon_nonempty
  rw [splitQuartetCovarianceEvent_eq_splitQuartetCovariance
      (T₁.edgeSplit t u) (T₂.edgeSplit v w)
      (T₁.edgeSplit_isFullSplit htu).1
      (T₂.edgeSplit_isFullSplit hvw).1,
    edgeSplit_quartetCovariance_eq T₁ T₂ htu hvw]

/-- The paper's tree-independence condition is equivalent to vanishing of
every edge-pair determinant coefficient. -/
theorem treesIndependent_iff_xCoefficient_eq_zero
    {X : Type uX} {V₁ : Type*} {V₂ : Type*}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    TreesIndependent T₁ T₂ ↔
      ∀ t u v w, T₁.graph.Adj t u → T₂.graph.Adj v w →
        xCoefficient T₁ T₂ t u v w = 0 := by
  constructor
  · intro h t u v w htu hvw
    have hz := h t u v w htu hvw
    unfold SplitIndependent at hz
    rw [edgeSplit_quartetCovarianceEvent_eq T₁ T₂ htu hvw] at hz
    nlinarith [sq_nonneg (xCoefficient T₁ T₂ t u v w)]
  · intro h t u v w htu hvw
    unfold SplitIndependent
    rw [edgeSplit_quartetCovarianceEvent_eq T₁ T₂ htu hvw,
      h t u v w htu hvw]
    norm_num

end QDFull
