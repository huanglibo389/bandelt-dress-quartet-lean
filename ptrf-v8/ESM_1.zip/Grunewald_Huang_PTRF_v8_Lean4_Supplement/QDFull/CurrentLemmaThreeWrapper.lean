import QDFull.UpperEqualityReconstruction

/-!
# Current-manuscript wrapper for Lemma 3

This file packages the final assertion of Lemma 3 in the current manuscript
with exactly its printed hypotheses: every singleton-versus-pair partial
quartet on three distinct taxa is displayed, and every four-taxon support
carries a displayed full quartet.
-/

namespace QDFull

universe uX uV

namespace XTree

variable {X : Type uX} {V : Type uV} [Fintype X] [Fintype V]

/-- Current Lemma 3, final assertion: if `|X| >= 4`, an `X`-tree which
displays `xx | yz` for every three distinct taxa and a full quartet on every
four-taxon support is binary phylogenetic. -/
theorem isBinaryPhylogenetic_of_all_three_and_four_partialQuartets_displayed
    (T : XTree X V) (hX : 4 ≤ Fintype.card X)
    (hthree : ∀ x y z : X,
      ∀ _hxy : x ≠ y, ∀ _hxz : x ≠ z, ∀ hyz : y ≠ z,
      T.DisplaysPartialSplit
        (Sym2.mk ({x} : Finset X)
          (Finset.cons y {z} (by simpa using hyz))))
    (hfour : ∀ S : Finset X, S.card = 4 →
      ∃ P : PartialSplit X, IsQuartet P ∧
        T.DisplaysPartialSplit P ∧ partialSplitSupport P = S) :
    T.IsBinaryPhylogenetic := by
  classical
  have hinj : Function.Injective T.label := by
    intro a b habLabel
    by_contra hab
    have hcExists : ∃ c : X, c ∉ ({a, b} : Finset X) := by
      by_contra hc
      push Not at hc
      have hsub : (Finset.univ : Finset X) ⊆ {a, b} := by
        intro c _hc
        exact hc c
      have hcard := Finset.card_le_card hsub
      rw [Finset.card_univ, Finset.card_pair hab] at hcard
      omega
    obtain ⟨c, hc⟩ := hcExists
    have hca : c ≠ a := by
      intro hca
      subst c
      exact hc (by simp)
    have hcb : c ≠ b := by
      intro hcb
      subst c
      exact hc (by simp)
    have hdisplayThree := hthree a b c hab hca.symm hcb.symm
    have hdisplayThree' :
        T.DisplaysPartialSplit
          s(({a} : Finset X), ({b, c} : Finset X)) := by
      simpa using hdisplayThree
    have hdisplayPair :
        T.DisplaysPartialSplit (pairPartialQuartet s(a, b)) := by
      apply hdisplayThree'.trans
      simp only [pairPartialQuartet, Sym2.map_mk]
      rw [displays_comm_representative]
      simp
    exact (label_ne_of_displays_pairPartialQuartet T hdisplayPair) habLabel
  have hleaf : ∀ x : X, T.IsLeaf (T.label x) := by
    apply labels_are_leaves_of_all_marked_three_displayed T (by omega) hinj
    intro z hz
    have hzData := (mem_markedThreeSupports z).1 hz
    have heraseCard : (z.1.erase z.2).card = 2 := by
      rw [Finset.card_erase_of_mem hzData.2, hzData.1]
    obtain ⟨y, w, hyw, herase⟩ := Finset.card_eq_two.mp heraseCard
    have hyMem : y ∈ z.1.erase z.2 := by
      rw [herase]
      simp
    have hwMem : w ∈ z.1.erase z.2 := by
      rw [herase]
      simp
    have hyx : y ≠ z.2 := (Finset.mem_erase.mp hyMem).1
    have hwx : w ≠ z.2 := (Finset.mem_erase.mp hwMem).1
    have hdisplay := hthree z.2 y w hyx.symm hwx.symm hyw
    unfold markedThreePartialQuartet
    rw [herase]
    simpa using hdisplay
  have hphy : T.IsPhylogenetic :=
    isPhylogenetic_of_injective_and_labels_are_leaves T hinj hleaf
  exact isBinaryPhylogenetic_of_all_four_supports_displayed T hX hphy hfour

end XTree

end QDFull
