import QDFull.InclusionExclusionCoefficient
import QDFull.EventClassification

/-!
# Uniqueness of the displayed pairing of one four-draw sample

Theorem 1 treats the quartet induced and displayed by one tree as unique.
For repeated taxa and vertex-labelled trees this is not a definitional fact.
Here it is proved from tree geometry: two edge cuts cannot have all four
cross-intersection cells nonempty.  Consequently the three canonical
`2 + 2` pairings of four draw positions are pairwise incompatible in one
tree.
-/

open SimpleGraph

namespace QDFull

universe uX uV

namespace XTree

variable {X : Type uX} {V : Type uV}
  [Fintype X] [Fintype V] [DecidableEq X] [DecidableEq V]

/-- If two taxa lie on the same side of an edge, that edge is absent from
their unique tree path. -/
theorem edge_not_mem_taxonPath_of_mem_same_side
    (T : XTree X V) {u v : V} (huv : T.graph.Adj u v)
    {a b : X} (ha : a ∈ T.edgeSide u v) (hb : b ∈ T.edgeSide u v) :
    s(u, v) ∉ (T.taxonPath a b).edges := by
  intro hedge
  have hop := (T.edge_mem_taxonPath_iff_opposite_sides huv a b).1 hedge
  have hdisj := Finset.disjoint_left.1
    (T.edgeSide_disjoint_reverse_of_adj huv)
  rcases hop with hop | hop
  · exact hdisj hb hop.2
  · exact hdisj ha hop.1

/-- Every vertex on a taxon path whose endpoints lie on one side of an edge
lies in the corresponding vertex component.  The proof transfers the prefix
of the chosen tree path to the graph with that edge deleted. -/
theorem mem_vertexSide_of_mem_taxonPath_support_same_side
    (T : XTree X V) {u v z : V} (huv : T.graph.Adj u v)
    {a b : X} (ha : a ∈ T.edgeSide u v) (hb : b ∈ T.edgeSide u v)
    (hz : z ∈ (T.taxonPath a b).support) :
    z ∈ T.vertexSide u v := by
  classical
  let H : SimpleGraph V := T.graph.deleteEdges {s(u, v)}
  let p := T.taxonPath a b
  have hnot : s(u, v) ∉ p.edges :=
    T.edge_not_mem_taxonPath_of_mem_same_side huv ha hb
  let pz : T.graph.Walk (T.label a) z := p.takeUntil z hz
  let pzH : H.Walk (T.label a) z :=
    pz.transfer H (fun e he => by
      rw [SimpleGraph.edgeSet_deleteEdges]
      refine ⟨pz.edges_subset_edgeSet he, ?_⟩
      have hene : e ≠ s(u, v) := by
        intro heq
        apply hnot
        rw [← heq]
        exact p.edges_takeUntil_subset_edges hz he
      simpa using hene)
  have hva : H.Reachable v (T.label a) := by
    simpa [H] using (T.mem_edgeSide u v a).1 ha
  exact hva.trans pzH.reachable

/-- Two edge cuts of a tree cannot have all four cross-intersection cells
nonempty.  Otherwise a path joining two taxa on the first side would put an
endpoint of the second edge in that component, while another such path on
the opposite side would put the same endpoint in the opposite component. -/
theorem not_four_edgeSide_intersections_nonempty
    (T : XTree X V) {u v x y : V}
    (huv : T.graph.Adj u v) (hxy : T.graph.Adj x y) :
    ¬ ((T.edgeSide u v ∩ T.edgeSide x y).Nonempty ∧
       (T.edgeSide u v ∩ T.edgeSide y x).Nonempty ∧
       (T.edgeSide v u ∩ T.edgeSide x y).Nonempty ∧
       (T.edgeSide v u ∩ T.edgeSide y x).Nonempty) := by
  rintro ⟨⟨a, ha⟩, ⟨b, hb⟩, ⟨c, hc⟩, ⟨d, hd⟩⟩
  simp only [Finset.mem_inter] at ha hb hc hd
  have hxyab : s(x, y) ∈ (T.taxonPath a b).edges :=
    (T.edge_mem_taxonPath_iff_opposite_sides hxy a b).2
      (Or.inl ⟨ha.2, hb.2⟩)
  have hxA : x ∈ T.vertexSide u v :=
    T.mem_vertexSide_of_mem_taxonPath_support_same_side huv
      ha.1 hb.1
      ((T.taxonPath a b).fst_mem_support_of_mem_edges hxyab)
  have hxycd : s(x, y) ∈ (T.taxonPath c d).edges :=
    (T.edge_mem_taxonPath_iff_opposite_sides hxy c d).2
      (Or.inl ⟨hc.2, hd.2⟩)
  have hxB : x ∈ T.vertexSide v u :=
    T.mem_vertexSide_of_mem_taxonPath_support_same_side huv.symm
      hc.1 hd.1
      ((T.taxonPath c d).fst_mem_support_of_mem_edges hxycd)
  exact (Set.disjoint_left.1
    (T.vertexSide_disjoint_reverse_of_adj huv)) hxA hxB

/-- Two crossing `2 + 2` pairings cannot both be displayed by one tree. -/
theorem not_displays_cross_pairings
    (T : XTree X V) (a b c d : X) :
    ¬ (T.DisplaysPartialSplit s(({a, b} : Finset X), {c, d}) ∧
       T.DisplaysPartialSplit s(({a, c} : Finset X), {b, d})) := by
  classical
  rintro ⟨⟨u, v, huv, hP⟩, ⟨x, y, hxy, hQ⟩⟩
  change Displays
      s(T.edgeSide u v, T.edgeSide v u)
      s(({a, b} : Finset X), {c, d}) at hP
  change Displays
      s(T.edgeSide x y, T.edgeSide y x)
      s(({a, c} : Finset X), {b, d}) at hQ
  rw [displays_comm_representative] at hP hQ
  rcases hP with hP | hP <;> rcases hQ with hQ | hQ
  · apply T.not_four_edgeSide_intersections_nonempty huv hxy
    exact ⟨⟨a, Finset.mem_inter.2
        ⟨hP.1 (by simp), hQ.1 (by simp)⟩⟩,
      ⟨b, Finset.mem_inter.2
        ⟨hP.1 (by simp), hQ.2 (by simp)⟩⟩,
      ⟨c, Finset.mem_inter.2
        ⟨hP.2 (by simp), hQ.1 (by simp)⟩⟩,
      ⟨d, Finset.mem_inter.2
        ⟨hP.2 (by simp), hQ.2 (by simp)⟩⟩⟩
  · apply T.not_four_edgeSide_intersections_nonempty huv hxy.symm
    exact ⟨⟨a, Finset.mem_inter.2
        ⟨hP.1 (by simp), hQ.1 (by simp)⟩⟩,
      ⟨b, Finset.mem_inter.2
        ⟨hP.1 (by simp), hQ.2 (by simp)⟩⟩,
      ⟨c, Finset.mem_inter.2
        ⟨hP.2 (by simp), hQ.1 (by simp)⟩⟩,
      ⟨d, Finset.mem_inter.2
        ⟨hP.2 (by simp), hQ.2 (by simp)⟩⟩⟩
  · apply T.not_four_edgeSide_intersections_nonempty huv.symm hxy
    exact ⟨⟨a, Finset.mem_inter.2
        ⟨hP.1 (by simp), hQ.1 (by simp)⟩⟩,
      ⟨b, Finset.mem_inter.2
        ⟨hP.1 (by simp), hQ.2 (by simp)⟩⟩,
      ⟨c, Finset.mem_inter.2
        ⟨hP.2 (by simp), hQ.1 (by simp)⟩⟩,
      ⟨d, Finset.mem_inter.2
        ⟨hP.2 (by simp), hQ.2 (by simp)⟩⟩⟩
  · apply T.not_four_edgeSide_intersections_nonempty huv.symm hxy.symm
    exact ⟨⟨a, Finset.mem_inter.2
        ⟨hP.1 (by simp), hQ.1 (by simp)⟩⟩,
      ⟨b, Finset.mem_inter.2
        ⟨hP.1 (by simp), hQ.2 (by simp)⟩⟩,
      ⟨c, Finset.mem_inter.2
        ⟨hP.2 (by simp), hQ.1 (by simp)⟩⟩,
      ⟨d, Finset.mem_inter.2
        ⟨hP.2 (by simp), hQ.2 (by simp)⟩⟩⟩

/-- The first and second canonical pairings are incompatible. -/
theorem not_displays_pairing01_pairing02
    (T : XTree X V) (draw : Fin 4 → X) :
    ¬ (T.DisplaysPartialSplit (drawPairSplit draw 0 1 2 3) ∧
       T.DisplaysPartialSplit (drawPairSplit draw 0 2 1 3)) := by
  classical
  letI : DecidableEq X := Classical.decEq X
  simpa [drawPairSplit] using T.not_displays_cross_pairings
    (draw 0) (draw 1) (draw 2) (draw 3)

/-- The first and third canonical pairings are incompatible. -/
theorem not_displays_pairing01_pairing03
    (T : XTree X V) (draw : Fin 4 → X) :
    ¬ (T.DisplaysPartialSplit (drawPairSplit draw 0 1 2 3) ∧
       T.DisplaysPartialSplit (drawPairSplit draw 0 3 1 2)) := by
  classical
  letI : DecidableEq X := Classical.decEq X
  simpa [drawPairSplit, Finset.pair_comm] using
    T.not_displays_cross_pairings
      (draw 0) (draw 1) (draw 3) (draw 2)

/-- The second and third canonical pairings are incompatible. -/
theorem not_displays_pairing02_pairing03
    (T : XTree X V) (draw : Fin 4 → X) :
    ¬ (T.DisplaysPartialSplit (drawPairSplit draw 0 2 1 3) ∧
       T.DisplaysPartialSplit (drawPairSplit draw 0 3 1 2)) := by
  classical
  letI : DecidableEq X := Classical.decEq X
  simpa [drawPairSplit, Finset.pair_comm] using
    T.not_displays_cross_pairings
      (draw 0) (draw 2) (draw 3) (draw 1)

/-- A tree displays at most one partial quartet induced by a fixed ordered
four-draw sample.  This includes repeated taxa and labels at internal
vertices. -/
theorem induced_displayed_partialQuartet_unique
    (T : XTree X V) (draw : Fin 4 → X)
    {P Q : PartialSplit X}
    (hindP : Induces draw P) (hindQ : Induces draw Q)
    (hdisplayP : T.DisplaysPartialSplit P)
    (hdisplayQ : T.DisplaysPartialSplit Q) :
    P = Q := by
  classical
  letI : DecidableEq X := Classical.decEq X
  have hP := (induces_iff_canonical draw P).1 hindP
  have hQ := (induces_iff_canonical draw Q).1 hindQ
  rcases hP.2 with hP | hP | hP <;>
    rcases hQ.2 with hQ | hQ | hQ
  · exact hP.trans hQ.symm
  · exfalso
    apply T.not_displays_pairing01_pairing02 draw
    exact ⟨by simpa only [← hP] using hdisplayP,
      by simpa only [← hQ] using hdisplayQ⟩
  · exfalso
    apply T.not_displays_pairing01_pairing03 draw
    exact ⟨by simpa only [← hP] using hdisplayP,
      by simpa only [← hQ] using hdisplayQ⟩
  · exfalso
    apply T.not_displays_pairing01_pairing02 draw
    exact ⟨by simpa only [← hQ] using hdisplayQ,
      by simpa only [← hP] using hdisplayP⟩
  · exact hP.trans hQ.symm
  · exfalso
    apply T.not_displays_pairing02_pairing03 draw
    exact ⟨by simpa only [← hP] using hdisplayP,
      by simpa only [← hQ] using hdisplayQ⟩
  · exfalso
    apply T.not_displays_pairing01_pairing03 draw
    exact ⟨by simpa only [← hQ] using hdisplayQ,
      by simpa only [← hP] using hdisplayP⟩
  · exfalso
    apply T.not_displays_pairing02_pairing03 draw
    exact ⟨by simpa only [← hQ] using hdisplayQ,
      by simpa only [← hP] using hdisplayP⟩
  · exact hP.trans hQ.symm

end XTree

end QDFull
