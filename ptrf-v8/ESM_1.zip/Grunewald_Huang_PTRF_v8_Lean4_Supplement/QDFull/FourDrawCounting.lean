import QDFull.QuartetEvents

/-!
# Exact counting of four-draw cell patterns

The quartet-covariance determinant is a finite counting identity.  This file
isolates its two multinomial counts.  A fixed assignment of one cell to each
of the four ordered draw positions is represented by `Fintype.piFinset`.
The six `2+2` assignments and the twenty-four `1+1+1+1` assignments are then
unions of pairwise-disjoint such products.
-/

open scoped BigOperators

namespace QDFull

universe uX

/-- Draws whose value at position `i` lies in the prescribed cell `cells i`. -/
noncomputable def drawsFromCells {X : Type uX} [Fintype X]
    (cells : Fin 4 → Finset X) : Finset (Fin 4 → X) := by
  classical
  exact Fintype.piFinset cells

@[simp] theorem mem_drawsFromCells {X : Type uX} [Fintype X]
    (cells : Fin 4 → Finset X) (draw : Fin 4 → X) :
    draw ∈ drawsFromCells cells ↔ ∀ i, draw i ∈ cells i := by
  classical
  exact Fintype.mem_piFinset

theorem card_drawsFromCells {X : Type uX} [Fintype X]
    (cells : Fin 4 → Finset X) :
    (drawsFromCells cells).card = ∏ i, (cells i).card := by
  classical
  exact Fintype.card_piFinset cells

/-- The cell assignment associated with a set `S` of positions: positions in
`S` draw from `E`, and the other positions draw from `F`. -/
noncomputable def twoTwoCells {X : Type uX}
    (E F : Finset X) (S : Finset (Fin 4)) (i : Fin 4) : Finset X := by
  classical
  exact if i ∈ S then E else F

/-- All ordered draws containing two entries in `E` and two in `F`. -/
noncomputable def twoTwoDraws {X : Type uX} [Fintype X]
    (E F : Finset X) : Finset (Fin 4 → X) := by
  classical
  exact (Finset.univ.powersetCard 2).biUnion fun S =>
    drawsFromCells (twoTwoCells E F S)

@[simp] theorem mem_twoTwoDraws {X : Type uX} [Fintype X]
    (E F : Finset X) (draw : Fin 4 → X) :
    draw ∈ twoTwoDraws E F ↔
      ∃ S ∈ Finset.univ.powersetCard 2,
        ∀ i, draw i ∈ if i ∈ S then E else F := by
  classical
  simp [twoTwoDraws, twoTwoCells]

private theorem exists_position_membership_diff
    {S T : Finset (Fin 4)} (hne : S ≠ T) :
    ∃ i : Fin 4, (i ∈ S) ≠ (i ∈ T) := by
  classical
  by_contra h
  push Not at h
  apply hne
  ext i
  simpa using h i

private theorem twoTwo_pattern_disjoint {X : Type uX} [Fintype X]
    {E F : Finset X} (hEF : Disjoint E F)
    {S T : Finset (Fin 4)} (hne : S ≠ T) :
    Disjoint
      (drawsFromCells (twoTwoCells E F S))
      (drawsFromCells (twoTwoCells E F T)) := by
  classical
  obtain ⟨i, hi⟩ := exists_position_membership_diff hne
  by_cases hiS : i ∈ S
  · have hiT : i ∉ T := by
      intro hiT
      exact hi (propext ⟨fun _ => hiT, fun _ => hiS⟩)
    apply Fintype.piFinset_disjoint_of_disjoint
      (twoTwoCells E F S) (twoTwoCells E F T) (a := i)
    simpa [twoTwoCells, hiS, hiT] using hEF
  · have hiT : i ∈ T := by
      by_contra hiT
      exact hi (propext ⟨fun h => (hiS h).elim, fun h => (hiT h).elim⟩)
    apply Fintype.piFinset_disjoint_of_disjoint
      (twoTwoCells E F S) (twoTwoCells E F T) (a := i)
    simpa [twoTwoCells, hiS, hiT] using hEF.symm

private theorem twoTwo_pairwiseDisjoint {X : Type uX} [Fintype X]
    {E F : Finset X} (hEF : Disjoint E F) :
    ((Finset.univ.powersetCard 2 : Finset (Finset (Fin 4))) :
      Set (Finset (Fin 4))).PairwiseDisjoint
        (fun S => drawsFromCells (twoTwoCells E F S)) := by
  intro S _ T _ hST
  exact twoTwo_pattern_disjoint hEF hST

/-- The six two-element subsets of the four draw positions. -/
theorem fin4_card_two_classification (S : Finset (Fin 4)) (hS : S.card = 2) :
      S = {0, 1} ∨ S = {0, 2} ∨ S = {0, 3} ∨
      S = {1, 2} ∨ S = {1, 3} ∨ S = {2, 3} := by
  revert S
  decide

/-- Membership in the `2+2` draw set written as its six position patterns. -/
theorem mem_twoTwoDraws_iff_six {X : Type uX} [Fintype X]
    (E F : Finset X) (draw : Fin 4 → X) :
    draw ∈ twoTwoDraws E F ↔
      (draw 0 ∈ E ∧ draw 1 ∈ E ∧ draw 2 ∈ F ∧ draw 3 ∈ F) ∨
      (draw 0 ∈ E ∧ draw 2 ∈ E ∧ draw 1 ∈ F ∧ draw 3 ∈ F) ∨
      (draw 0 ∈ E ∧ draw 3 ∈ E ∧ draw 1 ∈ F ∧ draw 2 ∈ F) ∨
      (draw 1 ∈ E ∧ draw 2 ∈ E ∧ draw 0 ∈ F ∧ draw 3 ∈ F) ∨
      (draw 1 ∈ E ∧ draw 3 ∈ E ∧ draw 0 ∈ F ∧ draw 2 ∈ F) ∨
      (draw 2 ∈ E ∧ draw 3 ∈ E ∧ draw 0 ∈ F ∧ draw 1 ∈ F) := by
  classical
  constructor
  · rw [mem_twoTwoDraws]
    rintro ⟨S, hS, hdraw⟩
    have hcard := (Finset.mem_powersetCard.mp hS).2
    rcases fin4_card_two_classification S hcard with
      rfl | rfl | rfl | rfl | rfl | rfl <;>
      simp [Fin.forall_fin_succ] at hdraw <;> aesop
  · intro h
    rw [mem_twoTwoDraws]
    rcases h with h | h | h | h | h | h
    · refine ⟨{0, 1}, by decide, ?_⟩
      simp [Fin.forall_fin_succ]
      aesop
    · refine ⟨{0, 2}, by decide, ?_⟩
      simp [Fin.forall_fin_succ]
      aesop
    · refine ⟨{0, 3}, by decide, ?_⟩
      simp [Fin.forall_fin_succ]
      aesop
    · refine ⟨{1, 2}, by decide, ?_⟩
      simp [Fin.forall_fin_succ]
      aesop
    · refine ⟨{1, 3}, by decide, ?_⟩
      simp [Fin.forall_fin_succ]
      aesop
    · refine ⟨{2, 3}, by decide, ?_⟩
      simp [Fin.forall_fin_succ]
      aesop

private theorem card_twoTwo_pattern {X : Type uX} [Fintype X]
    (E F : Finset X) {S : Finset (Fin 4)} (hS : S.card = 2) :
    (drawsFromCells (twoTwoCells E F S)).card = E.card ^ 2 * F.card ^ 2 := by
  classical
  rw [card_drawsFromCells]
  have hclass := fin4_card_two_classification S hS
  rcases hclass with rfl | rfl | rfl | rfl | rfl | rfl <;>
    simp [twoTwoCells, Fin.prod_univ_succ] <;> ring

/-- Exact multinomial count for two draws from each of two disjoint cells. -/
theorem card_twoTwoDraws {X : Type uX} [Fintype X]
    (E F : Finset X) (hEF : Disjoint E F) :
    (twoTwoDraws E F).card = 6 * E.card ^ 2 * F.card ^ 2 := by
  classical
  unfold twoTwoDraws
  rw [Finset.card_biUnion (twoTwo_pairwiseDisjoint hEF)]
  calc
    ∑ S ∈ Finset.univ.powersetCard 2,
        (drawsFromCells (twoTwoCells E F S)).card =
        ∑ _S ∈ Finset.univ.powersetCard 2, E.card ^ 2 * F.card ^ 2 := by
      apply Finset.sum_congr rfl
      intro S hS
      rw [card_twoTwo_pattern E F]
      simpa using (Finset.mem_powersetCard.mp hS).2
    _ = 6 * E.card ^ 2 * F.card ^ 2 := by
      have hcount :
          (Finset.univ.powersetCard 2 : Finset (Finset (Fin 4))).card = 6 := by
        decide
      simp [hcount, mul_assoc]

/-- Reindex a four-cell assignment by a permutation of the four draw
positions. -/
noncomputable def permutedCells {X : Type uX}
    (cells : Fin 4 → Finset X) (π : Equiv.Perm (Fin 4)) (i : Fin 4) :
    Finset X :=
  cells (π i)

/-- Ordered draws containing one entry from each of four cells, in arbitrary
position order. -/
noncomputable def oneEachDraws {X : Type uX} [Fintype X]
    (cells : Fin 4 → Finset X) : Finset (Fin 4 → X) := by
  classical
  exact Finset.univ.biUnion fun π : Equiv.Perm (Fin 4) =>
    drawsFromCells (permutedCells cells π)

@[simp] theorem mem_oneEachDraws {X : Type uX} [Fintype X]
    (cells : Fin 4 → Finset X) (draw : Fin 4 → X) :
    draw ∈ oneEachDraws cells ↔
      ∃ π : Equiv.Perm (Fin 4), ∀ i, draw i ∈ cells (π i) := by
  classical
  simp [oneEachDraws, permutedCells]

/-- For pairwise-disjoint cells, a four-draw sample contains one entry from
each cell exactly when every cell is hit.  The reverse implication constructs
the permutation from the four chosen hit positions. -/
theorem mem_oneEachDraws_iff_hits_all {X : Type uX} [Fintype X]
    (cells : Fin 4 → Finset X)
    (hdisj : (Set.univ : Set (Fin 4)).PairwiseDisjoint cells)
    (draw : Fin 4 → X) :
    draw ∈ oneEachDraws cells ↔
      ∀ j : Fin 4, ∃ i : Fin 4, draw i ∈ cells j := by
  classical
  constructor
  · rw [mem_oneEachDraws]
    rintro ⟨π, hπ⟩ j
    exact ⟨π.symm j, by simpa using hπ (π.symm j)⟩
  · intro hhit
    choose f hf using hhit
    have hinj : Function.Injective f := by
      intro j k hjk
      by_contra hne
      have hcells : Disjoint (cells j) (cells k) :=
        hdisj (Set.mem_univ _) (Set.mem_univ _) hne
      rw [Finset.disjoint_left] at hcells
      exact hcells (by simpa [hjk] using hf j) (hf k)
    have hbij : Function.Bijective f :=
      (Fintype.bijective_iff_injective_and_card f).2 ⟨hinj, rfl⟩
    let ρ : Equiv.Perm (Fin 4) := Equiv.ofBijective f hbij
    rw [mem_oneEachDraws]
    refine ⟨ρ.symm, ?_⟩
    intro i
    have hi := hf (ρ.symm i)
    change draw (ρ (ρ.symm i)) ∈ cells (ρ.symm i) at hi
    simpa using hi

private theorem permuted_pattern_disjoint {X : Type uX} [Fintype X]
    {cells : Fin 4 → Finset X}
    (hdisj : (Set.univ : Set (Fin 4)).PairwiseDisjoint cells)
    {π σ : Equiv.Perm (Fin 4)} (hne : π ≠ σ) :
    Disjoint
      (drawsFromCells (permutedCells cells π))
      (drawsFromCells (permutedCells cells σ)) := by
  classical
  have hfun : (π : Fin 4 → Fin 4) ≠ σ := by
    intro h
    exact hne (Equiv.ext (fun i => congrFun h i))
  obtain ⟨i, hi⟩ := Function.ne_iff.mp hfun
  apply Fintype.piFinset_disjoint_of_disjoint
    (permutedCells cells π) (permutedCells cells σ) (a := i)
  exact hdisj (Set.mem_univ _) (Set.mem_univ _) hi

private theorem permuted_pairwiseDisjoint {X : Type uX} [Fintype X]
    {cells : Fin 4 → Finset X}
    (hdisj : (Set.univ : Set (Fin 4)).PairwiseDisjoint cells) :
    ((Finset.univ : Finset (Equiv.Perm (Fin 4))) :
      Set (Equiv.Perm (Fin 4))).PairwiseDisjoint
        (fun π => drawsFromCells (permutedCells cells π)) := by
  intro π _ σ _ hπσ
  exact permuted_pattern_disjoint hdisj hπσ

private theorem card_permuted_pattern {X : Type uX} [Fintype X]
    (cells : Fin 4 → Finset X) (π : Equiv.Perm (Fin 4)) :
    (drawsFromCells (permutedCells cells π)).card =
      ∏ i, (cells i).card := by
  classical
  rw [card_drawsFromCells]
  exact Fintype.prod_equiv π
    (fun i => (cells (π i)).card) (fun i => (cells i).card) (fun _ => rfl)

/-- Exact multinomial count for one draw from each of four pairwise-disjoint
cells. -/
theorem card_oneEachDraws {X : Type uX} [Fintype X]
    (cells : Fin 4 → Finset X)
    (hdisj : (Set.univ : Set (Fin 4)).PairwiseDisjoint cells) :
    (oneEachDraws cells).card = 24 * ∏ i, (cells i).card := by
  classical
  unfold oneEachDraws
  rw [Finset.card_biUnion (permuted_pairwiseDisjoint hdisj)]
  calc
    ∑ π : Equiv.Perm (Fin 4),
        (drawsFromCells (permutedCells cells π)).card =
        ∑ _π : Equiv.Perm (Fin 4), ∏ i, (cells i).card := by
      apply Finset.sum_congr rfl
      intro π _
      exact card_permuted_pattern cells π
    _ = 24 * ∏ i, (cells i).card := by
      rw [Finset.sum_const, Finset.card_univ, Fintype.card_perm]
      norm_num

end QDFull
