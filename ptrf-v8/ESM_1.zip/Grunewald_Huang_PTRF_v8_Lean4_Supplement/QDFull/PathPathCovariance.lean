import QDFull.PathEdgeCovariance

/-!
# Path--path covariance identities

This file audits the corresponding part of the manuscript.  It proves the
correct `alpha = 1` and `alpha = 0` formulas, multiplies them without
suppressing either mixed product, and then proves the paper's final local
`q,b,s,p` decomposition directly.  The counterexample retained below is a
regression test for an earlier draft; the locked manuscript is corrected.
-/

open scoped BigOperators

namespace QDFull

universe uX uV₁ uV₂

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]

/-- On two actual directed edges, `X` is the principal joint cell minus the
product of its row and column marginals. -/
theorem xCoefficient_eq_centered_jointMass
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w) :
    xCoefficient T₁ T₂ t u v w =
      jointMass T₁ T₂ t u v w t v -
        T₁.rowMass t u t * T₂.columnMass v w v := by
  rw [xCoefficient_eq_column_contrast T₁ T₂ htu hvw]
  let A := jointMass T₁ T₂ t u v w t v
  let B := jointMass T₁ T₂ t u w v t w
  let r := T₁.rowMass t u t
  let cv := T₂.columnMass v w v
  let cw := T₂.columnMass w v w
  change A * cw - B * cv = A - r * cv
  have hrow : B + A = r := by
    dsimp [A, B, r]
    exact jointMass_edgeSide_partition_column T₁ T₂ t u t hvw
  have hcol : cw + cv = 1 := by
    dsimp [cw, cv]
    exact columnMass_edgeSide_partition T₂ hvw
  have hB : B = r - A := by linarith
  have hcw : cw = 1 - cv := by linarith
  rw [hB, hcw]
  ring

/-- The exact `2 x 2` determinant for two length-two paths. -/
theorem sidePairSidePair_quartetCovariance_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t₁ u t₂ : V₁} {v₁ w v₂ : V₂}
    (ht₁u : T₁.graph.Adj t₁ u) (hut₂ : T₁.graph.Adj u t₂)
    (ht₁t₂ : t₁ ≠ t₂)
    (hv₁w : T₂.graph.Adj v₁ w) (hwv₂ : T₂.graph.Adj w v₂)
    (hv₁v₂ : v₁ ≠ v₂) :
    splitQuartetCovariance
        (T₁.sidePairSplit t₁ u t₂) (T₂.sidePairSplit v₁ w v₂) =
      6 *
        (jointMass T₁ T₂ t₁ u v₁ w t₂ v₂ *
              jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ -
            jointMass T₁ T₂ t₁ u v₂ w t₂ v₁ *
              jointMass T₁ T₂ t₂ u v₁ w t₁ v₂) ^ 2 := by
  change orientedSplitCovariance
      (T₁.edgeSide u t₁) (T₁.edgeSide u t₂)
      (T₂.edgeSide w v₁) (T₂.edgeSide w v₂) = _
  unfold orientedSplitCovariance orientedSplitDeterminant
  unfold jointMass jointBlock
  rw [T₁.rowBlock_of_adj t₁ hut₂,
    T₁.rowBlock_of_adj t₂ ht₁u.symm,
    T₂.columnBlock_of_adj v₁ hwv₂,
    T₂.columnBlock_of_adj v₂ hv₁w.symm]
  ring

/-- The `alpha = 1` representation used by the current manuscript: the first
coefficient is the `t₁,v₂` cell, and the first bracket uses the two `X`
coordinates with row endpoint `t₂`. -/
theorem pathPath_determinant_alpha_one
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t₁ u t₂ : V₁} {v₁ w v₂ : V₂}
    (ht₁u : T₁.graph.Adj t₁ u) (hut₂ : T₁.graph.Adj u t₂)
    (hv₁w : T₂.graph.Adj v₁ w) (hwv₂ : T₂.graph.Adj w v₂) :
    jointMass T₁ T₂ t₁ u v₁ w t₂ v₂ *
          jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ -
        jointMass T₁ T₂ t₁ u v₂ w t₂ v₁ *
          jointMass T₁ T₂ t₂ u v₁ w t₁ v₂ =
      jointMass T₁ T₂ t₂ u v₁ w t₁ v₂ /
          T₂.columnMass v₁ w v₂ *
        (T₂.columnMass v₂ w v₁ * xCoefficient T₁ T₂ t₂ u v₂ w -
          T₂.columnMass v₁ w v₂ * xCoefficient T₁ T₂ t₂ u v₁ w) -
      jointMass T₁ T₂ t₁ u v₁ w t₂ v₂ /
          T₂.columnMass v₁ w v₂ *
        (T₂.columnMass v₂ w v₁ * xCoefficient T₁ T₂ t₁ u v₂ w -
          T₂.columnMass v₁ w v₂ * xCoefficient T₁ T₂ t₁ u v₁ w) := by
  have hx₂₂ := xCoefficient_eq_centered_jointMass
    T₁ T₂ hut₂.symm hwv₂.symm
  have hx₂₁ := xCoefficient_eq_centered_jointMass
    T₁ T₂ hut₂.symm hv₁w
  have hx₁₂ := xCoefficient_eq_centered_jointMass
    T₁ T₂ ht₁u hwv₂.symm
  have hx₁₁ := xCoefficient_eq_centered_jointMass
    T₁ T₂ ht₁u hv₁w
  let A := jointMass T₁ T₂ t₁ u v₁ w t₂ v₂
  let B := jointMass T₁ T₂ t₁ u v₂ w t₂ v₁
  let C := jointMass T₁ T₂ t₂ u v₁ w t₁ v₂
  let D := jointMass T₁ T₂ t₂ u v₂ w t₁ v₁
  let r₁ := T₁.rowMass t₁ u t₁
  let r₂ := T₁.rowMass t₂ u t₂
  let c₁ := T₂.columnMass v₂ w v₁
  let c₂ := T₂.columnMass v₁ w v₂
  change xCoefficient T₁ T₂ t₂ u v₂ w = A - r₂ * c₂ at hx₂₂
  change xCoefficient T₁ T₂ t₂ u v₁ w = B - r₂ * c₁ at hx₂₁
  change xCoefficient T₁ T₂ t₁ u v₂ w = C - r₁ * c₂ at hx₁₂
  change xCoefficient T₁ T₂ t₁ u v₁ w = D - r₁ * c₁ at hx₁₁
  change A * D - B * C =
    C / c₂ * (c₁ * xCoefficient T₁ T₂ t₂ u v₂ w -
      c₂ * xCoefficient T₁ T₂ t₂ u v₁ w) -
    A / c₂ * (c₁ * xCoefficient T₁ T₂ t₁ u v₂ w -
      c₂ * xCoefficient T₁ T₂ t₁ u v₁ w)
  rw [hx₂₂, hx₂₁, hx₁₂, hx₁₁]
  have hc₂ : c₂ ≠ 0 := by
    dsimp [c₂]
    exact ne_of_gt (T₂.columnMass_pos_of_adj hwv₂.symm)
  field_simp [hc₂]
  ring

/-- Corrected `alpha = 0` representation.  The first bracket again uses the
two `X` coordinates with row endpoint `t₂`. -/
theorem pathPath_determinant_alpha_zero
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t₁ u t₂ : V₁} {v₁ w v₂ : V₂}
    (ht₁u : T₁.graph.Adj t₁ u) (hut₂ : T₁.graph.Adj u t₂)
    (hv₁w : T₂.graph.Adj v₁ w) (hwv₂ : T₂.graph.Adj w v₂) :
    jointMass T₁ T₂ t₁ u v₁ w t₂ v₂ *
          jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ -
        jointMass T₁ T₂ t₁ u v₂ w t₂ v₁ *
          jointMass T₁ T₂ t₂ u v₁ w t₁ v₂ =
      jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ /
          T₂.columnMass v₂ w v₁ *
        (T₂.columnMass v₂ w v₁ * xCoefficient T₁ T₂ t₂ u v₂ w -
          T₂.columnMass v₁ w v₂ * xCoefficient T₁ T₂ t₂ u v₁ w) -
      jointMass T₁ T₂ t₁ u v₂ w t₂ v₁ /
          T₂.columnMass v₂ w v₁ *
        (T₂.columnMass v₂ w v₁ * xCoefficient T₁ T₂ t₁ u v₂ w -
          T₂.columnMass v₁ w v₂ * xCoefficient T₁ T₂ t₁ u v₁ w) := by
  have hx₂₂ := xCoefficient_eq_centered_jointMass
    T₁ T₂ hut₂.symm hwv₂.symm
  have hx₂₁ := xCoefficient_eq_centered_jointMass
    T₁ T₂ hut₂.symm hv₁w
  have hx₁₂ := xCoefficient_eq_centered_jointMass
    T₁ T₂ ht₁u hwv₂.symm
  have hx₁₁ := xCoefficient_eq_centered_jointMass
    T₁ T₂ ht₁u hv₁w
  let A := jointMass T₁ T₂ t₁ u v₁ w t₂ v₂
  let B := jointMass T₁ T₂ t₁ u v₂ w t₂ v₁
  let C := jointMass T₁ T₂ t₂ u v₁ w t₁ v₂
  let D := jointMass T₁ T₂ t₂ u v₂ w t₁ v₁
  let r₁ := T₁.rowMass t₁ u t₁
  let r₂ := T₁.rowMass t₂ u t₂
  let c₁ := T₂.columnMass v₂ w v₁
  let c₂ := T₂.columnMass v₁ w v₂
  change xCoefficient T₁ T₂ t₂ u v₂ w = A - r₂ * c₂ at hx₂₂
  change xCoefficient T₁ T₂ t₂ u v₁ w = B - r₂ * c₁ at hx₂₁
  change xCoefficient T₁ T₂ t₁ u v₂ w = C - r₁ * c₂ at hx₁₂
  change xCoefficient T₁ T₂ t₁ u v₁ w = D - r₁ * c₁ at hx₁₁
  change A * D - B * C =
    D / c₁ * (c₁ * xCoefficient T₁ T₂ t₂ u v₂ w -
      c₂ * xCoefficient T₁ T₂ t₂ u v₁ w) -
    B / c₁ * (c₁ * xCoefficient T₁ T₂ t₁ u v₂ w -
      c₂ * xCoefficient T₁ T₂ t₁ u v₁ w)
  rw [hx₂₂, hx₂₁, hx₁₂, hx₁₁]
  have hc₁ : c₁ ≠ 0 := by
    dsimp [c₁]
    exact ne_of_gt (T₂.columnMass_pos_of_adj hv₁w)
  field_simp [hc₁]
  ring

/-- The product of the two corrected determinant representations. -/
theorem pathPath_quartetCovariance_product_expansion
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t₁ u t₂ : V₁} {v₁ w v₂ : V₂}
    (ht₁u : T₁.graph.Adj t₁ u) (hut₂ : T₁.graph.Adj u t₂)
    (ht₁t₂ : t₁ ≠ t₂)
    (hv₁w : T₂.graph.Adj v₁ w) (hwv₂ : T₂.graph.Adj w v₂)
    (hv₁v₂ : v₁ ≠ v₂) :
    (1 / 6 : ℝ) * splitQuartetCovariance
        (T₁.sidePairSplit t₁ u t₂) (T₂.sidePairSplit v₁ w v₂) =
      (jointMass T₁ T₂ t₂ u v₁ w t₁ v₂ /
            T₂.columnMass v₁ w v₂ *
          (T₂.columnMass v₂ w v₁ * xCoefficient T₁ T₂ t₂ u v₂ w -
            T₂.columnMass v₁ w v₂ * xCoefficient T₁ T₂ t₂ u v₁ w) -
        jointMass T₁ T₂ t₁ u v₁ w t₂ v₂ /
            T₂.columnMass v₁ w v₂ *
          (T₂.columnMass v₂ w v₁ * xCoefficient T₁ T₂ t₁ u v₂ w -
            T₂.columnMass v₁ w v₂ * xCoefficient T₁ T₂ t₁ u v₁ w)) *
      (jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ /
            T₂.columnMass v₂ w v₁ *
          (T₂.columnMass v₂ w v₁ * xCoefficient T₁ T₂ t₂ u v₂ w -
            T₂.columnMass v₁ w v₂ * xCoefficient T₁ T₂ t₂ u v₁ w) -
        jointMass T₁ T₂ t₁ u v₂ w t₂ v₁ /
            T₂.columnMass v₂ w v₁ *
          (T₂.columnMass v₂ w v₁ * xCoefficient T₁ T₂ t₁ u v₂ w -
            T₂.columnMass v₁ w v₂ * xCoefficient T₁ T₂ t₁ u v₁ w)) := by
  rw [sidePairSidePair_quartetCovariance_eq T₁ T₂ ht₁u hut₂ ht₁t₂
      hv₁w hwv₂ hv₁v₂]
  let det := jointMass T₁ T₂ t₁ u v₁ w t₂ v₂ *
      jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ -
    jointMass T₁ T₂ t₁ u v₂ w t₂ v₁ *
      jointMass T₁ T₂ t₂ u v₁ w t₁ v₂
  have h₁ := pathPath_determinant_alpha_one T₁ T₂ ht₁u hut₂ hv₁w hwv₂
  have h₀ := pathPath_determinant_alpha_zero T₁ T₂ ht₁u hut₂ hv₁w hwv₂
  change (1 / 6 : ℝ) * (6 * det ^ 2) = _
  change det = _ at h₁
  change det = _ at h₀
  calc
    (1 / 6 : ℝ) * (6 * det ^ 2) = det * det := by ring
    _ =
        (jointMass T₁ T₂ t₂ u v₁ w t₁ v₂ /
              T₂.columnMass v₁ w v₂ *
            (T₂.columnMass v₂ w v₁ * xCoefficient T₁ T₂ t₂ u v₂ w -
              T₂.columnMass v₁ w v₂ * xCoefficient T₁ T₂ t₂ u v₁ w) -
          jointMass T₁ T₂ t₁ u v₁ w t₂ v₂ /
              T₂.columnMass v₁ w v₂ *
            (T₂.columnMass v₂ w v₁ * xCoefficient T₁ T₂ t₁ u v₂ w -
              T₂.columnMass v₁ w v₂ * xCoefficient T₁ T₂ t₁ u v₁ w)) * det := by
          rw [h₁]
    _ = _ := by rw [h₀]

/-- First diagonal `q` coefficient in the path--path expansion. -/
theorem pathPath_q_t₁_v₁_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t₁ u t₂ : V₁) (v₁ w v₂ : V₂) :
    qCoefficient T₁ T₂ t₁ u v₁ w t₂ t₂ v₂ v₂ =
      T₂.columnMass v₁ w v₂ *
        jointMass T₁ T₂ t₁ u v₁ w t₂ v₂ *
        jointMass T₁ T₂ t₁ u v₂ w t₂ v₁ /
          T₂.columnMass v₂ w v₁ := by
  unfold qCoefficient
  change (1 / 2 : ℝ) * T₂.columnMass v₁ w v₂ *
      (jointMass T₁ T₂ t₁ u v₁ w t₂ v₂ *
          jointMass T₁ T₂ t₁ u v₂ w t₂ v₁ /
            T₂.columnMass v₂ w v₁ +
        jointMass T₁ T₂ t₁ u v₁ w t₂ v₂ *
          jointMass T₁ T₂ t₁ u v₂ w t₂ v₁ /
            T₂.columnMass v₂ w v₁) = _
  ring

/-- Second diagonal `q` coefficient in the first row orientation. -/
theorem pathPath_q_t₁_v₂_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t₁ u t₂ : V₁) (v₁ w v₂ : V₂) :
    qCoefficient T₁ T₂ t₁ u v₂ w t₂ t₂ v₁ v₁ =
      T₂.columnMass v₂ w v₁ *
        jointMass T₁ T₂ t₁ u v₂ w t₂ v₁ *
        jointMass T₁ T₂ t₁ u v₁ w t₂ v₂ /
          T₂.columnMass v₁ w v₂ := by
  unfold qCoefficient
  change (1 / 2 : ℝ) * T₂.columnMass v₂ w v₁ *
      (jointMass T₁ T₂ t₁ u v₂ w t₂ v₁ *
          jointMass T₁ T₂ t₁ u v₁ w t₂ v₂ /
            T₂.columnMass v₁ w v₂ +
        jointMass T₁ T₂ t₁ u v₂ w t₂ v₁ *
          jointMass T₁ T₂ t₁ u v₁ w t₂ v₂ /
            T₂.columnMass v₁ w v₂) = _
  ring

/-- First diagonal `q` coefficient in the second row orientation. -/
theorem pathPath_q_t₂_v₁_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t₁ u t₂ : V₁) (v₁ w v₂ : V₂) :
    qCoefficient T₁ T₂ t₂ u v₁ w t₁ t₁ v₂ v₂ =
      T₂.columnMass v₁ w v₂ *
        jointMass T₁ T₂ t₂ u v₁ w t₁ v₂ *
        jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ /
          T₂.columnMass v₂ w v₁ := by
  unfold qCoefficient
  change (1 / 2 : ℝ) * T₂.columnMass v₁ w v₂ *
      (jointMass T₁ T₂ t₂ u v₁ w t₁ v₂ *
          jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ /
            T₂.columnMass v₂ w v₁ +
        jointMass T₁ T₂ t₂ u v₁ w t₁ v₂ *
          jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ /
            T₂.columnMass v₂ w v₁) = _
  ring

/-- Second diagonal `q` coefficient in the second row orientation. -/
theorem pathPath_q_t₂_v₂_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t₁ u t₂ : V₁) (v₁ w v₂ : V₂) :
    qCoefficient T₁ T₂ t₂ u v₂ w t₁ t₁ v₁ v₁ =
      T₂.columnMass v₂ w v₁ *
        jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ *
        jointMass T₁ T₂ t₂ u v₁ w t₁ v₂ /
          T₂.columnMass v₁ w v₂ := by
  unfold qCoefficient
  change (1 / 2 : ℝ) * T₂.columnMass v₂ w v₁ *
      (jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ *
          jointMass T₁ T₂ t₂ u v₁ w t₁ v₂ /
            T₂.columnMass v₁ w v₂ +
        jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ *
          jointMass T₁ T₂ t₂ u v₁ w t₁ v₂ /
            T₂.columnMass v₁ w v₂) = _
  ring

/-- Same-column mixed coefficient for column endpoint `v₁`. -/
theorem pathPath_b_v₁_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t₁ u t₂ : V₁) (v₁ w v₂ : V₂) :
    bCoefficient T₁ T₂ t₁ u t₂ v₁ w v₂ v₂ =
      T₂.columnMass v₁ w v₂ *
        (jointMass T₁ T₂ t₁ u v₁ w t₂ v₂ *
            jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ +
          jointMass T₁ T₂ t₂ u v₁ w t₁ v₂ *
            jointMass T₁ T₂ t₁ u v₂ w t₂ v₁) /
          (2 * T₂.columnMass v₂ w v₁) := by
  unfold bCoefficient qCoefficient
  have hD : jointMass T₁ T₂ t₁ u v₁ w t₁ v₁ =
      jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ := by rfl
  have hC : jointMass T₁ T₂ t₁ u v₁ w t₁ v₂ =
      jointMass T₁ T₂ t₂ u v₁ w t₁ v₂ := by rfl
  have hB : jointMass T₁ T₂ t₁ u v₁ w t₂ v₁ =
      jointMass T₁ T₂ t₁ u v₂ w t₂ v₁ := by rfl
  have hc₁ : T₂.columnMass v₁ w v₁ = T₂.columnMass v₂ w v₁ := by rfl
  rw [hD, hC, hB, hc₁]
  ring

/-- Same-column mixed coefficient for column endpoint `v₂`. -/
theorem pathPath_b_v₂_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t₁ u t₂ : V₁) (v₁ w v₂ : V₂) :
    bCoefficient T₁ T₂ t₁ u t₂ v₂ w v₁ v₁ =
      T₂.columnMass v₂ w v₁ *
        (jointMass T₁ T₂ t₁ u v₂ w t₂ v₁ *
            jointMass T₁ T₂ t₂ u v₁ w t₁ v₂ +
          jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ *
            jointMass T₁ T₂ t₁ u v₁ w t₂ v₂) /
          (2 * T₂.columnMass v₁ w v₂) := by
  unfold bCoefficient qCoefficient
  have hC : jointMass T₁ T₂ t₁ u v₂ w t₁ v₂ =
      jointMass T₁ T₂ t₂ u v₁ w t₁ v₂ := by rfl
  have hD : jointMass T₁ T₂ t₁ u v₂ w t₁ v₁ =
      jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ := by rfl
  have hA : jointMass T₁ T₂ t₁ u v₂ w t₂ v₂ =
      jointMass T₁ T₂ t₁ u v₁ w t₂ v₂ := by rfl
  have hc₂ : T₂.columnMass v₂ w v₂ = T₂.columnMass v₁ w v₂ := by rfl
  rw [hC, hD, hA, hc₂]
  ring

/-- Same-row mixed coefficient for row endpoint `t₁`. -/
theorem pathPath_s_t₁_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t₁ u t₂ : V₁) (v₁ w v₂ : V₂)
    (hv₁w : T₂.graph.Adj v₁ w) :
    sCoefficient T₁ T₂ t₁ u t₂ t₂ v₁ w v₂ =
      jointMass T₁ T₂ t₁ u v₁ w t₂ v₂ *
        jointMass T₁ T₂ t₁ u v₂ w t₂ v₁ := by
  unfold sCoefficient qCoefficient
  have hB : jointMass T₁ T₂ t₁ u v₁ w t₂ v₁ =
      jointMass T₁ T₂ t₁ u v₂ w t₂ v₁ := by rfl
  have hc₁ : T₂.columnMass v₁ w v₁ = T₂.columnMass v₂ w v₁ := by rfl
  rw [hB, hc₁]
  have hc₁ne : T₂.columnMass v₂ w v₁ ≠ 0 := by
    exact ne_of_gt (T₂.columnMass_pos_of_adj hv₁w)
  field_simp [hc₁ne]
  ring

/-- Same-row mixed coefficient for row endpoint `t₂`. -/
theorem pathPath_s_t₂_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t₁ u t₂ : V₁) (v₁ w v₂ : V₂)
    (hv₁w : T₂.graph.Adj v₁ w) :
    sCoefficient T₁ T₂ t₂ u t₁ t₁ v₁ w v₂ =
      jointMass T₁ T₂ t₂ u v₁ w t₁ v₂ *
        jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ := by
  unfold sCoefficient qCoefficient
  have hD : jointMass T₁ T₂ t₂ u v₁ w t₁ v₁ =
      jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ := by rfl
  have hc₁ : T₂.columnMass v₁ w v₁ = T₂.columnMass v₂ w v₁ := by rfl
  rw [hD, hc₁]
  have hc₁ne : T₂.columnMass v₂ w v₁ ≠ 0 := by
    exact ne_of_gt (T₂.columnMass_pos_of_adj hv₁w)
  field_simp [hc₁ne]
  ring

/-- The cross-diagonal `p` coefficient in the path--path block. -/
theorem pathPath_p_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t₁ u t₂ : V₁) (v₁ w v₂ : V₂)
    (hv₁w : T₂.graph.Adj v₁ w) :
    pCoefficient T₁ T₂ t₁ u t₂ v₁ w v₂ =
      (jointMass T₁ T₂ t₁ u v₁ w t₂ v₂ *
            jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ +
          jointMass T₁ T₂ t₂ u v₁ w t₁ v₂ *
          jointMass T₁ T₂ t₁ u v₂ w t₂ v₁) / 2 := by
  unfold pCoefficient qCoefficient
  have hD : jointMass T₁ T₂ t₁ u v₁ w t₁ v₁ =
      jointMass T₁ T₂ t₂ u v₂ w t₁ v₁ := by rfl
  have hC : jointMass T₁ T₂ t₁ u v₁ w t₁ v₂ =
      jointMass T₁ T₂ t₂ u v₁ w t₁ v₂ := by rfl
  have hB : jointMass T₁ T₂ t₁ u v₁ w t₂ v₁ =
      jointMass T₁ T₂ t₁ u v₂ w t₂ v₁ := by rfl
  have hc₁ : T₂.columnMass v₁ w v₁ = T₂.columnMass v₂ w v₁ := by rfl
  rw [hD, hC, hB, hc₁]
  have hc₁ne : T₂.columnMass v₂ w v₁ ≠ 0 := by
    exact ne_of_gt (T₂.columnMass_pos_of_adj hv₁w)
  field_simp [hc₁ne]

/-- Exact local version of equation `(path-path)`.  All four diagonal `q`
terms and every `b`, `s`, and `p` mixed monomial are shown explicitly. -/
theorem pathPath_local_qbsp_decomposition
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t₁ u t₂ : V₁} {v₁ w v₂ : V₂}
    (ht₁u : T₁.graph.Adj t₁ u) (hut₂ : T₁.graph.Adj u t₂)
    (ht₁t₂ : t₁ ≠ t₂)
    (hv₁w : T₂.graph.Adj v₁ w) (hwv₂ : T₂.graph.Adj w v₂)
    (hv₁v₂ : v₁ ≠ v₂) :
    (1 / 6 : ℝ) * splitQuartetCovariance
        (T₁.sidePairSplit t₁ u t₂) (T₂.sidePairSplit v₁ w v₂) =
      qCoefficient T₁ T₂ t₁ u v₁ w t₂ t₂ v₂ v₂ *
          xCoefficient T₁ T₂ t₁ u v₁ w ^ 2 +
      qCoefficient T₁ T₂ t₁ u v₂ w t₂ t₂ v₁ v₁ *
          xCoefficient T₁ T₂ t₁ u v₂ w ^ 2 +
      qCoefficient T₁ T₂ t₂ u v₁ w t₁ t₁ v₂ v₂ *
          xCoefficient T₁ T₂ t₂ u v₁ w ^ 2 +
      qCoefficient T₁ T₂ t₂ u v₂ w t₁ t₁ v₁ v₁ *
          xCoefficient T₁ T₂ t₂ u v₂ w ^ 2 -
      2 * (bCoefficient T₁ T₂ t₁ u t₂ v₁ w v₂ v₂ *
          xCoefficient T₁ T₂ t₁ u v₁ w *
            xCoefficient T₁ T₂ t₂ u v₁ w +
        bCoefficient T₁ T₂ t₁ u t₂ v₂ w v₁ v₁ *
          xCoefficient T₁ T₂ t₁ u v₂ w *
            xCoefficient T₁ T₂ t₂ u v₂ w) -
      2 * (sCoefficient T₁ T₂ t₁ u t₂ t₂ v₁ w v₂ *
          xCoefficient T₁ T₂ t₁ u v₁ w *
            xCoefficient T₁ T₂ t₁ u v₂ w +
        sCoefficient T₁ T₂ t₂ u t₁ t₁ v₁ w v₂ *
          xCoefficient T₁ T₂ t₂ u v₁ w *
            xCoefficient T₁ T₂ t₂ u v₂ w) +
      2 * pCoefficient T₁ T₂ t₁ u t₂ v₁ w v₂ *
        (xCoefficient T₁ T₂ t₁ u v₁ w *
            xCoefficient T₁ T₂ t₂ u v₂ w +
          xCoefficient T₁ T₂ t₁ u v₂ w *
            xCoefficient T₁ T₂ t₂ u v₁ w) := by
  rw [sidePairSidePair_quartetCovariance_eq T₁ T₂ ht₁u hut₂ ht₁t₂
      hv₁w hwv₂ hv₁v₂]
  have hx₂₂ := xCoefficient_eq_centered_jointMass
    T₁ T₂ hut₂.symm hwv₂.symm
  have hx₂₁ := xCoefficient_eq_centered_jointMass
    T₁ T₂ hut₂.symm hv₁w
  have hx₁₂ := xCoefficient_eq_centered_jointMass
    T₁ T₂ ht₁u hwv₂.symm
  have hx₁₁ := xCoefficient_eq_centered_jointMass
    T₁ T₂ ht₁u hv₁w
  let A := jointMass T₁ T₂ t₁ u v₁ w t₂ v₂
  let B := jointMass T₁ T₂ t₁ u v₂ w t₂ v₁
  let C := jointMass T₁ T₂ t₂ u v₁ w t₁ v₂
  let D := jointMass T₁ T₂ t₂ u v₂ w t₁ v₁
  let r₁ := T₁.rowMass t₁ u t₁
  let r₂ := T₁.rowMass t₂ u t₂
  let c₁ := T₂.columnMass v₂ w v₁
  let c₂ := T₂.columnMass v₁ w v₂
  change xCoefficient T₁ T₂ t₂ u v₂ w = A - r₂ * c₂ at hx₂₂
  change xCoefficient T₁ T₂ t₂ u v₁ w = B - r₂ * c₁ at hx₂₁
  change xCoefficient T₁ T₂ t₁ u v₂ w = C - r₁ * c₂ at hx₁₂
  change xCoefficient T₁ T₂ t₁ u v₁ w = D - r₁ * c₁ at hx₁₁
  rw [pathPath_q_t₁_v₁_eq T₁ T₂ t₁ u t₂ v₁ w v₂,
    pathPath_q_t₁_v₂_eq T₁ T₂ t₁ u t₂ v₁ w v₂,
    pathPath_q_t₂_v₁_eq T₁ T₂ t₁ u t₂ v₁ w v₂,
    pathPath_q_t₂_v₂_eq T₁ T₂ t₁ u t₂ v₁ w v₂,
    pathPath_b_v₁_eq T₁ T₂ t₁ u t₂ v₁ w v₂,
    pathPath_b_v₂_eq T₁ T₂ t₁ u t₂ v₁ w v₂,
    pathPath_s_t₁_eq T₁ T₂ t₁ u t₂ v₁ w v₂ hv₁w,
    pathPath_s_t₂_eq T₁ T₂ t₁ u t₂ v₁ w v₂ hv₁w,
    pathPath_p_eq T₁ T₂ t₁ u t₂ v₁ w v₂ hv₁w]
  rw [hx₂₂, hx₂₁, hx₁₂, hx₁₁]
  have hc₁ : c₁ ≠ 0 := by
    dsimp [c₁]
    exact ne_of_gt (T₂.columnMass_pos_of_adj hv₁w)
  have hc₂ : c₂ ≠ 0 := by
    dsimp [c₂]
    exact ne_of_gt (T₂.columnMass_pos_of_adj hwv₂.symm)
  change (1 / 6 : ℝ) * (6 * (A * D - B * C) ^ 2) =
    (c₂ * A * B / c₁) * (D - r₁ * c₁) ^ 2 +
    (c₁ * B * A / c₂) * (C - r₁ * c₂) ^ 2 +
    (c₂ * C * D / c₁) * (B - r₂ * c₁) ^ 2 +
    (c₁ * D * C / c₂) * (A - r₂ * c₂) ^ 2 -
    2 * ((c₂ * (A * D + C * B) / (2 * c₁)) *
          (D - r₁ * c₁) * (B - r₂ * c₁) +
        (c₁ * (B * C + D * A) / (2 * c₂)) *
          (C - r₁ * c₂) * (A - r₂ * c₂)) -
    2 * (A * B * (D - r₁ * c₁) * (C - r₁ * c₂) +
      C * D * (B - r₂ * c₁) * (A - r₂ * c₂)) +
    2 * ((A * D + C * B) / 2) *
      ((D - r₁ * c₁) * (A - r₂ * c₂) +
        (C - r₁ * c₂) * (B - r₂ * c₁))
  field_simp [hc₁, hc₂]
  ring

/-- Regression test for two path--path `alpha` formulas in an earlier draft.
The current locked manuscript uses the corrected formulas.  The table has corner cells
`(D,C;B,A)=(5,8;12,20)/100`, row masses `1/5,9/20`, and column masses
`27/100,38/100`. -/
theorem printed_pathPath_alpha_counterexample :
    let A : ℝ := 1 / 5
    let B : ℝ := 3 / 25
    let C : ℝ := 2 / 25
    let D : ℝ := 1 / 20
    let r₁ : ℝ := 1 / 5
    let r₂ : ℝ := 9 / 20
    let c₁ : ℝ := 27 / 100
    let c₂ : ℝ := 19 / 50
    let X₂₂ := A - r₂ * c₂
    let X₂₁ := B - r₂ * c₁
    let X₁₂ := C - r₁ * c₂
    let X₁₁ := D - r₁ * c₁
    A * D - B * C = 1 / 2500 ∧
      A * D - B * C ≠
        D / c₂ * (c₁ * X₂₂ - c₂ * X₁₂) -
          A / c₂ * (c₁ * X₁₂ - c₂ * X₁₁) ∧
      A * D - B * C ≠
        D / c₁ * (c₁ * X₂₂ - c₂ * X₁₂) -
          B / c₁ * (c₁ * X₁₂ - c₂ * X₁₁) := by
  norm_num

end QDFull
