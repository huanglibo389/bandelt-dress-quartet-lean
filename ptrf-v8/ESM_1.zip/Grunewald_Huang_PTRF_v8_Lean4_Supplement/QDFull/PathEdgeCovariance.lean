import QDFull.MixedCovariance

/-!
# Path--edge covariance identities

This file audits the corresponding part of the manuscript.  The determinant
and the two `alpha` representations are formalized exactly.  Multiplying the
two representations produces two mixed products; this is also what the
`b`-coefficient partition yields.
-/

open scoped BigOperators

namespace QDFull

universe uX uV₁ uV₂

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]

/-- A directed edge coordinate can be written using its two principal row
cells and the two column-side masses. -/
theorem xCoefficient_eq_column_contrast
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w) :
    xCoefficient T₁ T₂ t u v w =
      jointMass T₁ T₂ t u v w t v * T₂.columnMass w v w -
        jointMass T₁ T₂ t u w v t w * T₂.columnMass v w v := by
  have hwcomp :
      jointMass T₁ T₂ u t w v u w =
        T₂.columnMass w v w - jointMass T₁ T₂ t u w v t w := by
    have h := jointMass_edgeSide_partition_row T₁ T₂ htu w v w
    linarith
  have hvcomp :
      jointMass T₁ T₂ u t v w u v =
        T₂.columnMass v w v - jointMass T₁ T₂ t u v w t v := by
    have h := jointMass_edgeSide_partition_row T₁ T₂ htu v w v
    linarith
  unfold xCoefficient
  rw [hwcomp, hvcomp]
  ring

/-- The exact `2 x 2` determinant for a length-two path against an edge. -/
theorem sidePairEdge_quartetCovariance_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t₁ u t₂ : V₁} {v w : V₂}
    (ht₁u : T₁.graph.Adj t₁ u) (hut₂ : T₁.graph.Adj u t₂)
    (ht₁t₂ : t₁ ≠ t₂) (hvw : T₂.graph.Adj v w) :
    splitQuartetCovariance
        (T₁.sidePairSplit t₁ u t₂) (T₂.edgeSplit v w) =
      6 *
        (jointMass T₁ T₂ t₁ u v w t₂ v *
              jointMass T₁ T₂ t₂ u w v t₁ w -
            jointMass T₁ T₂ t₁ u w v t₂ w *
              jointMass T₁ T₂ t₂ u v w t₁ v) ^ 2 := by
  change orientedSplitCovariance
      (T₁.edgeSide u t₁) (T₁.edgeSide u t₂)
      (T₂.edgeSide v w) (T₂.edgeSide w v) = _
  unfold orientedSplitCovariance orientedSplitDeterminant
  unfold jointMass jointBlock
  rw [T₁.rowBlock_of_adj t₁ hut₂,
    T₁.rowBlock_of_adj t₂ ht₁u.symm,
    T₂.columnBlock_of_adj v hvw.symm,
    T₂.columnBlock_of_adj w hvw]
  ring

/-- The `alpha = 1` determinant representation for the path--edge block. -/
theorem pathEdge_determinant_alpha_one
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t₁ u t₂ : V₁} {v w : V₂}
    (ht₁u : T₁.graph.Adj t₁ u) (hut₂ : T₁.graph.Adj u t₂)
    (hvw : T₂.graph.Adj v w) :
    jointMass T₁ T₂ t₁ u v w t₂ v *
          jointMass T₁ T₂ t₂ u w v t₁ w -
        jointMass T₁ T₂ t₁ u w v t₂ w *
          jointMass T₁ T₂ t₂ u v w t₁ v =
      jointMass T₁ T₂ t₂ u v w t₁ v / T₂.columnMass v w v *
          xCoefficient T₁ T₂ t₂ u v w -
        jointMass T₁ T₂ t₁ u v w t₂ v / T₂.columnMass v w v *
          xCoefficient T₁ T₂ t₁ u v w := by
  rw [xCoefficient_eq_column_contrast T₁ T₂ hut₂.symm hvw,
    xCoefficient_eq_column_contrast T₁ T₂ ht₁u hvw]
  let P := jointMass T₁ T₂ t₁ u v w t₂ v
  let Q := jointMass T₁ T₂ t₁ u w v t₂ w
  let R := jointMass T₁ T₂ t₂ u v w t₁ v
  let S := jointMass T₁ T₂ t₂ u w v t₁ w
  let cv := T₂.columnMass v w v
  let cw := T₂.columnMass w v w
  change P * S - Q * R = R / cv * (P * cw - Q * cv) -
    P / cv * (R * cw - S * cv)
  have hcv : T₂.columnMass v w v ≠ 0 :=
    ne_of_gt (T₂.columnMass_pos_of_adj hvw)
  have hcv' : cv ≠ 0 := by simpa [cv] using hcv
  field_simp [hcv']
  ring

/-- The `alpha = 0` determinant representation for the path--edge block. -/
theorem pathEdge_determinant_alpha_zero
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t₁ u t₂ : V₁} {v w : V₂}
    (ht₁u : T₁.graph.Adj t₁ u) (hut₂ : T₁.graph.Adj u t₂)
    (hvw : T₂.graph.Adj v w) :
    jointMass T₁ T₂ t₁ u v w t₂ v *
          jointMass T₁ T₂ t₂ u w v t₁ w -
        jointMass T₁ T₂ t₁ u w v t₂ w *
          jointMass T₁ T₂ t₂ u v w t₁ v =
      jointMass T₁ T₂ t₂ u w v t₁ w / T₂.columnMass w v w *
          xCoefficient T₁ T₂ t₂ u v w -
        jointMass T₁ T₂ t₁ u w v t₂ w / T₂.columnMass w v w *
          xCoefficient T₁ T₂ t₁ u v w := by
  rw [xCoefficient_eq_column_contrast T₁ T₂ hut₂.symm hvw,
    xCoefficient_eq_column_contrast T₁ T₂ ht₁u hvw]
  let P := jointMass T₁ T₂ t₁ u v w t₂ v
  let Q := jointMass T₁ T₂ t₁ u w v t₂ w
  let R := jointMass T₁ T₂ t₂ u v w t₁ v
  let S := jointMass T₁ T₂ t₂ u w v t₁ w
  let cv := T₂.columnMass v w v
  let cw := T₂.columnMass w v w
  change P * S - Q * R = S / cw * (P * cw - Q * cv) -
    Q / cw * (R * cw - S * cv)
  have hcw : T₂.columnMass w v w ≠ 0 :=
    ne_of_gt (T₂.columnMass_pos_of_adj hvw.symm)
  have hcw' : cw ≠ 0 := by simpa [cw] using hcw
  field_simp [hcw']
  ring

/-- Multiplying the two preceding determinant representations gives the
four-term product.  Both mixed products are present. -/
theorem pathEdge_quartetCovariance_product_expansion
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t₁ u t₂ : V₁} {v w : V₂}
    (ht₁u : T₁.graph.Adj t₁ u) (hut₂ : T₁.graph.Adj u t₂)
    (ht₁t₂ : t₁ ≠ t₂) (hvw : T₂.graph.Adj v w) :
    (1 / 6 : ℝ) *
        splitQuartetCovariance
          (T₁.sidePairSplit t₁ u t₂) (T₂.edgeSplit v w) =
      (jointMass T₁ T₂ t₂ u v w t₁ v *
            jointMass T₁ T₂ t₂ u w v t₁ w /
              (T₂.columnMass v w v * T₂.columnMass w v w)) *
          xCoefficient T₁ T₂ t₂ u v w ^ 2 -
      ((jointMass T₁ T₂ t₂ u v w t₁ v *
              jointMass T₁ T₂ t₁ u w v t₂ w +
            jointMass T₁ T₂ t₁ u v w t₂ v *
              jointMass T₁ T₂ t₂ u w v t₁ w) /
              (T₂.columnMass v w v * T₂.columnMass w v w)) *
          xCoefficient T₁ T₂ t₂ u v w *
            xCoefficient T₁ T₂ t₁ u v w +
      (jointMass T₁ T₂ t₁ u v w t₂ v *
            jointMass T₁ T₂ t₁ u w v t₂ w /
              (T₂.columnMass v w v * T₂.columnMass w v w)) *
          xCoefficient T₁ T₂ t₁ u v w ^ 2 := by
  rw [sidePairEdge_quartetCovariance_eq T₁ T₂ ht₁u hut₂ ht₁t₂ hvw]
  let det := jointMass T₁ T₂ t₁ u v w t₂ v *
      jointMass T₁ T₂ t₂ u w v t₁ w -
    jointMass T₁ T₂ t₁ u w v t₂ w *
      jointMass T₁ T₂ t₂ u v w t₁ v
  have h₁ := pathEdge_determinant_alpha_one T₁ T₂ ht₁u hut₂ hvw
  have h₀ := pathEdge_determinant_alpha_zero T₁ T₂ ht₁u hut₂ hvw
  change (1 / 6 : ℝ) * (6 * det ^ 2) = _
  change det = _ at h₁
  change det = _ at h₀
  have hprod : det ^ 2 =
      (jointMass T₁ T₂ t₂ u v w t₁ v / T₂.columnMass v w v *
            xCoefficient T₁ T₂ t₂ u v w -
          jointMass T₁ T₂ t₁ u v w t₂ v / T₂.columnMass v w v *
            xCoefficient T₁ T₂ t₁ u v w) *
      (jointMass T₁ T₂ t₂ u w v t₁ w / T₂.columnMass w v w *
            xCoefficient T₁ T₂ t₂ u v w -
          jointMass T₁ T₂ t₁ u w v t₂ w / T₂.columnMass w v w *
            xCoefficient T₁ T₂ t₁ u v w) := by
    calc
      det ^ 2 = det * det := pow_two det
      _ = (jointMass T₁ T₂ t₂ u v w t₁ v / T₂.columnMass v w v *
              xCoefficient T₁ T₂ t₂ u v w -
            jointMass T₁ T₂ t₁ u v w t₂ v / T₂.columnMass v w v *
              xCoefficient T₁ T₂ t₁ u v w) * det := by rw [h₁]
      _ = _ := by rw [h₀]
  rw [hprod]
  have hcv : T₂.columnMass v w v ≠ 0 :=
    ne_of_gt (T₂.columnMass_pos_of_adj hvw)
  have hcw : T₂.columnMass w v w ≠ 0 :=
    ne_of_gt (T₂.columnMass_pos_of_adj hvw.symm)
  field_simp [hcv, hcw]
  ring

/-- Column analogue of `qRowOrientationSum`: the first two row branch
arguments are fixed and the two column branch arguments are summed over one
oriented edge side and the complete branch partition. -/
noncomputable def qColumnOrientationSum
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u : V₁) (v w : V₂) (z y : V₁) : ℝ :=
  ∑ w' ∈ T₂.awayBranchIndices v w,
    ∑ w'' ∈ T₂.branchIndices w,
      qCoefficient T₁ T₂ t u v w z y w' w''

/-- Closed form of one column-oriented coefficient block. -/
theorem qColumnOrientationSum_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u z y : V₁) {v w : V₂} (hvw : T₂.graph.Adj v w) :
    qColumnOrientationSum T₁ T₂ t u v w z y =
      (1 / 2 : ℝ) *
        (jointMass T₁ T₂ t u w v z w *
              jointMass T₁ T₂ t u v w y v /
                T₂.columnMass v w v +
          jointMass T₁ T₂ t u w v y w *
              jointMass T₁ T₂ t u v w z v /
                T₂.columnMass v w v) := by
  classical
  have hfactor := sum_symmetric_q_kernel
    ({z} : Finset V₁) ({y} : Finset V₁)
    (T₂.awayBranchIndices v w) (T₂.branchIndices w)
    (fun i j => jointMass T₁ T₂ t u v w i j)
    (fun j => T₂.columnMass v w j) v
  simp only [Finset.sum_singleton] at hfactor
  unfold qColumnOrientationSum qCoefficient
  rw [hfactor, sum_columnMass_allBranches T₂ v w,
    sum_jointMass_awayColumnBranches T₁ T₂ t u z hvw,
    sum_jointMass_awayColumnBranches T₁ T₂ t u y hvw]
  ring

/-- The two column orientations combine to the symmetric coefficient divided
by twice the product of the two edge-side masses. -/
theorem two_qColumnOrientationSums_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u z y : V₁) {v w : V₂} (hvw : T₂.graph.Adj v w) :
    qColumnOrientationSum T₁ T₂ t u v w z y +
        qColumnOrientationSum T₁ T₂ t u w v z y =
      (jointMass T₁ T₂ t u v w z v *
            jointMass T₁ T₂ t u w v y w +
          jointMass T₁ T₂ t u v w y v *
            jointMass T₁ T₂ t u w v z w) /
        (2 * T₂.columnMass v w v * T₂.columnMass w v w) := by
  rw [qColumnOrientationSum_eq T₁ T₂ t u z y hvw,
    qColumnOrientationSum_eq T₁ T₂ t u z y hvw.symm]
  let A := jointMass T₁ T₂ t u v w z v
  let B := jointMass T₁ T₂ t u w v z w
  let C := jointMass T₁ T₂ t u v w y v
  let D := jointMass T₁ T₂ t u w v y w
  let cv := T₂.columnMass v w v
  let cw := T₂.columnMass w v w
  change (1 / 2 : ℝ) * (B * C / cv + D * A / cv) +
      (1 / 2 : ℝ) * (A * D / cw + C * B / cw) =
    (A * D + C * B) / (2 * cv * cw)
  have hcv : cv ≠ 0 := by
    dsimp [cv]
    exact ne_of_gt (T₂.columnMass_pos_of_adj hvw)
  have hcw : cw ≠ 0 := by
    dsimp [cw]
    exact ne_of_gt (T₂.columnMass_pos_of_adj hvw.symm)
  have hsum : cw + cv = 1 := by
    dsimp [cw, cv]
    exact columnMass_edgeSide_partition T₂ hvw
  have hrecip : (1 / cv : ℝ) + 1 / cw = 1 / (cv * cw) := by
    field_simp [hcv, hcw]
    linarith
  calc
    (1 / 2 : ℝ) * (B * C / cv + D * A / cv) +
          (1 / 2 : ℝ) * (A * D / cw + C * B / cw) =
        (1 / 2 : ℝ) * (A * D + C * B) * (1 / cv + 1 / cw) := by
      ring
    _ = (1 / 2 : ℝ) * (A * D + C * B) * (1 / (cv * cw)) := by
      rw [hrecip]
    _ = (A * D + C * B) / (2 * cv * cw) := by
      field_simp [hcv, hcw]

/-- Correct local `q,b` settlement for a path against an edge.  The factor
`2` in front of the mixed block is forced by the two mixed products in
`pathEdge_quartetCovariance_product_expansion`. -/
theorem pathEdge_local_qb_decomposition
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t₁ u t₂ : V₁} {v w : V₂}
    (ht₁u : T₁.graph.Adj t₁ u) (hut₂ : T₁.graph.Adj u t₂)
    (ht₁t₂ : t₁ ≠ t₂) (hvw : T₂.graph.Adj v w) :
    (1 / 6 : ℝ) *
        splitQuartetCovariance
          (T₁.sidePairSplit t₁ u t₂) (T₂.edgeSplit v w) =
      (qColumnOrientationSum T₁ T₂ t₂ u v w t₁ t₁ +
          qColumnOrientationSum T₁ T₂ t₂ u w v t₁ t₁) *
            xCoefficient T₁ T₂ t₂ u v w ^ 2 +
      (qColumnOrientationSum T₁ T₂ t₁ u v w t₂ t₂ +
          qColumnOrientationSum T₁ T₂ t₁ u w v t₂ t₂) *
            xCoefficient T₁ T₂ t₁ u v w ^ 2 -
      2 *
        (qColumnOrientationSum T₁ T₂ t₁ u v w t₂ t₁ +
          qColumnOrientationSum T₁ T₂ t₁ u w v t₂ t₁) *
            xCoefficient T₁ T₂ t₂ u v w *
              xCoefficient T₁ T₂ t₁ u v w := by
  rw [pathEdge_quartetCovariance_product_expansion T₁ T₂ ht₁u hut₂ ht₁t₂ hvw,
    two_qColumnOrientationSums_eq T₁ T₂ t₂ u t₁ t₁ hvw,
    two_qColumnOrientationSums_eq T₁ T₂ t₁ u t₂ t₂ hvw,
    two_qColumnOrientationSums_eq T₁ T₂ t₁ u t₂ t₁ hvw]
  have hRv : jointMass T₁ T₂ t₁ u v w t₁ v =
      jointMass T₁ T₂ t₂ u v w t₁ v := by rfl
  have hSw : jointMass T₁ T₂ t₁ u w v t₁ w =
      jointMass T₁ T₂ t₂ u w v t₁ w := by rfl
  rw [hRv, hSw]
  ring

/-- Regression test for a three-term path--edge display in an earlier draft.
The current locked manuscript uses the corrected local decomposition.  Here
`P,Q` are the two cells in the `t₂` branch, `R,S` those in the `t₁` branch,
and `Mv,Mw` the two residual cells. -/
theorem printed_pathEdge_three_term_counterexample :
    let P : ℝ := 1 / 10
    let Q : ℝ := 3 / 20
    let R : ℝ := 1 / 5
    let S : ℝ := 1 / 10
    let Mv : ℝ := 1 / 5
    let Mw : ℝ := 1 / 4
    let cv : ℝ := 1 / 2
    let cw : ℝ := 1 / 2
    let X₂ := P * cw - Q * cv
    let X₁ := R * cw - S * cv
    P + R + Mv = cv ∧ Q + S + Mw = cw ∧ cv + cw = 1 ∧
      (P * S - Q * R) ^ 2 = 1 / 2500 ∧
      (1 / (cv * cw)) *
          (R * S * X₂ ^ 2 - R * Q * X₂ * X₁ + P * Q * X₁ ^ 2) =
        7 / 20000 ∧
      (P * S - Q * R) ^ 2 ≠
        (1 / (cv * cw)) *
          (R * S * X₂ ^ 2 - R * Q * X₂ * X₁ + P * Q * X₁ ^ 2) := by
  norm_num

end QDFull
