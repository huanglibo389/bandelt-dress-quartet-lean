import QDFull.CorollaryOneReconstruction
import QDFull.QuartetCorrelation

/-!
# Equality in the quartet-correlation comparison

This file supplies the equality analysis omitted from the short proof of
Proposition 2.  It separates two logically distinct issues.

1. The analytic equality `0 < rho_Q = c_Q` is equivalent to equality of the
   two complete displayed-partial-quartet systems together with a positive
   self covariance.
2. Positivity is not automatic from literal identity, even when there are
   four taxa: all taxa may be carried by the single vertex of an edgeless
   `X`-tree.  The current locked manuscript therefore includes the necessary
   positivity clause; the counterexample below is retained as a regression test.

The graph-reconstruction consequence of equality of the complete partial
quartet systems is treated separately, so that no combinatorial step is
hidden inside the real-algebra argument below.
-/

namespace QDFull

universe uX uV₁ uV₂

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂] [DecidableEq X]

/-- Equality of all displayed partial quartets of support sizes two, three,
and four.  This is the exact finite observable extracted by the quartet
statistics, before graph reconstruction is invoked. -/
def SameDisplayedPartialQuartetSystem
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : Prop :=
  ∀ P : PartialSplit X, IsPartialQuartet P →
    (T₁.DisplaysPartialSplit P ↔ T₂.DisplaysPartialSplit P)

/-- A legal partial quartet has at least one ordered four-draw realization.
The proof uses the already verified exact fibre cardinalities `6`, `12`, and
`24`, including repeated-draw realizations for supports of size two or three. -/
theorem inducingDrawFinset_nonempty_of_isPartialQuartet
    {P : PartialSplit X} (hP : IsPartialQuartet P) :
    (inducingDrawFinset P).Nonempty := by
  classical
  apply Finset.card_pos.mp
  rw [card_inducingDrawFinset_partialQuartet hP]
  rcases partialQuartet_support_card_cases hP with h₂ | h₃ | h₄
  · simp [partialQuartetFiberMultiplicity, h₂]
  · simp [partialQuartetFiberMultiplicity, h₃]
  · simp [partialQuartetFiberMultiplicity, h₄]

/-- On a nonempty finite sample space, equal event probabilities and an
event inclusion imply equality of the actual finite event sets. -/
theorem fourDrawEventSet_eq_of_subset_of_probability_eq
    [Nonempty X]
    {E F : (Fin 4 → X) → Prop}
    (hsub : fourDrawEventSet E ⊆ fourDrawEventSet F)
    (hprob : fourDrawProbability E = fourDrawProbability F) :
    fourDrawEventSet E = fourDrawEventSet F := by
  classical
  apply Finset.eq_of_subset_of_card_le hsub
  rw [fourDrawProbability_eq, fourDrawProbability_eq] at hprob
  have hcardX : (Fintype.card X : ℝ) ≠ 0 := by
    exact_mod_cast (Fintype.card_ne_zero : Fintype.card X ≠ 0)
  have hden : (Fintype.card X : ℝ) ^ 4 ≠ 0 := pow_ne_zero 4 hcardX
  have hcast :
      ((fourDrawEventSet E).card : ℝ) =
        ((fourDrawEventSet F).card : ℝ) :=
    (div_left_inj' hden).mp hprob
  have hcard : (fourDrawEventSet E).card =
      (fourDrawEventSet F).card := by
    exact_mod_cast hcast
  omega

/-- The common event is pointwise contained in the first self event. -/
theorem sameTreeQuartetEventSet_subset_self_left
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    fourDrawEventSet (SameTreeQuartetEvent T₁ T₂) ⊆
      fourDrawEventSet (SameTreeQuartetEvent T₁ T₁) := by
  classical
  intro draw hdraw
  have h : SameTreeQuartetEvent T₁ T₂ draw := by
    simpa [fourDrawEventSet] using hdraw
  simpa [fourDrawEventSet] using h.self_left

/-- The common event is pointwise contained in the second self event. -/
theorem sameTreeQuartetEventSet_subset_self_right
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    fourDrawEventSet (SameTreeQuartetEvent T₁ T₂) ⊆
      fourDrawEventSet (SameTreeQuartetEvent T₂ T₂) := by
  classical
  intro draw hdraw
  have h : SameTreeQuartetEvent T₁ T₂ draw := by
    simpa [fourDrawEventSet] using hdraw
  simpa [fourDrawEventSet] using h.self_right

/-- The real-algebra equality ledger behind Proposition 2.  Positive equality
of the normalized quotients forces the conflicting-event probability to be
zero and the common-event probability to equal both self probabilities. -/
theorem positive_equal_quartet_indices_force_probability_equalities
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hpositive : 0 < quartetCorrelation T₁ T₂)
    (hequal : quartetCorrelation T₁ T₂ =
      quartetCompatibilityIndex T₁ T₂) :
    fourDrawProbability (DifferentTreeQuartetEvent T₁ T₂) = 0 ∧
      fourDrawProbability (SameTreeQuartetEvent T₁ T₂) =
        fourDrawProbability (SameTreeQuartetEvent T₁ T₁) ∧
      fourDrawProbability (SameTreeQuartetEvent T₁ T₂) =
        fourDrawProbability (SameTreeQuartetEvent T₂ T₂) := by
  let Q := treeQuartetCovariance T₁ T₂
  let D := quartetCompatibilityDenominator T₁ T₂
  let A := treeQuartetCovariance T₁ T₁
  let B := treeQuartetCovariance T₂ T₂
  let M := fourDrawProbability (SameTreeQuartetEvent T₁ T₂)
  let F := fourDrawProbability (DifferentTreeQuartetEvent T₁ T₂)
  let S := Real.sqrt (A * B)
  have hQnonneg : 0 ≤ Q := treeQuartetCovariance_nonneg T₁ T₂
  have hAnonneg : 0 ≤ A := treeQuartetCovariance_self_nonneg T₁
  have hBnonneg : 0 ≤ B := treeQuartetCovariance_self_nonneg T₂
  have hDnonneg : 0 ≤ D := quartetCompatibilityDenominator_nonneg T₁ T₂
  have hSnonneg : 0 ≤ S := Real.sqrt_nonneg _
  have hQleD : Q ≤ D :=
    treeQuartetCovariance_le_compatibilityDenominator T₁ T₂
  have hDleA : D ≤ A := quartetCompatibilityDenominator_le_self_left T₁ T₂
  have hDleB : D ≤ B := quartetCompatibilityDenominator_le_self_right T₁ T₂
  change 0 < Q / S at hpositive
  change Q / S = Q / D at hequal
  have hSpos : 0 < S := by
    by_contra hnot
    have hSzero : S = 0 := le_antisymm (le_of_not_gt hnot) hSnonneg
    rw [hSzero, div_zero] at hpositive
    exact (lt_irrefl 0) hpositive
  have hQpos : 0 < Q :=
    (div_pos_iff_of_pos_right hSpos).mp hpositive
  have hDpos : 0 < D := lt_of_lt_of_le hQpos hQleD
  have hcross : Q * D = Q * S :=
    (div_eq_div_iff (ne_of_gt hSpos) (ne_of_gt hDpos)).mp hequal
  have hDeqS : D = S := by
    nlinarith
  have hSsq : S ^ 2 = A * B := by
    exact Real.sq_sqrt (mul_nonneg hAnonneg hBnonneg)
  have hDsq : D ^ 2 = A * B := by
    simpa only [hDeqS] using hSsq
  have hgapProduct : 0 ≤ (A - D) * (B - D) :=
    mul_nonneg (sub_nonneg.mpr hDleA) (sub_nonneg.mpr hDleB)
  have hAeqD : A = D := by
    nlinarith
  have hBeqD : B = D := by
    nlinarith
  have hFnonneg : 0 ≤ F := fourDrawProbability_nonneg _
  have hMFleA : M + F ≤ A := by
    simpa only [M, F, A, treeQuartetCovariance_self_eq_sameProbability] using
      same_add_different_probability_le_self_left T₁ T₂
  have hDformula : D = M + (1 / 2 : ℝ) * F := rfl
  have hFzero : F = 0 := by
    nlinarith
  have hMeqA : M = A := by
    nlinarith
  have hMeqB : M = B := by
    nlinarith
  simpa only [F, M, A, B,
    treeQuartetCovariance_self_eq_sameProbability] using
    And.intro hFzero (And.intro hMeqA hMeqB)

/-- A partial quartet displayed by the first tree transfers to the second if
every first-tree self draw belongs to the common event. -/
theorem displaysPartialSplit_right_of_selfEventSet_subset_same
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hsub : fourDrawEventSet (SameTreeQuartetEvent T₁ T₁) ⊆
      fourDrawEventSet (SameTreeQuartetEvent T₁ T₂))
    {P : PartialSplit X} (hP : IsPartialQuartet P)
    (hT₁P : T₁.DisplaysPartialSplit P) :
    T₂.DisplaysPartialSplit P := by
  classical
  obtain ⟨draw, hdraw⟩ := inducingDrawFinset_nonempty_of_isPartialQuartet hP
  have hindP : Induces draw P := (mem_inducingDrawFinset P draw).1 hdraw
  have hself : draw ∈ fourDrawEventSet
      (SameTreeQuartetEvent T₁ T₁) := by
    simp only [fourDrawEventSet, Finset.mem_filter, Finset.mem_univ, true_and]
    exact ⟨P, hindP, hT₁P, hT₁P⟩
  have hcommon := hsub hself
  have hcommon' : SameTreeQuartetEvent T₁ T₂ draw := by
    simpa [fourDrawEventSet] using hcommon
  obtain ⟨Q, hindQ, hT₁Q, hT₂Q⟩ := hcommon'
  have hPQ : P = Q :=
    T₁.induced_displayed_partialQuartet_unique
      draw hindP hindQ hT₁P hT₁Q
  simpa only [hPQ] using hT₂Q

/-- The symmetric transfer from the second tree to the first. -/
theorem displaysPartialSplit_left_of_selfEventSet_subset_same
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hsub : fourDrawEventSet (SameTreeQuartetEvent T₂ T₂) ⊆
      fourDrawEventSet (SameTreeQuartetEvent T₁ T₂))
    {P : PartialSplit X} (hP : IsPartialQuartet P)
    (hT₂P : T₂.DisplaysPartialSplit P) :
    T₁.DisplaysPartialSplit P := by
  classical
  obtain ⟨draw, hdraw⟩ := inducingDrawFinset_nonempty_of_isPartialQuartet hP
  have hindP : Induces draw P := (mem_inducingDrawFinset P draw).1 hdraw
  have hself : draw ∈ fourDrawEventSet
      (SameTreeQuartetEvent T₂ T₂) := by
    simp only [fourDrawEventSet, Finset.mem_filter, Finset.mem_univ, true_and]
    exact ⟨P, hindP, hT₂P, hT₂P⟩
  have hcommon := hsub hself
  have hcommon' : SameTreeQuartetEvent T₁ T₂ draw := by
    simpa [fourDrawEventSet] using hcommon
  obtain ⟨Q, hindQ, hT₁Q, hT₂Q⟩ := hcommon'
  have hPQ : P = Q :=
    T₂.induced_displayed_partialQuartet_unique
      draw hindP hindQ hT₂P hT₂Q
  simpa only [hPQ] using hT₁Q

/-- Positive equality of the two normalized indices forces equality of every
displayed partial quartet, not merely equality of their cardinalities. -/
theorem sameDisplayedPartialQuartetSystem_of_positive_equal_indices
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hpositive : 0 < quartetCorrelation T₁ T₂)
    (hequal : quartetCorrelation T₁ T₂ =
      quartetCompatibilityIndex T₁ T₂) :
    SameDisplayedPartialQuartetSystem T₁ T₂ := by
  classical
  obtain ⟨_hFzero, hprob₁, hprob₂⟩ :=
    positive_equal_quartet_indices_force_probability_equalities
      T₁ T₂ hpositive hequal
  letI : Nonempty X := T₁.taxon_nonempty
  have hset₁ :
      fourDrawEventSet (SameTreeQuartetEvent T₁ T₂) =
        fourDrawEventSet (SameTreeQuartetEvent T₁ T₁) :=
    fourDrawEventSet_eq_of_subset_of_probability_eq
      (sameTreeQuartetEventSet_subset_self_left T₁ T₂) hprob₁
  have hset₂ :
      fourDrawEventSet (SameTreeQuartetEvent T₁ T₂) =
        fourDrawEventSet (SameTreeQuartetEvent T₂ T₂) :=
    fourDrawEventSet_eq_of_subset_of_probability_eq
      (sameTreeQuartetEventSet_subset_self_right T₁ T₂) hprob₂
  intro P hP
  constructor
  · exact displaysPartialSplit_right_of_selfEventSet_subset_same
      T₁ T₂ (by rw [hset₁]) hP
  · exact displaysPartialSplit_left_of_selfEventSet_subset_same
      T₁ T₂ (by rw [hset₂]) hP

/-- Equality of the displayed partial-quartet systems makes the conflicting
tree event impossible on every ordered sample. -/
theorem differentTreeQuartetProbability_eq_zero_of_sameDisplayedSystem
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hsame : SameDisplayedPartialQuartetSystem T₁ T₂) :
    fourDrawProbability (DifferentTreeQuartetEvent T₁ T₂) = 0 := by
  rw [fourDrawProbability_eq]
  have hempty : fourDrawEventSet
      (DifferentTreeQuartetEvent T₁ T₂) = ∅ := by
    classical
    apply Finset.eq_empty_iff_forall_notMem.mpr
    intro draw hdraw
    have hdiff : DifferentTreeQuartetEvent T₁ T₂ draw := by
      simpa [fourDrawEventSet] using hdraw
    obtain ⟨P, Q, hindP, hindQ, hT₁P, hT₂Q, hPQ⟩ := hdiff
    have hT₂P : T₂.DisplaysPartialSplit P :=
      (hsame P hindP.isPartialQuartet).1 hT₁P
    exact hPQ (T₂.induced_displayed_partialQuartet_unique
      draw hindP hindQ hT₂P hT₂Q)
  rw [hempty]
  simp

/-- Equality of displayed partial-quartet systems identifies the common event
with each self event, pointwise. -/
theorem sameTreeEventSets_eq_self_of_sameDisplayedSystem
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hsame : SameDisplayedPartialQuartetSystem T₁ T₂) :
    fourDrawEventSet (SameTreeQuartetEvent T₁ T₂) =
        fourDrawEventSet (SameTreeQuartetEvent T₁ T₁) ∧
      fourDrawEventSet (SameTreeQuartetEvent T₁ T₂) =
        fourDrawEventSet (SameTreeQuartetEvent T₂ T₂) := by
  classical
  constructor
  · apply Finset.Subset.antisymm
    · exact sameTreeQuartetEventSet_subset_self_left T₁ T₂
    · intro draw hdraw
      have hself : SameTreeQuartetEvent T₁ T₁ draw := by
        simpa [fourDrawEventSet] using hdraw
      obtain ⟨P, hindP, hT₁P, _⟩ := hself
      have hT₂P := (hsame P hindP.isPartialQuartet).1 hT₁P
      simp only [fourDrawEventSet, Finset.mem_filter, Finset.mem_univ, true_and]
      exact ⟨P, hindP, hT₁P, hT₂P⟩
  · apply Finset.Subset.antisymm
    · exact sameTreeQuartetEventSet_subset_self_right T₁ T₂
    · intro draw hdraw
      have hself : SameTreeQuartetEvent T₂ T₂ draw := by
        simpa [fourDrawEventSet] using hdraw
      obtain ⟨P, hindP, hT₂P, _⟩ := hself
      have hT₁P := (hsame P hindP.isPartialQuartet).2 hT₂P
      simp only [fourDrawEventSet, Finset.mem_filter, Finset.mem_univ, true_and]
      exact ⟨P, hindP, hT₁P, hT₂P⟩

/-- If the complete displayed systems agree and the first self covariance is
positive, then both normalized indices equal one. -/
theorem quartet_indices_eq_one_of_sameDisplayedSystem
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hsame : SameDisplayedPartialQuartetSystem T₁ T₂)
    (hself : 0 < treeQuartetCovariance T₁ T₁) :
    quartetCorrelation T₁ T₂ = 1 ∧
      quartetCompatibilityIndex T₁ T₂ = 1 := by
  classical
  obtain ⟨hset₁, hset₂⟩ :=
    sameTreeEventSets_eq_self_of_sameDisplayedSystem T₁ T₂ hsame
  have hdiff :=
    differentTreeQuartetProbability_eq_zero_of_sameDisplayedSystem
      T₁ T₂ hsame
  have hprob₁ :
      fourDrawProbability (SameTreeQuartetEvent T₁ T₂) =
        fourDrawProbability (SameTreeQuartetEvent T₁ T₁) := by
    rw [fourDrawProbability_eq, fourDrawProbability_eq, hset₁]
  have hprob₂ :
      fourDrawProbability (SameTreeQuartetEvent T₁ T₂) =
        fourDrawProbability (SameTreeQuartetEvent T₂ T₂) := by
    rw [fourDrawProbability_eq, fourDrawProbability_eq, hset₂]
  have hcross : treeQuartetCovariance T₁ T₂ =
      treeQuartetCovariance T₁ T₁ := by
    rw [treeQuartetCovariance, treeQuartetCovariance_self_eq_sameProbability]
    nlinarith
  have hself₂ : treeQuartetCovariance T₂ T₂ =
      treeQuartetCovariance T₁ T₁ := by
    rw [treeQuartetCovariance_self_eq_sameProbability,
      treeQuartetCovariance_self_eq_sameProbability]
    exact hprob₂.symm.trans hprob₁
  have hcrossNe : treeQuartetCovariance T₁ T₂ ≠ 0 := by
    rw [hcross]
    exact ne_of_gt hself
  have hsqrt :
      Real.sqrt
          (treeQuartetCovariance T₁ T₁ *
            treeQuartetCovariance T₂ T₂) =
        treeQuartetCovariance T₁ T₁ := by
    rw [hself₂, ← pow_two, Real.sqrt_sq_eq_abs,
      abs_of_nonneg (le_of_lt hself)]
  have hden : quartetCompatibilityDenominator T₁ T₂ =
      treeQuartetCovariance T₁ T₁ := by
    rw [quartetCompatibilityDenominator,
      treeQuartetCovariance_self_eq_sameProbability]
    nlinarith
  constructor
  · rw [quartetCorrelation, hsqrt, hcross]
    exact div_self (ne_of_gt hself)
  · rw [quartetCompatibilityIndex, hden, hcross]
    exact div_self (ne_of_gt hself)

/-- Exact analytic form of Proposition 2.  The positivity condition
on the right is indispensable; no cardinality assumption alone removes the
edgeless, all-taxa-colocated boundary. -/
theorem positive_equal_quartet_indices_iff_sameDisplayedSystem_and_positive
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    (0 < quartetCorrelation T₁ T₂ ∧
        quartetCorrelation T₁ T₂ = quartetCompatibilityIndex T₁ T₂) ↔
      SameDisplayedPartialQuartetSystem T₁ T₂ ∧
        0 < treeQuartetCovariance T₁ T₁ := by
  constructor
  · rintro ⟨hpositive, hequal⟩
    have hsame := sameDisplayedPartialQuartetSystem_of_positive_equal_indices
      T₁ T₂ hpositive hequal
    obtain ⟨_hFzero, hprob₁, _hprob₂⟩ :=
      positive_equal_quartet_indices_force_probability_equalities
        T₁ T₂ hpositive hequal
    have hQpos : 0 < treeQuartetCovariance T₁ T₂ := by
      have hsqrtNonneg : 0 ≤ Real.sqrt
          (treeQuartetCovariance T₁ T₁ *
            treeQuartetCovariance T₂ T₂) := Real.sqrt_nonneg _
      change 0 < treeQuartetCovariance T₁ T₂ /
        Real.sqrt (treeQuartetCovariance T₁ T₁ *
          treeQuartetCovariance T₂ T₂) at hpositive
      rcases (div_pos_iff.mp hpositive) with h | h
      · exact h.1
      · exact False.elim ((not_lt_of_ge hsqrtNonneg) h.2)
    have hself : 0 < treeQuartetCovariance T₁ T₁ := by
      rw [treeQuartetCovariance_self_eq_sameProbability]
      have hcross : treeQuartetCovariance T₁ T₂ =
          fourDrawProbability (SameTreeQuartetEvent T₁ T₂) := by
        rw [treeQuartetCovariance]
        obtain ⟨hFzero, _, _⟩ :=
          positive_equal_quartet_indices_force_probability_equalities
            T₁ T₂ hpositive hequal
        nlinarith
      rw [← hprob₁, ← hcross]
      exact hQpos
    exact ⟨hsame, hself⟩
  · rintro ⟨hsame, hself⟩
    obtain ⟨hrho, hc⟩ :=
      quartet_indices_eq_one_of_sameDisplayedSystem T₁ T₂ hsame hself
    rw [hrho, hc]
    norm_num

/-- In the positive equality case, the common value is one. -/
theorem quartetCorrelation_eq_one_of_positive_equal_indices
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hpositive : 0 < quartetCorrelation T₁ T₂)
    (hequal : quartetCorrelation T₁ T₂ =
      quartetCompatibilityIndex T₁ T₂) :
    quartetCorrelation T₁ T₂ = 1 := by
  have hdata :=
    (positive_equal_quartet_indices_iff_sameDisplayedSystem_and_positive
      T₁ T₂).1 ⟨hpositive, hequal⟩
  exact (quartet_indices_eq_one_of_sameDisplayedSystem
    T₁ T₂ hdata.1 hdata.2).1

/-! ## Four-taxon regression for the positivity condition -/

/-- An edgeless one-vertex `X`-tree carrying every taxon at that vertex. -/
def colocatedTaxaTree (Y : Type*) [Fintype Y] [Nonempty Y] :
    XTree Y Unit where
  graph := ⊥
  isTree := SimpleGraph.IsTree.of_subsingleton
  label := fun _ => ()
  lowDegree_labelled := by
    intro _v _hdegree
    exact ⟨Classical.choice inferInstance, rfl⟩

/-- The four-taxon colocated tree is literally compared with itself but has
zero quartet correlation. -/
theorem fourTaxa_colocated_self_correlation_eq_zero :
    quartetCorrelation (colocatedTaxaTree (Fin 4))
      (colocatedTaxaTree (Fin 4)) = 0 := by
  apply (quartetCorrelation_eq_zero_iff_treesIndependent _ _).2
  intro t u v w htu _hvw
  simpa [colocatedTaxaTree] using htu

/-- Regression test showing that `|X| = 4` alone does not imply positive
equality from identity: an explicit identical self-pair has correlation zero.
The current locked manuscript includes positivity in the statement. -/
theorem printed_identical_imp_positive_equal_indices_fails_with_four_taxa :
    Fintype.card (Fin 4) = 4 ∧
      ¬(0 < quartetCorrelation (colocatedTaxaTree (Fin 4))
          (colocatedTaxaTree (Fin 4)) ∧
        quartetCorrelation (colocatedTaxaTree (Fin 4))
          (colocatedTaxaTree (Fin 4)) =
        quartetCompatibilityIndex (colocatedTaxaTree (Fin 4))
          (colocatedTaxaTree (Fin 4))) := by
  constructor
  · simp
  · rw [fourTaxa_colocated_self_correlation_eq_zero]
    norm_num

end QDFull
