import QDFull.PreliminaryFacts
import QDFull.SplitCovariance

/-!
# Four-draw event semantics

This file encodes the four-draw probability definitions in Section 2 of the
locked manuscript.  A draw is an ordered function `Fin 4 → X`, so repeated
taxa are allowed exactly as required by sampling with replacement.
-/

namespace QDFull

universe uX uV₁ uV₂

/-- Every partial split induced by four draws is automatically a partial
quartet: each side is represented by a set made from two draw positions. -/
theorem Induces.isPartialQuartet {X : Type uX} [Fintype X]
    {draw : Fin 4 → X} {P : PartialSplit X} (h : Induces draw P) :
    IsPartialQuartet P := by
  classical
  rcases h with ⟨hP, π, rfl⟩
  refine ⟨hP, {draw (π 0), draw (π 1)},
    {draw (π 2), draw (π 3)}, rfl, ?_, ?_⟩ <;>
    exact Finset.card_le_two

/-- One ordered four-draw sample induces a partial quartet displayed by both
partial splits. -/
def SameSplitQuartetEvent {X : Type uX}
    (P Q : PartialSplit X) (draw : Fin 4 → X) : Prop :=
  ∃ R : PartialSplit X,
    Induces draw R ∧ Displays P R ∧ Displays Q R

/-- One ordered four-draw sample induces two different partial quartets, the
first displayed by `P` and the second by `Q`. -/
def DifferentSplitQuartetEvent {X : Type uX}
    (P Q : PartialSplit X) (draw : Fin 4 → X) : Prop :=
  ∃ R S : PartialSplit X,
    Induces draw R ∧ Induces draw S ∧
      Displays P R ∧ Displays Q S ∧ R ≠ S

/-- One sample induces a partial quartet displayed by both trees. -/
def SameTreeQuartetEvent
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (draw : Fin 4 → X) : Prop :=
  ∃ R : PartialSplit X,
    Induces draw R ∧ T₁.DisplaysPartialSplit R ∧
      T₂.DisplaysPartialSplit R

/-- One sample induces two different partial quartets, one displayed by each
tree. -/
def DifferentTreeQuartetEvent
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (draw : Fin 4 → X) : Prop :=
  ∃ R S : PartialSplit X,
    Induces draw R ∧ Induces draw S ∧
      T₁.DisplaysPartialSplit R ∧ T₂.DisplaysPartialSplit S ∧ R ≠ S

/-- The finite subset of the ordered sample space on which `E` holds. -/
noncomputable def fourDrawEventSet {X : Type uX} [Fintype X]
    (E : (Fin 4 → X) → Prop) : Finset (Fin 4 → X) := by
  classical
  exact Finset.univ.filter E

/-- Probability of an event on four independent uniform draws with
replacement.  The denominator is the cardinality of the ordered sample space
`Fin 4 → X`. -/
noncomputable def fourDrawProbability {X : Type uX} [Fintype X]
    (E : (Fin 4 → X) → Prop) : ℝ :=
  normalizedCard (fourDrawEventSet E)

theorem fourDraw_sampleSpace_card {X : Type uX} [Fintype X] :
    Fintype.card (Fin 4 → X) = Fintype.card X ^ 4 := by
  rw [Fintype.card_fun, Fintype.card_fin]

theorem fourDrawProbability_eq {X : Type uX} [Fintype X]
    (E : (Fin 4 → X) → Prop) :
    fourDrawProbability E =
      ((fourDrawEventSet E).card : ℝ) / (Fintype.card X : ℝ) ^ 4 := by
  unfold fourDrawProbability normalizedCard
  rw [fourDraw_sampleSpace_card]
  norm_cast

/-- The paper's verbal quartet covariance for two partial splits. -/
noncomputable def splitQuartetCovarianceEvent {X : Type uX} [Fintype X]
    (P Q : PartialSplit X) : ℝ :=
  fourDrawProbability (SameSplitQuartetEvent P Q) -
    (1 / 2 : ℝ) * fourDrawProbability (DifferentSplitQuartetEvent P Q)

/-- The paper's verbal quartet covariance for two `X`-trees. -/
noncomputable def treeQuartetCovariance
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  fourDrawProbability (SameTreeQuartetEvent T₁ T₂) -
    (1 / 2 : ℝ) * fourDrawProbability (DifferentTreeQuartetEvent T₁ T₂)

end QDFull
