import QDFull.InclusionExclusionPath

/-!
# Exact edge and length-two-path counts for Theorem 1

This file replaces the paper's informal statement that the displaying edges
form a path and the displaying side-pairs are its consecutive edge pairs by
finite types and explicit equivalences.
-/

open SimpleGraph

namespace QDFull

universe uX uV

namespace XTree

variable {X : Type uX} {V : Type uV}
  [Fintype X] [Fintype V] [DecidableEq X] [DecidableEq V]

/-- Canonical edge representatives whose edge splits display `P`. -/
noncomputable def displayingEdgeFinset [LinearOrder V]
    (T : XTree X V) (P : PartialSplit X) : Finset (V × V) := by
  classical
  exact T.canonicalEdgeFinset.filter fun e =>
    Displays (T.edgeSplit e.1 e.2) P

/-- Canonical length-two paths whose side-pair splits display `P`. -/
noncomputable def displayingLengthTwoPathFinset [LinearOrder V]
    (T : XTree X V) (P : PartialSplit X) : Finset (V × V × V) := by
  classical
  exact T.canonicalLengthTwoPathFinset.filter fun p =>
    Displays (T.sidePairSplit p.1 p.2.1 p.2.2) P

@[simp] theorem mem_displayingEdgeFinset [LinearOrder V]
    (T : XTree X V) (P : PartialSplit X) (u v : V) :
    (u, v) ∈ T.displayingEdgeFinset P ↔
      T.graph.Adj u v ∧ u < v ∧ Displays (T.edgeSplit u v) P := by
  classical
  simp [displayingEdgeFinset, and_assoc]

@[simp] theorem mem_displayingLengthTwoPathFinset [LinearOrder V]
    (T : XTree X V) (P : PartialSplit X) (u v w : V) :
    (u, v, w) ∈ T.displayingLengthTwoPathFinset P ↔
      T.graph.Adj u v ∧ T.graph.Adj v w ∧ u < w ∧
        Displays (T.sidePairSplit u v w) P := by
  classical
  simp [displayingLengthTwoPathFinset, and_assoc]

/-- Forget the auxiliary endpoint order on a canonical edge. -/
noncomputable def canonicalEdgeToEdgeSet [LinearOrder V]
    (T : XTree X V) :
    T.canonicalEdgeFinset → T.graph.edgeSet := fun e =>
  ⟨s(e.1.1, e.1.2),
    (T.mem_canonicalEdgeFinset e.1.1 e.1.2).1 e.2 |>.1⟩

theorem canonicalEdgeToEdgeSet_injective [LinearOrder V]
    (T : XTree X V) :
    Function.Injective T.canonicalEdgeToEdgeSet := by
  rintro ⟨⟨u, v⟩, huv⟩ ⟨⟨x, y⟩, hxy⟩ heq
  apply Subtype.ext
  have heq' : s(u, v) = s(x, y) := Subtype.mk.inj heq
  rw [Sym2.eq_iff] at heq'
  rcases heq' with h | h
  · simp [h.1, h.2]
  · have huvlt := ((T.mem_canonicalEdgeFinset u v).1 huv).2
    have hxylt := ((T.mem_canonicalEdgeFinset x y).1 hxy).2
    exfalso
    have hyx : y < x := by simpa [h.1, h.2] using huvlt
    exact (asymm hxylt) hyx

theorem canonicalEdgeToEdgeSet_surjective [LinearOrder V]
    (T : XTree X V) :
    Function.Surjective T.canonicalEdgeToEdgeSet := by
  rintro ⟨e, he⟩
  induction e using Sym2.inductionOn with
  | _ u v =>
      have huv : T.graph.Adj u v := (SimpleGraph.mem_edgeSet T.graph).1 he
      rcases lt_or_gt_of_ne huv.ne with huvlt | hvult
      · refine ⟨⟨(u, v), (T.mem_canonicalEdgeFinset u v).2
          ⟨huv, huvlt⟩⟩, ?_⟩
        rfl
      · refine ⟨⟨(v, u), (T.mem_canonicalEdgeFinset v u).2
          ⟨huv.symm, hvult⟩⟩, ?_⟩
        apply Subtype.ext
        exact Sym2.eq_swap

/-- Canonical edge representatives are exactly the unordered graph edges. -/
noncomputable def canonicalEdgeEquivEdgeSet [LinearOrder V]
    (T : XTree X V) :
    T.canonicalEdgeFinset ≃ T.graph.edgeSet :=
  Equiv.ofBijective T.canonicalEdgeToEdgeSet
    ⟨T.canonicalEdgeToEdgeSet_injective,
      T.canonicalEdgeToEdgeSet_surjective⟩

@[simp] theorem canonicalEdgeEquivEdgeSet_apply [LinearOrder V]
    (T : XTree X V) (e : T.canonicalEdgeFinset) :
    T.canonicalEdgeEquivEdgeSet e = T.canonicalEdgeToEdgeSet e := rfl

/-- Restricting the preceding edge equivalence to one paired partial split
identifies displaying canonical edges with the edges of the common quartet
path subgraph. -/
noncomputable def displayingEdgeEquivQuartetPathEdgeSet [LinearOrder V]
    (T : XTree X V) (q₁ q₂ q₃ q₄ : X) :
    T.displayingEdgeFinset
        s(({q₁, q₂} : Finset X), ({q₃, q₄} : Finset X)) ≃
      (T.quartetPathSubgraph q₁ q₂ q₃ q₄).edgeSet := by
  classical
  let P : PartialSplit X :=
    s(({q₁, q₂} : Finset X), ({q₃, q₄} : Finset X))
  let H := T.quartetPathSubgraph q₁ q₂ q₃ q₄
  let f : T.displayingEdgeFinset P → H.edgeSet := fun e => by
    have he := (T.mem_displayingEdgeFinset P e.1.1 e.1.2).1 e.2
    exact ⟨s(e.1.1, e.1.2),
      (T.edge_mem_quartetPathSubgraph_iff_displays he.1
        q₁ q₂ q₃ q₄).2 he.2.2⟩
  apply Equiv.ofBijective f
  constructor
  · intro e₁ e₂ heq
    let c₁ : T.canonicalEdgeFinset :=
      ⟨e₁.1, (Finset.mem_filter.1 e₁.2).1⟩
    let c₂ : T.canonicalEdgeFinset :=
      ⟨e₂.1, (Finset.mem_filter.1 e₂.2).1⟩
    have hc : c₁ = c₂ := T.canonicalEdgeToEdgeSet_injective
      (Subtype.ext (Subtype.mk.inj heq))
    exact Subtype.ext
      (congrArg (fun z : T.canonicalEdgeFinset => z.1) hc)
  · rintro ⟨e, heH⟩
    have heG : e ∈ T.graph.edgeSet := H.edgeSet_subset heH
    let eG : T.graph.edgeSet := ⟨e, heG⟩
    let c := (T.canonicalEdgeEquivEdgeSet).symm eG
    have hbase : T.canonicalEdgeToEdgeSet c = eG := by
      simpa only [T.canonicalEdgeEquivEdgeSet_apply] using
        (T.canonicalEdgeEquivEdgeSet).apply_symm_apply eG
    rcases c with ⟨⟨u, v⟩, hc⟩
    have heval : s(u, v) = e := Subtype.mk.inj hbase
    have huv : T.graph.Adj u v :=
      ((T.mem_canonicalEdgeFinset u v).1 hc).1
    have hdisplay : Displays (T.edgeSplit u v) P := by
      apply (T.edge_mem_quartetPathSubgraph_iff_displays huv
        q₁ q₂ q₃ q₄).1
      simpa only [heval] using heH
    let ce : T.displayingEdgeFinset P :=
      ⟨(u, v), (T.mem_displayingEdgeFinset P u v).2
        ⟨huv, ((T.mem_canonicalEdgeFinset u v).1 hc).2, hdisplay⟩⟩
    refine ⟨ce, ?_⟩
    apply Subtype.ext
    exact heval

theorem card_displayingEdgeFinset_eq_quartetPathEdgeSet [LinearOrder V]
    (T : XTree X V) (q₁ q₂ q₃ q₄ : X) :
    (T.displayingEdgeFinset
      s(({q₁, q₂} : Finset X), ({q₃, q₄} : Finset X))).card =
      (T.quartetPathSubgraph q₁ q₂ q₃ q₄).edgeSet.ncard := by
  simpa only [Nat.card_coe_set_eq, Nat.card_eq_fintype_card,
    Fintype.card_coe] using Nat.card_congr
      (T.displayingEdgeEquivQuartetPathEdgeSet q₁ q₂ q₃ q₄)

/-- A canonically oriented length-two path is uniquely determined by the
unordered pair of its two graph edges.  The endpoint order is used only to
eliminate the reversal duplicate. -/
private theorem canonicalPath_eq_of_edgePair_eq [LinearOrder V]
    {u v w x y z : V}
    (huv : u ≠ v) (hvw : v ≠ w) (hxy : x ≠ y) (hyz : y ≠ z)
    (huw : u < w) (hxz : x < z)
    (hpair : s(s(u, v), s(v, w)) = s(s(x, y), s(y, z))) :
    (u, v, w) = (x, y, z) := by
  simp only [Sym2.eq_iff] at hpair
  rcases hpair with hpair | hpair
  · rcases hpair with ⟨h₁, h₂⟩
    rcases h₁ with h₁ | h₁ <;> rcases h₂ with h₂ | h₂
    · simp [h₁.1, h₁.2, h₂.1, h₂.2]
    · exfalso
      apply hyz
      calc
        y = v := h₁.2.symm
        _ = z := h₂.1
    · exfalso
      apply hxy
      calc
        x = v := h₁.2.symm
        _ = y := h₂.1
    · exfalso
      have huw' : u = w := h₁.1.trans h₂.2.symm
      exact (ne_of_lt huw) huw'
  · rcases hpair with ⟨h₁, h₂⟩
    rcases h₁ with h₁ | h₁ <;> rcases h₂ with h₂ | h₂
    · exfalso
      have huw' : u = w := h₁.1.trans h₂.2.symm
      exact (ne_of_lt huw) huw'
    · exfalso
      apply hyz
      calc
        y = v := h₂.1.symm
        _ = z := h₁.2
    · exfalso
      apply hxy
      calc
        x = v := h₂.1.symm
        _ = y := h₁.2
    · exfalso
      have hzx : z < x := by simpa [h₁.1, h₁.2, h₂.1, h₂.2] using huw
      exact (asymm hxz) hzx

/-- Canonical length-two paths all of whose edges lie in a chosen subgraph. -/
noncomputable def canonicalLengthTwoPathInSubgraphFinset [LinearOrder V]
    (T : XTree X V) (H : T.graph.Subgraph) : Finset (V × V × V) := by
  classical
  exact T.canonicalLengthTwoPathFinset.filter fun p =>
    s(p.1, p.2.1) ∈ H.edgeSet ∧ s(p.2.1, p.2.2) ∈ H.edgeSet

@[simp] theorem mem_canonicalLengthTwoPathInSubgraphFinset [LinearOrder V]
    (T : XTree X V) (H : T.graph.Subgraph) (u v w : V) :
    (u, v, w) ∈ T.canonicalLengthTwoPathInSubgraphFinset H ↔
      T.graph.Adj u v ∧ T.graph.Adj v w ∧ u < w ∧
        s(u, v) ∈ H.edgeSet ∧ s(v, w) ∈ H.edgeSet := by
  classical
  simp [canonicalLengthTwoPathInSubgraphFinset, and_assoc]

/-- Regard one ambient subgraph adjacency as an edge of the subgraph's
coefficient graph. -/
def subgraphEdgeOfAdj {G : SimpleGraph V} (H : G.Subgraph)
    {u v : V} (huv : H.Adj u v) : H.coe.edgeSet :=
  ⟨s(⟨u, huv.fst_mem⟩, ⟨v, huv.snd_mem⟩), by
    exact (SimpleGraph.mem_edgeSet H.coe).2 huv⟩

@[simp] theorem coeEdgeMap_subgraphEdgeOfAdj
    {G : SimpleGraph V} (H : G.Subgraph) {u v : V} (huv : H.Adj u v) :
    PathGeometry.coeEdgeMap H (subgraphEdgeOfAdj H huv) =
      (⟨s(u, v), (SimpleGraph.Subgraph.mem_edgeSet).2 huv⟩ : H.edgeSet) := by
  apply Subtype.ext
  simp [PathGeometry.coeEdgeMap, subgraphEdgeOfAdj]

/-- Send a canonical length-two path in `H` to the corresponding edge of
the line graph of `H`. -/
noncomputable def canonicalPathInSubgraphToLineEdge [LinearOrder V]
    (T : XTree X V) (H : T.graph.Subgraph) :
    T.canonicalLengthTwoPathInSubgraphFinset H → H.coe.lineGraph.edgeSet :=
  fun p => by
    classical
    rcases p with ⟨⟨u, v, w⟩, hp⟩
    have h := (T.mem_canonicalLengthTwoPathInSubgraphFinset H u v w).1 hp
    have huvH : H.Adj u v :=
      (SimpleGraph.Subgraph.mem_edgeSet).1 h.2.2.2.1
    have hvwH : H.Adj v w :=
      (SimpleGraph.Subgraph.mem_edgeSet).1 h.2.2.2.2
    let e₁ : H.coe.edgeSet := subgraphEdgeOfAdj H huvH
    let e₂ : H.coe.edgeSet := subgraphEdgeOfAdj H hvwH
    have hne : e₁ ≠ e₂ := by
      intro heq
      have hmap := congrArg (PathGeometry.coeEdgeMap H) heq
      have hedge : s(u, v) = s(v, w) := Subtype.mk.inj hmap
      rw [Sym2.eq_iff] at hedge
      rcases hedge with hedge | hedge
      · exact h.1.ne hedge.1
      · exact (ne_of_lt h.2.2.1) hedge.1
    refine ⟨s(e₁, e₂), (SimpleGraph.mem_edgeSet H.coe.lineGraph).2 ?_⟩
    rw [SimpleGraph.lineGraph_adj_iff_exists]
    refine ⟨hne, ⟨⟨v, huvH.snd_mem⟩, ?_, ?_⟩⟩
    · simp [e₁, subgraphEdgeOfAdj, Sym2.mem_iff]
    · simp [e₂, subgraphEdgeOfAdj, Sym2.mem_iff]

theorem canonicalPathInSubgraphToLineEdge_injective [LinearOrder V]
    (T : XTree X V) (H : T.graph.Subgraph) :
    Function.Injective (T.canonicalPathInSubgraphToLineEdge H) := by
  rintro ⟨⟨u, v, w⟩, hp⟩ ⟨⟨x, y, z⟩, hq⟩ heq
  have hp' :=
    (T.mem_canonicalLengthTwoPathInSubgraphFinset H u v w).1 hp
  have hq' :=
    (T.mem_canonicalLengthTwoPathInSubgraphFinset H x y z).1 hq
  apply Subtype.ext
  apply canonicalPath_eq_of_edgePair_eq
      hp'.1.ne hp'.2.1.ne hq'.1.ne hq'.2.1.ne
      hp'.2.2.1 hq'.2.2.1
  have hraw := Subtype.mk.inj heq
  change s(subgraphEdgeOfAdj H
      ((SimpleGraph.Subgraph.mem_edgeSet).1 hp'.2.2.2.1),
      subgraphEdgeOfAdj H
        ((SimpleGraph.Subgraph.mem_edgeSet).1 hp'.2.2.2.2)) =
    s(subgraphEdgeOfAdj H
      ((SimpleGraph.Subgraph.mem_edgeSet).1 hq'.2.2.2.1),
      subgraphEdgeOfAdj H
        ((SimpleGraph.Subgraph.mem_edgeSet).1 hq'.2.2.2.2)) at hraw
  have hmapped := congrArg
    (Sym2.map (fun e : H.coe.edgeSet =>
      ((PathGeometry.coeEdgeMap H e).1 : Sym2 V))) hraw
  simpa [subgraphEdgeOfAdj, PathGeometry.coeEdgeMap] using hmapped

theorem canonicalPathInSubgraphToLineEdge_surjective [LinearOrder V]
    (T : XTree X V) (H : T.graph.Subgraph) :
    Function.Surjective (T.canonicalPathInSubgraphToLineEdge H) := by
  rintro ⟨E, hE⟩
  induction E using Sym2.inductionOn with
  | _ e₁ e₂ =>
      have hadj : H.coe.lineGraph.Adj e₁ e₂ :=
        (SimpleGraph.mem_edgeSet H.coe.lineGraph).1 hE
      obtain ⟨hne, c, hc₁, hc₂⟩ :=
        (SimpleGraph.lineGraph_adj_iff_exists).1 hadj
      obtain ⟨a, he₁⟩ := Sym2.mem_iff_exists.1 hc₁
      obtain ⟨b, he₂⟩ := Sym2.mem_iff_exists.1 hc₂
      have hcaCoe : H.coe.Adj c a := by
        apply (SimpleGraph.mem_edgeSet H.coe).1
        simpa only [he₁] using e₁.2
      have hcbCoe : H.coe.Adj c b := by
        apply (SimpleGraph.mem_edgeSet H.coe).1
        simpa only [he₂] using e₂.2
      have hcaH : H.Adj c.1 a.1 := by
        simpa only [H.coe_adj] using hcaCoe
      have hcbH : H.Adj c.1 b.1 := by
        simpa only [H.coe_adj] using hcbCoe
      have hab : (a.1 : V) ≠ b.1 := by
        intro habval
        apply hne
        apply Subtype.ext
        have habsub : a = b := Subtype.ext habval
        simpa only [he₁, he₂, habsub]
      rcases lt_or_gt_of_ne hab with hablt | hbalt
      · let p : T.canonicalLengthTwoPathInSubgraphFinset H :=
          ⟨(a.1, c.1, b.1),
            (T.mem_canonicalLengthTwoPathInSubgraphFinset H
              a.1 c.1 b.1).2
              ⟨hcaH.symm.adj_sub, hcbH.adj_sub, hablt,
                (SimpleGraph.Subgraph.mem_edgeSet).2 hcaH.symm,
                (SimpleGraph.Subgraph.mem_edgeSet).2 hcbH⟩⟩
        have he₁' : subgraphEdgeOfAdj H hcaH.symm = e₁ := by
          apply Subtype.ext
          simpa [subgraphEdgeOfAdj, he₁, Sym2.eq_swap]
        have he₂' : subgraphEdgeOfAdj H hcbH = e₂ := by
          apply Subtype.ext
          simpa [subgraphEdgeOfAdj, he₂]
        refine ⟨p, ?_⟩
        apply Subtype.ext
        change s(subgraphEdgeOfAdj H hcaH.symm,
          subgraphEdgeOfAdj H hcbH) = s(e₁, e₂)
        rw [he₁', he₂']
      · let p : T.canonicalLengthTwoPathInSubgraphFinset H :=
          ⟨(b.1, c.1, a.1),
            (T.mem_canonicalLengthTwoPathInSubgraphFinset H
              b.1 c.1 a.1).2
              ⟨hcbH.symm.adj_sub, hcaH.adj_sub, hbalt,
                (SimpleGraph.Subgraph.mem_edgeSet).2 hcbH.symm,
                (SimpleGraph.Subgraph.mem_edgeSet).2 hcaH⟩⟩
        have he₂' : subgraphEdgeOfAdj H hcbH.symm = e₂ := by
          apply Subtype.ext
          simpa [subgraphEdgeOfAdj, he₂, Sym2.eq_swap]
        have he₁' : subgraphEdgeOfAdj H hcaH = e₁ := by
          apply Subtype.ext
          simpa [subgraphEdgeOfAdj, he₁]
        refine ⟨p, ?_⟩
        apply Subtype.ext
        change s(subgraphEdgeOfAdj H hcbH.symm,
          subgraphEdgeOfAdj H hcaH) = s(e₁, e₂)
        rw [he₂', he₁']
        exact Sym2.eq_swap

/-- Canonical length-two paths in a subgraph are exactly the edges of its
line graph. -/
noncomputable def canonicalPathInSubgraphEquivLineEdge [LinearOrder V]
    (T : XTree X V) (H : T.graph.Subgraph) :
    T.canonicalLengthTwoPathInSubgraphFinset H ≃
      H.coe.lineGraph.edgeSet :=
  Equiv.ofBijective (T.canonicalPathInSubgraphToLineEdge H)
    ⟨T.canonicalPathInSubgraphToLineEdge_injective H,
      T.canonicalPathInSubgraphToLineEdge_surjective H⟩

/-- For a paired partial split, being a displaying side-pair is equivalent
to having both adjacent edges in the common displaying path. -/
theorem displayingLengthTwoPathFinset_eq_quartetPathPaths [LinearOrder V]
    (T : XTree X V) (q₁ q₂ q₃ q₄ : X)
    (hP : IsPartialSplit
      s(({q₁, q₂} : Finset X), ({q₃, q₄} : Finset X))) :
    T.displayingLengthTwoPathFinset
        s(({q₁, q₂} : Finset X), ({q₃, q₄} : Finset X)) =
      T.canonicalLengthTwoPathInSubgraphFinset
        (T.quartetPathSubgraph q₁ q₂ q₃ q₄) := by
  classical
  let P : PartialSplit X :=
    s(({q₁, q₂} : Finset X), ({q₃, q₄} : Finset X))
  let H := T.quartetPathSubgraph q₁ q₂ q₃ q₄
  ext p
  rcases p with ⟨u, v, w⟩
  rw [T.mem_displayingLengthTwoPathFinset P u v w,
    T.mem_canonicalLengthTwoPathInSubgraphFinset H u v w]
  constructor
  · rintro ⟨huv, hvw, huw, hdisplay⟩
    have hb := (T.displays_sidePairSplit_iff_displays_both_edges
      huv hvw (ne_of_lt huw) hP).1 hdisplay
    exact ⟨huv, hvw, huw,
      (T.edge_mem_quartetPathSubgraph_iff_displays huv
        q₁ q₂ q₃ q₄).2 hb.1,
      (T.edge_mem_quartetPathSubgraph_iff_displays hvw
        q₁ q₂ q₃ q₄).2 hb.2⟩
  · rintro ⟨huv, hvw, huw, he₁, he₂⟩
    refine ⟨huv, hvw, huw,
      (T.displays_sidePairSplit_iff_displays_both_edges
        huv hvw (ne_of_lt huw) hP).2 ?_⟩
    exact ⟨(T.edge_mem_quartetPathSubgraph_iff_displays huv
        q₁ q₂ q₃ q₄).1 he₁,
      (T.edge_mem_quartetPathSubgraph_iff_displays hvw
        q₁ q₂ q₃ q₄).1 he₂⟩

theorem card_displayingLengthTwoPathFinset_eq_lineEdgeSet [LinearOrder V]
    (T : XTree X V) (q₁ q₂ q₃ q₄ : X)
    (hP : IsPartialSplit
      s(({q₁, q₂} : Finset X), ({q₃, q₄} : Finset X))) :
    (T.displayingLengthTwoPathFinset
      s(({q₁, q₂} : Finset X), ({q₃, q₄} : Finset X))).card =
      (T.quartetPathSubgraph q₁ q₂ q₃ q₄).coe.lineGraph.edgeSet.ncard := by
  rw [T.displayingLengthTwoPathFinset_eq_quartetPathPaths
    q₁ q₂ q₃ q₄ hP]
  simpa only [Nat.card_coe_set_eq, Nat.card_eq_fintype_card,
    Fintype.card_coe] using Nat.card_congr
      (T.canonicalPathInSubgraphEquivLineEdge
        (T.quartetPathSubgraph q₁ q₂ q₃ q₄))

/-- Exact `k-1` statement used in Theorem 1: whenever the paired partial
split is genuinely displayed, its canonical displaying side-pairs are one
fewer than its canonical displaying edges. -/
theorem card_displayingLengthTwoPathFinset_add_one_eq_edges [LinearOrder V]
    (T : XTree X V) (q₁ q₂ q₃ q₄ : X)
    (hP : IsPartialSplit
      s(({q₁, q₂} : Finset X), ({q₃, q₄} : Finset X)))
    (hdisplay : T.DisplaysPartialSplit
      s(({q₁, q₂} : Finset X), ({q₃, q₄} : Finset X))) :
    (T.displayingLengthTwoPathFinset
      s(({q₁, q₂} : Finset X), ({q₃, q₄} : Finset X))).card + 1 =
      (T.displayingEdgeFinset
        s(({q₁, q₂} : Finset X), ({q₃, q₄} : Finset X))).card := by
  classical
  let P : PartialSplit X :=
    s(({q₁, q₂} : Finset X), ({q₃, q₄} : Finset X))
  let H := T.quartetPathSubgraph q₁ q₂ q₃ q₄
  rcases hdisplay with ⟨u, v, huv, hdisplays⟩
  have heH : s(u, v) ∈ H.edgeSet :=
    (T.edge_mem_quartetPathSubgraph_iff_displays huv
      q₁ q₂ q₃ q₄).2 hdisplays
  have htree : H.coe.lineGraph.IsTree :=
    T.quartetPathLineGraph_isTree_of_edge q₁ q₂ q₃ q₄ heH
  letI : Fintype H.coe.edgeSet := Fintype.ofFinite _
  letI : Fintype H.coe.lineGraph.edgeSet := Fintype.ofFinite _
  have hline : H.coe.lineGraph.edgeSet.ncard + 1 =
      H.coe.edgeSet.ncard := by
    calc
      H.coe.lineGraph.edgeSet.ncard + 1 =
          H.coe.lineGraph.edgeFinset.card + 1 := by
        simp [SimpleGraph.edgeFinset, Set.ncard_eq_toFinset_card]
      _ = Fintype.card H.coe.edgeSet := htree.card_edgeFinset
      _ = H.coe.edgeSet.ncard := by
        rw [← Nat.card_coe_set_eq, Nat.card_eq_fintype_card]
  have hcoe : H.coe.edgeSet.ncard = H.edgeSet.ncard := by
    simpa only [Nat.card_coe_set_eq] using Nat.card_congr
      (PathGeometry.coeEdgeEquiv H)
  calc
    (T.displayingLengthTwoPathFinset P).card + 1 =
        H.coe.lineGraph.edgeSet.ncard + 1 := by
      rw [T.card_displayingLengthTwoPathFinset_eq_lineEdgeSet
        q₁ q₂ q₃ q₄ hP]
    _ = H.coe.edgeSet.ncard := hline
    _ = H.edgeSet.ncard := hcoe
    _ = (T.displayingEdgeFinset P).card := by
      rw [T.card_displayingEdgeFinset_eq_quartetPathEdgeSet
        q₁ q₂ q₃ q₄]

end XTree

end QDFull
