import QDFull.LocalMasses

/-!
# Split covariance and the edge-coordinate determinant

This file formalizes the corresponding part of the manuscript.  The square of
the normalized `2 x 2` determinant is first shown to be independent of the
choice of representatives of the two unordered partial splits.  The paper's
edge coordinate `X_{t,u}^{v,w}` is then identified with that determinant.
-/

open scoped BigOperators
open SimpleGraph

namespace QDFull

universe uX uV₁ uV₂

/-- The oriented normalized `2 x 2` determinant associated with four blocks.
The square of this number is independent of swapping either pair of blocks. -/
noncomputable def orientedSplitDeterminant {X : Type uX} [Fintype X]
    (A B C D : Finset X) : ℝ := by
  classical
  exact normalizedCard (A ∩ C) * normalizedCard (B ∩ D) -
    normalizedCard (A ∩ D) * normalizedCard (B ∩ C)

/-- Six times the squared oriented determinant, exactly the closed formula for
the paper's split quartet covariance. -/
noncomputable def orientedSplitCovariance {X : Type uX} [Fintype X]
    (A B C D : Finset X) : ℝ :=
  6 * orientedSplitDeterminant A B C D ^ 2

theorem orientedSplitDeterminant_swap_left {X : Type uX} [Fintype X]
    (A B C D : Finset X) :
    orientedSplitDeterminant B A C D =
      -orientedSplitDeterminant A B C D := by
  unfold orientedSplitDeterminant
  ring

theorem orientedSplitDeterminant_swap_right {X : Type uX} [Fintype X]
    (A B C D : Finset X) :
    orientedSplitDeterminant A B D C =
      -orientedSplitDeterminant A B C D := by
  unfold orientedSplitDeterminant
  ring

theorem orientedSplitDeterminant_swap_both {X : Type uX} [Fintype X]
    (A B C D : Finset X) :
    orientedSplitDeterminant B A D C =
      orientedSplitDeterminant A B C D := by
  rw [orientedSplitDeterminant_swap_left,
    orientedSplitDeterminant_swap_right]
  simp

theorem orientedSplitCovariance_swap_left {X : Type uX} [Fintype X]
    (A B C D : Finset X) :
    orientedSplitCovariance B A C D =
      orientedSplitCovariance A B C D := by
  rw [orientedSplitCovariance, orientedSplitCovariance,
    orientedSplitDeterminant_swap_left]
  ring

theorem orientedSplitCovariance_swap_right {X : Type uX} [Fintype X]
    (A B C D : Finset X) :
    orientedSplitCovariance A B D C =
      orientedSplitCovariance A B C D := by
  rw [orientedSplitCovariance, orientedSplitCovariance,
    orientedSplitDeterminant_swap_right]
  ring

/-- Quartet covariance of two unordered partial splits, represented by the
paper's closed determinant formula.  The two symmetry proofs above make the
definition independent of both choices of side order. -/
noncomputable def splitQuartetCovariance {X : Type uX} [Fintype X]
    (P Q : PartialSplit X) : ℝ :=
  Sym2.lift₂
    ⟨fun A B C D => orientedSplitCovariance A B C D,
      fun A B C D =>
        ⟨(orientedSplitCovariance_swap_left A B C D).symm,
          (orientedSplitCovariance_swap_right A B C D).symm⟩⟩ P Q

@[simp] theorem splitQuartetCovariance_mk {X : Type uX} [Fintype X]
    (A B C D : Finset X) :
    splitQuartetCovariance s(A, B) s(C, D) =
      orientedSplitCovariance A B C D := by
  rfl

/-- The paper's edge coordinate `X_{t,u}^{v,w}`. -/
noncomputable def xCoefficient
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u : V₁) (v w : V₂) : ℝ :=
  jointMass T₁ T₂ t u v w t v *
      jointMass T₁ T₂ u t w v u w -
    jointMass T₁ T₂ t u w v t w *
      jointMass T₁ T₂ u t v w u v

/-- Reversing the column edge changes the sign of `X`. -/
theorem xCoefficient_reverse_column
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u : V₁) (v w : V₂) :
    xCoefficient T₁ T₂ t u w v =
      -xCoefficient T₁ T₂ t u v w := by
  unfold xCoefficient
  ring

/-- Reversing the row edge changes the sign of `X`. -/
theorem xCoefficient_reverse_row
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u : V₁) (v w : V₂) :
    xCoefficient T₁ T₂ u t v w =
      -xCoefficient T₁ T₂ t u v w := by
  unfold xCoefficient
  ring

/-- Reversing both edges preserves `X`. -/
theorem xCoefficient_reverse_both
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u : V₁) (v w : V₂) :
    xCoefficient T₁ T₂ u t w v =
      xCoefficient T₁ T₂ t u v w := by
  unfold xCoefficient
  ring

/-- On two actual tree edges, `X` is the normalized `2 x 2` determinant of
the four edge-side intersections. -/
theorem xCoefficient_eq_edge_determinant
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w) :
    xCoefficient T₁ T₂ t u v w =
      orientedSplitDeterminant
        (T₁.edgeSide u t) (T₁.edgeSide t u)
        (T₂.edgeSide w v) (T₂.edgeSide v w) := by
  unfold xCoefficient jointMass jointBlock
  rw [T₁.rowBlock_of_adj t htu.symm, T₂.columnBlock_of_adj v hvw.symm,
    T₁.rowBlock_of_adj u htu, T₂.columnBlock_of_adj w hvw]
  unfold orientedSplitDeterminant
  rfl

/-- Exact paper identity `Q(S_{tu},S_{vw}) = 6 (X_{t,u}^{v,w})^2`. -/
theorem edgeSplit_quartetCovariance_eq
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w) :
    splitQuartetCovariance (T₁.edgeSplit t u) (T₂.edgeSplit v w) =
      6 * xCoefficient T₁ T₂ t u v w ^ 2 := by
  rw [xCoefficient_eq_edge_determinant T₁ T₂ htu hvw]
  change orientedSplitCovariance
      (T₁.edgeSide t u) (T₁.edgeSide u t)
      (T₂.edgeSide v w) (T₂.edgeSide w v) =
    6 * orientedSplitDeterminant
      (T₁.edgeSide u t) (T₁.edgeSide t u)
      (T₂.edgeSide w v) (T₂.edgeSide v w) ^ 2
  unfold orientedSplitCovariance
  rw [orientedSplitDeterminant_swap_both]

end QDFull
