import QDFull.Preliminaries

/-!
# Local branch blocks and normalized masses

This file formalizes the corresponding part of the manuscript.  The parent
index in `R_{t,u}` or `C^{v,w}` records the chosen oriented principal edge;
the underlying block at the centre is determined by the centre and the branch
argument.  Keeping that distinction explicit makes the later reindexing
identities auditable.
-/

open scoped BigOperators
open SimpleGraph

namespace QDFull

universe uX uV uV₁ uV₂

/-- Cardinality normalized by the total number of taxa. -/
noncomputable def normalizedCard {X : Type uX} [Fintype X]
    (S : Finset X) : ℝ :=
  (S.card : ℝ) / (Fintype.card X : ℝ)

theorem normalizedCard_nonneg {X : Type uX} [Fintype X]
    (S : Finset X) : 0 ≤ normalizedCard S := by
  unfold normalizedCard
  positivity

theorem normalizedCard_pos {X : Type uX} [Fintype X] [Nonempty X]
    {S : Finset X} (hS : S.Nonempty) : 0 < normalizedCard S := by
  unfold normalizedCard
  have hcardX : 0 < Fintype.card X := Fintype.card_pos
  have hcardS : 0 < S.card := Finset.card_pos.mpr hS
  positivity

namespace XTree

variable {X : Type uX} {V : Type uV} [Fintype X] [Fintype V]

/-- The taxa whose label is exactly the indicated graph vertex. -/
noncomputable def labelFiber (T : XTree X V) (v : V) : Finset X := by
  classical
  exact Finset.univ.filter fun x => T.label x = v

@[simp] theorem mem_labelFiber (T : XTree X V) (v : V) (x : X) :
    x ∈ T.labelFiber v ↔ T.label x = v := by
  classical
  simp [labelFiber]

/-- The local block at `z ∈ N_+(centre)`: the labels at the centre itself, or
the taxa in the component leaving the centre through the neighbour `z`.
Outside `N_+(centre)` the value is defined as the empty set; all paper uses
are accompanied by the corresponding membership hypothesis. -/
noncomputable def branchBlock (T : XTree X V) (centre z : V) : Finset X := by
  classical
  exact if z = centre then T.labelFiber centre
    else if T.graph.Adj centre z then T.edgeSide centre z else ∅

@[simp] theorem branchBlock_self (T : XTree X V) (centre : V) :
    T.branchBlock centre centre = T.labelFiber centre := by
  classical
  simp [branchBlock]

theorem branchBlock_of_adj (T : XTree X V) {centre z : V}
    (hadj : T.graph.Adj centre z) :
    T.branchBlock centre z = T.edgeSide centre z := by
  classical
  simp [branchBlock, hadj, hadj.ne']

/-- `R_{t,u}(u')` from the paper. -/
noncomputable def rowBlock (T : XTree X V) (_t u u' : V) : Finset X :=
  T.branchBlock u u'

/-- `C^{v,w}(w')` from the paper. -/
noncomputable def columnBlock (T : XTree X V) (_v w w' : V) : Finset X :=
  T.branchBlock w w'

@[simp] theorem rowBlock_center (T : XTree X V) (t u : V) :
    T.rowBlock t u u = T.labelFiber u := by
  simp [rowBlock]

@[simp] theorem columnBlock_center (T : XTree X V) (v w : V) :
    T.columnBlock v w w = T.labelFiber w := by
  simp [columnBlock]

theorem rowBlock_of_adj (T : XTree X V) (t : V) {u u' : V}
    (hadj : T.graph.Adj u u') :
    T.rowBlock t u u' = T.edgeSide u u' := by
  simpa [rowBlock] using T.branchBlock_of_adj hadj

theorem columnBlock_of_adj (T : XTree X V) (v : V) {w w' : V}
    (hadj : T.graph.Adj w w') :
    T.columnBlock v w w' = T.edgeSide w w' := by
  simpa [columnBlock] using T.branchBlock_of_adj hadj

/-- Lowercase row mass. -/
noncomputable def rowMass (T : XTree X V) (t u u' : V) : ℝ :=
  normalizedCard (T.rowBlock t u u')

/-- Lowercase column mass. -/
noncomputable def columnMass (T : XTree X V) (v w w' : V) : ℝ :=
  normalizedCard (T.columnBlock v w w')

theorem rowMass_pos_of_adj (T : XTree X V) {t u : V}
    (htu : T.graph.Adj t u) : 0 < T.rowMass t u t := by
  letI : Nonempty X := T.taxon_nonempty
  rw [rowMass, T.rowBlock_of_adj t htu.symm]
  exact normalizedCard_pos (T.edgeSide_nonempty_of_adj htu.symm)

theorem columnMass_pos_of_adj (T : XTree X V) {v w : V}
    (hvw : T.graph.Adj v w) : 0 < T.columnMass v w v := by
  letI : Nonempty X := T.taxon_nonempty
  rw [columnMass, T.columnBlock_of_adj v hvw.symm]
  exact normalizedCard_pos (T.edgeSide_nonempty_of_adj hvw.symm)

end XTree

section TwoTrees

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]

/-- `A_{t,u}^{v,w}(u',w')`, the intersection of one row block and one
column block. -/
noncomputable def jointBlock
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u : V₁) (v w : V₂) (u' : V₁) (w' : V₂) : Finset X := by
  classical
  exact T₁.rowBlock t u u' ∩ T₂.columnBlock v w w'

/-- The normalized cardinality `a_{t,u}^{v,w}(u',w')`. -/
noncomputable def jointMass
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u : V₁) (v w : V₂) (u' : V₁) (w' : V₂) : ℝ :=
  normalizedCard (jointBlock T₁ T₂ t u v w u' w')

@[simp] theorem jointBlock_parent_irrelevant_row
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t t' u u' : V₁) (v w w' : V₂) :
    jointBlock T₁ T₂ t u v w u' w' =
      jointBlock T₁ T₂ t' u v w u' w' := by
  rfl

@[simp] theorem jointBlock_parent_irrelevant_column
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' : V₁) (v v' w w' : V₂) :
    jointBlock T₁ T₂ t u v w u' w' =
      jointBlock T₁ T₂ t u v' w u' w' := by
  rfl

@[simp] theorem jointMass_parent_irrelevant_row
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t t' u u' : V₁) (v w w' : V₂) :
    jointMass T₁ T₂ t u v w u' w' =
      jointMass T₁ T₂ t' u v w u' w' := by
  rfl

@[simp] theorem jointMass_parent_irrelevant_column
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' : V₁) (v v' w w' : V₂) :
    jointMass T₁ T₂ t u v w u' w' =
      jointMass T₁ T₂ t u v' w u' w' := by
  rfl

/-- The coefficient `q_{t,u}^{v,w}(u',u'',w',w'')`. -/
noncomputable def qCoefficient
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u : V₁) (v w : V₂)
    (u' u'' : V₁) (w' w'' : V₂) : ℝ :=
  (1 / 2 : ℝ) * T₂.columnMass v w w'' *
    (jointMass T₁ T₂ t u v w u' w' *
        jointMass T₁ T₂ t u v w u'' v / T₂.columnMass v w v +
      jointMass T₁ T₂ t u v w u'' w' *
        jointMass T₁ T₂ t u v w u' v / T₂.columnMass v w v)

/-- Reversing the row principal edge and swapping the two row arguments does
not change `q`.  This is the first reindexing identity in the paper. -/
theorem qCoefficient_row_reindex
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' : V₁) (v w : V₂) (w' w'' : V₂) :
    qCoefficient T₁ T₂ t u v w u' t w' w'' =
      qCoefficient T₁ T₂ u' u v w t u' w' w'' := by
  unfold qCoefficient jointMass jointBlock XTree.rowBlock
  ring

/-- Reversing the column principal edge and swapping the two column roles does
not change `q`, provided both denominators correspond to actual edge sides. -/
theorem qCoefficient_column_reindex
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' u'' : V₁) (v w w' : V₂)
    (hvw : T₂.graph.Adj v w) (hw'w : T₂.graph.Adj w' w) :
    qCoefficient T₁ T₂ t u v w u' u'' w' v =
      qCoefficient T₁ T₂ t u w' w u' u'' v w' := by
  have hcv : T₂.columnMass v w v ≠ 0 :=
    ne_of_gt (T₂.columnMass_pos_of_adj hvw)
  have hcw' : T₂.columnMass w' w w' ≠ 0 :=
    ne_of_gt (T₂.columnMass_pos_of_adj hw'w)
  unfold qCoefficient
  change
    (1 / 2 : ℝ) * T₂.columnMass v w v *
        (jointMass T₁ T₂ t u v w u' w' *
              jointMass T₁ T₂ t u v w u'' v / T₂.columnMass v w v +
          jointMass T₁ T₂ t u v w u'' w' *
              jointMass T₁ T₂ t u v w u' v / T₂.columnMass v w v) =
      (1 / 2 : ℝ) * T₂.columnMass w' w w' *
        (jointMass T₁ T₂ t u v w u' v *
              jointMass T₁ T₂ t u v w u'' w' / T₂.columnMass w' w w' +
          jointMass T₁ T₂ t u v w u'' v *
              jointMass T₁ T₂ t u v w u' w' / T₂.columnMass w' w w')
  field_simp [hcv, hcw']
  ring

/-- The paper's `b` coefficient.  The printed definition writes
`b_{u u'}^{v,w}`, although its defining right-hand side depends on the full
length-two path `t-u-u'` and Theorem 2 later indexes it by the two path
endpoints.  Lean therefore keeps all three path vertices explicit. -/
noncomputable def bCoefficient
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' : V₁) (v w w' w'' : V₂) : ℝ :=
  qCoefficient T₁ T₂ t u v w u' t w' w''

/-- `s_{t,u}^{vw'}(u',u'')`. -/
noncomputable def sCoefficient
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' u'' : V₁) (v w w' : V₂) : ℝ :=
  qCoefficient T₁ T₂ t u v w u' u'' w' v

/-- `p_{tu'}^{vw'}`. -/
noncomputable def pCoefficient
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' : V₁) (v w w' : V₂) : ℝ :=
  qCoefficient T₁ T₂ t u v w u' t w' v

/-- First equality in the paper's eightfold display for `p`: row reversal. -/
theorem pCoefficient_eq_q_row
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' : V₁) (v w w' : V₂) :
    pCoefficient T₁ T₂ t u u' v w w' =
      qCoefficient T₁ T₂ u' u v w t u' w' v := by
  unfold pCoefficient
  exact qCoefficient_row_reindex T₁ T₂ t u u' v w w' v

/-- Second equality in the paper's eightfold display for `p`: column
reversal.  The adjacency hypotheses are exactly what make the two column-side
denominators nonzero. -/
theorem pCoefficient_eq_q_column
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' : V₁) (v w w' : V₂)
    (hvw : T₂.graph.Adj v w) (hw'w : T₂.graph.Adj w' w) :
    pCoefficient T₁ T₂ t u u' v w w' =
      qCoefficient T₁ T₂ t u w' w u' t v w' := by
  unfold pCoefficient
  exact qCoefficient_column_reindex T₁ T₂ t u u' t v w w' hvw hw'w

/-- Third equality in the paper's eightfold display for `p`: simultaneous row
and column reversal. -/
theorem pCoefficient_eq_q_row_column
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' : V₁) (v w w' : V₂)
    (hvw : T₂.graph.Adj v w) (hw'w : T₂.graph.Adj w' w) :
    pCoefficient T₁ T₂ t u u' v w w' =
      qCoefficient T₁ T₂ u' u w' w t u' v w' := by
  rw [pCoefficient_eq_q_column T₁ T₂ t u u' v w w' hvw hw'w]
  exact qCoefficient_row_reindex T₁ T₂ t u u' w' w v w'

/-- Fourth entry in the eightfold display: the defining `b` occurrence. -/
theorem pCoefficient_eq_b
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' : V₁) (v w w' : V₂) :
    pCoefficient T₁ T₂ t u u' v w w' =
      bCoefficient T₁ T₂ t u u' v w w' v := rfl

/-- Fifth entry in the eightfold display: the column-reversed `b`
occurrence. -/
theorem pCoefficient_eq_b_column
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' : V₁) (v w w' : V₂)
    (hvw : T₂.graph.Adj v w) (hw'w : T₂.graph.Adj w' w) :
    pCoefficient T₁ T₂ t u u' v w w' =
      bCoefficient T₁ T₂ t u u' w' w v w' := by
  exact pCoefficient_eq_q_column T₁ T₂ t u u' v w w' hvw hw'w

/-- Sixth entry in the eightfold display: the defining `s` occurrence. -/
theorem pCoefficient_eq_s
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' : V₁) (v w w' : V₂) :
    pCoefficient T₁ T₂ t u u' v w w' =
      sCoefficient T₁ T₂ t u u' t v w w' := rfl

/-- Seventh entry in the eightfold display: the row-reversed `s`
occurrence. -/
theorem pCoefficient_eq_s_row
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' : V₁) (v w w' : V₂) :
    pCoefficient T₁ T₂ t u u' v w w' =
      sCoefficient T₁ T₂ u' u t u' v w w' := by
  exact pCoefficient_eq_q_row T₁ T₂ t u u' v w w'

end TwoTrees

end QDFull
