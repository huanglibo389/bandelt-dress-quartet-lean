import QDFull.PathPathCovariance

/-!
# A finite audit of the path-index convention in Theorem 2

An earlier draft left the path index `P_i` undefined and could be read as using
all ordered length-two paths.  The current locked manuscript instead selects
one representative from every reversal orbit.  This file retains an exact
four-taxon regression test comparing the two interpretations.
-/

open scoped BigOperators
open SimpleGraph

namespace QDFull

namespace TheoremTwoCounterexample

abbrev Taxon4 := Fin 4
abbrev Vertex6 := Fin 6

/-- One orientation of the five edges of the quartet tree with cherries
`0,1` and `2,3` and internal vertices `4,5`.  `fromRel` adds the reverse
orientations and removes loops. -/
def quartetRel (x y : Vertex6) : Prop :=
  (x.1 = 0 ∧ y.1 = 4) ∨
  (x.1 = 1 ∧ y.1 = 4) ∨
  (x.1 = 4 ∧ y.1 = 5) ∨
  (x.1 = 2 ∧ y.1 = 5) ∨
  (x.1 = 3 ∧ y.1 = 5)

instance quartetRel_decidable : DecidableRel quartetRel := by
  intro x y
  unfold quartetRel
  infer_instance

def quartetGraph : SimpleGraph Vertex6 :=
  SimpleGraph.fromRel quartetRel

instance quartetGraph_decidableAdj : DecidableRel quartetGraph.Adj := by
  intro x y
  unfold quartetGraph
  infer_instance

theorem quartetGraph_isTree : quartetGraph.IsTree := by
  apply SimpleGraph.isTree_iff_connected_and_card.mpr
  constructor
  · decide
  · rw [Nat.card_eq_fintype_card, Nat.card_eq_fintype_card]
    decide

def quartetLabel : Taxon4 → Vertex6 :=
  Fin.castLE (by decide)

theorem quartetGraph_lowDegree_labelled :
    ∀ v : Vertex6,
      Nat.card (quartetGraph.neighborSet v) ≤ 2 →
        ∃ x : Taxon4, quartetLabel x = v := by
  intro v hv
  fin_cases v
  · exact ⟨0, rfl⟩
  · exact ⟨1, rfl⟩
  · exact ⟨2, rfl⟩
  · exact ⟨3, rfl⟩
  · exfalso
    change Nat.card (quartetGraph.neighborSet (4 : Vertex6)) ≤ 2 at hv
    have hcard : Nat.card (quartetGraph.neighborSet (4 : Vertex6)) = 3 := by
      rw [Nat.card_eq_fintype_card]
      decide
    omega
  · exfalso
    change Nat.card (quartetGraph.neighborSet (5 : Vertex6)) ≤ 2 at hv
    have hcard : Nat.card (quartetGraph.neighborSet (5 : Vertex6)) = 3 := by
      rw [Nat.card_eq_fintype_card]
      decide
    omega

def quartetTree : XTree Taxon4 Vertex6 where
  graph := quartetGraph
  isTree := quartetGraph_isTree
  label := quartetLabel
  lowDegree_labelled := quartetGraph_lowDegree_labelled

instance quartetTree_decidableAdj : DecidableRel quartetTree.graph.Adj :=
  quartetGraph_decidableAdj

@[simp] theorem quartetTree_adj_iff (x y : Vertex6) :
    quartetTree.graph.Adj x y ↔
      x ≠ y ∧ (quartetRel x y ∨ quartetRel y x) := by
  rfl

theorem edgeSide_4_0 : quartetTree.edgeSide 4 0 = {0} := by
  ext x
  rw [quartetTree.mem_edgeSide]
  fin_cases x <;> decide

theorem edgeSide_0_4 : quartetTree.edgeSide 0 4 = {1, 2, 3} := by
  ext x
  rw [quartetTree.mem_edgeSide]
  fin_cases x <;> decide

theorem edgeSide_4_1 : quartetTree.edgeSide 4 1 = {1} := by
  ext x
  rw [quartetTree.mem_edgeSide]
  fin_cases x <;> decide

theorem edgeSide_1_4 : quartetTree.edgeSide 1 4 = {0, 2, 3} := by
  ext x
  rw [quartetTree.mem_edgeSide]
  fin_cases x <;> decide

theorem edgeSide_5_2 : quartetTree.edgeSide 5 2 = {2} := by
  ext x
  rw [quartetTree.mem_edgeSide]
  fin_cases x <;> decide

theorem edgeSide_2_5 : quartetTree.edgeSide 2 5 = {0, 1, 3} := by
  ext x
  rw [quartetTree.mem_edgeSide]
  fin_cases x <;> decide

theorem edgeSide_5_3 : quartetTree.edgeSide 5 3 = {3} := by
  ext x
  rw [quartetTree.mem_edgeSide]
  fin_cases x <;> decide

theorem edgeSide_3_5 : quartetTree.edgeSide 3 5 = {0, 1, 2} := by
  ext x
  rw [quartetTree.mem_edgeSide]
  fin_cases x <;> decide

theorem edgeSide_4_5 : quartetTree.edgeSide 4 5 = {2, 3} := by
  ext x
  rw [quartetTree.mem_edgeSide]
  fin_cases x <;> decide

theorem edgeSide_5_4 : quartetTree.edgeSide 5 4 = {0, 1} := by
  ext x
  rw [quartetTree.mem_edgeSide]
  fin_cases x <;> decide

/-- The complete branch-block table of the concrete quartet tree. -/
def expectedBranchBlock (centre z : Vertex6) : Finset Taxon4 :=
  if centre = 0 then
    if z = 0 then {0} else if z = 4 then {1, 2, 3} else ∅
  else if centre = 1 then
    if z = 1 then {1} else if z = 4 then {0, 2, 3} else ∅
  else if centre = 2 then
    if z = 2 then {2} else if z = 5 then {0, 1, 3} else ∅
  else if centre = 3 then
    if z = 3 then {3} else if z = 5 then {0, 1, 2} else ∅
  else if centre = 4 then
    if z = 0 then {0} else if z = 1 then {1}
    else if z = 5 then {2, 3} else ∅
  else
    if z = 2 then {2} else if z = 3 then {3}
    else if z = 4 then {0, 1} else ∅

theorem branchBlock_eq_expected (centre z : Vertex6) :
    quartetTree.branchBlock centre z = expectedBranchBlock centre z := by
  ext x
  fin_cases centre <;> fin_cases z <;> fin_cases x <;>
    simp [XTree.branchBlock, expectedBranchBlock, XTree.mem_labelFiber,
      quartetTree_adj_iff, quartetRel, quartetTree.mem_edgeSide] <;>
    decide

/-! ## A computable rational mirror of the paper's coefficients -/

/-- Exact branch mass on the concrete four-taxon tree. -/
def branchMassQ (centre z : Vertex6) : ℚ :=
  (expectedBranchBlock centre z).card / 4

/-- Exact mass of the intersection of two concrete branch blocks. -/
def jointMassQ (u u' w w' : Vertex6) : ℚ :=
  (expectedBranchBlock u u' ∩ expectedBranchBlock w w').card / 4

/-- Rational version of the paper's edge coordinate `X`. -/
def xCoefficientQ (t u v w : Vertex6) : ℚ :=
  jointMassQ u t w v * jointMassQ t u v w -
    jointMassQ u t v w * jointMassQ t u w v

/-- Rational version of the paper's coefficient `q`. -/
def qCoefficientQ (t u v w u' u'' w' w'' : Vertex6) : ℚ :=
  (1 / 2 : ℚ) * branchMassQ w w'' *
    (jointMassQ u u' w w' * jointMassQ u u'' w v / branchMassQ w v +
      jointMassQ u u'' w w' * jointMassQ u u' w v / branchMassQ w v)

/-- Rational version of the paper's coefficient `s`. -/
def sCoefficientQ (t u u' u'' v w v' : Vertex6) : ℚ :=
  qCoefficientQ t u v w u' u'' v' v

/-- Rational version of the corrected path-indexed coefficient `b`. -/
def bCoefficientQ (t u t' v w w' w'' : Vertex6) : ℚ :=
  qCoefficientQ t u v w t' t w' w''

/-- Rational version of the paper's coefficient `p`. -/
def pCoefficientQ (t u t' v w v' : Vertex6) : ℚ :=
  qCoefficientQ t u v w t' t v' v

/-- Computable directed-edge index set of the concrete tree. -/
def directedEdgeFinsetQ : Finset (Vertex6 × Vertex6) :=
  Finset.univ.filter fun e => quartetTree.graph.Adj e.1 e.2

/-- Explicit directed-edge table used to split the exact rational audit into
small kernel-checked rows. -/
@[simp] theorem directedEdgeFinsetQ_value :
    directedEdgeFinsetQ =
      {((0 : Vertex6), (4 : Vertex6)), ((4 : Vertex6), (0 : Vertex6)),
       ((1 : Vertex6), (4 : Vertex6)), ((4 : Vertex6), (1 : Vertex6)),
       ((2 : Vertex6), (5 : Vertex6)), ((5 : Vertex6), (2 : Vertex6)),
       ((3 : Vertex6), (5 : Vertex6)), ((5 : Vertex6), (3 : Vertex6)),
       ((4 : Vertex6), (5 : Vertex6)), ((5 : Vertex6), (4 : Vertex6))} := by
  ext e
  rcases e with ⟨x, y⟩
  fin_cases x <;> fin_cases y <;>
    simp [directedEdgeFinsetQ, quartetTree_adj_iff, quartetRel]

/-- Computable ordered length-two paths of the concrete tree. -/
def orderedPathFinsetQ : Finset (Vertex6 × Vertex6 × Vertex6) :=
  Finset.univ.filter fun p =>
    quartetTree.graph.Adj p.1 p.2.1 ∧
      quartetTree.graph.Adj p.2.1 p.2.2 ∧ p.1 ≠ p.2.2

set_option maxHeartbeats 2000000 in
@[simp] theorem orderedPathFinsetQ_value :
    orderedPathFinsetQ =
      {((0 : Vertex6), (4 : Vertex6), (1 : Vertex6)),
       ((0 : Vertex6), (4 : Vertex6), (5 : Vertex6)),
       ((1 : Vertex6), (4 : Vertex6), (0 : Vertex6)),
       ((1 : Vertex6), (4 : Vertex6), (5 : Vertex6)),
       ((5 : Vertex6), (4 : Vertex6), (0 : Vertex6)),
       ((5 : Vertex6), (4 : Vertex6), (1 : Vertex6)),
       ((2 : Vertex6), (5 : Vertex6), (3 : Vertex6)),
       ((2 : Vertex6), (5 : Vertex6), (4 : Vertex6)),
       ((3 : Vertex6), (5 : Vertex6), (2 : Vertex6)),
       ((3 : Vertex6), (5 : Vertex6), (4 : Vertex6)),
       ((4 : Vertex6), (5 : Vertex6), (2 : Vertex6)),
       ((4 : Vertex6), (5 : Vertex6), (3 : Vertex6))} := by
  ext p
  rcases p with ⟨x, y, z⟩
  fin_cases x <;> fin_cases y <;> fin_cases z <;>
    simp [orderedPathFinsetQ, quartetTree_adj_iff, quartetRel]

/-- One endpoint-ordered representative from each path-reversal orbit. -/
def canonicalPathFinsetQ : Finset (Vertex6 × Vertex6 × Vertex6) :=
  orderedPathFinsetQ.filter fun p => p.1 < p.2.2

set_option maxHeartbeats 2000000 in
@[simp] theorem canonicalPathFinsetQ_value :
    canonicalPathFinsetQ =
      {((0 : Vertex6), (4 : Vertex6), (1 : Vertex6)),
       ((0 : Vertex6), (4 : Vertex6), (5 : Vertex6)),
       ((1 : Vertex6), (4 : Vertex6), (5 : Vertex6)),
       ((2 : Vertex6), (5 : Vertex6), (3 : Vertex6)),
       ((2 : Vertex6), (5 : Vertex6), (4 : Vertex6)),
       ((3 : Vertex6), (5 : Vertex6), (4 : Vertex6))} := by
  ext p
  rcases p with ⟨x, y, z⟩
  fin_cases x <;> fin_cases y <;> fin_cases z <;>
    simp [canonicalPathFinsetQ, orderedPathFinsetQ,
      quartetTree_adj_iff, quartetRel]

/-- Computable finite copy of `I_{t,u}` on the concrete tree. -/
def indexIFinsetQ (t u : Vertex6) : Finset (Vertex6 × Vertex6) :=
  Finset.univ.filter fun p =>
    (p.1 = u ∨ (quartetTree.graph.Adj u p.1 ∧ p.1 ≠ t)) ∧
      (p.2 = u ∨ quartetTree.graph.Adj u p.2) ∧
        (p.1 = u ∨ (p.2 ≠ t ∧ p.2 ≠ p.1))

@[simp] theorem indexIFinsetQ_0_4 :
    indexIFinsetQ 0 4 =
      {((4 : Vertex6), (4 : Vertex6)), ((4 : Vertex6), (0 : Vertex6)),
       ((4 : Vertex6), (1 : Vertex6)), ((4 : Vertex6), (5 : Vertex6)),
       ((1 : Vertex6), (4 : Vertex6)), ((1 : Vertex6), (5 : Vertex6)),
       ((5 : Vertex6), (4 : Vertex6)), ((5 : Vertex6), (1 : Vertex6))} := by
  ext p
  rcases p with ⟨x, y⟩
  fin_cases x <;> fin_cases y <;>
    simp [indexIFinsetQ, quartetTree_adj_iff, quartetRel]

@[simp] theorem indexIFinsetQ_4_0 :
    indexIFinsetQ 4 0 =
      {((0 : Vertex6), (0 : Vertex6)), ((0 : Vertex6), (4 : Vertex6))} := by
  ext p
  rcases p with ⟨x, y⟩
  fin_cases x <;> fin_cases y <;>
    simp [indexIFinsetQ, quartetTree_adj_iff, quartetRel]

@[simp] theorem indexIFinsetQ_1_4 :
    indexIFinsetQ 1 4 =
      {((4 : Vertex6), (4 : Vertex6)), ((4 : Vertex6), (0 : Vertex6)),
       ((4 : Vertex6), (1 : Vertex6)), ((4 : Vertex6), (5 : Vertex6)),
       ((0 : Vertex6), (4 : Vertex6)), ((0 : Vertex6), (5 : Vertex6)),
       ((5 : Vertex6), (4 : Vertex6)), ((5 : Vertex6), (0 : Vertex6))} := by
  ext p
  rcases p with ⟨x, y⟩
  fin_cases x <;> fin_cases y <;>
    simp [indexIFinsetQ, quartetTree_adj_iff, quartetRel]

@[simp] theorem indexIFinsetQ_4_1 :
    indexIFinsetQ 4 1 =
      {((1 : Vertex6), (1 : Vertex6)), ((1 : Vertex6), (4 : Vertex6))} := by
  ext p
  rcases p with ⟨x, y⟩
  fin_cases x <;> fin_cases y <;>
    simp [indexIFinsetQ, quartetTree_adj_iff, quartetRel]

@[simp] theorem indexIFinsetQ_2_5 :
    indexIFinsetQ 2 5 =
      {((5 : Vertex6), (5 : Vertex6)), ((5 : Vertex6), (2 : Vertex6)),
       ((5 : Vertex6), (3 : Vertex6)), ((5 : Vertex6), (4 : Vertex6)),
       ((3 : Vertex6), (5 : Vertex6)), ((3 : Vertex6), (4 : Vertex6)),
       ((4 : Vertex6), (5 : Vertex6)), ((4 : Vertex6), (3 : Vertex6))} := by
  ext p
  rcases p with ⟨x, y⟩
  fin_cases x <;> fin_cases y <;>
    simp [indexIFinsetQ, quartetTree_adj_iff, quartetRel]

@[simp] theorem indexIFinsetQ_5_2 :
    indexIFinsetQ 5 2 =
      {((2 : Vertex6), (2 : Vertex6)), ((2 : Vertex6), (5 : Vertex6))} := by
  ext p
  rcases p with ⟨x, y⟩
  fin_cases x <;> fin_cases y <;>
    simp [indexIFinsetQ, quartetTree_adj_iff, quartetRel]

@[simp] theorem indexIFinsetQ_3_5 :
    indexIFinsetQ 3 5 =
      {((5 : Vertex6), (5 : Vertex6)), ((5 : Vertex6), (2 : Vertex6)),
       ((5 : Vertex6), (3 : Vertex6)), ((5 : Vertex6), (4 : Vertex6)),
       ((2 : Vertex6), (5 : Vertex6)), ((2 : Vertex6), (4 : Vertex6)),
       ((4 : Vertex6), (5 : Vertex6)), ((4 : Vertex6), (2 : Vertex6))} := by
  ext p
  rcases p with ⟨x, y⟩
  fin_cases x <;> fin_cases y <;>
    simp [indexIFinsetQ, quartetTree_adj_iff, quartetRel]

@[simp] theorem indexIFinsetQ_5_3 :
    indexIFinsetQ 5 3 =
      {((3 : Vertex6), (3 : Vertex6)), ((3 : Vertex6), (5 : Vertex6))} := by
  ext p
  rcases p with ⟨x, y⟩
  fin_cases x <;> fin_cases y <;>
    simp [indexIFinsetQ, quartetTree_adj_iff, quartetRel]

@[simp] theorem indexIFinsetQ_4_5 :
    indexIFinsetQ 4 5 =
      {((5 : Vertex6), (5 : Vertex6)), ((5 : Vertex6), (2 : Vertex6)),
       ((5 : Vertex6), (3 : Vertex6)), ((5 : Vertex6), (4 : Vertex6)),
       ((2 : Vertex6), (5 : Vertex6)), ((2 : Vertex6), (3 : Vertex6)),
       ((3 : Vertex6), (5 : Vertex6)), ((3 : Vertex6), (2 : Vertex6))} := by
  ext p
  rcases p with ⟨x, y⟩
  fin_cases x <;> fin_cases y <;>
    simp [indexIFinsetQ, quartetTree_adj_iff, quartetRel]

@[simp] theorem indexIFinsetQ_5_4 :
    indexIFinsetQ 5 4 =
      {((4 : Vertex6), (4 : Vertex6)), ((4 : Vertex6), (0 : Vertex6)),
       ((4 : Vertex6), (1 : Vertex6)), ((4 : Vertex6), (5 : Vertex6)),
       ((0 : Vertex6), (4 : Vertex6)), ((0 : Vertex6), (1 : Vertex6)),
       ((1 : Vertex6), (4 : Vertex6)), ((1 : Vertex6), (0 : Vertex6))} := by
  ext p
  rcases p with ⟨x, y⟩
  fin_cases x <;> fin_cases y <;>
    simp [indexIFinsetQ, quartetTree_adj_iff, quartetRel]

theorem directedEdgeFinset_eq_computable :
    quartetTree.directedEdgeFinset = directedEdgeFinsetQ := by
  ext e
  rcases e with ⟨u, v⟩
  simp [directedEdgeFinsetQ]

theorem orderedLengthTwoPathFinset_eq_computable :
    quartetTree.orderedLengthTwoPathFinset = orderedPathFinsetQ := by
  ext p
  rcases p with ⟨u, v, w⟩
  simp [orderedPathFinsetQ]

theorem canonicalLengthTwoPathFinset_eq_computable :
    quartetTree.canonicalLengthTwoPathFinset = canonicalPathFinsetQ := by
  ext p
  rcases p with ⟨u, v, w⟩
  simp only [quartetTree.mem_canonicalLengthTwoPathFinset,
    canonicalPathFinsetQ, Finset.mem_filter, orderedPathFinsetQ,
    Finset.mem_univ, true_and]
  constructor
  · rintro ⟨huv, hvw, huw⟩
    exact ⟨⟨huv, hvw, ne_of_lt huw⟩, huw⟩
  · rintro ⟨⟨huv, hvw, _⟩, huw⟩
    exact ⟨huv, hvw, huw⟩

theorem indexIFinset_eq_computable (t u : Vertex6) :
    quartetTree.indexIFinset t u = indexIFinsetQ t u := by
  ext p
  rcases p with ⟨u', u''⟩
  simp [indexIFinsetQ, quartetTree.mem_indexI]

theorem rowMass_eq_ratCast (t u u' : Vertex6) :
    quartetTree.rowMass t u u' = (branchMassQ u u' : ℝ) := by
  simp [XTree.rowMass, XTree.rowBlock, normalizedCard, branchMassQ,
    branchBlock_eq_expected]

theorem columnMass_eq_ratCast (v w w' : Vertex6) :
    quartetTree.columnMass v w w' = (branchMassQ w w' : ℝ) := by
  simp [XTree.columnMass, XTree.columnBlock, normalizedCard, branchMassQ,
    branchBlock_eq_expected]

theorem jointMass_eq_ratCast
    (t u v w u' w' : Vertex6) :
    jointMass quartetTree quartetTree t u v w u' w' =
      (jointMassQ u u' w w' : ℝ) := by
  simp [jointMass, jointBlock, XTree.rowBlock, XTree.columnBlock,
    normalizedCard, jointMassQ, branchBlock_eq_expected]
  apply congrArg Finset.card
  ext x
  simp

theorem xCoefficient_eq_ratCast (t u v w : Vertex6) :
    xCoefficient quartetTree quartetTree t u v w =
      (xCoefficientQ t u v w : ℝ) := by
  simp [xCoefficient, xCoefficientQ, jointMass_eq_ratCast]

theorem qCoefficient_eq_ratCast
    (t u v w u' u'' w' w'' : Vertex6) :
    qCoefficient quartetTree quartetTree t u v w u' u'' w' w'' =
      (qCoefficientQ t u v w u' u'' w' w'' : ℝ) := by
  simp [qCoefficient, qCoefficientQ, columnMass_eq_ratCast,
    jointMass_eq_ratCast]

theorem sCoefficient_eq_ratCast
    (t u u' u'' v w v' : Vertex6) :
    sCoefficient quartetTree quartetTree t u u' u'' v w v' =
      (sCoefficientQ t u u' u'' v w v' : ℝ) := by
  simp [sCoefficient, sCoefficientQ, qCoefficient_eq_ratCast]

theorem bCoefficient_eq_ratCast
    (t u t' v w w' w'' : Vertex6) :
    bCoefficient quartetTree quartetTree t u t' v w w' w'' =
      (bCoefficientQ t u t' v w w' w'' : ℝ) := by
  simp [bCoefficient, bCoefficientQ, qCoefficient_eq_ratCast]

theorem pCoefficient_eq_ratCast
    (t u t' v w v' : Vertex6) :
    pCoefficient quartetTree quartetTree t u t' v w v' =
      (pCoefficientQ t u t' v w v' : ℝ) := by
  simp [pCoefficient, pCoefficientQ, qCoefficient_eq_ratCast]

/-- One fixed first-edge row of the edge/edge (`q`) square family. -/
def squareQRowPartQ (e₁ : Vertex6 × Vertex6) : ℚ :=
  ∑ e₂ ∈ directedEdgeFinsetQ,
      ∑ a ∈ indexIFinsetQ e₁.1 e₁.2,
        ∑ b ∈ indexIFinsetQ e₂.1 e₂.2,
          qCoefficientQ e₁.1 e₁.2 e₂.1 e₂.2
            a.1 a.2 b.1 b.2 *
              xCoefficientQ e₁.1 e₁.2 e₂.1 e₂.2 ^ 2

/-- The edge/edge (`q`) square family in Theorem 2. -/
def squareQPartQ : ℚ :=
  ∑ e₁ ∈ directedEdgeFinsetQ, squareQRowPartQ e₁

/-- The edge/path (`s`) square family in Theorem 2. -/
def squareSPartQ (paths : Finset (Vertex6 × Vertex6 × Vertex6)) : ℚ :=
  ∑ e₁ ∈ directedEdgeFinsetQ, ∑ p₂ ∈ paths,
      ∑ a ∈ indexIFinsetQ e₁.1 e₁.2,
        sCoefficientQ e₁.1 e₁.2 a.1 a.2
          p₂.1 p₂.2.1 p₂.2.2 *
            (xCoefficientQ e₁.1 e₁.2 p₂.1 p₂.2.1 +
              xCoefficientQ e₁.1 e₁.2 p₂.2.2 p₂.2.1) ^ 2

/-- The path/edge (`b`) square family in Theorem 2. -/
def squareBPartQ (paths : Finset (Vertex6 × Vertex6 × Vertex6)) : ℚ :=
  ∑ p₁ ∈ paths, ∑ e₂ ∈ directedEdgeFinsetQ,
      ∑ b ∈ indexIFinsetQ e₂.1 e₂.2,
        bCoefficientQ p₁.1 p₁.2.1 p₁.2.2
          e₂.1 e₂.2 b.1 b.2 *
            (xCoefficientQ p₁.1 p₁.2.1 e₂.1 e₂.2 +
              xCoefficientQ p₁.2.2 p₁.2.1 e₂.1 e₂.2) ^ 2

/-- The path/path (`p`) square family in Theorem 2. -/
def squarePPartQ (paths : Finset (Vertex6 × Vertex6 × Vertex6)) : ℚ :=
  ∑ p₁ ∈ paths, ∑ p₂ ∈ paths,
    pCoefficientQ p₁.1 p₁.2.1 p₁.2.2
      p₂.1 p₂.2.1 p₂.2.2 *
        (xCoefficientQ p₁.1 p₁.2.1 p₂.1 p₂.2.1 +
          xCoefficientQ p₁.1 p₁.2.1 p₂.2.2 p₂.2.1 +
          xCoefficientQ p₁.2.2 p₁.2.1 p₂.1 p₂.2.1 +
          xCoefficientQ p₁.2.2 p₁.2.1 p₂.2.2 p₂.2.1) ^ 2

/-- The four square families in Theorem 2, evaluated using the given path
index set.  Taking `paths = canonicalPathFinsetQ` implements the current
one-representative-per-reversal-orbit convention; taking
`paths = orderedPathFinsetQ` implements the superseded earlier-draft
interpretation `P_i = D_i^2`. -/
def squareRhsQ (paths : Finset (Vertex6 × Vertex6 × Vertex6)) : ℚ :=
  squareQPartQ + squareSPartQ paths + squareBPartQ paths + squarePPartQ paths

/-- The literal real-valued right-hand side of Theorem 2, with the path
index set left as a parameter so that the two competing interpretations can
be compared without changing any coefficient formula. -/
noncomputable def paperSquareRhs
    (paths : Finset (Vertex6 × Vertex6 × Vertex6)) : ℝ :=
  (∑ e₁ ∈ quartetTree.directedEdgeFinset,
      ∑ e₂ ∈ quartetTree.directedEdgeFinset,
      ∑ a ∈ quartetTree.indexIFinset e₁.1 e₁.2,
        ∑ b ∈ quartetTree.indexIFinset e₂.1 e₂.2,
          qCoefficient quartetTree quartetTree e₁.1 e₁.2 e₂.1 e₂.2
            a.1 a.2 b.1 b.2 *
              xCoefficient quartetTree quartetTree
                e₁.1 e₁.2 e₂.1 e₂.2 ^ 2) +
  (∑ e₁ ∈ quartetTree.directedEdgeFinset, ∑ p₂ ∈ paths,
      ∑ a ∈ quartetTree.indexIFinset e₁.1 e₁.2,
        sCoefficient quartetTree quartetTree e₁.1 e₁.2 a.1 a.2
          p₂.1 p₂.2.1 p₂.2.2 *
            (xCoefficient quartetTree quartetTree
                e₁.1 e₁.2 p₂.1 p₂.2.1 +
              xCoefficient quartetTree quartetTree
                e₁.1 e₁.2 p₂.2.2 p₂.2.1) ^ 2) +
  (∑ p₁ ∈ paths, ∑ e₂ ∈ quartetTree.directedEdgeFinset,
      ∑ b ∈ quartetTree.indexIFinset e₂.1 e₂.2,
        bCoefficient quartetTree quartetTree p₁.1 p₁.2.1 p₁.2.2
          e₂.1 e₂.2 b.1 b.2 *
            (xCoefficient quartetTree quartetTree
                p₁.1 p₁.2.1 e₂.1 e₂.2 +
              xCoefficient quartetTree quartetTree
                p₁.2.2 p₁.2.1 e₂.1 e₂.2) ^ 2) +
  ∑ p₁ ∈ paths, ∑ p₂ ∈ paths,
    pCoefficient quartetTree quartetTree p₁.1 p₁.2.1 p₁.2.2
      p₂.1 p₂.2.1 p₂.2.2 *
        (xCoefficient quartetTree quartetTree
            p₁.1 p₁.2.1 p₂.1 p₂.2.1 +
          xCoefficient quartetTree quartetTree
            p₁.1 p₁.2.1 p₂.2.2 p₂.2.1 +
          xCoefficient quartetTree quartetTree
            p₁.2.2 p₁.2.1 p₂.1 p₂.2.1 +
          xCoefficient quartetTree quartetTree
            p₁.2.2 p₁.2.1 p₂.2.2 p₂.2.1) ^ 2

theorem paperSquareRhs_eq_ratCast
    (paths : Finset (Vertex6 × Vertex6 × Vertex6)) :
    paperSquareRhs paths = (squareRhsQ paths : ℝ) := by
  simp only [paperSquareRhs, squareRhsQ, squareQPartQ, squareQRowPartQ, squareSPartQ,
    squareBPartQ, squarePPartQ,
    directedEdgeFinset_eq_computable, indexIFinset_eq_computable]
  push_cast
  simp only [qCoefficient_eq_ratCast, sCoefficient_eq_ratCast,
    bCoefficient_eq_ratCast, pCoefficient_eq_ratCast,
    xCoefficient_eq_ratCast]

macro "audit_q_row" : tactic =>
  `(tactic|
    (simp [squareQRowPartQ, directedEdgeFinsetQ_value]
     simp [
      pCoefficientQ, bCoefficientQ, sCoefficientQ, qCoefficientQ,
      xCoefficientQ, jointMassQ, branchMassQ, expectedBranchBlock]
     norm_num))

set_option maxHeartbeats 2000000 in
theorem squareQRowPartQ_0_4 :
    squareQRowPartQ ((0 : Vertex6), (4 : Vertex6)) = 13 / 3072 := by
  audit_q_row

set_option maxHeartbeats 2000000 in
theorem squareQRowPartQ_4_0 :
    squareQRowPartQ ((4 : Vertex6), (0 : Vertex6)) = 11 / 1024 := by
  audit_q_row

set_option maxHeartbeats 2000000 in
theorem squareQRowPartQ_1_4 :
    squareQRowPartQ ((1 : Vertex6), (4 : Vertex6)) = 13 / 3072 := by
  audit_q_row

set_option maxHeartbeats 2000000 in
theorem squareQRowPartQ_4_1 :
    squareQRowPartQ ((4 : Vertex6), (1 : Vertex6)) = 11 / 1024 := by
  audit_q_row

set_option maxHeartbeats 2000000 in
theorem squareQRowPartQ_2_5 :
    squareQRowPartQ ((2 : Vertex6), (5 : Vertex6)) = 13 / 3072 := by
  audit_q_row

set_option maxHeartbeats 2000000 in
theorem squareQRowPartQ_5_2 :
    squareQRowPartQ ((5 : Vertex6), (2 : Vertex6)) = 11 / 1024 := by
  audit_q_row

set_option maxHeartbeats 2000000 in
theorem squareQRowPartQ_3_5 :
    squareQRowPartQ ((3 : Vertex6), (5 : Vertex6)) = 13 / 3072 := by
  audit_q_row

set_option maxHeartbeats 2000000 in
theorem squareQRowPartQ_5_3 :
    squareQRowPartQ ((5 : Vertex6), (3 : Vertex6)) = 11 / 1024 := by
  audit_q_row

set_option maxHeartbeats 2000000 in
theorem squareQRowPartQ_4_5 :
    squareQRowPartQ ((4 : Vertex6), (5 : Vertex6)) = 5 / 768 := by
  audit_q_row

set_option maxHeartbeats 2000000 in
theorem squareQRowPartQ_5_4 :
    squareQRowPartQ ((5 : Vertex6), (4 : Vertex6)) = 5 / 768 := by
  audit_q_row

theorem squareQPartQ_value : squareQPartQ = 7 / 96 := by
  simp [squareQPartQ, directedEdgeFinsetQ_value,
    squareQRowPartQ_0_4, squareQRowPartQ_4_0,
    squareQRowPartQ_1_4, squareQRowPartQ_4_1,
    squareQRowPartQ_2_5, squareQRowPartQ_5_2,
    squareQRowPartQ_3_5, squareQRowPartQ_5_3,
    squareQRowPartQ_4_5, squareQRowPartQ_5_4]
  norm_num

set_option maxHeartbeats 5000000 in
theorem canonical_squareSPartQ_value :
    squareSPartQ canonicalPathFinsetQ = 1 / 32 := by
  simp [squareSPartQ, canonicalPathFinsetQ_value, directedEdgeFinsetQ_value]
  simp [pCoefficientQ, bCoefficientQ, sCoefficientQ, qCoefficientQ,
    xCoefficientQ, jointMassQ, branchMassQ, expectedBranchBlock]
  norm_num

set_option maxHeartbeats 5000000 in
theorem canonical_squareBPartQ_value :
    squareBPartQ canonicalPathFinsetQ = 23 / 1536 := by
  simp [squareBPartQ, canonicalPathFinsetQ_value, directedEdgeFinsetQ_value]
  simp [pCoefficientQ, bCoefficientQ, sCoefficientQ, qCoefficientQ,
    xCoefficientQ, jointMassQ, branchMassQ, expectedBranchBlock]
  norm_num

set_option maxHeartbeats 5000000 in
theorem canonical_squarePPartQ_value :
    squarePPartQ canonicalPathFinsetQ = 7 / 512 := by
  simp [squarePPartQ, canonicalPathFinsetQ_value]
  simp [pCoefficientQ, bCoefficientQ, sCoefficientQ, qCoefficientQ,
    xCoefficientQ, jointMassQ, branchMassQ, expectedBranchBlock]
  norm_num

set_option maxHeartbeats 5000000 in
theorem ordered_squareSPartQ_value :
    squareSPartQ orderedPathFinsetQ = 1 / 16 := by
  simp [squareSPartQ, orderedPathFinsetQ_value, directedEdgeFinsetQ_value]
  simp [pCoefficientQ, bCoefficientQ, sCoefficientQ, qCoefficientQ,
    xCoefficientQ, jointMassQ, branchMassQ, expectedBranchBlock]
  norm_num

set_option maxHeartbeats 5000000 in
theorem ordered_squareBPartQ_value :
    squareBPartQ orderedPathFinsetQ = 23 / 768 := by
  simp [squareBPartQ, orderedPathFinsetQ_value, directedEdgeFinsetQ_value]
  simp [pCoefficientQ, bCoefficientQ, sCoefficientQ, qCoefficientQ,
    xCoefficientQ, jointMassQ, branchMassQ, expectedBranchBlock]
  norm_num

set_option maxHeartbeats 5000000 in
theorem ordered_squarePPartQ_value :
    squarePPartQ orderedPathFinsetQ = 7 / 128 := by
  simp [squarePPartQ, orderedPathFinsetQ_value]
  simp [pCoefficientQ, bCoefficientQ, sCoefficientQ, qCoefficientQ,
    xCoefficientQ, jointMassQ, branchMassQ, expectedBranchBlock]
  norm_num

theorem canonical_squareRhsQ_value :
    squareRhsQ canonicalPathFinsetQ = 17 / 128 := by
  rw [squareRhsQ, squareQPartQ_value, canonical_squareSPartQ_value,
    canonical_squareBPartQ_value, canonical_squarePPartQ_value]
  norm_num

theorem ordered_squareRhsQ_value :
    squareRhsQ orderedPathFinsetQ = 169 / 768 := by
  rw [squareRhsQ, squareQPartQ_value, ordered_squareSPartQ_value,
    ordered_squareBPartQ_value, ordered_squarePPartQ_value]
  norm_num

theorem ordered_squareRhsQ_ne_canonical :
    squareRhsQ orderedPathFinsetQ ≠ squareRhsQ canonicalPathFinsetQ := by
  rw [ordered_squareRhsQ_value, canonical_squareRhsQ_value]
  norm_num

theorem canonical_paperSquareRhs_value :
    paperSquareRhs quartetTree.canonicalLengthTwoPathFinset =
      (17 / 128 : ℝ) := by
  rw [canonicalLengthTwoPathFinset_eq_computable,
    paperSquareRhs_eq_ratCast, canonical_squareRhsQ_value]
  norm_num

theorem ordered_paperSquareRhs_value :
    paperSquareRhs quartetTree.orderedLengthTwoPathFinset =
      (169 / 768 : ℝ) := by
  rw [orderedLengthTwoPathFinset_eq_computable,
    paperSquareRhs_eq_ratCast, ordered_squareRhsQ_value]
  norm_num

/-- Lean-checked regression test showing why the superseded earlier-draft
identification `P_i := D_i^2` cannot be used: it changes the value of the
right-hand side on the same concrete tree pair. -/
theorem ordered_path_interpretation_changes_theorem_two_rhs :
    paperSquareRhs quartetTree.orderedLengthTwoPathFinset ≠
      paperSquareRhs quartetTree.canonicalLengthTwoPathFinset := by
  rw [ordered_paperSquareRhs_value, canonical_paperSquareRhs_value]
  norm_num

end TheoremTwoCounterexample

end QDFull
