import QDFull.BinaryPhylogeneticQuartetCounts
import QDFull.GlobalQuartetCounts
import QDFull.JointVertexLaw

/-!
# Exact wrappers for definition-level and expository paper claims

The underlying objects were introduced in the early infrastructure files.
This module records theorem-shaped correspondences for the statements that
the manuscript presents verbally, so that the coverage audit does not count
the mere existence of a similarly named Lean definition as verification.
-/

namespace QDFull

universe uX uV uV₁ uV₂

open SimpleGraph

namespace XTree

variable {X : Type uX} {V : Type uV} [Fintype X] [Fintype V]

/-- The four neighbourhood notations in the manuscript have exactly the
printed membership conditions. -/
theorem paper_neighbourhood_membership
    (T : XTree X V) (t u z : V) :
    (z ∈ T.neighbors u ↔ T.graph.Adj u z) ∧
    (z ∈ T.neighborsPlus u ↔ z = u ∨ T.graph.Adj u z) ∧
    (z ∈ T.neighborsAway t u ↔ T.graph.Adj u z ∧ z ≠ t) ∧
    (z ∈ T.neighborsAwayPlus t u ↔
      z = u ∨ (T.graph.Adj u z ∧ z ≠ t)) := by
  simp

/-- Constructor-level equivalence between the manuscript's data for an
`X`-tree and the `XTree` structure used in the formalization. -/
theorem nonempty_xtree_iff_exists_paper_data :
    Nonempty (XTree X V) ↔
      ∃ G : SimpleGraph V, G.IsTree ∧
        ∃ phi : X → V,
          ∀ v : V, Nat.card (G.neighborSet v) ≤ 2 →
            ∃ x : X, phi x = v := by
  constructor
  · rintro ⟨T⟩
    exact ⟨T.graph, T.isTree, T.label, T.lowDegree_labelled⟩
  · rintro ⟨G, hG, phi, hphi⟩
    exact ⟨⟨G, hG, phi, hphi⟩⟩

/-- Exact membership theorem for the displayed-quartet sets `Q_i(T)`. -/
theorem mem_displayedPartialQuartets_iff
    (T : XTree X V) (i : ℕ) (P : PartialSplit X) :
    P ∈ T.displayedPartialQuartets i ↔
      IsPartialQuartet P ∧ T.DisplaysPartialSplit P ∧
        (partialSplitSupport P).card = i := by
  rfl

/-- The paper's row and column blocks are precisely the centre fibre or the
outgoing edge component, and their joint cell is their intersection. -/
theorem paper_local_blocks_exact
    [DecidableEq X]
    (T₁ : XTree X V) (T₂ : XTree X V)
    (t u v w u' w' : V)
    (huu' : T₁.graph.Adj u u') (hww' : T₂.graph.Adj w w') :
    T₁.rowBlock t u u = T₁.labelFiber u ∧
    T₁.rowBlock t u u' = T₁.edgeSide u u' ∧
    T₂.columnBlock v w w = T₂.labelFiber w ∧
    T₂.columnBlock v w w' = T₂.edgeSide w w' ∧
    jointBlock T₁ T₂ t u v w u' w' =
      T₁.rowBlock t u u' ∩ T₂.columnBlock v w w' := by
  classical
  exact ⟨T₁.rowBlock_center t u,
    T₁.rowBlock_of_adj t huu',
    T₂.columnBlock_center v w,
    T₂.columnBlock_of_adj v hww', by
      ext x
      simp [jointBlock]⟩

/-- Lowercase block notation is literally cardinality divided by `|X|`. -/
theorem rowMass_eq_printed_cardinality
    (T : XTree X V) (t u u' : V) :
    T.rowMass t u u' =
      ((T.rowBlock t u u').card : ℝ) / (Fintype.card X : ℝ) := by
  rfl

/-- The analogous exact formula for a column mass. -/
theorem columnMass_eq_printed_cardinality
    (T : XTree X V) (v w w' : V) :
    T.columnMass v w w' =
      ((T.columnBlock v w w').card : ℝ) / (Fintype.card X : ℝ) := by
  rfl

end XTree

/-- For fixed representatives, the manuscript's definition of a partial
split is exactly nonemptiness and disjointness of the two displayed sides. -/
theorem paper_partialSplit_mk_iff
    {X : Type uX} [Fintype X] (A B : Finset X) :
    IsPartialSplit s(A, B) ↔
      A.Nonempty ∧ B.Nonempty ∧ Disjoint A B :=
  isPartialSplit_mk_iff A B

/-- Exact representative-level display relation printed in the paper. -/
theorem paper_displays_mk_iff
    {X : Type uX} (A B C D : Finset X) :
    Displays s(A, B) s(C, D) ↔
      ((C ⊆ A ∧ D ⊆ B) ∨ (C ⊆ B ∧ D ⊆ A)) :=
  displays_comm_representative A B C D

/-- The abstract's main probability assertion, stated directly rather than
through the abbreviation `treeQuartetCovariance`. -/
theorem sameTreeQuartetProbability_ge_half_differentTreeQuartetProbability
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    [DecidableEq X] [DecidableEq V₁] [DecidableEq V₂]
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    (1 / 2 : ℝ) * fourDrawProbability (DifferentTreeQuartetEvent T₁ T₂) ≤
      fourDrawProbability (SameTreeQuartetEvent T₁ T₂) := by
  have h := treeQuartetCovariance_nonneg T₁ T₂
  unfold treeQuartetCovariance at h
  linarith

end QDFull
