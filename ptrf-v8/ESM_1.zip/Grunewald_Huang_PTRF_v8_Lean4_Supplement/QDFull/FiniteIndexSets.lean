import QDFull.BranchPartition
import QDFull.PreliminaryFacts

/-!
# Finite forms of the paper's graph index sets

All sums in the main theorem are finite.  This file turns the set-valued
notation from the preliminaries into explicit `Finset`s and proves the branch
union identity used whenever a principal edge is reversed.
-/

open scoped BigOperators
open SimpleGraph

namespace QDFull

universe uX uV

namespace XTree

variable {X : Type uX} {V : Type uV} [Fintype X] [Fintype V]

/-- Finite copy of `N_+(v)`. -/
noncomputable def neighborsPlusFinset (T : XTree X V) (v : V) : Finset V := by
  classical
  exact Finset.univ.filter fun z => z ∈ T.neighborsPlus v

/-- Finite copy of `N_{t+}(u)`. -/
noncomputable def neighborsAwayPlusFinset
    (T : XTree X V) (t u : V) : Finset V := by
  classical
  exact Finset.univ.filter fun z => z ∈ T.neighborsAwayPlus t u

@[simp] theorem mem_neighborsPlusFinset
    (T : XTree X V) (v z : V) :
    z ∈ T.neighborsPlusFinset v ↔ z ∈ T.neighborsPlus v := by
  classical
  simp [neighborsPlusFinset]

@[simp] theorem mem_neighborsAwayPlusFinset
    (T : XTree X V) (t u z : V) :
    z ∈ T.neighborsAwayPlusFinset t u ↔
      z ∈ T.neighborsAwayPlus t u := by
  classical
  simp [neighborsAwayPlusFinset]

/-- Finite copy of `I_{t,u}`. -/
noncomputable def indexIFinset (T : XTree X V) (t u : V) : Finset (V × V) := by
  classical
  exact Finset.univ.filter fun z => z ∈ T.indexI t u

/-- Finite copy of `I'_{t,u}`. -/
noncomputable def indexIPrimeFinset
    (T : XTree X V) (t u : V) : Finset (V × V) := by
  classical
  exact Finset.univ.filter fun z => z ∈ T.indexIPrime t u

@[simp] theorem mem_indexIFinset
    (T : XTree X V) (t u u' u'' : V) :
    (u', u'') ∈ T.indexIFinset t u ↔ (u', u'') ∈ T.indexI t u := by
  classical
  simp [indexIFinset]

@[simp] theorem mem_indexIPrimeFinset
    (T : XTree X V) (t u u' u'' : V) :
    (u', u'') ∈ T.indexIPrimeFinset t u ↔
      (u', u'') ∈ T.indexIPrime t u := by
  classical
  simp [indexIPrimeFinset]

/-- The branch indices at `centre` after removing the branch pointing back to
`parent`. -/
noncomputable def awayBranchIndices
    (T : XTree X V) (parent centre : V) : Finset V := by
  classical
  exact (T.branchIndices centre).erase parent

@[simp] theorem mem_awayBranchIndices_of_adj
    (T : XTree X V) {parent centre : V}
    (hpc : T.graph.Adj parent centre) (z : V) :
    z ∈ T.awayBranchIndices parent centre ↔
      z ∈ T.neighborsAwayPlus parent centre := by
  classical
  simp [awayBranchIndices, T.mem_branchIndices,
    T.mem_neighborsPlus, T.mem_neighborsAwayPlus]
  aesop

theorem awayBranchIndices_eq_neighborsAwayPlusFinset
    (T : XTree X V) {parent centre : V}
    (hpc : T.graph.Adj parent centre) :
    T.awayBranchIndices parent centre =
      T.neighborsAwayPlusFinset parent centre := by
  classical
  ext z
  simp [T.mem_awayBranchIndices_of_adj hpc]

/-- The unrestricted branch-pair pool used before the edge--path and
path--edge corrections are subtracted. -/
noncomputable def fullIndexFinset
    (T : XTree X V) (t u : V) : Finset (V × V) :=
  T.awayBranchIndices t u ×ˢ T.branchIndices u

@[simp] theorem mem_fullIndexFinset
    (T : XTree X V) (t u u' u'' : V) :
    (u', u'') ∈ T.fullIndexFinset t u ↔
      u' ∈ T.awayBranchIndices t u ∧ u'' ∈ T.branchIndices u := by
  simp [fullIndexFinset]

/-- The complement of `I'` inside the unrestricted branch-pair pool.  It
contains exactly the pairs `(u',u')` carried by a noncentral branch. -/
noncomputable def diagonalIndexFinset
    (T : XTree X V) (t u : V) : Finset (V × V) := by
  classical
  exact ((T.awayBranchIndices t u).erase u).image fun u' => (u', u')

@[simp] theorem mem_diagonalIndexFinset
    (T : XTree X V) (t u u' u'' : V) :
    (u', u'') ∈ T.diagonalIndexFinset t u ↔
      u' ∈ T.awayBranchIndices t u ∧ u' ≠ u ∧ u'' = u' := by
  classical
  simp only [diagonalIndexFinset, Finset.mem_image, Finset.mem_erase,
    Prod.mk.injEq]
  constructor
  · rintro ⟨z, ⟨hz_ne, hz⟩, hzu', hzu''⟩
    subst z
    subst u''
    exact ⟨hz, hz_ne, rfl⟩
  · rintro ⟨hu'mem, hu'ne, rfl⟩
    exact ⟨u'', ⟨hu'ne, hu'mem⟩, rfl, rfl⟩

/-- On an actual principal edge, `I'` is contained in the unrestricted
branch-pair pool. -/
theorem indexIPrimeFinset_subset_fullIndexFinset
    (T : XTree X V) {t u : V} (htu : T.graph.Adj t u) :
    T.indexIPrimeFinset t u ⊆ T.fullIndexFinset t u := by
  classical
  rintro ⟨u', u''⟩ hmem
  rw [T.mem_indexIPrimeFinset] at hmem
  rw [T.mem_fullIndexFinset, T.mem_awayBranchIndices_of_adj htu,
    T.mem_branchIndices, T.mem_neighborsPlus]
  exact ⟨hmem.1, hmem.2.1⟩

/-- `I'` and the diagonal complement are disjoint. -/
theorem indexIPrimeFinset_disjoint_diagonalIndexFinset
    (T : XTree X V) {t u : V} (htu : T.graph.Adj t u) :
    Disjoint (T.indexIPrimeFinset t u) (T.diagonalIndexFinset t u) := by
  classical
  rw [Finset.disjoint_left]
  rintro ⟨u', u''⟩ hprime hdiag
  rw [T.mem_indexIPrimeFinset] at hprime
  rw [T.mem_diagonalIndexFinset] at hdiag
  rcases hprime.2.2 with hu'eq | hu''ne
  · exact hdiag.2.1 hu'eq
  · exact hu''ne hdiag.2.2

/-- Exact source partition: unrestricted pairs are `I'` pairs together
with the diagonal pairs indexed by length-two paths. -/
theorem fullIndexFinset_eq_indexIPrime_union_diagonal
    [DecidableEq V]
    (T : XTree X V) {t u : V} (htu : T.graph.Adj t u) :
    T.fullIndexFinset t u =
      T.indexIPrimeFinset t u ∪ T.diagonalIndexFinset t u := by
  classical
  ext z
  rcases z with ⟨u', u''⟩
  rw [Finset.mem_union, T.mem_fullIndexFinset,
    T.mem_indexIPrimeFinset, T.mem_diagonalIndexFinset,
    T.mem_awayBranchIndices_of_adj htu,
    T.mem_branchIndices, T.mem_neighborsPlus]
  constructor
  · rintro ⟨hu', hu''⟩
    by_cases hcentral : u' = u
    · exact Or.inl ⟨hu', hu'', Or.inl hcentral⟩
    · by_cases hne : u'' ≠ u'
      · exact Or.inl ⟨hu', hu'', Or.inr hne⟩
      · exact Or.inr ⟨hu', hcentral, not_ne_iff.mp hne⟩
  · rintro (hprime | hdiag)
    · exact ⟨hprime.1, hprime.2.1⟩
    · rcases hdiag with ⟨haway, hne, rfl⟩
      have hadj : T.graph.Adj u u'' :=
        (((T.mem_neighborsAwayPlus u'' t u).1 haway).resolve_left hne).1
      exact ⟨haway, Or.inr hadj⟩

/-- Finite-sum form of the source partition. -/
theorem sum_fullIndex_eq_sum_indexIPrime_add_diagonal
    {M : Type*} [AddCommMonoid M]
    (T : XTree X V) {t u : V} (htu : T.graph.Adj t u)
    (f : V × V → M) :
    (∑ z ∈ T.fullIndexFinset t u, f z) =
      (∑ z ∈ T.indexIPrimeFinset t u, f z) +
        ∑ z ∈ T.diagonalIndexFinset t u, f z := by
  classical
  rw [T.fullIndexFinset_eq_indexIPrime_union_diagonal htu,
    Finset.sum_union (T.indexIPrimeFinset_disjoint_diagonalIndexFinset htu)]

/-- Every pair allowed by `I_{t,u}` is also allowed by the enlarged set
`I'_{t,u}`. -/
theorem indexIFinset_subset_indexIPrimeFinset
    (T : XTree X V) (t u : V) :
    T.indexIFinset t u ⊆ T.indexIPrimeFinset t u := by
  classical
  rintro ⟨u', u''⟩ hmem
  rw [T.mem_indexIFinset] at hmem
  rw [T.mem_indexIPrimeFinset]
  refine ⟨hmem.1, hmem.2.1, ?_⟩
  rcases hmem.2.2 with hrow | haway
  · exact Or.inl hrow
  · exact Or.inr haway.2

/-- The new pairs introduced when `I_{t,u}` is enlarged to `I'_{t,u}`. -/
noncomputable def indexIExtraFinset
    (T : XTree X V) (t u : V) : Finset (V × V) := by
  classical
  exact T.indexIPrimeFinset t u \ T.indexIFinset t u

/-- A pair lies in `I'_{t,u} \ I_{t,u}` precisely when its first entry is a
noncentral branch at `u` and its second entry is the omitted principal
endpoint `t`.  This is the exact index interface through which length-two
path terms enter the raw quadratic expansion. -/
@[simp] theorem mem_indexIExtraFinset
    (T : XTree X V) (t u u' u'' : V) :
    (u', u'') ∈ T.indexIExtraFinset t u ↔
      u' ∈ T.neighborsAwayPlus t u ∧
        u'' ∈ T.neighborsPlus u ∧ u' ≠ u ∧ u'' = t := by
  classical
  rw [indexIExtraFinset, Finset.mem_sdiff,
    T.mem_indexIPrimeFinset, T.mem_indexIFinset]
  constructor
  · rintro ⟨⟨hu', hu'', hprime⟩, hnotI⟩
    have hu'ne : u' ≠ u := by
      intro hu'eq
      exact hnotI ⟨hu', hu'', Or.inl hu'eq⟩
    have hu''ne : u'' ≠ u' := hprime.resolve_left hu'ne
    have hu''eq : u'' = t := by
      by_contra hu''net
      exact hnotI ⟨hu', hu'', Or.inr ⟨hu''net, hu''ne⟩⟩
    exact ⟨hu', hu'', hu'ne, hu''eq⟩
  · rintro ⟨hu', hu'', hu'ne, hu''eq⟩
    have hu'net : u' ≠ t := by
      rcases (T.mem_neighborsAwayPlus u' t u).mp hu' with hu'eq | hbranch
      · exact False.elim (hu'ne hu'eq)
      · exact hbranch.2
    have hu''ne : u'' ≠ u' := by
      rw [hu''eq]
      exact hu'net.symm
    refine ⟨⟨hu', hu'', Or.inr hu''ne⟩, ?_⟩
    rintro ⟨_, _, hI⟩
    rcases hI with hrow | haway
    · exact hu'ne hrow
    · exact haway.1 hu''eq

/-- The extra pairs written directly as the endpoint pairs of length-two
paths through `u`. -/
noncomputable def pathExtensionFinset
    (T : XTree X V) (t u : V) : Finset (V × V) := by
  classical
  exact ((T.neighborsAwayPlusFinset t u).erase u).image fun u' => (u', t)

/-- On an actual principal edge, the set-theoretic difference
`I'_{t,u} \ I_{t,u}` is exactly the path-extension set. -/
theorem indexIExtraFinset_eq_pathExtensionFinset
    (T : XTree X V) {t u : V} (htu : T.graph.Adj t u) :
    T.indexIExtraFinset t u = T.pathExtensionFinset t u := by
  classical
  ext z
  rcases z with ⟨u', u''⟩
  rw [T.mem_indexIExtraFinset]
  simp only [pathExtensionFinset, Finset.mem_image, Finset.mem_erase,
    T.mem_neighborsAwayPlusFinset, Prod.mk.injEq]
  constructor
  · rintro ⟨hu', hu'', hu'ne, rfl⟩
    exact ⟨u', ⟨hu'ne, hu'⟩, rfl, rfl⟩
  · rintro ⟨z, ⟨hzne, hzaway⟩, hzu', hzt⟩
    subst z
    subst u''
    exact ⟨hzaway, (T.mem_neighborsPlus t u).2 (Or.inr htu.symm),
      hzne, rfl⟩

/-- Exact finite-sum decomposition of the enlarged index set into the
original set and its path-extension correction. -/
theorem sum_indexIPrime_eq_sum_indexI_add_extra
    {M : Type*} [AddCommMonoid M]
    (T : XTree X V) (t u : V) (f : V × V → M) :
    (∑ z ∈ T.indexIPrimeFinset t u, f z) =
      (∑ z ∈ T.indexIFinset t u, f z) +
        ∑ z ∈ T.indexIExtraFinset t u, f z := by
  classical
  have hsub := T.indexIFinset_subset_indexIPrimeFinset t u
  simpa only [indexIExtraFinset, add_comm] using
    (Finset.sum_sdiff (f := f) hsub).symm

/-- Finite copy of the directed-edge set `D(T)`. -/
noncomputable def directedEdgeFinset (T : XTree X V) : Finset (V × V) := by
  classical
  exact Finset.univ.filter fun e => e ∈ T.directedEdges

/-- One orientation from each reversal orbit of an edge. -/
noncomputable def canonicalEdgeFinset
    [LinearOrder V] (T : XTree X V) : Finset (V × V) :=
  T.directedEdgeFinset.filter fun e => e.1 < e.2

/-- Reverse a directed edge. -/
def reverseEdge (e : V × V) : V × V := (e.2, e.1)

@[simp] theorem reverseEdge_mk (u v : V) :
    reverseEdge (u, v) = (v, u) := rfl

@[simp] theorem reverseEdge_reverseEdge (e : V × V) :
    reverseEdge (reverseEdge e) = e := by
  rcases e with ⟨u, v⟩
  rfl

theorem reverseEdge_injective :
    Function.Injective (reverseEdge : V × V → V × V) := by
  intro e f hef
  simpa only [reverseEdge_reverseEdge] using congrArg reverseEdge hef

/-- Reversals of the selected edge representatives. -/
noncomputable def reversedCanonicalEdgeFinset
    [LinearOrder V] (T : XTree X V) : Finset (V × V) :=
  T.canonicalEdgeFinset.image reverseEdge

/-- Finite copy of the ordered length-two path set `P(T)=D²(T)`. -/
noncomputable def orderedLengthTwoPathFinset
    (T : XTree X V) : Finset (V × V × V) := by
  classical
  exact Finset.univ.filter fun p => p ∈ T.orderedLengthTwoPaths

/-- One representative from each reversal orbit of length-two paths.  The
auxiliary vertex order is used only to choose the representative; all
path-split expressions below are invariant under reversing the endpoints. -/
noncomputable def canonicalLengthTwoPathFinset
    [LinearOrder V] (T : XTree X V) : Finset (V × V × V) :=
  T.orderedLengthTwoPathFinset.filter fun p => p.1 < p.2.2

/-- Reverse the endpoints of a length-two path while retaining its centre. -/
def reversePath (p : V × V × V) : V × V × V :=
  (p.2.2, p.2.1, p.1)

@[simp] theorem reversePath_mk (u v w : V) :
    reversePath (u, v, w) = (w, v, u) := rfl

@[simp] theorem reversePath_reversePath (p : V × V × V) :
    reversePath (reversePath p) = p := by
  rcases p with ⟨u, v, w⟩
  rfl

/-- Reversal is injective because it is an involution. -/
theorem reversePath_injective :
    Function.Injective (reversePath : V × V × V → V × V × V) := by
  intro p q hpq
  simpa only [reversePath_reversePath] using congrArg reversePath hpq

/-- The reversals of the chosen representatives of the length-two path
orbits. -/
noncomputable def reversedCanonicalLengthTwoPathFinset
    [LinearOrder V] (T : XTree X V) : Finset (V × V × V) :=
  T.canonicalLengthTwoPathFinset.image reversePath

@[simp] theorem mem_directedEdgeFinset (T : XTree X V) (u v : V) :
    (u, v) ∈ T.directedEdgeFinset ↔ T.graph.Adj u v := by
  classical
  simp [directedEdgeFinset]

@[simp] theorem mem_canonicalEdgeFinset
    [LinearOrder V] (T : XTree X V) (u v : V) :
    (u, v) ∈ T.canonicalEdgeFinset ↔ T.graph.Adj u v ∧ u < v := by
  classical
  simp [canonicalEdgeFinset]

@[simp] theorem mem_reversedCanonicalEdgeFinset
    [LinearOrder V] (T : XTree X V) (e : V × V) :
    e ∈ T.reversedCanonicalEdgeFinset ↔
      reverseEdge e ∈ T.canonicalEdgeFinset := by
  classical
  constructor
  · rw [reversedCanonicalEdgeFinset, Finset.mem_image]
    rintro ⟨f, hf, rfl⟩
    simpa only [reverseEdge_reverseEdge] using hf
  · intro he
    rw [reversedCanonicalEdgeFinset, Finset.mem_image]
    exact ⟨reverseEdge e, he, by simp⟩

theorem mem_canonical_or_reverse_of_mem_directedEdge
    [LinearOrder V] (T : XTree X V) {u v : V}
    (h : (u, v) ∈ T.directedEdgeFinset) :
    (u, v) ∈ T.canonicalEdgeFinset ∨
      (v, u) ∈ T.canonicalEdgeFinset := by
  rw [T.mem_directedEdgeFinset] at h
  rcases lt_or_gt_of_ne h.ne with huv | hvu
  · exact Or.inl ((T.mem_canonicalEdgeFinset u v).2 ⟨h, huv⟩)
  · exact Or.inr ((T.mem_canonicalEdgeFinset v u).2 ⟨h.symm, hvu⟩)

theorem not_mem_canonical_reverseEdge_of_mem
    [LinearOrder V] (T : XTree X V) {u v : V}
    (h : (u, v) ∈ T.canonicalEdgeFinset) :
    (v, u) ∉ T.canonicalEdgeFinset := by
  rw [T.mem_canonicalEdgeFinset] at h
  rw [T.mem_canonicalEdgeFinset]
  intro hrev
  exact (not_lt_of_ge (le_of_lt h.2)) hrev.2

/-- Directed edges are the disjoint union of canonical representatives and
their reversals. -/
theorem directedEdgeFinset_eq_canonical_union_reversed
    [LinearOrder V] (T : XTree X V) :
    T.directedEdgeFinset =
      T.canonicalEdgeFinset ∪ T.reversedCanonicalEdgeFinset := by
  classical
  ext e
  rcases e with ⟨u, v⟩
  rw [Finset.mem_union, T.mem_reversedCanonicalEdgeFinset]
  simp only [reverseEdge_mk]
  constructor
  · exact T.mem_canonical_or_reverse_of_mem_directedEdge
  · rintro (h | h)
    · exact (T.mem_directedEdgeFinset u v).2
        ((T.mem_canonicalEdgeFinset u v).1 h).1
    · exact (T.mem_directedEdgeFinset u v).2
        ((T.mem_canonicalEdgeFinset v u).1 h).1.symm

theorem canonicalEdgeFinset_disjoint_reversed
    [LinearOrder V] (T : XTree X V) :
    Disjoint T.canonicalEdgeFinset T.reversedCanonicalEdgeFinset := by
  classical
  rw [Finset.disjoint_left]
  intro e he herev
  rcases e with ⟨u, v⟩
  rw [T.mem_reversedCanonicalEdgeFinset] at herev
  simp only [reverseEdge_mk] at herev
  exact T.not_mem_canonical_reverseEdge_of_mem he herev

/-- Exact edge-reversal orbit reindexing, retaining both directed copies. -/
theorem sum_directedEdge_eq_sum_canonical_with_reverse
    [LinearOrder V] {M : Type*} [AddCommMonoid M]
    (T : XTree X V) (f : V × V → M) :
    (∑ e ∈ T.directedEdgeFinset, f e) =
      ∑ e ∈ T.canonicalEdgeFinset, (f e + f (reverseEdge e)) := by
  classical
  calc
    (∑ e ∈ T.directedEdgeFinset, f e) =
        (∑ e ∈ T.canonicalEdgeFinset, f e) +
          ∑ e ∈ T.reversedCanonicalEdgeFinset, f e := by
      rw [T.directedEdgeFinset_eq_canonical_union_reversed,
        Finset.sum_union T.canonicalEdgeFinset_disjoint_reversed]
    _ = (∑ e ∈ T.canonicalEdgeFinset, f e) +
          ∑ e ∈ T.canonicalEdgeFinset, f (reverseEdge e) := by
      rw [reversedCanonicalEdgeFinset,
        Finset.sum_image reverseEdge_injective.injOn]
    _ = _ := (Finset.sum_add_distrib).symm

/-- Sum the `I' = I \sqcup (I' \ I)` decomposition uniformly over all
directed principal edges. -/
theorem sum_directedEdge_indexIPrime_eq_indexI_add_extra
    {M : Type*} [AddCommMonoid M]
    (T : XTree X V) (f : (V × V) → (V × V) → M) :
    (∑ e ∈ T.directedEdgeFinset,
        ∑ z ∈ T.indexIPrimeFinset e.1 e.2, f e z) =
      (∑ e ∈ T.directedEdgeFinset,
          ∑ z ∈ T.indexIFinset e.1 e.2, f e z) +
        ∑ e ∈ T.directedEdgeFinset,
          ∑ z ∈ T.indexIExtraFinset e.1 e.2, f e z := by
  classical
  simp_rw [T.sum_indexIPrime_eq_sum_indexI_add_extra]
  exact Finset.sum_add_distrib

@[simp] theorem mem_orderedLengthTwoPathFinset
    (T : XTree X V) (u v w : V) :
    (u, v, w) ∈ T.orderedLengthTwoPathFinset ↔
      T.graph.Adj u v ∧ T.graph.Adj v w ∧ u ≠ w := by
  classical
  simp [orderedLengthTwoPathFinset]

@[simp] theorem mem_canonicalLengthTwoPathFinset
    [LinearOrder V] (T : XTree X V) (u v w : V) :
    (u, v, w) ∈ T.canonicalLengthTwoPathFinset ↔
      T.graph.Adj u v ∧ T.graph.Adj v w ∧ u < w := by
  classical
  rw [canonicalLengthTwoPathFinset, Finset.mem_filter,
    T.mem_orderedLengthTwoPathFinset]
  constructor
  · rintro ⟨⟨huv, hvw, _⟩, huw⟩
    exact ⟨huv, hvw, huw⟩
  · rintro ⟨huv, hvw, huw⟩
    exact ⟨⟨huv, hvw, ne_of_lt huw⟩, huw⟩

@[simp] theorem mem_reversedCanonicalLengthTwoPathFinset
    [LinearOrder V] (T : XTree X V) (p : V × V × V) :
    p ∈ T.reversedCanonicalLengthTwoPathFinset ↔
      reversePath p ∈ T.canonicalLengthTwoPathFinset := by
  classical
  constructor
  · rw [reversedCanonicalLengthTwoPathFinset, Finset.mem_image]
    rintro ⟨q, hq, rfl⟩
    simpa only [reversePath_reversePath] using hq
  · intro hp
    rw [reversedCanonicalLengthTwoPathFinset, Finset.mem_image]
    exact ⟨reversePath p, hp, by simp⟩

/-- Every ordered length-two path has exactly one endpoint ordering selected
by `canonicalLengthTwoPathFinset`. -/
theorem mem_canonical_or_reverse_of_mem_ordered
    [LinearOrder V] (T : XTree X V) {u v w : V}
    (h : (u, v, w) ∈ T.orderedLengthTwoPathFinset) :
    (u, v, w) ∈ T.canonicalLengthTwoPathFinset ∨
      (w, v, u) ∈ T.canonicalLengthTwoPathFinset := by
  rw [T.mem_orderedLengthTwoPathFinset] at h
  rcases h with ⟨huv, hvw, huw⟩
  rcases lt_or_gt_of_ne huw with huwlt | hwult
  · exact Or.inl ((T.mem_canonicalLengthTwoPathFinset u v w).2
      ⟨huv, hvw, huwlt⟩)
  · exact Or.inr ((T.mem_canonicalLengthTwoPathFinset w v u).2
      ⟨hvw.symm, huv.symm, hwult⟩)

/-- A path and its reversal cannot both be canonical. -/
theorem not_mem_canonical_reverse_of_mem
    [LinearOrder V] (T : XTree X V) {u v w : V}
    (h : (u, v, w) ∈ T.canonicalLengthTwoPathFinset) :
    (w, v, u) ∉ T.canonicalLengthTwoPathFinset := by
  rw [T.mem_canonicalLengthTwoPathFinset] at h
  rw [T.mem_canonicalLengthTwoPathFinset]
  intro hrev
  exact (not_lt_of_ge (le_of_lt h.2.2)) hrev.2.2

/-- The full ordered path set is the disjoint union of the selected
representatives and their reversals. -/
theorem orderedLengthTwoPathFinset_eq_canonical_union_reversed
    [LinearOrder V] (T : XTree X V) :
    T.orderedLengthTwoPathFinset =
      T.canonicalLengthTwoPathFinset ∪
        T.reversedCanonicalLengthTwoPathFinset := by
  classical
  ext p
  rcases p with ⟨u, v, w⟩
  rw [Finset.mem_union, T.mem_reversedCanonicalLengthTwoPathFinset]
  simp only [reversePath_mk]
  constructor
  · intro hp
    exact T.mem_canonical_or_reverse_of_mem_ordered hp
  · rintro (hp | hp)
    · rw [T.mem_canonicalLengthTwoPathFinset] at hp
      exact (T.mem_orderedLengthTwoPathFinset u v w).2
        ⟨hp.1, hp.2.1, ne_of_lt hp.2.2⟩
    · rw [T.mem_canonicalLengthTwoPathFinset] at hp
      exact (T.mem_orderedLengthTwoPathFinset u v w).2
        ⟨hp.2.1.symm, hp.1.symm, (ne_of_lt hp.2.2).symm⟩

/-- The selected representatives and their reversals are disjoint. -/
theorem canonicalLengthTwoPathFinset_disjoint_reversed
    [LinearOrder V] (T : XTree X V) :
    Disjoint T.canonicalLengthTwoPathFinset
      T.reversedCanonicalLengthTwoPathFinset := by
  classical
  rw [Finset.disjoint_left]
  intro p hp hprev
  rcases p with ⟨u, v, w⟩
  rw [T.mem_reversedCanonicalLengthTwoPathFinset] at hprev
  simp only [reversePath_mk] at hprev
  exact T.not_mem_canonical_reverse_of_mem hp hprev

/-- Exact reversal-orbit reindexing.  No reversal symmetry of `f` is
assumed: both directed occurrences are retained explicitly in each orbit. -/
theorem sum_orderedLengthTwoPath_eq_sum_canonical_with_reverse
    [LinearOrder V] {M : Type*} [AddCommMonoid M]
    (T : XTree X V) (f : V × V × V → M) :
    (∑ p ∈ T.orderedLengthTwoPathFinset, f p) =
      ∑ p ∈ T.canonicalLengthTwoPathFinset,
        (f p + f (reversePath p)) := by
  classical
  calc
    (∑ p ∈ T.orderedLengthTwoPathFinset, f p) =
        (∑ p ∈ T.canonicalLengthTwoPathFinset, f p) +
          ∑ p ∈ T.reversedCanonicalLengthTwoPathFinset, f p := by
      rw [T.orderedLengthTwoPathFinset_eq_canonical_union_reversed,
        Finset.sum_union
          T.canonicalLengthTwoPathFinset_disjoint_reversed]
    _ = (∑ p ∈ T.canonicalLengthTwoPathFinset, f p) +
          ∑ p ∈ T.canonicalLengthTwoPathFinset,
            f (reversePath p) := by
      rw [reversedCanonicalLengthTwoPathFinset,
        Finset.sum_image reversePath_injective.injOn]
    _ = ∑ p ∈ T.canonicalLengthTwoPathFinset,
          (f p + f (reversePath p)) :=
      (Finset.sum_add_distrib).symm

/-- A source occurrence consists of a directed principal edge together with
one of the new pairs in `I' \ I` for that edge. -/
noncomputable def rowExtensionOccurrenceFinset
    (T : XTree X V) :
    Finset (Sigma fun _ : V × V => V × V) :=
  T.directedEdgeFinset.sigma fun e =>
    T.indexIExtraFinset e.1 e.2

/-- Forget the redundant fourth entry of an `I' \ I` occurrence and read the
remaining three vertices as a directed length-two path. -/
def rowExtensionPath
    (o : Sigma fun _ : V × V => V × V) : V × V × V :=
  (o.1.1, o.1.2, o.2.1)

/-- Recover the source occurrence carried by a directed length-two path. -/
def pathToRowExtensionOccurrence
    (p : V × V × V) : Sigma fun _ : V × V => V × V :=
  ⟨(p.1, p.2.1), (p.2.2, p.1)⟩

@[simp] theorem mem_rowExtensionOccurrenceFinset
    (T : XTree X V)
    (o : Sigma fun _ : V × V => V × V) :
    o ∈ T.rowExtensionOccurrenceFinset ↔
      o.1 ∈ T.directedEdgeFinset ∧
        o.2 ∈ T.indexIExtraFinset o.1.1 o.1.2 := by
  classical
  simp [rowExtensionOccurrenceFinset]

/-- Every source occurrence determines an ordered length-two path. -/
theorem rowExtensionPath_mem_orderedLengthTwoPathFinset
    (T : XTree X V)
    {o : Sigma fun _ : V × V => V × V}
    (ho : o ∈ T.rowExtensionOccurrenceFinset) :
    rowExtensionPath o ∈ T.orderedLengthTwoPathFinset := by
  rcases o with ⟨⟨t, u⟩, ⟨u', u''⟩⟩
  rw [T.mem_rowExtensionOccurrenceFinset] at ho
  rcases ho with ⟨hedge, hextra⟩
  rw [T.mem_directedEdgeFinset] at hedge
  rw [T.mem_indexIExtraFinset] at hextra
  have huu' : T.graph.Adj u u' := by
    rcases (T.mem_neighborsAwayPlus u' t u).mp hextra.1 with h | h
    · exact False.elim (hextra.2.2.1 h)
    · exact h.1
  have htu' : t ≠ u' := by
    rcases (T.mem_neighborsAwayPlus u' t u).mp hextra.1 with h | h
    · subst u'
      exact hedge.ne
    · exact h.2.symm
  exact (T.mem_orderedLengthTwoPathFinset t u u').2
    ⟨hedge, huu', htu'⟩

/-- Every ordered length-two path determines a valid `I' \ I` occurrence. -/
theorem pathToRowExtensionOccurrence_mem
    (T : XTree X V) {p : V × V × V}
    (hp : p ∈ T.orderedLengthTwoPathFinset) :
    pathToRowExtensionOccurrence p ∈
      T.rowExtensionOccurrenceFinset := by
  rcases p with ⟨t, u, u'⟩
  rw [T.mem_orderedLengthTwoPathFinset] at hp
  rw [T.mem_rowExtensionOccurrenceFinset,
    T.mem_directedEdgeFinset, T.mem_indexIExtraFinset]
  exact ⟨hp.1,
    (T.mem_neighborsAwayPlus u' t u).2
      (Or.inr ⟨hp.2.1, hp.2.2.symm⟩),
    (T.mem_neighborsPlus t u).2 (Or.inr hp.1.symm),
    hp.2.1.ne.symm, rfl⟩

@[simp] theorem rowExtensionPath_pathToRowExtensionOccurrence
    (p : V × V × V) :
    rowExtensionPath (pathToRowExtensionOccurrence p) = p := by
  rcases p with ⟨t, u, u'⟩
  rfl

/-- On valid source occurrences, recovering an occurrence from its path
returns the original occurrence; the equality uses the defining fact that
the fourth entry of every pair in `I' \ I` is the principal endpoint. -/
theorem pathToRowExtensionOccurrence_rowExtensionPath
    (T : XTree X V)
    {o : Sigma fun _ : V × V => V × V}
    (ho : o ∈ T.rowExtensionOccurrenceFinset) :
    pathToRowExtensionOccurrence (rowExtensionPath o) = o := by
  rcases o with ⟨⟨t, u⟩, ⟨u', u''⟩⟩
  rw [T.mem_rowExtensionOccurrenceFinset] at ho
  rw [T.mem_indexIExtraFinset] at ho
  have hu'' : u'' = t := ho.2.2.2.2
  subst u''
  rfl

/-- The nested sum over all directed edges and all new `I' \ I` pairs is
exactly a sum over all directed length-two paths. -/
theorem sum_directedEdge_indexIExtra_eq_sum_orderedLengthTwoPath
    {M : Type*} [AddCommMonoid M]
    (T : XTree X V) (f : (V × V) → (V × V) → M) :
    (∑ e ∈ T.directedEdgeFinset,
        ∑ z ∈ T.indexIExtraFinset e.1 e.2, f e z) =
      ∑ p ∈ T.orderedLengthTwoPathFinset,
        f (p.1, p.2.1) (p.2.2, p.1) := by
  classical
  rw [Finset.sum_sigma' T.directedEdgeFinset
    (fun e => T.indexIExtraFinset e.1 e.2) f]
  refine Finset.sum_bij'
    (fun o _ => rowExtensionPath o)
    (fun p _ => pathToRowExtensionOccurrence p)
    (fun o ho => T.rowExtensionPath_mem_orderedLengthTwoPathFinset ho)
    (fun p hp => T.pathToRowExtensionOccurrence_mem hp)
    (fun o ho => T.pathToRowExtensionOccurrence_rowExtensionPath ho)
    (fun p _ => rowExtensionPath_pathToRowExtensionOccurrence p)
    ?_
  intro o ho
  rcases o with ⟨⟨t, u⟩, ⟨u', u''⟩⟩
  rw [Finset.mem_sigma, T.mem_indexIExtraFinset] at ho
  change (t, u) ∈ T.directedEdgeFinset ∧
    u' ∈ T.neighborsAwayPlus t u ∧
    u'' ∈ T.neighborsPlus u ∧ u' ≠ u ∧ u'' = t at ho
  have hu'' : u'' = t := ho.2.2.2.2
  subst u''
  rfl

/-- Orbit-resolved form of the preceding source-occurrence reindexing. -/
theorem sum_directedEdge_indexIExtra_eq_sum_canonical_orientations
    [LinearOrder V] {M : Type*} [AddCommMonoid M]
    (T : XTree X V) (f : (V × V) → (V × V) → M) :
    (∑ e ∈ T.directedEdgeFinset,
        ∑ z ∈ T.indexIExtraFinset e.1 e.2, f e z) =
      ∑ p ∈ T.canonicalLengthTwoPathFinset,
        (f (p.1, p.2.1) (p.2.2, p.1) +
          f (p.2.2, p.2.1) (p.1, p.2.2)) := by
  rw [T.sum_directedEdge_indexIExtra_eq_sum_orderedLengthTwoPath]
  simpa only [reversePath] using
    T.sum_orderedLengthTwoPath_eq_sum_canonical_with_reverse
      (fun p => f (p.1, p.2.1) (p.2.2, p.1))

/-- Relabel the diagonal complement and the `I' \ I` extension by their
common noncentral branch.  This is a coefficient-preserving bijection of
source occurrences, not an equality of coefficient values. -/
theorem sum_diagonalIndex_eq_sum_indexIExtra_relabel
    {M : Type*} [AddCommMonoid M]
    (T : XTree X V) {t u : V} (htu : T.graph.Adj t u)
    (f : V × V → M) :
    (∑ z ∈ T.diagonalIndexFinset t u, f z) =
      ∑ z ∈ T.indexIExtraFinset t u, f (z.1, z.1) := by
  classical
  rw [diagonalIndexFinset, T.indexIExtraFinset_eq_pathExtensionFinset htu,
    pathExtensionFinset]
  rw [T.awayBranchIndices_eq_neighborsAwayPlusFinset htu]
  have hdiag : Set.InjOn (fun u' : V => (u', u'))
      ↑((T.neighborsAwayPlusFinset t u).erase u) := by
    intro a ha b hb hab
    exact congrArg Prod.fst hab
  have hpath : Set.InjOn (fun u' : V => (u', t))
      ↑((T.neighborsAwayPlusFinset t u).erase u) := by
    intro a ha b hb hab
    exact congrArg Prod.fst hab
  rw [Finset.sum_image hdiag, Finset.sum_image hpath]

/-- Summing all diagonal-complement occurrences is exactly summing one
diagonal source over every directed length-two path. -/
theorem sum_directedEdge_diagonal_eq_sum_orderedLengthTwoPath
    {M : Type*} [AddCommMonoid M]
    (T : XTree X V) (f : (V × V) → (V × V) → M) :
    (∑ e ∈ T.directedEdgeFinset,
        ∑ z ∈ T.diagonalIndexFinset e.1 e.2, f e z) =
      ∑ p ∈ T.orderedLengthTwoPathFinset,
        f (p.1, p.2.1) (p.2.2, p.2.2) := by
  classical
  calc
    _ = ∑ e ∈ T.directedEdgeFinset,
          ∑ z ∈ T.indexIExtraFinset e.1 e.2,
            f e (z.1, z.1) := by
      apply Finset.sum_congr rfl
      intro e he
      exact T.sum_diagonalIndex_eq_sum_indexIExtra_relabel
        ((T.mem_directedEdgeFinset e.1 e.2).1 he) (f e)
    _ = _ := by
      simpa only using
        T.sum_directedEdge_indexIExtra_eq_sum_orderedLengthTwoPath
          (fun e z => f e (z.1, z.1))

/-- Orbit-resolved version of the diagonal-complement reindexing. -/
theorem sum_directedEdge_diagonal_eq_sum_canonical_orientations
    [LinearOrder V] {M : Type*} [AddCommMonoid M]
    (T : XTree X V) (f : (V × V) → (V × V) → M) :
    (∑ e ∈ T.directedEdgeFinset,
        ∑ z ∈ T.diagonalIndexFinset e.1 e.2, f e z) =
      ∑ p ∈ T.canonicalLengthTwoPathFinset,
        (f (p.1, p.2.1) (p.2.2, p.2.2) +
          f (p.2.2, p.2.1) (p.1, p.1)) := by
  rw [T.sum_directedEdge_diagonal_eq_sum_orderedLengthTwoPath]
  simpa only [reversePath] using
    T.sum_orderedLengthTwoPath_eq_sum_canonical_with_reverse
      (fun p => f (p.1, p.2.1) (p.2.2, p.2.2))

/-- Uniform source partition after summing over every directed principal
edge. -/
theorem sum_directedEdge_fullIndex_eq_prime_add_diagonal
    {M : Type*} [AddCommMonoid M]
    (T : XTree X V) (f : (V × V) → (V × V) → M) :
    (∑ e ∈ T.directedEdgeFinset,
        ∑ z ∈ T.fullIndexFinset e.1 e.2, f e z) =
      (∑ e ∈ T.directedEdgeFinset,
          ∑ z ∈ T.indexIPrimeFinset e.1 e.2, f e z) +
        ∑ e ∈ T.directedEdgeFinset,
          ∑ z ∈ T.diagonalIndexFinset e.1 e.2, f e z := by
  classical
  calc
    _ = ∑ e ∈ T.directedEdgeFinset,
          ((∑ z ∈ T.indexIPrimeFinset e.1 e.2, f e z) +
            ∑ z ∈ T.diagonalIndexFinset e.1 e.2, f e z) := by
      apply Finset.sum_congr rfl
      intro e he
      exact T.sum_fullIndex_eq_sum_indexIPrime_add_diagonal
        ((T.mem_directedEdgeFinset e.1 e.2).1 he) (f e)
    _ = _ := Finset.sum_add_distrib

/-- Reindex two independent `I' \ I` source occurrences by two ordered
length-two paths. -/
theorem sum_two_indexIExtra_eq_sum_two_orderedLengthTwoPaths
    {X₂ : Type*} {W : Type*}
    [Fintype X₂] [Fintype W]
    {M : Type*} [AddCommMonoid M]
    (T₁ : XTree X V) (T₂ : XTree X₂ W)
    (f : (V × V) → (V × V) → (W × W) → (W × W) → M) :
    (∑ e₁ ∈ T₁.directedEdgeFinset,
        ∑ z₁ ∈ T₁.indexIExtraFinset e₁.1 e₁.2,
          ∑ e₂ ∈ T₂.directedEdgeFinset,
            ∑ z₂ ∈ T₂.indexIExtraFinset e₂.1 e₂.2,
              f e₁ z₁ e₂ z₂) =
      ∑ p₁ ∈ T₁.orderedLengthTwoPathFinset,
        ∑ p₂ ∈ T₂.orderedLengthTwoPathFinset,
          f (p₁.1, p₁.2.1) (p₁.2.2, p₁.1)
            (p₂.1, p₂.2.1) (p₂.2.2, p₂.1) := by
  calc
    _ = ∑ e₁ ∈ T₁.directedEdgeFinset,
          ∑ z₁ ∈ T₁.indexIExtraFinset e₁.1 e₁.2,
            ∑ p₂ ∈ T₂.orderedLengthTwoPathFinset,
              f e₁ z₁ (p₂.1, p₂.2.1) (p₂.2.2, p₂.1) := by
      apply Finset.sum_congr rfl
      intro e₁ he₁
      apply Finset.sum_congr rfl
      intro z₁ hz₁
      exact T₂.sum_directedEdge_indexIExtra_eq_sum_orderedLengthTwoPath
        (fun e₂ z₂ => f e₁ z₁ e₂ z₂)
    _ = _ :=
      T₁.sum_directedEdge_indexIExtra_eq_sum_orderedLengthTwoPath
        (fun e₁ z₁ =>
          ∑ p₂ ∈ T₂.orderedLengthTwoPathFinset,
            f e₁ z₁ (p₂.1, p₂.2.1) (p₂.2.2, p₂.1))

/-- Orbit-resolved form of the two-sided source-occurrence reindexing.  Each
pair of unoriented paths contributes its four endpoint orientations exactly
once. -/
theorem sum_two_indexIExtra_eq_sum_two_canonical_orientations
    {X₂ : Type*} {W : Type*}
    [Fintype X₂] [Fintype W] [LinearOrder V] [LinearOrder W]
    {M : Type*} [AddCommMonoid M]
    (T₁ : XTree X V) (T₂ : XTree X₂ W)
    (f : (V × V) → (V × V) → (W × W) → (W × W) → M) :
    (∑ e₁ ∈ T₁.directedEdgeFinset,
        ∑ z₁ ∈ T₁.indexIExtraFinset e₁.1 e₁.2,
          ∑ e₂ ∈ T₂.directedEdgeFinset,
            ∑ z₂ ∈ T₂.indexIExtraFinset e₂.1 e₂.2,
              f e₁ z₁ e₂ z₂) =
      ∑ p₁ ∈ T₁.canonicalLengthTwoPathFinset,
        ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
          (f (p₁.1, p₁.2.1) (p₁.2.2, p₁.1)
              (p₂.1, p₂.2.1) (p₂.2.2, p₂.1) +
            f (p₁.1, p₁.2.1) (p₁.2.2, p₁.1)
              (p₂.2.2, p₂.2.1) (p₂.1, p₂.2.2) +
            f (p₁.2.2, p₁.2.1) (p₁.1, p₁.2.2)
              (p₂.1, p₂.2.1) (p₂.2.2, p₂.1) +
            f (p₁.2.2, p₁.2.1) (p₁.1, p₁.2.2)
              (p₂.2.2, p₂.2.1) (p₂.1, p₂.2.2)) := by
  rw [T₁.sum_two_indexIExtra_eq_sum_two_orderedLengthTwoPaths T₂ f]
  rw [T₁.sum_orderedLengthTwoPath_eq_sum_canonical_with_reverse]
  apply Finset.sum_congr rfl
  intro p₁ hp₁
  rw [Finset.sum_add_distrib]
  rw [T₂.sum_orderedLengthTwoPath_eq_sum_canonical_with_reverse]
  rw [T₂.sum_orderedLengthTwoPath_eq_sum_canonical_with_reverse]
  simp only [reversePath, Finset.sum_add_distrib]
  ac_rfl

/-- The union of all branches at `centre` except the branch returning to
`parent` is exactly the `centre`-side component of the edge
`parent--centre`. -/
theorem biUnion_awayBranchBlock_eq_edgeSide
    [DecidableEq X] (T : XTree X V) {parent centre : V}
    (hpc : T.graph.Adj parent centre) :
    (T.awayBranchIndices parent centre).biUnion
        (T.branchBlock centre) =
      T.edgeSide parent centre := by
  classical
  ext x
  constructor
  · intro hx
    rw [Finset.mem_biUnion] at hx
    obtain ⟨z, hzaway, hxz⟩ := hx
    have hzbranch : z ∈ T.branchIndices centre :=
      (Finset.mem_erase.mp hzaway).2
    have hzparent : z ≠ parent := (Finset.mem_erase.mp hzaway).1
    rw [T.mem_branchIndices, T.mem_neighborsPlus] at hzbranch
    rcases hzbranch with rfl | hcz
    · rw [T.branchBlock_self] at hxz
      exact T.labelFiber_subset_reverse_edgeSide hpc.symm hxz
    · rw [T.branchBlock_of_adj hcz] at hxz
      exact T.edgeSide_sidePair_subset hpc hcz hzparent.symm hxz
  · intro hx
    obtain ⟨z, hz, hxz⟩ := T.exists_mem_branchBlock centre x
    rw [Finset.mem_biUnion]
    refine ⟨z, ?_, hxz⟩
    change z ∈ (T.branchIndices centre).erase parent
    rw [Finset.mem_erase]
    refine ⟨?_, (T.mem_branchIndices centre z).mpr hz⟩
    intro hzp
    subst z
    have hxreverse : x ∈ T.edgeSide centre parent := by
      rw [T.branchBlock_of_adj hpc.symm] at hxz
      exact hxz
    exact (Finset.disjoint_left.mp
      (T.edgeSide_disjoint_reverse_of_adj hpc)) hx hxreverse

/-- Summing normalized intersections over any subfamily of the branch
partition is the normalized cardinality of the corresponding union. -/
theorem sum_normalizedCard_inter_branchBlock
    [DecidableEq X]
    (T : XTree X V) (centre : V) (J : Finset V)
    (hJ : J ⊆ T.branchIndices centre) (S : Finset X) :
    ∑ z ∈ J, normalizedCard (S ∩ T.branchBlock centre z) =
      normalizedCard
        (S ∩ J.biUnion (T.branchBlock centre)) := by
  classical
  have hdisj :
      ((J : Finset V) : Set V).PairwiseDisjoint
        (fun z => S ∩ T.branchBlock centre z) := by
    intro z hz y hy hzy
    exact (T.branchIndices_pairwiseDisjoint centre
      (hJ hz) (hJ hy) hzy).mono Finset.inter_subset_right
        Finset.inter_subset_right
  have hunion :
      J.biUnion (fun z => S ∩ T.branchBlock centre z) =
        S ∩ J.biUnion (T.branchBlock centre) := by
    ext x
    simp only [Finset.mem_biUnion, Finset.mem_inter]
    aesop
  have hcard :
      ∑ z ∈ J, (S ∩ T.branchBlock centre z).card =
        (S ∩ J.biUnion (T.branchBlock centre)).card := by
    calc
      ∑ z ∈ J, (S ∩ T.branchBlock centre z).card =
          (J.biUnion
            (fun z => S ∩ T.branchBlock centre z)).card :=
        (Finset.card_biUnion hdisj).symm
      _ = (S ∩ J.biUnion (T.branchBlock centre)).card := by
        rw [hunion]
  unfold normalizedCard
  rw [← Finset.sum_div]
  congr 1
  exact_mod_cast hcard

/-- Full-partition special case of the preceding intersection identity. -/
theorem sum_normalizedCard_inter_allBranches
    [DecidableEq X]
    (T : XTree X V) (centre : V) (S : Finset X) :
    ∑ z ∈ T.branchIndices centre,
        normalizedCard (S ∩ T.branchBlock centre z) =
      normalizedCard S := by
  classical
  rw [T.sum_normalizedCard_inter_branchBlock centre
    (T.branchIndices centre) Finset.Subset.rfl S,
    T.biUnion_branchBlock_eq_univ]
  simp

/-- Away-partition special case: summing over `N_{parent+}(centre)` replaces
the branch argument by the reversed principal-edge side. -/
theorem sum_normalizedCard_inter_awayBranches
    [DecidableEq X]
    (T : XTree X V) {parent centre : V}
    (hpc : T.graph.Adj parent centre) (S : Finset X) :
    ∑ z ∈ T.awayBranchIndices parent centre,
        normalizedCard (S ∩ T.branchBlock centre z) =
      normalizedCard (S ∩ T.edgeSide parent centre) := by
  classical
  rw [T.sum_normalizedCard_inter_branchBlock centre
    (T.awayBranchIndices parent centre) (Finset.erase_subset _ _) S,
    T.biUnion_awayBranchBlock_eq_edgeSide hpc]

end XTree

end QDFull
