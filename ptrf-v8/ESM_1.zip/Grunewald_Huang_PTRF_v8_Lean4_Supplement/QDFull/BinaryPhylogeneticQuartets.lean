import QDFull.GlobalQuartetCounts
import QDFull.PhylogeneticNonindependence

/-!
# Quartets displayed by binary phylogenetic trees

This file supplies the graph-theoretic existence statement used, but not
proved, in Corollary 2 of the paper: every four-taxon support in a binary
phylogenetic tree is separated two-versus-two by an edge.

The proof is intrinsic to `XTree`.  Starting from a pendant edge, choose an
oriented edge whose far side contains at least two of the four selected taxa
and whose far side has minimum cardinality.  At its far endpoint the binary
degree-three condition leaves two outward noncentral branches.  Any heavy
outward branch would give a strictly smaller heavy edge, so each contains at
most one selected taxon.  Hence the chosen side contains exactly two.
-/

open scoped BigOperators
open SimpleGraph

namespace QDFull

universe uX uV

namespace XTree

variable {X : Type uX} {V : Type uV} [Fintype X] [Fintype V]

noncomputable local instance : DecidableEq X := Classical.decEq X
noncomputable local instance : DecidableEq V := Classical.decEq V

/-- The finite neighbor set of a vertex. -/
noncomputable def neighborFinset (T : XTree X V) (v : V) : Finset V := by
  classical
  exact Finset.univ.filter fun z => T.graph.Adj v z

@[simp] theorem mem_neighborFinset (T : XTree X V) (v z : V) :
    z ∈ T.neighborFinset v ↔ T.graph.Adj v z := by
  classical
  simp [neighborFinset]

/-- The finite neighbor set has the same cardinality as the set-valued
neighbor set used in the paper's degree hypotheses. -/
theorem card_neighborFinset (T : XTree X V) (v : V) :
    (T.neighborFinset v).card = Nat.card (T.graph.neighborSet v) := by
  classical
  rw [Nat.card_coe_set_eq, Set.ncard_eq_toFinset_card]
  congr 1
  ext z
  simp [neighborFinset]

/-- No taxon labels an internal vertex of a phylogenetic tree. -/
theorem IsPhylogenetic.labelFiber_eq_empty_of_not_leaf
    (T : XTree X V) (hphy : T.IsPhylogenetic) {v : V}
    (hv : ¬T.IsLeaf v) :
    T.labelFiber v = ∅ := by
  classical
  ext x
  simp only [T.mem_labelFiber, Finset.notMem_empty, iff_false]
  intro hx
  apply hv
  simpa [hx] using hphy.2.1 x

/-- At a degree-three vertex, deleting one specified neighbor leaves exactly
two other graph neighbors. -/
theorem card_neighborFinset_erase_of_degree_three
    (T : XTree X V) {u v : V} (huv : T.graph.Adj u v)
    (hdeg : Nat.card (T.graph.neighborSet v) = 3) :
    ((T.neighborFinset v).erase u).card = 2 := by
  classical
  rw [Finset.card_erase_of_mem ((T.mem_neighborFinset v u).2 huv.symm),
    T.card_neighborFinset v, hdeg]

/-- The noncentral indices in the away-branch partition at a degree-three
vertex are precisely its two neighbors other than the parent. -/
theorem awayBranchIndices_erase_self_card_of_degree_three
    (T : XTree X V) {u v : V} (huv : T.graph.Adj u v)
    (hdeg : Nat.card (T.graph.neighborSet v) = 3) :
    ((T.awayBranchIndices u v).erase v).card = 2 := by
  classical
  have heq : (T.awayBranchIndices u v).erase v =
      (T.neighborFinset v).erase u := by
    ext z
    simp [T.mem_awayBranchIndices_of_adj huv, T.mem_neighborFinset]
    aesop
  rw [heq, T.card_neighborFinset_erase_of_degree_three huv hdeg]

/-- At a degree-three vertex, an outward branch is a strict subset of the
side from which it branches.  The witness to strictness is a taxon in the
third incident branch. -/
theorem edgeSide_ssubset_parentSide_of_degree_three
    (T : XTree X V) {u v z : V}
    (huv : T.graph.Adj u v) (hvz : T.graph.Adj v z) (huz : u ≠ z)
    (hdeg : Nat.card (T.graph.neighborSet v) = 3) :
    T.edgeSide v z ⊂ T.edgeSide u v := by
  classical
  let N := T.neighborFinset v
  have huN : u ∈ N := by
    simp [N, huv.symm]
  have hzN : z ∈ N := by
    simp [N, hvz]
  have hzErase : z ∈ N.erase u := by
    simp [hzN, huz.symm]
  have hcardN : N.card = 3 := by
    simpa [N] using T.card_neighborFinset v |>.trans hdeg
  have hcardEraseU : (N.erase u).card = 2 := by
    rw [Finset.card_erase_of_mem huN, hcardN]
  have hcardThird : ((N.erase u).erase z).card = 1 := by
    rw [Finset.card_erase_of_mem hzErase, hcardEraseU]
  obtain ⟨y, hyThird⟩ : ((N.erase u).erase z).Nonempty :=
    Finset.card_pos.mp (by omega)
  have hyN : y ∈ N := by
    exact Finset.mem_of_mem_erase (Finset.mem_of_mem_erase hyThird)
  have hyu : y ≠ u := by
    exact (Finset.mem_erase.mp (Finset.mem_of_mem_erase hyThird)).1
  have hyz : y ≠ z := by
    exact (Finset.mem_erase.mp hyThird).1
  have hvy : T.graph.Adj v y := by
    simpa [N] using (T.mem_neighborFinset v y).1 hyN
  have hsubset : T.edgeSide v z ⊆ T.edgeSide u v :=
    T.edgeSide_sidePair_subset huv hvz huz
  obtain ⟨x, hxy⟩ := T.edgeSide_nonempty_of_adj hvy
  have hxParent : x ∈ T.edgeSide u v :=
    T.edgeSide_sidePair_subset huv hvy hyu.symm hxy
  have hxNotZ : x ∉ T.edgeSide v z := by
    intro hxz
    exact (Finset.disjoint_left.mp
      (T.edgeSide_disjoint_sidePair hvy.symm hvz hyz)) hxy hxz
  exact (Finset.ssubset_iff_of_subset hsubset).2 ⟨x, hxParent, hxNotZ⟩

/-- At an arbitrary vertex of an `XTree`, every branch leaving the far
endpoint of an oriented edge is a strict subset of the far side of that
edge.  When the endpoint has degree at most two, a taxon carried at the
endpoint witnesses strictness.  At larger degree, a third incident branch
provides the witness. -/
theorem edgeSide_ssubset_parentSide
    (T : XTree X V) {u v z : V}
    (huv : T.graph.Adj u v) (hvz : T.graph.Adj v z) (huz : u ≠ z) :
    T.edgeSide v z ⊂ T.edgeSide u v := by
  classical
  have hsubset : T.edgeSide v z ⊆ T.edgeSide u v :=
    T.edgeSide_sidePair_subset huv hvz huz
  apply (Finset.ssubset_iff_of_subset hsubset).2
  by_cases hdeg : Nat.card (T.graph.neighborSet v) ≤ 2
  · obtain ⟨x, hx⟩ := T.lowDegree_labelled v hdeg
    have hxfiber : x ∈ T.labelFiber v := by
      rw [T.mem_labelFiber]
      exact hx
    have hxParent : x ∈ T.edgeSide u v :=
      T.labelFiber_subset_reverse_edgeSide huv.symm hxfiber
    have hxNotZ : x ∉ T.edgeSide v z := by
      intro hxz
      exact (Finset.disjoint_left.mp
        (T.labelFiber_disjoint_branch hvz)) hxfiber hxz
    exact ⟨x, hxParent, hxNotZ⟩
  · let N := T.neighborFinset v
    have huN : u ∈ N := by
      simp [N, huv.symm]
    have hzN : z ∈ N := by
      simp [N, hvz]
    have hzErase : z ∈ N.erase u := by
      simp [hzN, huz.symm]
    have hcardN : 3 ≤ N.card := by
      rw [T.card_neighborFinset]
      omega
    have hcardEraseU : 2 ≤ (N.erase u).card := by
      rw [Finset.card_erase_of_mem huN]
      omega
    have hcardThird : 1 ≤ ((N.erase u).erase z).card := by
      rw [Finset.card_erase_of_mem hzErase]
      omega
    obtain ⟨y, hyThird⟩ : ((N.erase u).erase z).Nonempty :=
      Finset.card_pos.mp (by omega)
    have hyN : y ∈ N :=
      Finset.mem_of_mem_erase (Finset.mem_of_mem_erase hyThird)
    have hyu : y ≠ u :=
      (Finset.mem_erase.mp (Finset.mem_of_mem_erase hyThird)).1
    have hyz : y ≠ z := (Finset.mem_erase.mp hyThird).1
    have hvy : T.graph.Adj v y := by
      simpa [N] using (T.mem_neighborFinset v y).1 hyN
    obtain ⟨x, hxy⟩ := T.edgeSide_nonempty_of_adj hvy
    have hxParent : x ∈ T.edgeSide u v :=
      T.edgeSide_sidePair_subset huv hvy hyu.symm hxy
    have hxNotZ : x ∉ T.edgeSide v z := by
      intro hxz
      exact (Finset.disjoint_left.mp
        (T.edgeSide_disjoint_sidePair hvy.symm hvz hyz)) hxy hxz
    exact ⟨x, hxParent, hxNotZ⟩

/-- Oriented edges whose far side contains at least two members of `S`. -/
noncomputable def heavyOrientedEdges
    (T : XTree X V) (S : Finset X) : Finset (V × V) := by
  classical
  exact T.directedEdgeFinset.filter fun e =>
    2 ≤ (S ∩ T.edgeSide e.1 e.2).card

@[simp] theorem mem_heavyOrientedEdges
    (T : XTree X V) (S : Finset X) (u v : V) :
    (u, v) ∈ T.heavyOrientedEdges S ↔
      T.graph.Adj u v ∧ 2 ≤ (S ∩ T.edgeSide u v).card := by
  classical
  simp [heavyOrientedEdges]

/-- A four-taxon support has at least one heavy oriented edge: orient the
pendant edge at any selected taxon away from that taxon. -/
theorem heavyOrientedEdges_nonempty_of_card_four
    (T : XTree X V) (hphy : T.IsPhylogenetic)
    (S : Finset X) (hS : S.card = 4) :
    (T.heavyOrientedEdges S).Nonempty := by
  classical
  have hSne : S.Nonempty := Finset.card_pos.mp (by omega)
  obtain ⟨a, haS⟩ := hSne
  letI : Nonempty X := ⟨a⟩
  obtain ⟨t, ht, _⟩ := hphy.exists_unique_neighbor_label T a
  refine ⟨(T.label a, t), (T.mem_heavyOrientedEdges S _ _).2 ⟨ht, ?_⟩⟩
  have hpendant := hphy.edgeSide_pendant_eq_singleton T a ht
  have hfar : T.edgeSide (T.label a) t = ({a} : Finset X)ᶜ := by
    rw [T.edgeSide_reverse_eq_compl ht.symm, hpendant]
  have hinter : S ∩ ({a} : Finset X)ᶜ = S.erase a := by
    ext x
    simp [and_comm]
  rw [hfar, hinter, Finset.card_erase_of_mem haS, hS]
  omega

/-- Core binary-tree separator theorem.  Every four-taxon support has an
oriented edge whose far side contains exactly two of its taxa. -/
theorem exists_edge_inter_card_two_of_binary_phylogenetic
    (T : XTree X V) (hbin : T.IsBinaryPhylogenetic)
    (S : Finset X) (hS : S.card = 4) :
    ∃ u v : V, T.graph.Adj u v ∧
      (S ∩ T.edgeSide u v).card = 2 := by
  classical
  have hheavy := T.heavyOrientedEdges_nonempty_of_card_four hbin.1 S hS
  obtain ⟨e, he, hminimal⟩ := Finset.exists_min_image
    (T.heavyOrientedEdges S)
    (fun e : V × V => (T.edgeSide e.1 e.2).card) hheavy
  rcases e with ⟨u, v⟩
  have heData := (T.mem_heavyOrientedEdges S u v).1 he
  have huv : T.graph.Adj u v := heData.1
  have htwo : 2 ≤ (S ∩ T.edgeSide u v).card := heData.2
  have hvNotLeaf : ¬T.IsLeaf v := by
    intro hvLeaf
    obtain ⟨x, hx⟩ := hbin.1.2.2 v hvLeaf
    have hpendant : T.edgeSide u v = {x} := by
      have hlabelAdj : T.graph.Adj (T.label x) u := by
        simpa [hx] using huv.symm
      simpa [hx] using
        hbin.1.edgeSide_pendant_eq_singleton T x hlabelAdj
    rw [hpendant] at htwo
    have hle : (S ∩ ({x} : Finset X)).card ≤ 1 := by
      exact (Finset.card_le_card Finset.inter_subset_right).trans (by simp)
    omega
  have hdeg : Nat.card (T.graph.neighborSet v) = 3 := hbin.2 v hvNotLeaf
  have hcenterEmpty : T.branchBlock v v = ∅ := by
    rw [T.branchBlock_self,
      hbin.1.labelFiber_eq_empty_of_not_leaf T hvNotLeaf]
  let J := (T.awayBranchIndices u v).erase v
  have hJcard : J.card = 2 := by
    simpa [J] using
      T.awayBranchIndices_erase_self_card_of_degree_three huv hdeg
  have hbranchLight : ∀ z ∈ J,
      (S ∩ T.branchBlock v z).card ≤ 1 := by
    intro z hzJ
    have hzAway : z ∈ T.awayBranchIndices u v :=
      Finset.mem_of_mem_erase hzJ
    have hzv : z ≠ v := (Finset.mem_erase.mp hzJ).1
    have hzAwayData := (T.mem_awayBranchIndices_of_adj huv z).1 hzAway
    have hvz : T.graph.Adj v z := by
      rcases hzAwayData with rfl | h
      · exact (hzv rfl).elim
      · exact h.1
    have huz : u ≠ z := by
      rcases hzAwayData with rfl | h
      · exact huv.ne
      · exact Ne.symm h.2
    rw [T.branchBlock_of_adj hvz]
    by_contra hnot
    have hheavyChild : (v, z) ∈ T.heavyOrientedEdges S :=
      (T.mem_heavyOrientedEdges S v z).2 ⟨hvz, by omega⟩
    have hminChild : (T.edgeSide u v).card ≤
        (T.edgeSide v z).card := by
      simpa using hminimal (v, z) hheavyChild
    have hstrict := T.edgeSide_ssubset_parentSide_of_degree_three
      huv hvz huz hdeg
    have hcardStrict := Finset.card_lt_card hstrict
    exact (Nat.not_lt_of_ge hminChild) hcardStrict
  have hJsubset : J ⊆ T.branchIndices v := by
    intro z hz
    exact Finset.erase_subset _ _ (Finset.mem_of_mem_erase hz)
  have hdisjoint : ((J : Finset V) : Set V).PairwiseDisjoint
      (fun z => S ∩ T.branchBlock v z) := by
    intro z hz y hy hzy
    exact (T.branchIndices_pairwiseDisjoint v
      (hJsubset hz) (hJsubset hy) hzy).mono
        Finset.inter_subset_right Finset.inter_subset_right
  have hunion : J.biUnion (fun z => S ∩ T.branchBlock v z) =
      S ∩ T.edgeSide u v := by
    have haway := T.biUnion_awayBranchBlock_eq_edgeSide huv
    ext x
    constructor
    · intro hx
      simp only [Finset.mem_biUnion, Finset.mem_inter] at hx
      obtain ⟨z, hzJ, hxS, hxBranch⟩ := hx
      simp only [Finset.mem_inter]
      refine ⟨hxS, ?_⟩
      rw [← haway, Finset.mem_biUnion]
      exact ⟨z, Finset.mem_of_mem_erase hzJ, hxBranch⟩
    · intro hx
      simp only [Finset.mem_inter] at hx
      have hxAway : x ∈ (T.awayBranchIndices u v).biUnion
          (T.branchBlock v) := by
        rw [haway]
        exact hx.2
      rw [Finset.mem_biUnion] at hxAway
      obtain ⟨z, hzAway, hxBranch⟩ := hxAway
      have hzv : z ≠ v := by
        intro hzv
        subst z
        rw [hcenterEmpty] at hxBranch
        simp at hxBranch
      simp only [Finset.mem_biUnion, Finset.mem_inter]
      exact ⟨z, Finset.mem_erase.mpr ⟨hzv, hzAway⟩, hx.1, hxBranch⟩
  have hupper : (S ∩ T.edgeSide u v).card ≤ 2 := by
    rw [← hunion, Finset.card_biUnion hdisjoint]
    calc
      (∑ z ∈ J, (S ∩ T.branchBlock v z).card) ≤
          ∑ _z ∈ J, 1 := by
        apply Finset.sum_le_sum
        intro z hz
        exact hbranchLight z hz
      _ = J.card := by simp
      _ = 2 := hJcard
  exact ⟨u, v, huv, Nat.le_antisymm hupper htwo⟩

/-- The pendant edge at `x` displays every partial split whose first side is
the singleton `{x}` and whose second side avoids `x`. -/
theorem IsPhylogenetic.displays_singleton_partialSplit
    (T : XTree X V) (hphy : T.IsPhylogenetic)
    (x : X) (B : Finset X) (hxB : x ∉ B) :
    T.DisplaysPartialSplit s(({x} : Finset X), B) := by
  classical
  letI : Nonempty X := ⟨x⟩
  obtain ⟨t, ht, _⟩ := hphy.exists_unique_neighbor_label T x
  refine ⟨t, T.label x, ht.symm, ?_⟩
  have hnear := hphy.edgeSide_pendant_eq_singleton T x ht
  have hfar : T.edgeSide (T.label x) t = ({x} : Finset X)ᶜ := by
    rw [T.edgeSide_reverse_eq_compl ht.symm, hnear]
  rw [XTree.edgeSplit, hnear, hfar,
    displays_comm_representative]
  left
  refine ⟨Finset.Subset.rfl, ?_⟩
  intro y hyB
  simp only [Finset.mem_compl, Finset.mem_singleton]
  intro hyx
  subst y
  exact hxB hyB

/-- Every non-full partial quartet is displayed by every phylogenetic tree.
The `1|1` and `1|2` forms are both supplied by the pendant edge at the
singleton-side taxon. -/
theorem IsPhylogenetic.displays_partialQuartet_of_support_card_le_three
    (T : XTree X V) (hphy : T.IsPhylogenetic)
    {P : PartialSplit X} (hP : IsPartialQuartet P)
    (hcard : (partialSplitSupport P).card ≤ 3) :
    T.DisplaysPartialSplit P := by
  classical
  rcases partialQuartet_representation_cases hP with
      ⟨a, b, hab, rfl⟩ |
      ⟨a, b, c, hab, hac, hbc, rfl⟩ |
      ⟨a, b, c, d, hab, hac, had, hbc, hbd, hcd, rfl⟩
  · exact hphy.displays_singleton_partialSplit T a {b} (by simp [hab])
  · exact hphy.displays_singleton_partialSplit T a {b, c}
      (by simp [hab, hac])
  · have hdisj : Disjoint ({a, b} : Finset X) {c, d} := by
      simp [Finset.disjoint_left, hac, had, hbc, hbd]
    have hsuppCard :
        (partialSplitSupport s(({a, b} : Finset X), {c, d})).card = 4 := by
      rw [partialSplitSupport_mk,
        Finset.card_union_of_disjoint hdisj]
      simp [hab, hcd]
    omega

/-- The two complementary intersections of a four-set with an actual edge
have cardinality two whenever the first one does. -/
theorem reverse_inter_card_two_of_inter_card_two
    (T : XTree X V) (S : Finset X) {u v : V}
    (huv : T.graph.Adj u v) (hS : S.card = 4)
    (hfirst : (S ∩ T.edgeSide u v).card = 2) :
    (S ∩ T.edgeSide v u).card = 2 := by
  classical
  letI : Nonempty X := T.taxon_nonempty
  let A := S ∩ T.edgeSide u v
  let B := S ∩ T.edgeSide v u
  have hdisj : Disjoint A B :=
    (T.edgeSide_disjoint_reverse_of_adj huv).mono
      Finset.inter_subset_right Finset.inter_subset_right
  have hunion : A ∪ B = S := by
    ext x
    simp only [A, B, Finset.mem_union, Finset.mem_inter]
    constructor
    · rintro (⟨hxS, _⟩ | ⟨hxS, _⟩) <;> exact hxS
    · intro hxS
      have hcover : x ∈ T.edgeSide u v ∨ x ∈ T.edgeSide v u := by
        have hset : x ∈ (T.edgeSide u v : Set X) ∪
            (T.edgeSide v u : Set X) := by
          rw [T.edgeSide_set_union_reverse_of_adj huv]
          simp
        simpa only [Set.mem_union, Finset.mem_coe] using hset
      exact hcover.elim (fun hx => Or.inl ⟨hxS, hx⟩)
        (fun hx => Or.inr ⟨hxS, hx⟩)
  have hsum : A.card + B.card = S.card := by
    rw [← Finset.card_union_of_disjoint hdisj, hunion]
  have hAcard : A.card = 2 := by simpa [A] using hfirst
  have hBcard : B.card = 2 := by omega
  simpa [B] using hBcard

/-- Every four-taxon support in a binary phylogenetic tree carries a displayed
full quartet with exactly that support. -/
theorem exists_displayed_quartet_on_support
    (T : XTree X V) (hbin : T.IsBinaryPhylogenetic)
    (S : Finset X) (hS : S.card = 4) :
    ∃ P : PartialSplit X,
      IsQuartet P ∧ T.DisplaysPartialSplit P ∧
        partialSplitSupport P = S := by
  classical
  obtain ⟨u, v, huv, hAcard⟩ :=
    T.exists_edge_inter_card_two_of_binary_phylogenetic hbin S hS
  let A := S ∩ T.edgeSide u v
  let B := S ∩ T.edgeSide v u
  have hBcard : B.card = 2 := by
    simpa [B] using
      T.reverse_inter_card_two_of_inter_card_two S huv hS hAcard
  have hAcard' : A.card = 2 := by simpa [A] using hAcard
  have hdisj : Disjoint A B :=
    (T.edgeSide_disjoint_reverse_of_adj huv).mono
      Finset.inter_subset_right Finset.inter_subset_right
  have hAne : A.Nonempty := Finset.card_pos.mp (by omega)
  have hBne : B.Nonempty := Finset.card_pos.mp (by omega)
  have hunion : A ∪ B = S := by
    ext x
    simp only [A, B, Finset.mem_union, Finset.mem_inter]
    constructor
    · rintro (⟨hxS, _⟩ | ⟨hxS, _⟩) <;> exact hxS
    · intro hxS
      have hcover : x ∈ T.edgeSide u v ∨ x ∈ T.edgeSide v u := by
        have hset : x ∈ (T.edgeSide u v : Set X) ∪
            (T.edgeSide v u : Set X) := by
          rw [T.edgeSide_set_union_reverse_of_adj huv]
          simp
        simpa only [Set.mem_union, Finset.mem_coe] using hset
      exact hcover.elim (fun hx => Or.inl ⟨hxS, hx⟩)
        (fun hx => Or.inr ⟨hxS, hx⟩)
  let P : PartialSplit X := s(A, B)
  refine ⟨P, ?_, ?_, ?_⟩
  · exact ⟨⟨A, B, rfl, hAne, hBne, hdisj⟩,
      A, B, rfl, hAcard', hBcard⟩
  · refine ⟨u, v, huv, ?_⟩
    rw [XTree.edgeSplit, displays_comm_representative]
    exact Or.inl ⟨Finset.inter_subset_right,
      Finset.inter_subset_right⟩
  · simpa [P, partialSplitSupport_mk] using hunion

/-- A tree cannot display two different full quartets on the same support. -/
theorem displayed_quartet_unique_on_support
    (T : XTree X V) {P Q : PartialSplit X}
    (hP : IsQuartet P) (hQ : IsQuartet Q)
    (hTP : T.DisplaysPartialSplit P) (hTQ : T.DisplaysPartialSplit Q)
    (hsupport : partialSplitSupport P = partialSplitSupport Q) :
    P = Q := by
  classical
  obtain ⟨a, b, c, d, hab, hac, had, hbc, hbd, hcd, hrep⟩ :=
    quartet_representation hP
  let draw : Fin 4 → X := ![a, b, c, d]
  have hdrawSupport : fourDrawSupport draw = partialSplitSupport P := by
    rw [hrep, partialSplitSupport_mk]
    ext x
    simp [draw, fourDrawSupport]
    aesop
  have hindP : Induces draw P :=
    induces_of_isQuartet_and_support_eq hP hdrawSupport
  have hindQ : Induces draw Q :=
    induces_of_isQuartet_and_support_eq hQ
      (hdrawSupport.trans hsupport)
  exact T.induced_displayed_partialQuartet_unique draw
    hindP hindQ hTP hTQ

end XTree

end QDFull
