import QDFull.TreeEventClassification
import QDFull.WeightedApplications

/-!
# Four-draw semantics for edge-weighted tree covariance

The manuscript first describes weighted quartet covariance sample by sample:
each tree selects the (necessarily unique, when it exists) partial quartet
induced by an ordered draw, the two selected quartet lengths are multiplied,
and the agreement coefficient is `1` for the same quartet and `-1/2` for two
different quartets.  `weightedTreeDrawContribution` formalizes that description
as a finite sum over partial splits.  In particular, it is not defined by the
edge-pair formula to which it is subsequently proved equal.

The finite-sum formulation avoids choosing a witness.  `Induces` is a
proposition, so its possibly many permutation witnesses are not counted, and
the unordered type `PartialSplit X` does not count a reversal twice.  Tree
quartet uniqueness then reduces the double sum to one term in the same and
different cases.  If a draw has repeated taxa that induce no displayed partial
quartet, if one tree displays no induced quartet, or if a tree has no edge
source, the corresponding finite sum is zero without any extra hypothesis.
-/

open scoped BigOperators

namespace QDFull
namespace WeightedApplications

open EdgeWeightedXTree

universe uX uV₁ uV₂

variable {X : Type uX} [Fintype X]
variable {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype V₁] [LinearOrder V₁]
  [Fintype V₂] [LinearOrder V₂]

noncomputable local instance : DecidableEq X := Classical.decEq X

/-- A partial quartet is eligible for a tree on a draw precisely when the
draw induces it and the tree displays it. -/
def drawDisplaysPartialQuartet {V : Type*} [Fintype V]
    (T : XTree X V) (draw : Fin 4 → X) (P : PartialSplit X) : Prop :=
  Induces draw P ∧ T.DisplaysPartialSplit P

/-- The pointwise covariance coefficient of the two tree-selected partial
quartets. -/
noncomputable def quartetAgreementWeight (P Q : PartialSplit X) : ℝ := by
  classical
  exact if P = Q then 1 else -(1 / 2 : ℝ)

/-- The manuscript's length-weighted contribution of one ordered four-draw
sample.  The two finite sums independently select the induced-and-displayed
partial quartet of each tree. -/
noncomputable def weightedTreeDrawContribution
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂)
    (draw : Fin 4 → X) : ℝ :=
  ∑ P : PartialSplit X, ∑ Q : PartialSplit X,
    propIndicator (drawDisplaysPartialQuartet W₁.tree draw P) *
      propIndicator (drawDisplaysPartialQuartet W₂.tree draw Q) *
      quartetAgreementWeight P Q *
      W₁.partialQuartetLength P * W₂.partialQuartetLength Q

/-- The genuine four-draw weighted covariance: the uniform finite average of
the preceding samplewise definition. -/
noncomputable def weightedFourDrawCovariance
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂) : ℝ :=
  fourDrawAverage (weightedTreeDrawContribution W₁ W₂)

/-- A tree has at most one eligible partial quartet on a fixed draw.  This is
the fact that makes the finite `P,Q` sums agree with the manuscript's singular
phrase "the induced partial quartet". -/
theorem drawDisplaysPartialQuartet_unique
    {V : Type*} [Fintype V] (T : XTree X V) (draw : Fin 4 → X)
    {P Q : PartialSplit X}
    (hP : drawDisplaysPartialQuartet T draw P)
    (hQ : drawDisplaysPartialQuartet T draw Q) :
    P = Q := by
  exact T.induced_displayed_partialQuartet_unique draw hP.1 hQ.1 hP.2 hQ.2

/-- In the common-quartet case, the finite definition is exactly the product
of the two displayed quartet lengths. -/
theorem weightedTreeDrawContribution_eq_of_sameWitness
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂)
    {draw : Fin 4 → X} {P : PartialSplit X}
    (hindP : Induces draw P)
    (hT₁P : W₁.tree.DisplaysPartialSplit P)
    (hT₂P : W₂.tree.DisplaysPartialSplit P) :
    weightedTreeDrawContribution W₁ W₂ draw =
      W₁.partialQuartetLength P * W₂.partialQuartetLength P := by
  classical
  unfold weightedTreeDrawContribution
  rw [Finset.sum_eq_single P]
  · rw [Finset.sum_eq_single P]
    · simp [drawDisplaysPartialQuartet, quartetAgreementWeight,
        hindP, hT₁P, hT₂P]
    · intro Q _ hQP
      have hnot : ¬drawDisplaysPartialQuartet W₂.tree draw Q := by
        intro hQ
        apply hQP
        exact drawDisplaysPartialQuartet_unique W₂.tree draw hQ
          ⟨hindP, hT₂P⟩
      simp [propIndicator_of_false hnot]
    · simp
  · intro R _ hRP
    have hnot : ¬drawDisplaysPartialQuartet W₁.tree draw R := by
      intro hR
      apply hRP
      exact drawDisplaysPartialQuartet_unique W₁.tree draw hR
        ⟨hindP, hT₁P⟩
    simp [propIndicator_of_false hnot]
  · simp

/-- In the distinct-quartet case, the finite definition is minus one half of
the product of the two displayed quartet lengths. -/
theorem weightedTreeDrawContribution_eq_of_differentWitness
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂)
    {draw : Fin 4 → X} {P Q : PartialSplit X}
    (hindP : Induces draw P) (hindQ : Induces draw Q)
    (hT₁P : W₁.tree.DisplaysPartialSplit P)
    (hT₂Q : W₂.tree.DisplaysPartialSplit Q) (hPQ : P ≠ Q) :
    weightedTreeDrawContribution W₁ W₂ draw =
      -(1 / 2 : ℝ) *
        W₁.partialQuartetLength P * W₂.partialQuartetLength Q := by
  classical
  unfold weightedTreeDrawContribution
  rw [Finset.sum_eq_single P]
  · rw [Finset.sum_eq_single Q]
    · simp [drawDisplaysPartialQuartet, quartetAgreementWeight,
        hindP, hindQ, hT₁P, hT₂Q, hPQ]
    · intro R _ hRQ
      have hnot : ¬drawDisplaysPartialQuartet W₂.tree draw R := by
        intro hR
        apply hRQ
        exact drawDisplaysPartialQuartet_unique W₂.tree draw hR
          ⟨hindQ, hT₂Q⟩
      simp [propIndicator_of_false hnot]
    · simp
  · intro R _ hRP
    have hnot : ¬drawDisplaysPartialQuartet W₁.tree draw R := by
      intro hR
      apply hRP
      exact drawDisplaysPartialQuartet_unique W₁.tree draw hR
        ⟨hindP, hT₁P⟩
    simp [propIndicator_of_false hnot]
  · simp

/-- If neither tree event occurs, the weighted contribution is zero.  This
case includes all draws for which either tree has no induced displayed
partial quartet. -/
theorem weightedTreeDrawContribution_eq_zero_of_noTreeEvent
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂)
    {draw : Fin 4 → X}
    (hSame : ¬SameTreeQuartetEvent W₁.tree W₂.tree draw)
    (hDiff : ¬DifferentTreeQuartetEvent W₁.tree W₂.tree draw) :
    weightedTreeDrawContribution W₁ W₂ draw = 0 := by
  classical
  unfold weightedTreeDrawContribution
  apply Finset.sum_eq_zero
  intro P _
  apply Finset.sum_eq_zero
  intro Q _
  by_cases h₁ : drawDisplaysPartialQuartet W₁.tree draw P
  · by_cases h₂ : drawDisplaysPartialQuartet W₂.tree draw Q
    · by_cases hPQ : P = Q
      · subst Q
        exact False.elim (hSame ⟨P, h₁.1, h₁.2, h₂.2⟩)
      · exact False.elim
          (hDiff ⟨P, Q, h₁.1, h₂.1, h₁.2, h₂.2, hPQ⟩)
    · simp [propIndicator_of_false h₂]
  · simp [propIndicator_of_false h₁]

/-- The partial-quartet length is the display-indicator weighted sum of edge
lengths. -/
theorem partialQuartetLength_eq_sum_indicator_mul
    {V : Type*} [Fintype V] [LinearOrder V]
    (W : EdgeWeightedXTree X V) (P : PartialSplit X) :
    W.partialQuartetLength P =
      ∑ e, propIndicator (Displays (W.edgeSplit e) P) * W.length e := by
  classical
  unfold EdgeWeightedXTree.partialQuartetLength
  apply Finset.sum_congr rfl
  intro e _
  by_cases h : Displays (W.edgeSplit e) P <;>
    simp [propIndicator, h]

/-- The edge-pair source expansion on one ordered draw. -/
noncomputable def weightedEdgePairDrawSum
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂)
    (draw : Fin 4 → X) : ℝ :=
  ∑ e, ∑ f,
    splitDrawContribution (W₁.edgeSplit e) (W₂.edgeSplit f) draw *
      W₁.length e * W₂.length f

private theorem product_univ_sums
    {A B : Type*} [Fintype A] [Fintype B]
    (a : A → ℝ) (b : B → ℝ) :
    (∑ i, a i) * (∑ j, b j) = ∑ i, ∑ j, a i * b j := by
  rw [Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro i _
  rw [Finset.mul_sum]

variable [Nonempty X]

/-- Pointwise finite edge expansion of the genuine draw-level definition. -/
theorem weightedTreeDrawContribution_eq_edgePairSum
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂)
    (draw : Fin 4 → X) :
    weightedTreeDrawContribution W₁ W₂ draw =
      weightedEdgePairDrawSum W₁ W₂ draw := by
  classical
  by_cases hSame : SameTreeQuartetEvent W₁.tree W₂.tree draw
  · rcases hSame with ⟨P, hindP, hT₁P, hT₂P⟩
    rw [weightedTreeDrawContribution_eq_of_sameWitness
      W₁ W₂ hindP hT₁P hT₂P]
    rw [partialQuartetLength_eq_sum_indicator_mul,
      partialQuartetLength_eq_sum_indicator_mul,
      product_univ_sums]
    unfold weightedEdgePairDrawSum
    apply Finset.sum_congr rfl
    intro e _
    apply Finset.sum_congr rfl
    intro f _
    unfold EdgeWeightedXTree.edgeSplit
    rw [splitDrawContribution_eq_mul_of_sameTreeWitness
      W₁.tree W₂.tree
      (W₁.tree.displays_edgeSplit (W₁.canonicalEdge_adj e))
      (W₂.tree.displays_edgeSplit (W₂.canonicalEdge_adj f))
      hindP hT₁P hT₂P]
    ring
  · by_cases hDiff : DifferentTreeQuartetEvent W₁.tree W₂.tree draw
    · rcases hDiff with ⟨P, Q, hindP, hindQ, hT₁P, hT₂Q, hPQ⟩
      rw [weightedTreeDrawContribution_eq_of_differentWitness
        W₁ W₂ hindP hindQ hT₁P hT₂Q hPQ]
      rw [partialQuartetLength_eq_sum_indicator_mul,
        partialQuartetLength_eq_sum_indicator_mul]
      calc
        (-(1 / 2 : ℝ) *
              (∑ e, propIndicator (Displays (W₁.edgeSplit e) P) *
                W₁.length e)) *
            (∑ f, propIndicator (Displays (W₂.edgeSplit f) Q) *
              W₂.length f) =
            -(1 / 2 : ℝ) *
              ((∑ e, propIndicator (Displays (W₁.edgeSplit e) P) *
                  W₁.length e) *
                (∑ f, propIndicator (Displays (W₂.edgeSplit f) Q) *
                  W₂.length f)) := by ring
        _ = -(1 / 2 : ℝ) *
              (∑ e, ∑ f,
                (propIndicator (Displays (W₁.edgeSplit e) P) * W₁.length e) *
                  (propIndicator (Displays (W₂.edgeSplit f) Q) * W₂.length f)) := by
            rw [product_univ_sums]
        _ = weightedEdgePairDrawSum W₁ W₂ draw := by
          rw [Finset.mul_sum]
          unfold weightedEdgePairDrawSum
          apply Finset.sum_congr rfl
          intro e _
          rw [Finset.mul_sum]
          apply Finset.sum_congr rfl
          intro f _
          unfold EdgeWeightedXTree.edgeSplit
          rw [splitDrawContribution_eq_negHalf_mul_of_differentTreeWitness
            W₁.tree W₂.tree
            (W₁.tree.displays_edgeSplit (W₁.canonicalEdge_adj e))
            (W₂.tree.displays_edgeSplit (W₂.canonicalEdge_adj f))
            hindP hindQ hT₁P hT₂Q hPQ]
          ring
    · rw [weightedTreeDrawContribution_eq_zero_of_noTreeEvent
        W₁ W₂ hSame hDiff]
      unfold weightedEdgePairDrawSum
      symm
      apply Finset.sum_eq_zero
      intro e _
      apply Finset.sum_eq_zero
      intro f _
      unfold EdgeWeightedXTree.edgeSplit
      rw [splitDrawContribution_eq_zero_of_noTreeEvent
        W₁.tree W₂.tree
        (W₁.tree.displays_edgeSplit (W₁.canonicalEdge_adj e))
        (W₂.tree.displays_edgeSplit (W₂.canonicalEdge_adj f))
        hSame hDiff]
      ring

omit [Nonempty X] in
/-- Finite averaging commutes with multiplication by two constants on the
right. -/
private theorem fourDrawAverage_mul_two_constants
    (f : (Fin 4 → X) → ℝ) (a b : ℝ) :
    fourDrawAverage (fun draw => f draw * a * b) =
      fourDrawAverage f * a * b := by
  calc
    fourDrawAverage (fun draw => f draw * a * b) =
        fourDrawAverage (fun draw => (a * b) * f draw) := by
      congr 1
      funext draw
      ring
    _ = (a * b) * fourDrawAverage f :=
      fourDrawAverage_const_mul (a * b) f
    _ = fourDrawAverage f * a * b := by ring

/-- Averaging the pointwise edge expansion gives exactly the existing
edge-pair definition of weighted tree distance covariance. -/
theorem weightedFourDrawCovariance_eq_treeDistanceCovariance
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂) :
    weightedFourDrawCovariance W₁ W₂ =
      treeDistanceCovariance W₁ W₂ := by
  unfold weightedFourDrawCovariance
  rw [show weightedTreeDrawContribution W₁ W₂ =
      weightedEdgePairDrawSum W₁ W₂ by
    funext draw
    exact weightedTreeDrawContribution_eq_edgePairSum W₁ W₂ draw]
  unfold weightedEdgePairDrawSum treeDistanceCovariance
  calc
    fourDrawAverage (fun draw =>
        ∑ e, ∑ f,
          splitDrawContribution (W₁.edgeSplit e) (W₂.edgeSplit f) draw *
            W₁.length e * W₂.length f) =
        ∑ e, ∑ f, fourDrawAverage (fun draw =>
          splitDrawContribution (W₁.edgeSplit e) (W₂.edgeSplit f) draw *
            W₁.length e * W₂.length f) := by
      rw [fourDrawAverage_sum]
      apply Finset.sum_congr rfl
      intro e _
      rw [fourDrawAverage_sum]
    _ = ∑ e, ∑ f, splitQuartetCovarianceEvent
          (W₁.edgeSplit e) (W₂.edgeSplit f) *
            W₁.length e * W₂.length f := by
      apply Finset.sum_congr rfl
      intro e _
      apply Finset.sum_congr rfl
      intro f _
      rw [fourDrawAverage_mul_two_constants,
        ← splitQuartetCovarianceEvent_eq_average]

/-- The optional manuscript terminal obtained by composing the four-draw
bridge with the already proved distance-covariance identity. -/
theorem weightedFourDrawCovariance_eq_threeHalves_empirical
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂) :
    weightedFourDrawCovariance W₁ W₂ =
      (3 / 2 : ℝ) * empiricalTreeDistanceCovariance W₁ W₂ := by
  rw [weightedFourDrawCovariance_eq_treeDistanceCovariance,
    treeDistanceCovariance_eq_threeHalves_empirical]

end WeightedApplications
end QDFull
