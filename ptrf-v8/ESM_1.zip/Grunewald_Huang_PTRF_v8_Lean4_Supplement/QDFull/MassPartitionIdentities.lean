import QDFull.FiniteIndexSets

/-!
# Marginal identities for the local row--column table

The paper repeatedly collapses one branch index by saying that the local
blocks form a partition.  The theorems below are the exact finite-sum forms of
those collapses, including the restricted `N_{t+}(u)` sums used after an edge
orientation is reversed.
-/

open scoped BigOperators

namespace QDFull

universe uX uV₁ uV₂

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]

/-- Summing a joint table column over all row branches gives its column
marginal. -/
theorem sum_jointMass_allRowBranches
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u : V₁) (v w w' : V₂) :
    ∑ z ∈ T₁.branchIndices u,
        jointMass T₁ T₂ t u v w z w' =
      T₂.columnMass v w w' := by
  classical
  simpa [jointMass, jointBlock, XTree.rowBlock,
    XTree.columnMass, Finset.inter_comm] using
    T₁.sum_normalizedCard_inter_allBranches u
      (T₂.columnBlock v w w')

/-- Summing a joint table row over all column branches gives its row
marginal. -/
theorem sum_jointMass_allColumnBranches
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' : V₁) (v w : V₂) :
    ∑ z ∈ T₂.branchIndices w,
        jointMass T₁ T₂ t u v w u' z =
      T₁.rowMass t u u' := by
  classical
  simpa [jointMass, jointBlock, XTree.columnBlock,
    XTree.rowMass] using
    T₂.sum_normalizedCard_inter_allBranches w
      (T₁.rowBlock t u u')

/-- The row-branch masses at a fixed centre form a probability partition. -/
theorem sum_rowMass_allBranches
    (T : XTree X V₁) (t u : V₁) :
    ∑ z ∈ T.branchIndices u, T.rowMass t u z = 1 := by
  classical
  calc
    ∑ z ∈ T.branchIndices u, T.rowMass t u z =
        normalizedCard (Finset.univ : Finset X) := by
      simpa [XTree.rowMass, XTree.rowBlock] using
        T.sum_normalizedCard_inter_allBranches u (Finset.univ : Finset X)
    _ = 1 := by
      letI : Nonempty X := T.taxon_nonempty
      simp [normalizedCard, Fintype.card_ne_zero]

/-- The column-branch masses at a fixed centre form a probability partition. -/
theorem sum_columnMass_allBranches
    (T : XTree X V₂) (v w : V₂) :
    ∑ z ∈ T.branchIndices w, T.columnMass v w z = 1 := by
  classical
  calc
    ∑ z ∈ T.branchIndices w, T.columnMass v w z =
        normalizedCard (Finset.univ : Finset X) := by
      simpa [XTree.columnMass, XTree.columnBlock] using
        T.sum_normalizedCard_inter_allBranches w (Finset.univ : Finset X)
    _ = 1 := by
      letI : Nonempty X := T.taxon_nonempty
      simp [normalizedCard, Fintype.card_ne_zero]

/-- Restricted row collapse over `N_{t+}(u)`: the resulting block is the
`u`-side of `tu`, represented as the row block of the reversed orientation. -/
theorem sum_jointMass_awayRowBranches
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} (htu : T₁.graph.Adj t u)
    (v w w' : V₂) :
    ∑ z ∈ T₁.awayBranchIndices t u,
        jointMass T₁ T₂ t u v w z w' =
      jointMass T₁ T₂ u t v w u w' := by
  classical
  calc
    ∑ z ∈ T₁.awayBranchIndices t u,
        jointMass T₁ T₂ t u v w z w' =
        normalizedCard
          (T₂.columnBlock v w w' ∩ T₁.edgeSide t u) := by
      simpa [jointMass, jointBlock, XTree.rowBlock,
        Finset.inter_comm] using
        T₁.sum_normalizedCard_inter_awayBranches htu
          (T₂.columnBlock v w w')
    _ = jointMass T₁ T₂ u t v w u w' := by
      rw [jointMass, jointBlock, T₁.rowBlock_of_adj u htu]
      simp [Finset.inter_comm]

/-- Restricted column collapse over `N_{v+}(w)`, represented by the reversed
column orientation. -/
theorem sum_jointMass_awayColumnBranches
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' : V₁) {v w : V₂}
    (hvw : T₂.graph.Adj v w) :
    ∑ z ∈ T₂.awayBranchIndices v w,
        jointMass T₁ T₂ t u v w u' z =
      jointMass T₁ T₂ t u w v u' w := by
  classical
  calc
    ∑ z ∈ T₂.awayBranchIndices v w,
        jointMass T₁ T₂ t u v w u' z =
        normalizedCard
          (T₁.rowBlock t u u' ∩ T₂.edgeSide v w) := by
      simpa [jointMass, jointBlock, XTree.columnBlock] using
        T₂.sum_normalizedCard_inter_awayBranches hvw
          (T₁.rowBlock t u u')
    _ = jointMass T₁ T₂ t u w v u' w := by
      rw [jointMass, jointBlock, T₂.columnBlock_of_adj w hvw]

/-- Restricted row masses sum to the reversed orientation's principal-side
mass. -/
theorem sum_rowMass_awayBranches
    (T : XTree X V₁) {t u : V₁} (htu : T.graph.Adj t u) :
    ∑ z ∈ T.awayBranchIndices t u, T.rowMass t u z =
      T.rowMass u t u := by
  classical
  calc
    ∑ z ∈ T.awayBranchIndices t u, T.rowMass t u z =
        normalizedCard (T.edgeSide t u) := by
      simpa [XTree.rowMass, XTree.rowBlock] using
        T.sum_normalizedCard_inter_awayBranches htu (Finset.univ : Finset X)
    _ = T.rowMass u t u := by
      rw [XTree.rowMass, T.rowBlock_of_adj u htu]

/-- Restricted column masses satisfy the analogous reversal identity. -/
theorem sum_columnMass_awayBranches
    (T : XTree X V₂) {v w : V₂} (hvw : T.graph.Adj v w) :
    ∑ z ∈ T.awayBranchIndices v w, T.columnMass v w z =
      T.columnMass w v w := by
  classical
  calc
    ∑ z ∈ T.awayBranchIndices v w, T.columnMass v w z =
        normalizedCard (T.edgeSide v w) := by
      simpa [XTree.columnMass, XTree.columnBlock] using
        T.sum_normalizedCard_inter_awayBranches hvw (Finset.univ : Finset X)
    _ = T.columnMass w v w := by
      rw [XTree.columnMass, T.columnBlock_of_adj w hvw]

/-- Splitting the row coordinate by the two sides of an actual edge partitions
every fixed column block.  This is the two-term form of "row partition" used
in the four-orientation `q` settlement. -/
theorem jointMass_edgeSide_partition_row
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} (htu : T₁.graph.Adj t u)
    (v w w' : V₂) :
    jointMass T₁ T₂ u t v w u w' +
        jointMass T₁ T₂ t u v w t w' =
      T₂.columnMass v w w' := by
  classical
  have htmem : t ∈ T₁.branchIndices u := by
    rw [T₁.mem_branchIndices, T₁.mem_neighborsPlus]
    exact Or.inr htu.symm
  have haway :=
    sum_jointMass_awayRowBranches T₁ T₂ htu v w w'
  have hall :=
    sum_jointMass_allRowBranches T₁ T₂ t u v w w'
  calc
    jointMass T₁ T₂ u t v w u w' +
          jointMass T₁ T₂ t u v w t w' =
        (∑ z ∈ T₁.awayBranchIndices t u,
            jointMass T₁ T₂ t u v w z w') +
          jointMass T₁ T₂ t u v w t w' := by rw [haway]
    _ = ∑ z ∈ T₁.branchIndices u,
          jointMass T₁ T₂ t u v w z w' := by
      simpa [XTree.awayBranchIndices] using
        (Finset.sum_erase_add (T₁.branchIndices u)
          (fun z => jointMass T₁ T₂ t u v w z w') htmem)
    _ = T₂.columnMass v w w' := hall

/-- The two orientations of an actual column edge have complementary masses. -/
theorem columnMass_edgeSide_partition
    (T : XTree X V₂) {v w : V₂} (hvw : T.graph.Adj v w) :
    T.columnMass w v w + T.columnMass v w v = 1 := by
  classical
  have hvmem : v ∈ T.branchIndices w := by
    rw [T.mem_branchIndices, T.mem_neighborsPlus]
    exact Or.inr hvw.symm
  have haway := sum_columnMass_awayBranches T hvw
  have hall := sum_columnMass_allBranches T v w
  calc
    T.columnMass w v w + T.columnMass v w v =
        (∑ z ∈ T.awayBranchIndices v w, T.columnMass v w z) +
          T.columnMass v w v := by rw [haway]
    _ = ∑ z ∈ T.branchIndices w, T.columnMass v w z := by
      simpa [XTree.awayBranchIndices] using
        (Finset.sum_erase_add (T.branchIndices w)
          (fun z => T.columnMass v w z) hvmem)
    _ = 1 := hall

/-- Splitting the column coordinate by the two sides of an actual edge
partitions every fixed row block. -/
theorem jointMass_edgeSide_partition_column
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' : V₁) {v w : V₂} (hvw : T₂.graph.Adj v w) :
    jointMass T₁ T₂ t u w v u' w +
        jointMass T₁ T₂ t u v w u' v =
      T₁.rowMass t u u' := by
  classical
  have hvmem : v ∈ T₂.branchIndices w := by
    rw [T₂.mem_branchIndices, T₂.mem_neighborsPlus]
    exact Or.inr hvw.symm
  have haway :=
    sum_jointMass_awayColumnBranches T₁ T₂ t u u' hvw
  have hall :=
    sum_jointMass_allColumnBranches T₁ T₂ t u u' v w
  calc
    jointMass T₁ T₂ t u w v u' w +
          jointMass T₁ T₂ t u v w u' v =
        (∑ z ∈ T₂.awayBranchIndices v w,
            jointMass T₁ T₂ t u v w u' z) +
          jointMass T₁ T₂ t u v w u' v := by rw [haway]
    _ = ∑ z ∈ T₂.branchIndices w,
          jointMass T₁ T₂ t u v w u' z := by
      simpa [XTree.awayBranchIndices] using
        (Finset.sum_erase_add (T₂.branchIndices w)
          (fun z => jointMass T₁ T₂ t u v w u' z) hvmem)
    _ = T₁.rowMass t u u' := hall

/-- The two orientations of an actual row edge have complementary masses. -/
theorem rowMass_edgeSide_partition
    (T : XTree X V₁) {t u : V₁} (htu : T.graph.Adj t u) :
    T.rowMass u t u + T.rowMass t u t = 1 := by
  classical
  have htmem : t ∈ T.branchIndices u := by
    rw [T.mem_branchIndices, T.mem_neighborsPlus]
    exact Or.inr htu.symm
  have haway := sum_rowMass_awayBranches T htu
  have hall := sum_rowMass_allBranches T t u
  calc
    T.rowMass u t u + T.rowMass t u t =
        (∑ z ∈ T.awayBranchIndices t u, T.rowMass t u z) +
          T.rowMass t u t := by rw [haway]
    _ = ∑ z ∈ T.branchIndices u, T.rowMass t u z := by
      simpa [XTree.awayBranchIndices] using
        (Finset.sum_erase_add (T.branchIndices u)
          (fun z => T.rowMass t u z) htmem)
    _ = 1 := hall

end QDFull
