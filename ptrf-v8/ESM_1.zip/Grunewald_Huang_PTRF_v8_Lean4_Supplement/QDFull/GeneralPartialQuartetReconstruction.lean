import QDFull.QuartetCorrelationEquality

/-!
# Reconstruction of a general vertex-labelled X-tree from partial quartets

This file closes the graph-theoretic equality case in Proposition 2.  The
argument uses all partial quartets of support two, three, and four.  No
external reconstruction theorem is assumed.

For a proposed full split `A | Aᶜ`, choose a rooted cluster of minimum size
among those containing `A`.  If this cluster is larger than `A`, its root
vertex lies simultaneously on a path joining two (not necessarily distinct)
taxa of `A` and on a path joining two taxa of `Aᶜ`.  These four endpoints
give a partial quartet displayed by the proposed split but not by the tree.
Consequently, a full split is represented by an edge exactly when all of its
partial-quartet restrictions are displayed.  Equality of the complete
partial-quartet systems therefore gives equality of edge-split systems, and
the rooted-cluster reconstruction then gives a label-preserving graph
isomorphism for arbitrary `X`-trees.
-/

open SimpleGraph

namespace QDFull

universe uX uV uV₁ uV₂

variable {X : Type uX} {V : Type uV} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V] [Fintype V₁] [Fintype V₂]
  [DecidableEq X] [DecidableEq V] [DecidableEq V₁] [DecidableEq V₂]

namespace XTree

/-- A minimum rooted cluster containing a nonempty taxon set has its root
vertex on a path between two members of that set.  Repetition is allowed;
when the vertex itself carries a member of `A`, the two endpoints coincide.
-/
theorem exists_taxon_pair_path_through_of_minimal_rootedCluster
    (T : XTree X V) (r : X) {A : Finset X} (hA : A.Nonempty)
    {v : V} (hAv : A ⊆ T.rootedCluster r v)
    (hminimal : ∀ w : V, A ⊆ T.rootedCluster r w →
      (T.rootedCluster r v).card ≤ (T.rootedCluster r w).card) :
    ∃ a₁ ∈ A, ∃ a₂ ∈ A,
      v ∈ (T.taxonPath a₁ a₂).support := by
  classical
  obtain ⟨a₁, ha₁A⟩ := hA
  by_cases ha₁v : T.label a₁ = v
  · refine ⟨a₁, ha₁A, a₁, ha₁A, ?_⟩
    rw [← ha₁v]
    exact SimpleGraph.Walk.start_mem_support _
  · obtain ⟨w, hvw, ha₁Vertex⟩ :=
      T.exists_outgoing_branch (centre := v) (y := T.label a₁) ha₁v
    have ha₁Side : a₁ ∈ T.edgeSide v w :=
      (T.mem_edgeSide v w a₁).2 ha₁Vertex
    have hvRootPath :
        v ∈ (T.taxonPath r a₁).support :=
      T.mem_vertexPath_root_label_of_mem_rootedCluster r (hAv ha₁A)
    have hrReverse : r ∈ T.edgeSide w v := by
      rcases T.mem_edgeSide_or_mem_edgeSide_reverse_of_adj hvw r with
        hrForward | hrReverse
      · have hvForward : v ∈ T.vertexSide v w :=
          T.mem_vertexSide_of_mem_taxonPath_support_same_side
            hvw hrForward ha₁Side hvRootPath
        have hvReverse : v ∈ T.vertexSide w v := by
          change (T.graph.deleteEdges {s(w, v)}).Reachable v v
          exact SimpleGraph.Reachable.refl v
        exact False.elim ((Set.disjoint_left.mp
          (T.vertexSide_disjoint_reverse_of_adj hvw)) hvForward hvReverse)
      · exact hrReverse
    have hwRoot : w ≠ T.label r := by
      intro hw
      have hrForward : r ∈ T.edgeSide v w := by
        rw [T.mem_edgeSide, hw]
      exact (Finset.disjoint_left.mp
        (T.edgeSide_disjoint_reverse_of_adj hvw)) hrForward hrReverse
    have hparent : T.rootParent r w = v :=
      T.rootParent_eq_of_root_mem_reverse_edgeSide r hvw hrReverse
    have hclusterW :
        T.rootedCluster r w = T.edgeSide v w := by
      rw [T.rootedCluster_eq_edgeSide_rootParent r hwRoot, hparent]
    have hstrict :
        T.rootedCluster r w ⊂ T.rootedCluster r v := by
      simpa only [hparent] using T.rootedCluster_ssubset_parent r hwRoot
    have hnotSubset : ¬A ⊆ T.rootedCluster r w := by
      intro hAw
      have hcardMin := hminimal w hAw
      have hcardStrict := Finset.card_lt_card hstrict
      omega
    obtain ⟨a₂, ha₂A, ha₂Not⟩ := Finset.not_subset.mp hnotSubset
    have ha₂NotForward : a₂ ∉ T.edgeSide v w := by
      rw [← hclusterW]
      exact ha₂Not
    have ha₂Reverse : a₂ ∈ T.edgeSide w v :=
      (T.mem_edgeSide_or_mem_edgeSide_reverse_of_adj hvw a₂).resolve_left
        ha₂NotForward
    have hedge : s(v, w) ∈ (T.taxonPath a₁ a₂).edges :=
      (T.edge_mem_taxonPath_iff_opposite_sides hvw a₁ a₂).2
        (Or.inl ⟨ha₁Side, ha₂Reverse⟩)
    exact ⟨a₁, ha₁A, a₂, ha₂A,
      (T.taxonPath a₁ a₂).fst_mem_support_of_mem_edges hedge⟩

/-- If every partial-quartet restriction of the nontrivial full split
`A | Aᶜ` is displayed by `T`, then the full split itself is represented by an
edge of `T`. -/
theorem displays_compl_split_of_all_partialQuartet_restrictions
    (T : XTree X V) {A : Finset X}
    (hA : A.Nonempty) (hAc : (Finset.univ \ A).Nonempty)
    (hall : ∀ P : PartialSplit X, IsPartialQuartet P →
      Displays s(A, Finset.univ \ A) P → T.DisplaysPartialSplit P) :
    T.DisplaysPartialSplit s(A, Finset.univ \ A) := by
  classical
  by_contra hnotDisplay
  obtain ⟨r, hrAc⟩ := hAc
  let candidates : Finset V := Finset.univ.filter fun v =>
    A ⊆ T.rootedCluster r v
  have hcandidates : candidates.Nonempty := by
    refine ⟨T.label r, ?_⟩
    simp [candidates, T.rootedCluster_root]
  obtain ⟨v, hvCandidates, hminimal⟩ :=
    Finset.exists_min_image candidates
      (fun w : V => (T.rootedCluster r w).card) hcandidates
  have hAv : A ⊆ T.rootedCluster r v := by
    simpa [candidates] using hvCandidates
  have hclusterNe : T.rootedCluster r v ≠ A := by
    intro hcluster
    by_cases hvRoot : v = T.label r
    · subst v
      rw [T.rootedCluster_root] at hcluster
      have hrA : r ∈ A := by
        rw [← hcluster]
        exact Finset.mem_univ r
      exact (Finset.mem_sdiff.mp hrAc).2 hrA
    · have hedge := T.rootParent_adj r hvRoot
      have hsplit := T.edgeSplit_rootParent_eq_cluster_compl r hvRoot
      apply hnotDisplay
      have htarget :
          T.edgeSplit (T.rootParent r v) v =
            s(A, Finset.univ \ A) := by
        simpa only [hcluster] using hsplit
      rw [← htarget]
      exact T.displays_edgeSplit hedge
  have hb₁Exists :
      ∃ b₁ : X, b₁ ∈ T.rootedCluster r v ∧ b₁ ∉ A := by
    have hnotSubsetBack : ¬T.rootedCluster r v ⊆ A := by
      intro hback
      exact hclusterNe (Finset.Subset.antisymm hback hAv)
    exact Finset.not_subset.mp hnotSubsetBack
  obtain ⟨b₁, hb₁Cluster, hb₁NotA⟩ := hb₁Exists
  have hb₁Ac : b₁ ∈ Finset.univ \ A :=
    Finset.mem_sdiff.mpr ⟨Finset.mem_univ b₁, hb₁NotA⟩
  have hminimal' : ∀ w : V, A ⊆ T.rootedCluster r w →
      (T.rootedCluster r v).card ≤ (T.rootedCluster r w).card := by
    intro w hAw
    apply hminimal w
    simp [candidates, hAw]
  obtain ⟨a₁, ha₁A, a₂, ha₂A, hvAPath⟩ :=
    T.exists_taxon_pair_path_through_of_minimal_rootedCluster
      r hA hAv hminimal'
  have hvBPath : v ∈ (T.taxonPath r b₁).support :=
    T.mem_vertexPath_root_label_of_mem_rootedCluster r hb₁Cluster
  let PA : Finset X := {a₁, a₂}
  let PB : Finset X := {r, b₁}
  have hPA : PA ⊆ A := by
    intro x hx
    simp only [PA, Finset.mem_insert, Finset.mem_singleton] at hx
    rcases hx with rfl | rfl
    · exact ha₁A
    · exact ha₂A
  have hPB : PB ⊆ Finset.univ \ A := by
    intro x hx
    simp only [PB, Finset.mem_insert, Finset.mem_singleton] at hx
    rcases hx with rfl | rfl
    · exact hrAc
    · exact hb₁Ac
  have hPAdisjPB : Disjoint PA PB := by
    rw [Finset.disjoint_left]
    intro x hxPA hxPB
    exact (Finset.mem_sdiff.mp (hPB hxPB)).2 (hPA hxPA)
  let P : PartialSplit X := s(PA, PB)
  have hPpartial : IsPartialQuartet P := by
    refine ⟨⟨PA, PB, rfl, ?_, ?_, hPAdisjPB⟩,
      ⟨PA, PB, rfl, ?_, ?_⟩⟩
    · exact ⟨a₁, by simp [PA]⟩
    · exact ⟨r, by simp [PB]⟩
    · by_cases h : a₁ = a₂
      · subst a₂
        simp [PA]
      · simp [PA, h]
    · by_cases h : r = b₁
      · subst b₁
        simp [PB]
      · simp [PB, h]
  have hcandidateDisplays : Displays s(A, Finset.univ \ A) P := by
    change Displays s(A, Finset.univ \ A) s(PA, PB)
    rw [displays_comm_representative]
    exact Or.inl ⟨hPA, hPB⟩
  rcases hall P hPpartial hcandidateDisplays with
    ⟨p, q, hpq, htreeDisplays⟩
  change Displays s(T.edgeSide p q, T.edgeSide q p) s(PA, PB) at htreeDisplays
  rw [displays_comm_representative] at htreeDisplays
  rcases htreeDisplays with hforward | hreverse
  · have ha₁Side : a₁ ∈ T.edgeSide p q := hforward.1 (by simp [PA])
    have ha₂Side : a₂ ∈ T.edgeSide p q := hforward.1 (by simp [PA])
    have hrSide : r ∈ T.edgeSide q p := hforward.2 (by simp [PB])
    have hb₁Side : b₁ ∈ T.edgeSide q p := hforward.2 (by simp [PB])
    have hvForward : v ∈ T.vertexSide p q :=
      T.mem_vertexSide_of_mem_taxonPath_support_same_side
        hpq ha₁Side ha₂Side hvAPath
    have hvReverse : v ∈ T.vertexSide q p :=
      T.mem_vertexSide_of_mem_taxonPath_support_same_side
        hpq.symm hrSide hb₁Side hvBPath
    exact (Set.disjoint_left.mp
      (T.vertexSide_disjoint_reverse_of_adj hpq)) hvForward hvReverse
  · have ha₁Side : a₁ ∈ T.edgeSide q p := hreverse.1 (by simp [PA])
    have ha₂Side : a₂ ∈ T.edgeSide q p := hreverse.1 (by simp [PA])
    have hrSide : r ∈ T.edgeSide p q := hreverse.2 (by simp [PB])
    have hb₁Side : b₁ ∈ T.edgeSide p q := hreverse.2 (by simp [PB])
    have hvReverse : v ∈ T.vertexSide q p :=
      T.mem_vertexSide_of_mem_taxonPath_support_same_side
        hpq.symm ha₁Side ha₂Side hvAPath
    have hvForward : v ∈ T.vertexSide p q :=
      T.mem_vertexSide_of_mem_taxonPath_support_same_side
        hpq hrSide hb₁Side hvBPath
    exact (Set.disjoint_left.mp
      (T.vertexSide_disjoint_reverse_of_adj hpq)) hvForward hvReverse

end XTree

/-- Equality of all displayed partial quartets forces every edge split of the
first tree to occur in the second tree.  Unlike the binary reconstruction
argument, this implication uses the support-two and support-three partial
quartets as well as the ordinary four-taxon quartets. -/
theorem edgeSplitSet_subset_of_same_partialQuartet_system
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hsame : SameDisplayedPartialQuartetSystem T₁ T₂) :
    T₁.edgeSplitSet ⊆ T₂.edgeSplitSet := by
  classical
  rintro P ⟨u, v, huv, rfl⟩
  let A : Finset X := T₁.edgeSide u v
  have hA : A.Nonempty := by
    simpa [A] using T₁.edgeSide_nonempty_of_adj huv
  have hAc : (Finset.univ \ A).Nonempty := by
    simpa [A, T₁.edgeSide_reverse_eq_sdiff_univ huv] using
      T₁.edgeSide_nonempty_of_adj huv.symm
  have htarget : s(A, Finset.univ \ A) = T₁.edgeSplit u v := by
    rw [XTree.edgeSplit]
    simp only [A, T₁.edgeSide_reverse_eq_sdiff_univ huv]
  have hall : ∀ R : PartialSplit X, IsPartialQuartet R →
      Displays s(A, Finset.univ \ A) R →
        T₂.DisplaysPartialSplit R := by
    intro R hR hdisplay
    apply (hsame R hR).1
    refine ⟨u, v, huv, ?_⟩
    rw [← htarget]
    exact hdisplay
  have hdisplayTarget :=
    T₂.displays_compl_split_of_all_partialQuartet_restrictions hA hAc hall
  rw [htarget] at hdisplayTarget
  rcases hdisplayTarget with ⟨p, q, hpq, hdisplay⟩
  have heq : T₂.edgeSplit p q = T₁.edgeSplit u v := by
    apply displays_mk_eq_of_disjoint_cover
      (T₂.edgeSide_disjoint_reverse_of_adj hpq)
      (T₁.edgeSide_disjoint_reverse_of_adj huv)
      (T₂.edgeSides_union_eq_univ hpq)
      (T₁.edgeSides_union_eq_univ huv)
    simpa only [XTree.edgeSplit] using hdisplay
  exact ⟨p, q, hpq, heq.symm⟩

/-- General vertex-labelled `X`-trees with the same complete partial-quartet
system have exactly the same represented full edge splits. -/
theorem edgeSplitSet_eq_of_same_partialQuartet_system
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hsame : SameDisplayedPartialQuartetSystem T₁ T₂) :
    T₁.edgeSplitSet = T₂.edgeSplitSet := by
  apply Set.Subset.antisymm
  · exact edgeSplitSet_subset_of_same_partialQuartet_system T₁ T₂ hsame
  · exact edgeSplitSet_subset_of_same_partialQuartet_system T₂ T₁
      (fun P hP => (hsame P hP).symm)

/-- The complete support-two, support-three, and support-four quartet system
reconstructs an arbitrary vertex-labelled `X`-tree up to a graph isomorphism
that fixes every named taxon. -/
noncomputable def labelPreservingXTreeIsoOfSamePartialQuartetSystem
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hsame : SameDisplayedPartialQuartetSystem T₁ T₂) :
    LabelPreservingXTreeIso T₁ T₂ :=
  labelPreservingXTreeIsoOfEdgeSplitSetEqGeneral T₁ T₂
    (Classical.choice T₁.taxon_nonempty)
    (edgeSplitSet_eq_of_same_partialQuartet_system T₁ T₂ hsame)

/-- Exact graph-theoretic form of the equality statement in Proposition 2.
Positive equality of the two normalized quartet indices is
equivalent to label-preserving tree isomorphism together with positive self
quartet covariance.  The positivity clause excludes the explicit colocated
four-taxon counterexample. -/
theorem positive_equal_quartet_indices_iff_labelPreservingIso_and_positive
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    (0 < quartetCorrelation T₁ T₂ ∧
        quartetCorrelation T₁ T₂ = quartetCompatibilityIndex T₁ T₂) ↔
      Nonempty (LabelPreservingXTreeIso T₁ T₂) ∧
        0 < treeQuartetCovariance T₁ T₁ := by
  constructor
  · intro h
    obtain ⟨hsame, hself⟩ :=
      (positive_equal_quartet_indices_iff_sameDisplayedSystem_and_positive
        T₁ T₂).1 h
    exact ⟨⟨labelPreservingXTreeIsoOfSamePartialQuartetSystem
      T₁ T₂ hsame⟩, hself⟩
  · rintro ⟨⟨F⟩, hself⟩
    have hsplit : T₁.edgeSplitSet = T₂.edgeSplitSet := F.edgeSplitSet_eq
    have hsame : SameDisplayedPartialQuartetSystem T₁ T₂ := by
      intro P _hP
      exact displaysPartialSplit_iff_of_edgeSplitSet_eq T₁ T₂ hsplit P
    exact
      (positive_equal_quartet_indices_iff_sameDisplayedSystem_and_positive
        T₁ T₂).2 ⟨hsame, hself⟩

/-- In the isomorphism case with positive self covariance, the common index is exactly
one, as asserted after Proposition 2. -/
theorem quartetCorrelation_eq_one_of_labelPreservingIso_and_positive
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hiso : Nonempty (LabelPreservingXTreeIso T₁ T₂))
    (hself : 0 < treeQuartetCovariance T₁ T₁) :
    quartetCorrelation T₁ T₂ = 1 := by
  have hequality :=
    (positive_equal_quartet_indices_iff_labelPreservingIso_and_positive
      T₁ T₂).2 ⟨hiso, hself⟩
  exact quartetCorrelation_eq_one_of_positive_equal_indices
    T₁ T₂ hequality.1 hequality.2

end QDFull
