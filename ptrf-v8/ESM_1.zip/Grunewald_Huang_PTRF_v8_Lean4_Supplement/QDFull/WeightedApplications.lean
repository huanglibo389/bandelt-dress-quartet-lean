import QDFull.EventCovariance
import QDFull.FiniteIndexSets
import QuartetV060.DistanceCovariance

/-!
# Edge-weighted trees and the exact distance-covariance bridge

This file formalizes the edge-weighted consequences following Proposition 2
and Theorem 3 in the manuscript.  An unoriented tree edge is represented
exactly once by `canonicalEdgeFinset`.  The definitions below therefore match
the paper's sums over `E(T)` without inserting an orientation multiplicity.
-/

open scoped BigOperators
open SimpleGraph

namespace QDFull

universe uX uV uV₁ uV₂

namespace XTree

variable {X : Type uX} {V : Type uV}
  [Fintype X] [Nonempty X]
  [Fintype V]

noncomputable local instance : DecidableEq X := Classical.decEq X

/-- The reverse side of an actual edge is the finite-set complement of the
chosen side.  This converts the two component notation used for `XTree` into
the one-side split notation used in Appendix B. -/
theorem edgeSide_reverse_eq_compl (T : XTree X V) {u v : V}
    (huv : T.graph.Adj u v) :
    T.edgeSide v u = (T.edgeSide u v)ᶜ := by
  classical
  ext x
  constructor
  · intro hx
    simp only [Finset.mem_compl]
    intro hx'
    exact (Finset.disjoint_left.mp
      (T.edgeSide_disjoint_reverse_of_adj huv)) hx' hx
  · intro hx
    simp only [Finset.mem_compl] at hx
    have hcover : x ∈ T.edgeSide u v ∨ x ∈ T.edgeSide v u := by
      have hset :
          x ∈ (T.edgeSide u v : Set X) ∪ (T.edgeSide v u : Set X) := by
        rw [T.edgeSide_set_union_reverse_of_adj huv]
        simp
      simpa only [Set.mem_union, Finset.mem_coe] using hset
    exact hcover.resolve_left hx

end XTree

/-- An edge-weighted `X`-tree.  Positivity is part of the paper's definition;
the length function is indexed by the canonical representative of each
unoriented edge. -/
structure EdgeWeightedXTree
    (X : Type uX) (V : Type uV)
    [Fintype X] [Fintype V] [LinearOrder V] where
  tree : XTree X V
  length : tree.canonicalEdgeFinset → ℝ
  length_pos : ∀ e, 0 < length e

namespace EdgeWeightedXTree

variable {X : Type uX} {V : Type uV}
  [Fintype X] [Nonempty X]
  [Fintype V] [LinearOrder V]

noncomputable local instance : DecidableEq X := Classical.decEq X

/-- The two endpoints carried by a canonical edge index are adjacent. -/
theorem canonicalEdge_adj (W : EdgeWeightedXTree X V)
    (e : W.tree.canonicalEdgeFinset) :
    W.tree.graph.Adj e.1.1 e.1.2 :=
  ((W.tree.mem_canonicalEdgeFinset e.1.1 e.1.2).1 e.2).1

/-- The chosen side of a canonically represented edge. -/
noncomputable def edgeSide (W : EdgeWeightedXTree X V)
    (e : W.tree.canonicalEdgeFinset) : Finset X :=
  W.tree.edgeSide e.1.1 e.1.2

/-- The edge split attached to a canonically represented edge. -/
noncomputable def edgeSplit (W : EdgeWeightedXTree X V)
    (e : W.tree.canonicalEdgeFinset) : PartialSplit X :=
  W.tree.edgeSplit e.1.1 e.1.2

/-- The length of a partial quartet is the sum of the lengths of precisely the
tree edges whose full splits display it. -/
noncomputable def partialQuartetLength (W : EdgeWeightedXTree X V)
    (P : PartialSplit X) : ℝ := by
  classical
  exact ∑ e, if Displays (W.edgeSplit e) P then W.length e else 0

/-- The weighted tree pseudometric, expressed as the sum of the split
pseudometrics of its unoriented edges. -/
noncomputable def treePseudometric (W : EdgeWeightedXTree X V) : X → X → ℝ :=
  QuartetV060.DistanceCovariance.weightedSplitPseudometric W.edgeSide W.length

private theorem displays_singletons_iff
    (W : EdgeWeightedXTree X V) (e : W.tree.canonicalEdgeFinset)
    (x y : X) :
    Displays (W.edgeSplit e) s({x}, {y}) ↔
      ((x ∈ W.edgeSide e ∧ y ∉ W.edgeSide e) ∨
        (x ∉ W.edgeSide e ∧ y ∈ W.edgeSide e)) := by
  classical
  let u := e.1.1
  let v := e.1.2
  have huv : W.tree.graph.Adj u v := W.canonicalEdge_adj e
  rw [edgeSplit, XTree.edgeSplit, displays_comm_representative]
  rw [W.tree.edgeSide_reverse_eq_compl huv]
  simp [edgeSide, u, v]

/-- Real-valued indicator that a canonical edge displays a given partial
split.  The definition hides the classical decidability choice from theorem
statements. -/
noncomputable def displayIndicator (W : EdgeWeightedXTree X V)
    (e : W.tree.canonicalEdgeFinset) (P : PartialSplit X) : ℝ := by
  classical
  exact if Displays (W.edgeSplit e) P then 1 else 0

/-- A one-edge split metric is exactly the indicator that the edge displays
the two-singleton partial quartet. -/
theorem splitPseudometric_eq_displayIndicator
    (W : EdgeWeightedXTree X V) (e : W.tree.canonicalEdgeFinset)
    (x y : X) :
    QuartetV060.DistanceCovariance.splitPseudometric (W.edgeSide e) x y =
      W.displayIndicator e s({x}, {y}) := by
  classical
  unfold displayIndicator
  rw [displays_singletons_iff]
  by_cases hx : x ∈ W.edgeSide e <;>
    by_cases hy : y ∈ W.edgeSide e <;>
      simp [QuartetV060.DistanceCovariance.splitPseudometric,
        QuartetV060.DistanceCovariance.sideIndicator, hx, hy]

/-- For distinct taxa, the paper's definition of the tree pseudometric as the
length of `xx|yy` is equal to the usual weighted path/split pseudometric.
The equality actually remains valid on the diagonal as well. -/
theorem treePseudometric_eq_partialQuartetLength
    (W : EdgeWeightedXTree X V) (x y : X) :
    W.treePseudometric x y = W.partialQuartetLength s({x}, {y}) := by
  classical
  unfold treePseudometric partialQuartetLength
  unfold QuartetV060.DistanceCovariance.weightedSplitPseudometric
  apply Finset.sum_congr rfl
  intro e _
  rw [W.splitPseudometric_eq_displayIndicator e x y]
  unfold displayIndicator
  by_cases h : Displays (W.edgeSplit e) s({x}, {y}) <;> simp [h]

/-- A single split pseudometric is nonnegative. -/
theorem splitPseudometric_nonneg (P : Finset X) (x y : X) :
    0 ≤ QuartetV060.DistanceCovariance.splitPseudometric P x y := by
  unfold QuartetV060.DistanceCovariance.splitPseudometric
  exact sq_nonneg _

/-- A single split pseudometric vanishes on the diagonal. -/
@[simp] theorem splitPseudometric_self (P : Finset X) (x : X) :
    QuartetV060.DistanceCovariance.splitPseudometric P x x = 0 := by
  unfold QuartetV060.DistanceCovariance.splitPseudometric
  ring

/-- A single split pseudometric is symmetric. -/
theorem splitPseudometric_symm (P : Finset X) (x y : X) :
    QuartetV060.DistanceCovariance.splitPseudometric P x y =
      QuartetV060.DistanceCovariance.splitPseudometric P y x := by
  unfold QuartetV060.DistanceCovariance.splitPseudometric
  ring

/-- The `0`-`1` split pseudometric satisfies the triangle inequality. -/
theorem splitPseudometric_triangle (P : Finset X) (x y z : X) :
    QuartetV060.DistanceCovariance.splitPseudometric P x z ≤
      QuartetV060.DistanceCovariance.splitPseudometric P x y +
        QuartetV060.DistanceCovariance.splitPseudometric P y z := by
  classical
  by_cases hx : x ∈ P <;> by_cases hy : y ∈ P <;> by_cases hz : z ∈ P <;>
    simp [QuartetV060.DistanceCovariance.splitPseudometric,
      QuartetV060.DistanceCovariance.sideIndicator, hx, hy, hz]

/-- The induced weighted tree function is nonnegative. -/
theorem treePseudometric_nonneg (W : EdgeWeightedXTree X V) (x y : X) :
    0 ≤ W.treePseudometric x y := by
  unfold treePseudometric QuartetV060.DistanceCovariance.weightedSplitPseudometric
  apply Finset.sum_nonneg
  intro e _
  exact mul_nonneg (le_of_lt (W.length_pos e))
    (splitPseudometric_nonneg (W.edgeSide e) x y)

/-- The induced weighted tree function vanishes on the diagonal. -/
@[simp] theorem treePseudometric_self (W : EdgeWeightedXTree X V) (x : X) :
    W.treePseudometric x x = 0 := by
  unfold treePseudometric QuartetV060.DistanceCovariance.weightedSplitPseudometric
  simp

/-- The induced weighted tree function is symmetric. -/
theorem treePseudometric_symm (W : EdgeWeightedXTree X V) (x y : X) :
    W.treePseudometric x y = W.treePseudometric y x := by
  unfold treePseudometric QuartetV060.DistanceCovariance.weightedSplitPseudometric
  apply Finset.sum_congr rfl
  intro e _
  rw [splitPseudometric_symm (W.edgeSide e) x y]

/-- The induced weighted tree function satisfies the triangle inequality, so
the function called a pseudometric in the paper has all four pseudometric
properties. -/
theorem treePseudometric_triangle (W : EdgeWeightedXTree X V) (x y z : X) :
    W.treePseudometric x z ≤ W.treePseudometric x y + W.treePseudometric y z := by
  unfold treePseudometric QuartetV060.DistanceCovariance.weightedSplitPseudometric
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_le_sum
  intro e _
  simpa only [mul_add] using mul_le_mul_of_nonneg_left
    (splitPseudometric_triangle (W.edgeSide e) x y z)
    (le_of_lt (W.length_pos e))

end EdgeWeightedXTree

namespace WeightedApplications

open EdgeWeightedXTree
open QuartetV060
open QuartetV060.DistanceCovariance

variable {X : Type uX} [Fintype X] [Nonempty X]
variable {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype V₁] [LinearOrder V₁]
  [Fintype V₂] [LinearOrder V₂]

noncomputable local instance : DecidableEq X := Classical.decEq X

/-- Appendix B's normalized split-table determinant agrees exactly with the
paper's oriented edge coefficient on canonical edge representatives. -/
theorem splitIntersectionTable_det_eq_xCoefficient
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂)
    (e : W₁.tree.canonicalEdgeFinset)
    (f : W₂.tree.canonicalEdgeFinset) :
    Table2.det (splitIntersectionTable (W₁.edgeSide e) (W₂.edgeSide f)) =
      xCoefficient W₁.tree W₂.tree e.1.1 e.1.2 f.1.1 f.1.2 := by
  classical
  have he := W₁.canonicalEdge_adj e
  have hf := W₂.canonicalEdge_adj f
  rw [xCoefficient_eq_edge_determinant W₁.tree W₂.tree he hf]
  rw [W₁.tree.edgeSide_reverse_eq_compl he,
    W₂.tree.edgeSide_reverse_eq_compl hf]
  unfold Table2.det
  rw [splitIntersectionTable_a_eq, splitIntersectionTable_b_eq,
    splitIntersectionTable_c_eq, splitIntersectionTable_d_eq]
  unfold orientedSplitDeterminant
  simp only [EdgeWeightedXTree.edgeSide]
  let P : Finset X := W₁.edgeSide e
  let Q : Finset X := W₂.edgeSide f
  change normalizedCard (P ∩ Q) * normalizedCard (Pᶜ ∩ Qᶜ) -
      normalizedCard (P ∩ Qᶜ) * normalizedCard (Pᶜ ∩ Q) =
    normalizedCard (Pᶜ ∩ Qᶜ) * normalizedCard (P ∩ Q) -
      normalizedCard (Pᶜ ∩ Q) * normalizedCard (P ∩ Qᶜ)
  ring

/-- Squared form of the exact table/edge-coefficient bridge. -/
theorem splitIntersectionTable_detSquare_eq_xCoefficient_sq
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂)
    (e : W₁.tree.canonicalEdgeFinset)
    (f : W₂.tree.canonicalEdgeFinset) :
    Table2.detSquare
        (splitIntersectionTable (W₁.edgeSide e) (W₂.edgeSide f)) =
      xCoefficient W₁.tree W₂.tree e.1.1 e.1.2 f.1.1 f.1.2 ^ 2 := by
  unfold Table2.detSquare
  rw [splitIntersectionTable_det_eq_xCoefficient W₁ W₂ e f]

/-- The common weighted determinant-square sum underlying both definitions of
distance covariance. -/
noncomputable def weightedDetSquareSum
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂) : ℝ :=
  ∑ e, ∑ f, W₁.length e * W₂.length f *
    xCoefficient W₁.tree W₂.tree e.1.1 e.1.2 f.1.1 f.1.2 ^ 2

/-- The paper's edge-weighted tree distance covariance, with every unoriented
edge counted exactly once. -/
noncomputable def treeDistanceCovariance
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂) : ℝ :=
  ∑ e, ∑ f, splitQuartetCovarianceEvent
      (W₁.edgeSplit e) (W₂.edgeSplit f) * W₁.length e * W₂.length f

/-- Every weighted edge-pair contribution is six times its normalized
determinant square. -/
theorem treeDistanceCovariance_eq_six_weightedDetSquareSum
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂) :
    treeDistanceCovariance W₁ W₂ = 6 * weightedDetSquareSum W₁ W₂ := by
  unfold treeDistanceCovariance weightedDetSquareSum
  simp_rw [edgeSplit, edgeSplit_quartetCovarianceEvent_eq W₁.tree W₂.tree
    (W₁.canonicalEdge_adj _) (W₂.canonicalEdge_adj _)]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro e _
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro f _
  ring

/-- The empirical distance covariance of the two induced tree pseudometrics. -/
noncomputable def empiricalTreeDistanceCovariance
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂) : ℝ :=
  splitSystemDistanceCovariance W₁.edgeSide W₁.length W₂.edgeSide W₂.length

/-- The split-system expression is definitionally the empirical distance
covariance of the two induced tree pseudometrics. -/
theorem empiricalTreeDistanceCovariance_eq_pseudometricDefinition
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂) :
    empiricalTreeDistanceCovariance W₁ W₂ =
      empiricalDistanceCovariance W₁.treePseudometric W₂.treePseudometric := by
  rfl

/-- Appendix B gives four times the same weighted determinant-square sum. -/
theorem empiricalTreeDistanceCovariance_eq_four_weightedDetSquareSum
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂) :
    empiricalTreeDistanceCovariance W₁ W₂ =
      4 * weightedDetSquareSum W₁ W₂ := by
  unfold empiricalTreeDistanceCovariance
  rw [splitSystemDistanceCovariance_eq_detSquare]
  unfold weightedDetSquareSum
  simp_rw [splitIntersectionTable_detSquare_eq_xCoefficient_sq W₁ W₂]

/-- The empirical distance covariance of two individual split metrics is four
times the corresponding normalized determinant square. -/
theorem empiricalDistanceCovariance_splitPseudometric_eq_four_detSquare
    (P Q : Finset X) :
    empiricalDistanceCovariance (splitPseudometric P) (splitPseudometric Q) =
      4 * Table2.detSquare (splitIntersectionTable P Q) := by
  unfold empiricalDistanceCovariance
  simp_rw [doubleCentered_splitPseudometric]
  let z : X → ℝ := fun x => centeredIndicator P x * centeredIndicator Q x
  have hkernel :
      (fun i => empiricalMean (fun j =>
        (-2 * centeredIndicator P i * centeredIndicator P j) *
          (-2 * centeredIndicator Q i * centeredIndicator Q j))) =
        (fun i => empiricalMean (fun j => 4 * z i * z j)) := by
    funext i
    apply congrArg empiricalMean
    funext j
    simp only [z]
    ring
  rw [hkernel, empiricalMean_weighted_rankOne]
  rw [show empiricalMean z = Table2.det (splitIntersectionTable P Q) by
    simpa only [z] using centeredIndicator_product_mean_eq_det P Q]
  unfold Table2.detSquare
  rfl

/-- Exact finite bilinearity used in the proof of Theorem 3.  Both weighted
split sums are expanded, and no cross term is suppressed. -/
theorem splitSystemDistanceCovariance_bilinear
    {E F : Type*} [Fintype E] [Fintype F]
    (P : E → Finset X) (w : E → ℝ)
    (Q : F → Finset X) (v : F → ℝ) :
    splitSystemDistanceCovariance P w Q v =
      ∑ e, ∑ f, w e * v f *
        empiricalDistanceCovariance
          (splitPseudometric (P e)) (splitPseudometric (Q f)) := by
  rw [splitSystemDistanceCovariance_eq_detSquare]
  simp_rw [empiricalDistanceCovariance_splitPseudometric_eq_four_detSquare]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro e _
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro f _
  ring

/-- The paper's bilinear reduction specialized to the edge splits of two
weighted trees. -/
theorem empiricalTreeDistanceCovariance_bilinear
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂) :
    empiricalTreeDistanceCovariance W₁ W₂ =
      ∑ e, ∑ f, W₁.length e * W₂.length f *
        empiricalDistanceCovariance
          (splitPseudometric (W₁.edgeSide e))
          (splitPseudometric (W₂.edgeSide f)) := by
  unfold empiricalTreeDistanceCovariance
  exact splitSystemDistanceCovariance_bilinear
    W₁.edgeSide W₁.length W₂.edgeSide W₂.length

/-- Every summand in the common weighted determinant-square sum is
nonnegative because the edge lengths are positive. -/
theorem weightedDetSquareSum_nonneg
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂) :
    0 ≤ weightedDetSquareSum W₁ W₂ := by
  unfold weightedDetSquareSum
  apply Finset.sum_nonneg
  intro e _
  apply Finset.sum_nonneg
  intro f _
  exact mul_nonneg
    (mul_nonneg (le_of_lt (W₁.length_pos e)) (le_of_lt (W₂.length_pos f)))
    (sq_nonneg _)

/-- The weighted determinant-square sum vanishes exactly when every canonical
edge-pair coefficient vanishes. -/
theorem weightedDetSquareSum_eq_zero_iff
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂) :
    weightedDetSquareSum W₁ W₂ = 0 ↔
      ∀ (e : W₁.tree.canonicalEdgeFinset)
        (f : W₂.tree.canonicalEdgeFinset), xCoefficient W₁.tree W₂.tree
        e.1.1 e.1.2 f.1.1 f.1.2 = 0 := by
  constructor
  · intro hsum e f
    unfold weightedDetSquareSum at hsum
    have houter_nonneg : ∀ e ∈ (Finset.univ : Finset W₁.tree.canonicalEdgeFinset),
        0 ≤ ∑ f, W₁.length e * W₂.length f *
          xCoefficient W₁.tree W₂.tree
            e.1.1 e.1.2 f.1.1 f.1.2 ^ 2 := by
      intro e _
      apply Finset.sum_nonneg
      intro f _
      exact mul_nonneg
        (mul_nonneg (le_of_lt (W₁.length_pos e)) (le_of_lt (W₂.length_pos f)))
        (sq_nonneg _)
    have heq := (Finset.sum_eq_zero_iff_of_nonneg houter_nonneg).1
      hsum e (Finset.mem_univ e)
    have hinner_nonneg : ∀ f ∈ (Finset.univ : Finset W₂.tree.canonicalEdgeFinset),
        0 ≤ W₁.length e * W₂.length f *
          xCoefficient W₁.tree W₂.tree
            e.1.1 e.1.2 f.1.1 f.1.2 ^ 2 := by
      intro f _
      exact mul_nonneg
        (mul_nonneg (le_of_lt (W₁.length_pos e)) (le_of_lt (W₂.length_pos f)))
        (sq_nonneg _)
    have hterm := (Finset.sum_eq_zero_iff_of_nonneg hinner_nonneg).1
      heq f (Finset.mem_univ f)
    have hweight : W₁.length e * W₂.length f ≠ 0 :=
      ne_of_gt (mul_pos (W₁.length_pos e) (W₂.length_pos f))
    have hsquare : xCoefficient W₁.tree W₂.tree
        e.1.1 e.1.2 f.1.1 f.1.2 ^ 2 = 0 :=
      (mul_eq_zero.mp hterm).resolve_left hweight
    exact (sq_eq_zero_iff).mp hsquare
  · intro h
    unfold weightedDetSquareSum
    simp_rw [h]
    simp

/-- Vanishing on canonical representatives is equivalent to the paper's
orientation-free independence condition on all directed edge pairs. -/
theorem canonical_xCoefficient_zero_iff_treesIndependent
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂) :
    (∀ (e : W₁.tree.canonicalEdgeFinset)
      (f : W₂.tree.canonicalEdgeFinset), xCoefficient W₁.tree W₂.tree
      e.1.1 e.1.2 f.1.1 f.1.2 = 0) ↔
      TreesIndependent W₁.tree W₂.tree := by
  constructor
  · intro hcanon
    rw [treesIndependent_iff_xCoefficient_eq_zero]
    intro t u v w htu hvw
    have htu' : (t, u) ∈ W₁.tree.directedEdgeFinset :=
      (W₁.tree.mem_directedEdgeFinset t u).2 htu
    have hvw' : (v, w) ∈ W₂.tree.directedEdgeFinset :=
      (W₂.tree.mem_directedEdgeFinset v w).2 hvw
    rcases W₁.tree.mem_canonical_or_reverse_of_mem_directedEdge htu' with
      htuC | hutC <;>
    rcases W₂.tree.mem_canonical_or_reverse_of_mem_directedEdge hvw' with
      hvwC | hwvC
    · exact hcanon ⟨(t, u), htuC⟩ ⟨(v, w), hvwC⟩
    · have hz := hcanon ⟨(t, u), htuC⟩ ⟨(w, v), hwvC⟩
      rw [xCoefficient_reverse_column W₁.tree W₂.tree t u w v]
      simp [hz]
    · have hz := hcanon ⟨(u, t), hutC⟩ ⟨(v, w), hvwC⟩
      rw [xCoefficient_reverse_row W₁.tree W₂.tree u t v w]
      simp [hz]
    · have hz := hcanon ⟨(u, t), hutC⟩ ⟨(w, v), hwvC⟩
      rw [xCoefficient_reverse_both W₁.tree W₂.tree u t w v]
      exact hz
  · intro hind e f
    exact (treesIndependent_iff_xCoefficient_eq_zero W₁.tree W₂.tree).1 hind
      e.1.1 e.1.2 f.1.1 f.1.2
      (W₁.canonicalEdge_adj e) (W₂.canonicalEdge_adj f)

/-- The edge-weighted tree distance covariance is nonnegative. -/
theorem treeDistanceCovariance_nonneg
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂) :
    0 ≤ treeDistanceCovariance W₁ W₂ := by
  rw [treeDistanceCovariance_eq_six_weightedDetSquareSum]
  exact mul_nonneg (by norm_num) (weightedDetSquareSum_nonneg W₁ W₂)

/-- The paper's zero characterization for positive edge lengths: weighted tree
distance covariance vanishes exactly for independent underlying `X`-trees. -/
theorem treeDistanceCovariance_eq_zero_iff_treesIndependent
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂) :
    treeDistanceCovariance W₁ W₂ = 0 ↔
      TreesIndependent W₁.tree W₂.tree := by
  rw [treeDistanceCovariance_eq_six_weightedDetSquareSum]
  constructor
  · intro h
    have hsum : weightedDetSquareSum W₁ W₂ = 0 := by nlinarith
    exact (canonical_xCoefficient_zero_iff_treesIndependent W₁ W₂).1
      ((weightedDetSquareSum_eq_zero_iff W₁ W₂).1 hsum)
  · intro h
    have hcanon :=
      (canonical_xCoefficient_zero_iff_treesIndependent W₁ W₂).2 h
    rw [(weightedDetSquareSum_eq_zero_iff W₁ W₂).2 hcanon]
    norm_num

/-- Distance correlation of two edge-weighted trees, exactly as defined in the
paper. -/
noncomputable def treeDistanceCorrelation
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂) : ℝ :=
  treeDistanceCovariance W₁ W₂ /
    Real.sqrt (treeDistanceCovariance W₁ W₁ *
      treeDistanceCovariance W₂ W₂)

/-- Theorem 3 of the paper: tree distance covariance is exactly `3/2` times
the empirical distance covariance of the induced tree pseudometrics. -/
theorem treeDistanceCovariance_eq_threeHalves_empirical
    (W₁ : EdgeWeightedXTree X V₁) (W₂ : EdgeWeightedXTree X V₂) :
    treeDistanceCovariance W₁ W₂ =
      (3 / 2 : ℝ) * empiricalTreeDistanceCovariance W₁ W₂ := by
  rw [treeDistanceCovariance_eq_six_weightedDetSquareSum,
    empiricalTreeDistanceCovariance_eq_four_weightedDetSquareSum]
  ring

end WeightedApplications

end QDFull
