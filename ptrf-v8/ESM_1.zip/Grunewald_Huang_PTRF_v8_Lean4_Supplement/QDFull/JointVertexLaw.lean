import QDFull.EventCovariance
import QDFull.MassPartitionIdentities
import QDFull.PathPathCovariance

/-!
# The joint law of the two labelled vertices

This file formalizes the paragraph immediately preceding the paper's
discussion of Bergsma--Dassios `tau-star`.  A uniformly sampled taxon `x`
induces the pair of vertices `(T₁.label x, T₂.label x)`.  We prove, in both
directions and without a measure-theoretic shortcut, that independence of
this finite joint law is equivalent to the paper's edge-split definition of
independence of the two trees.
-/

open scoped BigOperators

namespace QDFull

universe uX uV uV₁ uV₂

namespace XTree

variable {X : Type uX} {V : Type uV} [Fintype X] [Fintype V]

noncomputable local instance jointVertexLawDecidableEqXTree : DecidableEq X :=
  Classical.decEq X

/-- Taxa whose labelled vertex belongs to `S`. -/
noncomputable def labelPreimage (T : XTree X V) (S : Finset V) : Finset X := by
  classical
  exact Finset.univ.filter fun x => T.label x ∈ S

@[simp] theorem mem_labelPreimage (T : XTree X V) (S : Finset V) (x : X) :
    x ∈ T.labelPreimage S ↔ T.label x ∈ S := by
  classical
  simp [labelPreimage]

@[simp] theorem labelPreimage_singleton (T : XTree X V) (v : V) :
    T.labelPreimage {v} = T.labelFiber v := by
  classical
  ext x
  simp

/-- Distinct vertex fibres are disjoint, whether or not the labelling map is
injective. -/
theorem labelFiber_disjoint (T : XTree X V) {v w : V} (hvw : v ≠ w) :
    Disjoint (T.labelFiber v) (T.labelFiber w) := by
  classical
  rw [Finset.disjoint_left]
  intro x hxv hxw
  exact hvw ((T.mem_labelFiber v x).mp hxv |>.symm.trans
    ((T.mem_labelFiber w x).mp hxw))

/-- The fibres indexed by a finite vertex set form a pairwise-disjoint
family. -/
theorem labelFibers_pairwiseDisjoint (T : XTree X V) (S : Finset V) :
    ((S : Finset V) : Set V).PairwiseDisjoint T.labelFiber := by
  intro v _hv w _hw hvw
  exact T.labelFiber_disjoint hvw

/-- The preimage of a vertex set is exactly the disjoint union of its vertex
fibres. -/
theorem biUnion_labelFiber_eq_labelPreimage (T : XTree X V) (S : Finset V) :
    S.biUnion T.labelFiber = T.labelPreimage S := by
  classical
  ext x
  simp [T.mem_labelPreimage]

/-- Summing normalized fibre sizes over a vertex set gives the normalized
size of its label preimage. -/
theorem sum_normalizedCard_labelFiber (T : XTree X V) (S : Finset V) :
    ∑ v ∈ S, normalizedCard (T.labelFiber v) =
      normalizedCard (T.labelPreimage S) := by
  classical
  unfold normalizedCard
  rw [← Finset.sum_div]
  congr 1
  norm_cast
  calc
    ∑ v ∈ S, (T.labelFiber v).card =
        (S.biUnion T.labelFiber).card :=
      (Finset.card_biUnion (T.labelFibers_pairwiseDisjoint S)).symm
    _ = (T.labelPreimage S).card := by
      rw [T.biUnion_labelFiber_eq_labelPreimage]

/-- A restricted fibre partition: intersecting a fixed taxon set with all
fibres indexed by `S` gives the intersection with the whole preimage. -/
theorem sum_normalizedCard_inter_labelFiber
    (T : XTree X V) (S : Finset V) (A : Finset X) :
    ∑ v ∈ S, normalizedCard (A ∩ T.labelFiber v) =
      normalizedCard (A ∩ T.labelPreimage S) := by
  classical
  unfold normalizedCard
  rw [← Finset.sum_div]
  congr 1
  norm_cast
  have hpair :
      ((S : Finset V) : Set V).PairwiseDisjoint
        (fun v => A ∩ T.labelFiber v) := by
    intro v _hv w _hw hvw
    exact Finset.disjoint_left.mpr (by
      intro x hxv hxw
      exact (Finset.disjoint_left.mp (T.labelFiber_disjoint hvw))
        (Finset.mem_inter.mp hxv).2 (Finset.mem_inter.mp hxw).2)
  calc
    ∑ v ∈ S, (A ∩ T.labelFiber v).card =
        (S.biUnion fun v => A ∩ T.labelFiber v).card :=
      (Finset.card_biUnion hpair).symm
    _ = (A ∩ T.labelPreimage S).card := by
      congr 1
      ext x
      simp [T.mem_labelPreimage, and_comm]

/-- A finite representation of the graph component `V^u(v)`. -/
noncomputable def vertexSideFinset (T : XTree X V) (u v : V) : Finset V := by
  classical
  exact Finset.univ.filter fun z => z ∈ T.vertexSide u v

@[simp] theorem mem_vertexSideFinset (T : XTree X V) (u v z : V) :
    z ∈ T.vertexSideFinset u v ↔ z ∈ T.vertexSide u v := by
  classical
  simp [vertexSideFinset]

/-- An edge side is the label preimage of its graph-theoretic vertex
component. -/
theorem edgeSide_eq_labelPreimage_vertexSideFinset
    (T : XTree X V) (u v : V) :
    T.edgeSide u v = T.labelPreimage (T.vertexSideFinset u v) := by
  classical
  ext x
  simp [T.mem_edgeSide, XTree.vertexSide]

end XTree

section JointLaw

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]

noncomputable local instance jointVertexLawDecidableEqX : DecidableEq X :=
  Classical.decEq X

/-- The marginal mass of a labelled vertex under the uniform law on taxa. -/
noncomputable def vertexMarginalMass
    (T : XTree X V₁) (v : V₁) : ℝ :=
  normalizedCard (T.labelFiber v)

/-- The joint mass printed in the paper:
`|phi₁⁻¹(v₁) ∩ phi₂⁻¹(v₂)| / |X|`. -/
noncomputable def vertexJointMass
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (v₁ : V₁) (v₂ : V₂) : ℝ :=
  normalizedCard (T₁.labelFiber v₁ ∩ T₂.labelFiber v₂)

theorem vertexJointMass_eq_printed_cardinality
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (v₁ : V₁) (v₂ : V₂) :
    vertexJointMass T₁ T₂ v₁ v₂ =
      ((T₁.labelFiber v₁ ∩ T₂.labelFiber v₂).card : ℝ) /
        (Fintype.card X : ℝ) := by
  rfl

/-- Independence of the two discrete random vertices induced by a uniformly
sampled taxon. -/
def VertexVariablesIndependent
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : Prop :=
  ∀ v₁ v₂,
    vertexJointMass T₁ T₂ v₁ v₂ =
      vertexMarginalMass T₁ v₁ * vertexMarginalMass T₂ v₂

/-- The joint mass of two vertex subsets is the double sum of their atomic
joint masses. -/
theorem normalizedCard_labelPreimage_inter_eq_sum_vertexJointMass
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (A : Finset V₁) (B : Finset V₂) :
    normalizedCard (T₁.labelPreimage A ∩ T₂.labelPreimage B) =
      ∑ v₁ ∈ A, ∑ v₂ ∈ B, vertexJointMass T₁ T₂ v₁ v₂ := by
  classical
  calc
    normalizedCard (T₁.labelPreimage A ∩ T₂.labelPreimage B) =
        ∑ v₁ ∈ A,
          normalizedCard (T₂.labelPreimage B ∩ T₁.labelFiber v₁) := by
      rw [Finset.inter_comm]
      exact (T₁.sum_normalizedCard_inter_labelFiber A
        (T₂.labelPreimage B)).symm
    _ = ∑ v₁ ∈ A, ∑ v₂ ∈ B,
          normalizedCard (T₁.labelFiber v₁ ∩ T₂.labelFiber v₂) := by
      apply Finset.sum_congr rfl
      intro v₁ hv₁
      rw [Finset.inter_comm]
      exact (T₂.sum_normalizedCard_inter_labelFiber B
        (T₁.labelFiber v₁)).symm
    _ = ∑ v₁ ∈ A, ∑ v₂ ∈ B,
          vertexJointMass T₁ T₂ v₁ v₂ := by
      rfl

/-- Atomic vertex independence implies factorization for arbitrary finite
sets of vertices. -/
theorem normalizedCard_labelPreimage_inter_eq_mul_of_independent
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (h : VertexVariablesIndependent T₁ T₂)
    (A : Finset V₁) (B : Finset V₂) :
    normalizedCard (T₁.labelPreimage A ∩ T₂.labelPreimage B) =
      normalizedCard (T₁.labelPreimage A) *
        normalizedCard (T₂.labelPreimage B) := by
  classical
  rw [normalizedCard_labelPreimage_inter_eq_sum_vertexJointMass]
  calc
    ∑ v₁ ∈ A, ∑ v₂ ∈ B, vertexJointMass T₁ T₂ v₁ v₂ =
        ∑ v₁ ∈ A, ∑ v₂ ∈ B,
          vertexMarginalMass T₁ v₁ * vertexMarginalMass T₂ v₂ := by
      apply Finset.sum_congr rfl
      intro v₁ _hv₁
      apply Finset.sum_congr rfl
      intro v₂ _hv₂
      exact h v₁ v₂
    _ = (∑ v₁ ∈ A, vertexMarginalMass T₁ v₁) *
          (∑ v₂ ∈ B, vertexMarginalMass T₂ v₂) := by
      rw [Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro v₁ _hv₁
      rw [Finset.mul_sum]
    _ = normalizedCard (T₁.labelPreimage A) *
          normalizedCard (T₂.labelPreimage B) := by
      rw [← T₁.sum_normalizedCard_labelFiber A,
        ← T₂.sum_normalizedCard_labelFiber B]
      rfl

/-- If every vertex atom factors, every pair of edge-side events factors. -/
theorem xCoefficient_eq_zero_of_vertexVariablesIndependent
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (h : VertexVariablesIndependent T₁ T₂)
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w) :
    xCoefficient T₁ T₂ t u v w = 0 := by
  rw [xCoefficient_eq_centered_jointMass T₁ T₂ htu hvw]
  have hfactor :=
    normalizedCard_labelPreimage_inter_eq_mul_of_independent T₁ T₂ h
      (T₁.vertexSideFinset u t) (T₂.vertexSideFinset w v)
  unfold jointMass jointBlock XTree.rowMass XTree.columnMass
  rw [T₁.rowBlock_of_adj t htu.symm,
    T₂.columnBlock_of_adj v hvw.symm]
  simpa [T₁.edgeSide_eq_labelPreimage_vertexSideFinset,
    T₂.edgeSide_eq_labelPreimage_vertexSideFinset] using sub_eq_zero.mpr hfactor

/-- Vertex-variable independence implies the paper's tree independence. -/
theorem treesIndependent_of_vertexVariablesIndependent
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (h : VertexVariablesIndependent T₁ T₂) :
    TreesIndependent T₁ T₂ := by
  rw [treesIndependent_iff_xCoefficient_eq_zero]
  intro t u v w htu hvw
  exact xCoefficient_eq_zero_of_vertexVariablesIndependent T₁ T₂ h htu hvw

/-- Elementary completion of a finite probability table: if every cell away
from one distinguished row and one distinguished column factors, and the
specified row and column sums are the given marginals, then every cell
factors. -/
private theorem missing_factor_of_sum
    {I : Type*} [DecidableEq I]
    (S : Finset I) (i₀ : I) (hi₀ : i₀ ∈ S)
    (f g : I → ℝ) (r : ℝ)
    (hf : ∑ i ∈ S, f i = r)
    (hg : ∑ i ∈ S, g i = 1)
    (hfactor : ∀ i ∈ S.erase i₀, f i = r * g i) :
    f i₀ = r * g i₀ := by
  have hfErase :
      (∑ i ∈ S.erase i₀, f i) + f i₀ = r := by
    rw [Finset.sum_erase_add S f hi₀, hf]
  have hgErase :
      (∑ i ∈ S.erase i₀, g i) + g i₀ = 1 := by
    rw [Finset.sum_erase_add S g hi₀, hg]
  have hsumFactor :
      ∑ i ∈ S.erase i₀, f i =
        r * ∑ i ∈ S.erase i₀, g i := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i hi
    exact hfactor i hi
  rw [hsumFactor] at hfErase
  have hmul := congrArg (fun x : ℝ => r * x) hgErase
  rw [mul_add, mul_one] at hmul
  linarith

private theorem table_factorization_of_off_centre
    {I J : Type*} [DecidableEq I] [DecidableEq J]
    (SI : Finset I) (SJ : Finset J)
    (i₀ : I) (j₀ : J) (hi₀ : i₀ ∈ SI) (hj₀ : j₀ ∈ SJ)
    (a : I → J → ℝ) (r : I → ℝ) (c : J → ℝ)
    (hrow : ∀ i ∈ SI, ∑ j ∈ SJ, a i j = r i)
    (hcol : ∀ j ∈ SJ, ∑ i ∈ SI, a i j = c j)
    (hsumr : ∑ i ∈ SI, r i = 1)
    (hsumc : ∑ j ∈ SJ, c j = 1)
    (hoff : ∀ i ∈ SI, i ≠ i₀ →
      ∀ j ∈ SJ, j ≠ j₀ → a i j = r i * c j) :
    ∀ i ∈ SI, ∀ j ∈ SJ, a i j = r i * c j := by
  intro i hi j hj
  by_cases hii : i = i₀
  · subst i
    by_cases hjj : j = j₀
    · subst j
      apply missing_factor_of_sum SJ j₀ hj₀ (a i₀) c (r i₀)
        (hrow i₀ hi₀) hsumc
      intro j hjErase
      have hjMem : j ∈ SJ := Finset.mem_of_mem_erase hjErase
      have hjNe : j ≠ j₀ := Finset.ne_of_mem_erase hjErase
      have hcolFactor :=
        missing_factor_of_sum SI i₀ hi₀ (fun i => a i j) r (c j)
          (hcol j hjMem) hsumr (by
            intro i hiErase
            have hiMem : i ∈ SI := Finset.mem_of_mem_erase hiErase
            have hiNe : i ≠ i₀ := Finset.ne_of_mem_erase hiErase
            simpa [mul_comm] using hoff i hiMem hiNe j hjMem hjNe)
      simpa [mul_comm] using hcolFactor
    · have hcolFactor :=
        missing_factor_of_sum SI i₀ hi₀ (fun i => a i j) r (c j)
          (hcol j hj) hsumr (by
            intro i hiErase
            have hiMem : i ∈ SI := Finset.mem_of_mem_erase hiErase
            have hiNe : i ≠ i₀ := Finset.ne_of_mem_erase hiErase
            simpa [mul_comm] using hoff i hiMem hiNe j hj hjj)
      simpa [mul_comm] using hcolFactor
  · by_cases hjj : j = j₀
    · subst j
      exact missing_factor_of_sum SJ j₀ hj₀ (a i) c (r i)
        (hrow i hi) hsumc (by
          intro j hjErase
          exact hoff i hi hii j (Finset.mem_of_mem_erase hjErase)
            (Finset.ne_of_mem_erase hjErase))
    · exact hoff i hi hii j hj hjj

/-- Joint mass of two cells in the branch partitions centred at `u,w`. -/
private noncomputable def branchJointMass
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (u : V₁) (w : V₂) (z : V₁) (l : V₂) : ℝ :=
  normalizedCard (T₁.branchBlock u z ∩ T₂.branchBlock w l)

/-- Marginal mass of one branch-partition cell. -/
private noncomputable def branchMass
    (T : XTree X V₁) (u z : V₁) : ℝ :=
  normalizedCard (T.branchBlock u z)

private theorem sum_branchJointMass_column
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (u : V₁) (w : V₂) (z : V₁) :
    ∑ l ∈ T₂.branchIndices w, branchJointMass T₁ T₂ u w z l =
      branchMass T₁ u z := by
  classical
  simpa [branchJointMass, branchMass] using
    T₂.sum_normalizedCard_inter_allBranches w (T₁.branchBlock u z)

private theorem sum_branchJointMass_row
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (u : V₁) (w : V₂) (l : V₂) :
    ∑ z ∈ T₁.branchIndices u, branchJointMass T₁ T₂ u w z l =
      branchMass T₂ w l := by
  classical
  simpa [branchJointMass, branchMass, Finset.inter_comm] using
    T₁.sum_normalizedCard_inter_allBranches u (T₂.branchBlock w l)

private theorem sum_branchMass
    (T : XTree X V₁) (u : V₁) :
    ∑ z ∈ T.branchIndices u, branchMass T u z = 1 := by
  classical
  simpa [branchMass] using T.sum_normalizedCard_branchBlock u

/-- Edge-split independence forces every cell of every centred branch table,
including the two centre-label cells not themselves represented by directed
edges, to factor into its row and column marginals. -/
private theorem branchJointMass_eq_mul_of_treesIndependent
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (h : TreesIndependent T₁ T₂)
    (u : V₁) (w : V₂) :
    ∀ z ∈ T₁.branchIndices u, ∀ l ∈ T₂.branchIndices w,
      branchJointMass T₁ T₂ u w z l =
        branchMass T₁ u z * branchMass T₂ w l := by
  classical
  have hu : u ∈ T₁.branchIndices u := by
    simp [XTree.mem_neighborsPlus]
  have hw : w ∈ T₂.branchIndices w := by
    simp [XTree.mem_neighborsPlus]
  apply table_factorization_of_off_centre
    (T₁.branchIndices u) (T₂.branchIndices w) u w hu hw
    (branchJointMass T₁ T₂ u w) (branchMass T₁ u) (branchMass T₂ w)
  · intro z hz
    exact sum_branchJointMass_column T₁ T₂ u w z
  · intro l hl
    exact sum_branchJointMass_row T₁ T₂ u w l
  · exact sum_branchMass T₁ u
  · exact sum_branchMass T₂ w
  · intro z hz hzu l hl hlw
    have hzuAdj : T₁.graph.Adj z u := by
      rw [T₁.mem_branchIndices, T₁.mem_neighborsPlus] at hz
      rcases hz with hz | hz
      · exact (hzu hz).elim
      · exact hz.symm
    have hlwAdj : T₂.graph.Adj l w := by
      rw [T₂.mem_branchIndices, T₂.mem_neighborsPlus] at hl
      rcases hl with hl | hl
      · exact (hlw hl).elim
      · exact hl.symm
    have hxzero :=
      (treesIndependent_iff_xCoefficient_eq_zero T₁ T₂).mp h
        z u l w hzuAdj hlwAdj
    have hcenter :=
      xCoefficient_eq_centered_jointMass T₁ T₂ hzuAdj hlwAdj
    rw [hxzero] at hcenter
    unfold branchJointMass branchMass
    simpa [jointMass, jointBlock, XTree.rowMass, XTree.columnMass,
      XTree.rowBlock, XTree.columnBlock] using sub_eq_zero.mp hcenter.symm

/-- The paper's edge-split independence implies independence of the two
random labelled vertices. -/
theorem vertexVariablesIndependent_of_treesIndependent
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (h : TreesIndependent T₁ T₂) :
    VertexVariablesIndependent T₁ T₂ := by
  intro v₁ v₂
  have hv₁ : v₁ ∈ T₁.branchIndices v₁ := by
    simp [XTree.mem_neighborsPlus]
  have hv₂ : v₂ ∈ T₂.branchIndices v₂ := by
    simp [XTree.mem_neighborsPlus]
  have hcell := branchJointMass_eq_mul_of_treesIndependent
    T₁ T₂ h v₁ v₂ v₁ hv₁ v₂ hv₂
  simpa [branchJointMass, branchMass, vertexJointMass, vertexMarginalMass]
    using hcell

/-- Exact formalization of the paper's assertion: the two random labelled
vertices are independent if and only if the two trees are independent. -/
theorem vertexVariablesIndependent_iff_treesIndependent
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    VertexVariablesIndependent T₁ T₂ ↔ TreesIndependent T₁ T₂ := by
  constructor
  · exact treesIndependent_of_vertexVariablesIndependent T₁ T₂
  · exact vertexVariablesIndependent_of_treesIndependent T₁ T₂

/-- Exact witness clause in the paper's vertex--side independence bridge.
If the two trees are not independent, then some positive-mass pair of
labelled vertices has incident directed edges whose split quartet covariance
is strictly positive.  The centre entries of the corresponding row and
column tables are precisely the two positive vertex masses. -/
theorem exists_positive_vertex_side_witness_of_not_treesIndependent
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hnot : ¬ TreesIndependent T₁ T₂) :
    ∃ u w t v,
      0 < vertexMarginalMass T₁ u ∧
      0 < vertexMarginalMass T₂ w ∧
      T₁.graph.Adj t u ∧
      T₂.graph.Adj v w ∧
      0 < splitQuartetCovarianceEvent
        (T₁.edgeSplit t u) (T₂.edgeSplit v w) ∧
      0 < T₁.rowMass t u u ∧
      0 < T₂.columnMass v w w := by
  classical
  have hvertex : ¬ VertexVariablesIndependent T₁ T₂ := by
    intro h
    exact hnot ((vertexVariablesIndependent_iff_treesIndependent T₁ T₂).mp h)
  rw [VertexVariablesIndependent] at hvertex
  push Not at hvertex
  rcases hvertex with ⟨u, w, hcenter⟩
  have huNonempty : (T₁.labelFiber u).Nonempty := by
    by_contra hu
    have huEmpty : T₁.labelFiber u = ∅ := Finset.not_nonempty_iff_eq_empty.mp hu
    apply hcenter
    simp [vertexJointMass, vertexMarginalMass, huEmpty, normalizedCard]
  have hwNonempty : (T₂.labelFiber w).Nonempty := by
    by_contra hw
    have hwEmpty : T₂.labelFiber w = ∅ := Finset.not_nonempty_iff_eq_empty.mp hw
    apply hcenter
    simp [vertexJointMass, vertexMarginalMass, hwEmpty, normalizedCard]
  letI : Nonempty X := T₁.taxon_nonempty
  have huPos : 0 < vertexMarginalMass T₁ u := by
    exact normalizedCard_pos huNonempty
  have hwPos : 0 < vertexMarginalMass T₂ w := by
    exact normalizedCard_pos hwNonempty
  have huMem : u ∈ T₁.branchIndices u := by
    simp [XTree.mem_neighborsPlus]
  have hwMem : w ∈ T₂.branchIndices w := by
    simp [XTree.mem_neighborsPlus]
  have hbranchCenter :
      branchJointMass T₁ T₂ u w u w ≠
        branchMass T₁ u u * branchMass T₂ w w := by
    simpa [branchJointMass, branchMass, vertexJointMass, vertexMarginalMass]
      using hcenter
  have hoff :
      ∃ t ∈ T₁.branchIndices u, t ≠ u ∧
        ∃ v ∈ T₂.branchIndices w, v ≠ w ∧
          branchJointMass T₁ T₂ u w t v ≠
            branchMass T₁ u t * branchMass T₂ w v := by
    by_contra hno
    have hfactor :
        ∀ t ∈ T₁.branchIndices u, t ≠ u →
          ∀ v ∈ T₂.branchIndices w, v ≠ w →
            branchJointMass T₁ T₂ u w t v =
              branchMass T₁ u t * branchMass T₂ w v := by
      intro t ht htu v hv hvw
      by_contra hne
      exact hno ⟨t, ht, htu, v, hv, hvw, hne⟩
    have hall := table_factorization_of_off_centre
      (T₁.branchIndices u) (T₂.branchIndices w) u w huMem hwMem
      (branchJointMass T₁ T₂ u w) (branchMass T₁ u) (branchMass T₂ w)
      (fun z _ => sum_branchJointMass_column T₁ T₂ u w z)
      (fun l _ => sum_branchJointMass_row T₁ T₂ u w l)
      (sum_branchMass T₁ u) (sum_branchMass T₂ w) hfactor
    exact hbranchCenter (hall u huMem w hwMem)
  rcases hoff with ⟨t, ht, htu, v, hv, hvw, hcell⟩
  have htuAdj : T₁.graph.Adj t u := by
    rw [T₁.mem_branchIndices, T₁.mem_neighborsPlus] at ht
    rcases ht with rfl | hut
    · exact (htu rfl).elim
    · exact hut.symm
  have hvwAdj : T₂.graph.Adj v w := by
    rw [T₂.mem_branchIndices, T₂.mem_neighborsPlus] at hv
    rcases hv with rfl | hwv
    · exact (hvw rfl).elim
    · exact hwv.symm
  have hxNe : xCoefficient T₁ T₂ t u v w ≠ 0 := by
    intro hx
    have hcentered := xCoefficient_eq_centered_jointMass
      T₁ T₂ htuAdj hvwAdj
    rw [hx] at hcentered
    apply hcell
    simpa [branchJointMass, branchMass, jointMass, jointBlock,
      XTree.rowMass, XTree.columnMass, XTree.rowBlock, XTree.columnBlock]
      using sub_eq_zero.mp hcentered.symm
  have hqPos :
      0 < splitQuartetCovarianceEvent
        (T₁.edgeSplit t u) (T₂.edgeSplit v w) := by
    rw [edgeSplit_quartetCovarianceEvent_eq T₁ T₂ htuAdj hvwAdj]
    exact mul_pos (by norm_num) (sq_pos_of_ne_zero hxNe)
  refine ⟨u, w, t, v, huPos, hwPos, htuAdj, hvwAdj, hqPos, ?_, ?_⟩
  · simpa [XTree.rowMass, vertexMarginalMass]
  · simpa [XTree.columnMass, vertexMarginalMass]

end JointLaw

end QDFull
