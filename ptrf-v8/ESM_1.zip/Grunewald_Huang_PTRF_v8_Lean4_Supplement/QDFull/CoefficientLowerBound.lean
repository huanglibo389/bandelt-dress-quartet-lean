import QDFull.CoefficientPartitions

/-!
# The exact coefficient lower bound (Lemma 6)

This file proves the first assertion of Lemma 6 directly for the paper's
finite branch index sets and its actual `q` coefficients.  No scalar
surrogate is assumed.  The proof retains the central row, separates the two
summands of `q`, and uses two explicit subfamilies of the column index set.
-/

open scoped BigOperators

namespace QDFull

universe uX uV₁ uV₂

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]

/-- The coefficient sum appearing in the first assertion of Lemma 6. -/
noncomputable def lemma3CoefficientSum
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u : V₁) (v w : V₂) : ℝ :=
  ∑ z₁ ∈ T₁.indexIFinset t u,
    ∑ z₂ ∈ T₂.indexIFinset v w,
      qCoefficient T₁ T₂ t u v w z₁.1 z₁.2 z₂.1 z₂.2

/-- The row indices retained in the paper's proof: the first row argument is
the centre `u`, while the second runs through every branch at `u`. -/
noncomputable def XTree.lemma3CentralRowFinset
    (T : XTree X V₁) (u : V₁) : Finset (V₁ × V₁) := by
  classical
  exact (T.branchIndices u).image fun u'' => (u, u'')

theorem lemma3CentralRowFinset_subset_indexI
    (T : XTree X V₁) (t u : V₁) :
    T.lemma3CentralRowFinset u ⊆ T.indexIFinset t u := by
  classical
  intro z hz
  rw [XTree.lemma3CentralRowFinset, Finset.mem_image] at hz
  rcases hz with ⟨u'', hu'', rfl⟩
  rw [T.mem_indexIFinset, T.mem_indexI]
  exact ⟨by simp, (T.mem_branchIndices u u'').mp hu'', Or.inl rfl⟩

/-- Collapsing the unrestricted second row branch in one fixed column
occurrence gives exactly the two terms displayed in the proof of Lemma 6. -/
private theorem sum_two_term_kernel
    {U : Type*} [DecidableEq U]
    (S : Finset U) (K A C d : ℝ) (b e : U → ℝ) :
    (∑ x ∈ S, K * (A * b x / d + e x * C / d)) =
      K * (A * (∑ x ∈ S, b x) / d +
        (∑ x ∈ S, e x) * C / d) := by
  calc
    (∑ x ∈ S, K * (A * b x / d + e x * C / d)) =
        (∑ x ∈ S, K * (A * b x / d)) +
          ∑ x ∈ S, K * (e x * C / d) := by
      simp_rw [mul_add, Finset.sum_add_distrib]
    _ = (K * A / d) * (∑ x ∈ S, b x) +
          (K * C / d) * (∑ x ∈ S, e x) := by
      simp_rw [Finset.mul_sum]
      apply congrArg₂ (.+.)
      · apply Finset.sum_congr rfl
        intro x hx
        ring
      · apply Finset.sum_congr rfl
        intro x hx
        ring
    _ = K * (A * (∑ x ∈ S, b x) / d +
        (∑ x ∈ S, e x) * C / d) := by ring

theorem sum_qCoefficient_centralRow
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u : V₁) (v w w' w'' : V₂)
    (hvw : T₂.graph.Adj v w) :
    (∑ u'' ∈ T₁.branchIndices u,
        qCoefficient T₁ T₂ t u v w u u'' w' w'') =
      (1 / 2 : ℝ) * T₂.columnMass v w w'' *
        (jointMass T₁ T₂ t u v w u w' +
          T₂.columnMass v w w' *
            jointMass T₁ T₂ t u v w u v /
              T₂.columnMass v w v) := by
  classical
  unfold qCoefficient
  rw [sum_two_term_kernel]
  rw [sum_jointMass_allRowBranches T₁ T₂ t u v w v,
    sum_jointMass_allRowBranches T₁ T₂ t u v w w']
  have hcv : T₂.columnMass v w v ≠ 0 :=
    ne_of_gt (T₂.columnMass_pos_of_adj hvw)
  field_simp [hcv]

/-- For every away-side branch `w'`, the pair `(w',w)` is a legal column
occurrence.  This is the first boundary subfamily in the retained sum. -/
theorem lemma3_firstBoundary_mem_indexI
    (T : XTree X V₂) {v w : V₂} (hvw : T.graph.Adj v w)
    {w' : V₂} (hw' : w' ∈ T.awayBranchIndices v w) :
    (w', w) ∈ T.indexIFinset v w := by
  classical
  rw [T.mem_awayBranchIndices_of_adj hvw] at hw'
  rw [T.mem_indexIFinset, T.mem_indexI]
  refine ⟨hw', ?_, ?_⟩
  · simp
  · by_cases h : w' = w
    · exact Or.inl h
    · right
      refine ⟨hvw.ne', ?_⟩
      exact Ne.symm h

/-- For every branch `w''` at `w`, the pair `(w,w'')` is a legal column
occurrence.  This is the distinguished `w'=w` subfamily. -/
theorem lemma3_secondBoundary_mem_indexI
    (T : XTree X V₂) (v w : V₂)
    {w'' : V₂} (hw'' : w'' ∈ T.branchIndices w) :
    (w, w'') ∈ T.indexIFinset v w := by
  classical
  rw [T.mem_indexIFinset, T.mem_indexI]
  exact ⟨by simp, (T.mem_branchIndices w w'').mp hw'', Or.inl rfl⟩

/-- An actual column-edge branch mass is at most one. -/
theorem columnMass_le_one_of_adj
    (T : XTree X V₂) {v w : V₂} (hvw : T.graph.Adj v w) :
    T.columnMass v w v ≤ 1 := by
  classical
  have hv : v ∈ T.branchIndices w := by
    rw [T.mem_branchIndices, T.mem_neighborsPlus]
    exact Or.inr hvw.symm
  calc
    T.columnMass v w v ≤
        ∑ z ∈ T.branchIndices w, T.columnMass v w z := by
      exact Finset.single_le_sum
        (fun z _ => normalizedCard_nonneg _) hv
    _ = 1 := sum_columnMass_allBranches T v w

/-- Exact first assertion of Lemma 6, with the paper's original index sets
and coefficient. -/
theorem lemma3_coefficient_lower_bound
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w) :
    (1 / 2 : ℝ) * T₂.columnMass v w w * T₁.rowMass t u u ≤
      lemma3CoefficientSum T₁ T₂ t u v w := by
  classical
  let c : V₂ → ℝ := fun z => T₂.columnMass v w z
  let a : V₁ → V₂ → ℝ :=
    fun x y => jointMass T₁ T₂ t u v w x y
  let cv : ℝ := c v
  let cw : ℝ := c w
  let auv : ℝ := a u v
  let r : ℝ := T₁.rowMass t u u

  have hcv : 0 < cv := by
    simpa [cv, c] using T₂.columnMass_pos_of_adj hvw
  have hcv_le : cv ≤ 1 := by
    simpa [cv, c] using columnMass_le_one_of_adj T₂ hvw
  have hcw : 0 ≤ cw := by
    exact normalizedCard_nonneg _
  have hauv : 0 ≤ auv := normalizedCard_nonneg _

  let firstTerm : V₂ × V₂ → ℝ := fun z =>
    (1 / 2 : ℝ) * c z.2 * a u z.1
  let secondTerm : V₂ × V₂ → ℝ := fun z =>
    (1 / 2 : ℝ) * c z.2 * (c z.1 * auv / cv)

  have hFirstNonneg : ∀ z, 0 ≤ firstTerm z := by
    intro z
    dsimp only [firstTerm]
    exact mul_nonneg
      (mul_nonneg (by norm_num) (normalizedCard_nonneg _))
      (normalizedCard_nonneg _)
  have hSecondNonneg : ∀ z, 0 ≤ secondTerm z := by
    intro z
    dsimp only [secondTerm]
    exact mul_nonneg
      (mul_nonneg (by norm_num) (normalizedCard_nonneg _))
      (div_nonneg (mul_nonneg (normalizedCard_nonneg _) hauv) hcv.le)

  have hFirstSubset :
      (T₂.awayBranchIndices v w).image (fun w' => (w', w)) ⊆
        T₂.indexIFinset v w := by
    intro z hz
    rw [Finset.mem_image] at hz
    rcases hz with ⟨w', hw', rfl⟩
    exact lemma3_firstBoundary_mem_indexI T₂ hvw hw'
  have hSecondSubset :
      (T₂.branchIndices w).image (fun w'' => (w, w'')) ⊆
        T₂.indexIFinset v w := by
    intro z hz
    rw [Finset.mem_image] at hz
    rcases hz with ⟨w'', hw'', rfl⟩
    exact lemma3_secondBoundary_mem_indexI T₂ v w hw''

  have hFirstLower :
      (1 / 2 : ℝ) * cw * (r - auv) ≤
        ∑ z ∈ T₂.indexIFinset v w, firstTerm z := by
    have hsub := Finset.sum_le_sum_of_subset_of_nonneg hFirstSubset
      (fun z _ _ => hFirstNonneg z)
    have haway :
        ∑ w' ∈ T₂.awayBranchIndices v w, a u w' = r - auv := by
      have hpart := jointMass_edgeSide_partition_column
        T₁ T₂ t u u hvw
      have hsum := sum_jointMass_awayColumnBranches
        T₁ T₂ t u u hvw
      dsimp [a, r, auv]
      rw [hsum]
      linarith
    calc
      (1 / 2 : ℝ) * cw * (r - auv) =
          ∑ w' ∈ T₂.awayBranchIndices v w,
            firstTerm (w', w) := by
        rw [← haway]
        simp_rw [Finset.mul_sum]
        simp [firstTerm, cw, c]
      _ = ∑ z ∈
          (T₂.awayBranchIndices v w).image (fun w' => (w', w)),
            firstTerm z := by
        rw [Finset.sum_image]
        intro x hx y hy hxy
        exact congrArg Prod.fst hxy
      _ ≤ ∑ z ∈ T₂.indexIFinset v w, firstTerm z := hsub

  have hSecondLower :
      (1 / 2 : ℝ) * cw * auv ≤
        ∑ z ∈ T₂.indexIFinset v w, secondTerm z := by
    have hsub := Finset.sum_le_sum_of_subset_of_nonneg hSecondSubset
      (fun z _ _ => hSecondNonneg z)
    have hmass : auv ≤ auv / cv := by
      apply (le_div_iff₀ hcv).2
      exact mul_le_of_le_one_right hauv hcv_le
    have hscaled :
        (1 / 2 : ℝ) * cw * auv ≤
          (1 / 2 : ℝ) * cw * (auv / cv) := by
      gcongr
    calc
      (1 / 2 : ℝ) * cw * auv ≤
          (1 / 2 : ℝ) * cw * (auv / cv) := hscaled
      _ = (∑ w'' ∈ T₂.branchIndices w, c w'') *
          ((1 / 2 : ℝ) * cw * (auv / cv)) := by
        rw [sum_columnMass_allBranches T₂ v w]
        ring
      _ = ∑ w'' ∈ T₂.branchIndices w,
          secondTerm (w, w'') := by
        rw [Finset.sum_mul]
        apply Finset.sum_congr rfl
        intro w'' hw''
        dsimp only [secondTerm, cw, c]
        ring
      _ = ∑ z ∈
          (T₂.branchIndices w).image (fun w'' => (w, w'')),
            secondTerm z := by
        rw [Finset.sum_image]
        intro x hx y hy hxy
        exact congrArg Prod.snd hxy
      _ ≤ ∑ z ∈ T₂.indexIFinset v w, secondTerm z := hsub

  have hCentralFormula :
      (∑ u'' ∈ T₁.branchIndices u,
        ∑ z ∈ T₂.indexIFinset v w,
          qCoefficient T₁ T₂ t u v w u u'' z.1 z.2) =
        (∑ z ∈ T₂.indexIFinset v w, firstTerm z) +
          ∑ z ∈ T₂.indexIFinset v w, secondTerm z := by
    rw [Finset.sum_comm]
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro z hz
    rw [sum_qCoefficient_centralRow T₁ T₂ t u v w z.1 z.2 hvw]
    dsimp [firstTerm, secondTerm, c, a, auv, cv]
    ring

  have hCentralLower :
      (1 / 2 : ℝ) * cw * r ≤
        ∑ u'' ∈ T₁.branchIndices u,
          ∑ z ∈ T₂.indexIFinset v w,
            qCoefficient T₁ T₂ t u v w u u'' z.1 z.2 := by
    rw [hCentralFormula]
    linarith

  have hRowSubset := lemma3CentralRowFinset_subset_indexI T₁ t u
  have hFullFromSubset :
      (∑ z₁ ∈ T₁.lemma3CentralRowFinset u,
        ∑ z₂ ∈ T₂.indexIFinset v w,
          qCoefficient T₁ T₂ t u v w z₁.1 z₁.2 z₂.1 z₂.2) ≤
        lemma3CoefficientSum T₁ T₂ t u v w := by
    unfold lemma3CoefficientSum
    exact Finset.sum_le_sum_of_subset_of_nonneg hRowSubset (by
      intro z₁ hz₁ hnot
      exact Finset.sum_nonneg fun z₂ hz₂ =>
        qCoefficient_nonneg_of_adj T₁ T₂
          t u z₁.1 z₁.2 hvw z₂.1 z₂.2)
  have hCentralAsImage :
      (∑ z₁ ∈ T₁.lemma3CentralRowFinset u,
        ∑ z₂ ∈ T₂.indexIFinset v w,
          qCoefficient T₁ T₂ t u v w z₁.1 z₁.2 z₂.1 z₂.2) =
        ∑ u'' ∈ T₁.branchIndices u,
          ∑ z₂ ∈ T₂.indexIFinset v w,
            qCoefficient T₁ T₂ t u v w u u'' z₂.1 z₂.2 := by
    unfold XTree.lemma3CentralRowFinset
    rw [Finset.sum_image]
    intro x hx y hy hxy
    exact congrArg Prod.snd hxy
  dsimp [cw, c, r] at hCentralLower ⊢
  rw [hCentralAsImage] at hFullFromSubset
  exact hCentralLower.trans hFullFromSubset

end QDFull
