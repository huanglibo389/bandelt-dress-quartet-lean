import QDFull.GlobalSquareAssembly

/-!
# Source-complement assembly of the raw quadratic

This file closes the finite source ledger between the four local covariance
types and the raw quadratic.  For every directed principal edge, the
unrestricted branch-pair pool is the disjoint union of `I'` and its diagonal
complement.  Applying that partition independently in the row and column
coordinates gives a four-cell decomposition.  The inclusion--exclusion signs
then cancel exactly the diagonal cells and leave the `I'` raw quadratic.
-/

open scoped BigOperators

namespace QDFull

universe uX uV₁ uV₂

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]

noncomputable def sourceFullFamily₁
    (T : XTree X V₁) (e : V₁ × V₁) : Finset (V₁ × V₁) :=
  T.fullIndexFinset e.1 e.2

noncomputable def sourcePrimeFamily₁
    (T : XTree X V₁) (e : V₁ × V₁) : Finset (V₁ × V₁) :=
  T.indexIPrimeFinset e.1 e.2

noncomputable def sourceDiagonalFamily₁
    (T : XTree X V₁) (e : V₁ × V₁) : Finset (V₁ × V₁) :=
  T.diagonalIndexFinset e.1 e.2

noncomputable def sourceFullFamily₂
    (T : XTree X V₂) (e : V₂ × V₂) : Finset (V₂ × V₂) :=
  T.fullIndexFinset e.1 e.2

noncomputable def sourcePrimeFamily₂
    (T : XTree X V₂) (e : V₂ × V₂) : Finset (V₂ × V₂) :=
  T.indexIPrimeFinset e.1 e.2

noncomputable def sourceDiagonalFamily₂
    (T : XTree X V₂) (e : V₂ × V₂) : Finset (V₂ × V₂) :=
  T.diagonalIndexFinset e.1 e.2

/-- Partition only the row source coordinate of a `q` block. -/
theorem qDiagonalBlock_rowFull_decomposition
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (J₂ : V₂ × V₂ → Finset (V₂ × V₂)) :
    qDiagonalBlock T₁ T₂ (sourceFullFamily₁ T₁) J₂ =
      qDiagonalBlock T₁ T₂ (sourcePrimeFamily₁ T₁) J₂ +
        qDiagonalBlock T₁ T₂ (sourceDiagonalFamily₁ T₁) J₂ := by
  classical
  rw [qDiagonalBlock_reindex, qDiagonalBlock_reindex,
    qDiagonalBlock_reindex]
  unfold sourceFullFamily₁ sourcePrimeFamily₁ sourceDiagonalFamily₁
  exact T₁.sum_directedEdge_fullIndex_eq_prime_add_diagonal
    (fun e₁ z₁ =>
      ∑ e₂ ∈ T₂.directedEdgeFinset,
        ∑ z₂ ∈ J₂ e₂,
          qCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2
              z₁.1 z₁.2 z₂.1 z₂.2 *
            xCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2 ^ 2)

/-- Partition only the column source coordinate of a `q` block. -/
theorem qDiagonalBlock_columnFull_decomposition
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (J₁ : V₁ × V₁ → Finset (V₁ × V₁)) :
    qDiagonalBlock T₁ T₂ J₁ (sourceFullFamily₂ T₂) =
      qDiagonalBlock T₁ T₂ J₁ (sourcePrimeFamily₂ T₂) +
        qDiagonalBlock T₁ T₂ J₁ (sourceDiagonalFamily₂ T₂) := by
  classical
  rw [qDiagonalBlock_reindex, qDiagonalBlock_reindex,
    qDiagonalBlock_reindex]
  unfold sourceFullFamily₂ sourcePrimeFamily₂ sourceDiagonalFamily₂
  calc
    _ = ∑ e₁ ∈ T₁.directedEdgeFinset,
          ∑ z₁ ∈ J₁ e₁,
            ((∑ e₂ ∈ T₂.directedEdgeFinset,
                ∑ z₂ ∈ T₂.indexIPrimeFinset e₂.1 e₂.2,
                  qCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2
                      z₁.1 z₁.2 z₂.1 z₂.2 *
                    xCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2 ^ 2) +
              ∑ e₂ ∈ T₂.directedEdgeFinset,
                ∑ z₂ ∈ T₂.diagonalIndexFinset e₂.1 e₂.2,
                  qCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2
                      z₁.1 z₁.2 z₂.1 z₂.2 *
                    xCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2 ^ 2) := by
      apply Finset.sum_congr rfl
      intro e₁ he₁
      apply Finset.sum_congr rfl
      intro z₁ hz₁
      exact T₂.sum_directedEdge_fullIndex_eq_prime_add_diagonal
        (fun e₂ z₂ =>
          qCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2
              z₁.1 z₁.2 z₂.1 z₂.2 *
            xCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2 ^ 2)
    _ = _ := by
      simp_rw [Finset.sum_add_distrib]

/-- Applying `full = I' \sqcup diagonal` in both coordinates gives the
four source cells of the unrestricted `q` block. -/
theorem qDiagonalBlock_full_decomposition
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    qDiagonalBlock T₁ T₂ (sourceFullFamily₁ T₁) (sourceFullFamily₂ T₂) =
      qDiagonalBlock T₁ T₂ (sourcePrimeFamily₁ T₁) (sourcePrimeFamily₂ T₂) +
      qDiagonalBlock T₁ T₂ (sourceDiagonalFamily₁ T₁) (sourcePrimeFamily₂ T₂) +
      qDiagonalBlock T₁ T₂ (sourcePrimeFamily₁ T₁) (sourceDiagonalFamily₂ T₂) +
      qDiagonalBlock T₁ T₂ (sourceDiagonalFamily₁ T₁) (sourceDiagonalFamily₂ T₂) := by
  classical
  let F := fun (e₁ : V₁ × V₁) (z₁ : V₁ × V₁)
      (e₂ : V₂ × V₂) (z₂ : V₂ × V₂) =>
    qCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2
        z₁.1 z₁.2 z₂.1 z₂.2 *
      xCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2 ^ 2
  simp only [qDiagonalBlock_reindex]
  unfold sourceFullFamily₁ sourceFullFamily₂
    sourcePrimeFamily₁ sourcePrimeFamily₂
    sourceDiagonalFamily₁ sourceDiagonalFamily₂
  change (∑ e₁ ∈ T₁.directedEdgeFinset,
      ∑ z₁ ∈ T₁.fullIndexFinset e₁.1 e₁.2,
        ∑ e₂ ∈ T₂.directedEdgeFinset,
          ∑ z₂ ∈ T₂.fullIndexFinset e₂.1 e₂.2,
            F e₁ z₁ e₂ z₂) = _
  calc
    _ = ∑ e₁ ∈ T₁.directedEdgeFinset,
          ∑ z₁ ∈ T₁.fullIndexFinset e₁.1 e₁.2,
            ((∑ e₂ ∈ T₂.directedEdgeFinset,
                ∑ z₂ ∈ T₂.indexIPrimeFinset e₂.1 e₂.2,
                  F e₁ z₁ e₂ z₂) +
              ∑ e₂ ∈ T₂.directedEdgeFinset,
                ∑ z₂ ∈ T₂.diagonalIndexFinset e₂.1 e₂.2,
                  F e₁ z₁ e₂ z₂) := by
      apply Finset.sum_congr rfl
      intro e₁ he₁
      apply Finset.sum_congr rfl
      intro z₁ hz₁
      exact T₂.sum_directedEdge_fullIndex_eq_prime_add_diagonal
        (fun e₂ z₂ => F e₁ z₁ e₂ z₂)
    _ = _ := by
      simp_rw [Finset.sum_add_distrib]
      rw [T₁.sum_directedEdge_fullIndex_eq_prime_add_diagonal]
      rw [T₁.sum_directedEdge_fullIndex_eq_prime_add_diagonal]
      simp only [F]
      ac_rfl

/-- The unrestricted row source pool in the `s` block is `I'` plus its
diagonal complement. -/
theorem sMixedBlock_full_decomposition
    [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    sMixedBlock T₁ T₂ (sourceFullFamily₁ T₁) =
      sMixedBlock T₁ T₂ (sourcePrimeFamily₁ T₁) +
        sMixedBlock T₁ T₂ (sourceDiagonalFamily₁ T₁) := by
  classical
  simp only [sMixedBlock_reindex]
  unfold sourceFullFamily₁ sourcePrimeFamily₁ sourceDiagonalFamily₁
  exact T₁.sum_directedEdge_fullIndex_eq_prime_add_diagonal
    (fun e₁ z₁ =>
      ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
        sCoefficient T₁ T₂ e₁.1 e₁.2 z₁.1 z₁.2
            p₂.1 p₂.2.1 p₂.2.2 *
          xCoefficient T₁ T₂ e₁.1 e₁.2 p₂.1 p₂.2.1 *
          xCoefficient T₁ T₂ e₁.1 e₁.2 p₂.2.2 p₂.2.1)

/-- The unrestricted column source pool in the `b` block is `I'` plus its
diagonal complement. -/
theorem bMixedBlock_full_decomposition
    [LinearOrder V₁]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    bMixedBlock T₁ T₂ (sourceFullFamily₂ T₂) =
      bMixedBlock T₁ T₂ (sourcePrimeFamily₂ T₂) +
        bMixedBlock T₁ T₂ (sourceDiagonalFamily₂ T₂) := by
  classical
  unfold bMixedBlock sourceFullFamily₂ sourcePrimeFamily₂
    sourceDiagonalFamily₂
  calc
    _ = ∑ p₁ ∈ T₁.canonicalLengthTwoPathFinset,
          ((∑ e₂ ∈ T₂.directedEdgeFinset,
              ∑ z₂ ∈ T₂.indexIPrimeFinset e₂.1 e₂.2,
                bCoefficient T₁ T₂ p₁.1 p₁.2.1 p₁.2.2
                    e₂.1 e₂.2 z₂.1 z₂.2 *
                  xCoefficient T₁ T₂ p₁.1 p₁.2.1 e₂.1 e₂.2 *
                  xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 e₂.1 e₂.2) +
            ∑ e₂ ∈ T₂.directedEdgeFinset,
              ∑ z₂ ∈ T₂.diagonalIndexFinset e₂.1 e₂.2,
                bCoefficient T₁ T₂ p₁.1 p₁.2.1 p₁.2.2
                    e₂.1 e₂.2 z₂.1 z₂.2 *
                  xCoefficient T₁ T₂ p₁.1 p₁.2.1 e₂.1 e₂.2 *
                  xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 e₂.1 e₂.2) := by
      apply Finset.sum_congr rfl
      intro p₁ hp₁
      exact T₂.sum_directedEdge_fullIndex_eq_prime_add_diagonal
        (fun e₂ z₂ =>
          bCoefficient T₁ T₂ p₁.1 p₁.2.1 p₁.2.2
              e₂.1 e₂.2 z₂.1 z₂.2 *
            xCoefficient T₁ T₂ p₁.1 p₁.2.1 e₂.1 e₂.2 *
            xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 e₂.1 e₂.2)
    _ = _ := Finset.sum_add_distrib

/-! ## The four local contribution blocks -/

/-- Sum of all edge--edge local coefficient polynomials. -/
noncomputable def edgeEdgeAlgebraBlock
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  qDiagonalBlock T₁ T₂ (sourceFullFamily₁ T₁) (sourceFullFamily₂ T₂)

/-- Sum of all edge--path local coefficient polynomials. -/
noncomputable def edgePathAlgebraBlock
    [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  qDiagonalBlock T₁ T₂ (sourceFullFamily₁ T₁) (sourceDiagonalFamily₂ T₂) -
    2 * sMixedBlock T₁ T₂ (sourceFullFamily₁ T₁)

/-- Sum of all path--edge local coefficient polynomials. -/
noncomputable def pathEdgeAlgebraBlock
    [LinearOrder V₁]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  qDiagonalBlock T₁ T₂ (sourceDiagonalFamily₁ T₁) (sourceFullFamily₂ T₂) -
    2 * bMixedBlock T₁ T₂ (sourceFullFamily₂ T₂)

/-- Sum of all path--path local coefficient polynomials. -/
noncomputable def pathPathAlgebraBlock
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  qDiagonalBlock T₁ T₂ (sourceDiagonalFamily₁ T₁) (sourceDiagonalFamily₂ T₂) -
    2 * sMixedBlock T₁ T₂ (sourceDiagonalFamily₁ T₁) -
    2 * bMixedBlock T₁ T₂ (sourceDiagonalFamily₂ T₂) +
    2 * pMixedBlock T₁ T₂

/-- Inclusion--exclusion applied to the four local algebra blocks. -/
noncomputable def inclusionExclusionAlgebra
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  edgeEdgeAlgebraBlock T₁ T₂ - edgePathAlgebraBlock T₁ T₂ -
    pathEdgeAlgebraBlock T₁ T₂ + pathPathAlgebraBlock T₁ T₂

/-- Exact source-level closure: inclusion--exclusion removes every diagonal
source occurrence and leaves precisely the raw `I'` quadratic. -/
theorem inclusionExclusionAlgebra_eq_rawQuadratic
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    inclusionExclusionAlgebra T₁ T₂ = rawQuadratic T₁ T₂ := by
  rw [inclusionExclusionAlgebra, edgeEdgeAlgebraBlock,
    edgePathAlgebraBlock, pathEdgeAlgebraBlock, pathPathAlgebraBlock,
    qDiagonalBlock_full_decomposition,
    qDiagonalBlock_rowFull_decomposition,
    qDiagonalBlock_columnFull_decomposition,
    sMixedBlock_full_decomposition, bMixedBlock_full_decomposition]
  change _ =
    qDiagonalBlock T₁ T₂ (sourcePrimeFamily₁ T₁) (sourcePrimeFamily₂ T₂) +
      2 * sMixedBlock T₁ T₂ (sourcePrimeFamily₁ T₁) +
      2 * bMixedBlock T₁ T₂ (sourcePrimeFamily₂ T₂) +
      2 * pMixedBlock T₁ T₂
  ring

/-! ## Identification with the actual local covariance sums -/

/-- The edge--edge term in the inclusion--exclusion formula, indexed once
per edge-reversal orbit. -/
noncomputable def edgeEdgeCovarianceBlock
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  ∑ e₁ ∈ T₁.canonicalEdgeFinset,
    ∑ e₂ ∈ T₂.canonicalEdgeFinset,
      (1 / 6 : ℝ) *
        splitQuartetCovariance
          (T₁.edgeSplit e₁.1 e₁.2) (T₂.edgeSplit e₂.1 e₂.2)

/-- Every unrestricted directed source occurrence in the `q` block is one
of the four oriented coefficient copies in the local edge--edge identity. -/
theorem edgeEdgeAlgebraBlock_eq_covarianceBlock
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    edgeEdgeAlgebraBlock T₁ T₂ = edgeEdgeCovarianceBlock T₁ T₂ := by
  classical
  unfold edgeEdgeAlgebraBlock edgeEdgeCovarianceBlock qDiagonalBlock
    sourceFullFamily₁ sourceFullFamily₂
  rw [T₁.sum_directedEdge_eq_sum_canonical_with_reverse]
  apply Finset.sum_congr rfl
  intro e₁ he₁
  simp_rw [T₂.sum_directedEdge_eq_sum_canonical_with_reverse]
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro e₂ he₂
  have h₁ := (T₁.mem_canonicalEdgeFinset e₁.1 e₁.2).1 he₁
  have h₂ := (T₂.mem_canonicalEdgeFinset e₂.1 e₂.2).1 he₂
  simpa only [XTree.reverseEdge, XTree.fullIndexFinset, Finset.sum_product,
      qOrientationSum, ← Finset.sum_mul, add_assoc] using
    (edgeEdge_local_q_decomposition T₁ T₂ h₁.1 h₂.1).symm

/-- The two diagonal `q` faces of every edge--path local polynomial. -/
noncomputable def edgePathDiagonalSum
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  ∑ e ∈ T₁.canonicalEdgeFinset,
    ∑ p ∈ T₂.canonicalLengthTwoPathFinset,
      ((qRowOrientationSum T₁ T₂ e.1 e.2 p.1 p.2.1 p.2.2 p.2.2 +
            qRowOrientationSum T₁ T₂ e.2 e.1 p.1 p.2.1 p.2.2 p.2.2) *
          xCoefficient T₁ T₂ e.1 e.2 p.1 p.2.1 ^ 2 +
        (qRowOrientationSum T₁ T₂ e.1 e.2 p.2.2 p.2.1 p.1 p.1 +
            qRowOrientationSum T₁ T₂ e.2 e.1 p.2.2 p.2.1 p.1 p.1) *
          xCoefficient T₁ T₂ e.1 e.2 p.2.2 p.2.1 ^ 2)

/-- Reindex the column diagonal complement for one fixed directed row edge. -/
theorem qDiagonal_fixedRowEdge_eq_edgePath_faces
    [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (e : V₁ × V₁) :
    (∑ z₁ ∈ T₁.fullIndexFinset e.1 e.2,
        ∑ e₂ ∈ T₂.directedEdgeFinset,
          ∑ z₂ ∈ T₂.diagonalIndexFinset e₂.1 e₂.2,
            qCoefficient T₁ T₂ e.1 e.2 e₂.1 e₂.2
                z₁.1 z₁.2 z₂.1 z₂.2 *
              xCoefficient T₁ T₂ e.1 e.2 e₂.1 e₂.2 ^ 2) =
      ∑ p ∈ T₂.canonicalLengthTwoPathFinset,
        (qRowOrientationSum T₁ T₂ e.1 e.2 p.1 p.2.1 p.2.2 p.2.2 *
              xCoefficient T₁ T₂ e.1 e.2 p.1 p.2.1 ^ 2 +
          qRowOrientationSum T₁ T₂ e.1 e.2 p.2.2 p.2.1 p.1 p.1 *
              xCoefficient T₁ T₂ e.1 e.2 p.2.2 p.2.1 ^ 2) := by
  classical
  simp_rw [T₂.sum_directedEdge_diagonal_eq_sum_canonical_orientations]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro p hp
  rw [Finset.sum_add_distrib]
  simp only [XTree.fullIndexFinset, Finset.sum_product,
    qRowOrientationSum, ← Finset.sum_mul]

theorem qFullDiagonalBlock_eq_edgePathDiagonalSum
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    qDiagonalBlock T₁ T₂ (sourceFullFamily₁ T₁)
        (sourceDiagonalFamily₂ T₂) =
      edgePathDiagonalSum T₁ T₂ := by
  classical
  rw [qDiagonalBlock_reindex]
  unfold sourceFullFamily₁ sourceDiagonalFamily₂ edgePathDiagonalSum
  rw [T₁.sum_directedEdge_eq_sum_canonical_with_reverse]
  apply Finset.sum_congr rfl
  intro e he
  rw [qDiagonal_fixedRowEdge_eq_edgePath_faces,
    qDiagonal_fixedRowEdge_eq_edgePath_faces,
    ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro p hp
  simp only [XTree.reverseEdge]
  rw [xCoefficient_reverse_row T₁ T₂ e.1 e.2 p.1 p.2.1,
    xCoefficient_reverse_row T₁ T₂ e.1 e.2 p.2.2 p.2.1]
  ring

/-- The mixed `s` face of every edge--path local polynomial. -/
noncomputable def edgePathMixedSum
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  ∑ e ∈ T₁.canonicalEdgeFinset,
    ∑ p ∈ T₂.canonicalLengthTwoPathFinset,
      (qRowOrientationSum T₁ T₂ e.1 e.2 p.1 p.2.1 p.2.2 p.1 +
          qRowOrientationSum T₁ T₂ e.2 e.1 p.1 p.2.1 p.2.2 p.1) *
        xCoefficient T₁ T₂ e.1 e.2 p.1 p.2.1 *
        xCoefficient T₁ T₂ e.1 e.2 p.2.2 p.2.1

theorem sFullBlock_eq_edgePathMixedSum
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    sMixedBlock T₁ T₂ (sourceFullFamily₁ T₁) =
      edgePathMixedSum T₁ T₂ := by
  classical
  unfold sMixedBlock sourceFullFamily₁ edgePathMixedSum
  rw [T₁.sum_directedEdge_eq_sum_canonical_with_reverse]
  apply Finset.sum_congr rfl
  intro e he
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro p hp
  simp only [XTree.reverseEdge, XTree.fullIndexFinset, Finset.sum_product,
    sCoefficient, qRowOrientationSum, ← Finset.sum_mul]
  rw [xCoefficient_reverse_row T₁ T₂ e.1 e.2 p.1 p.2.1,
    xCoefficient_reverse_row T₁ T₂ e.1 e.2 p.2.2 p.2.1]
  ring

/-- The edge--path covariance term, indexed by one row-edge orientation and
one column-path orientation from each reversal orbit. -/
noncomputable def edgePathCovarianceBlock
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  ∑ e ∈ T₁.canonicalEdgeFinset,
    ∑ p ∈ T₂.canonicalLengthTwoPathFinset,
      (1 / 6 : ℝ) * splitQuartetCovariance
        (T₁.edgeSplit e.1 e.2) (T₂.sidePairSplit p.1 p.2.1 p.2.2)

theorem edgePathAlgebraBlock_eq_covarianceBlock
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    edgePathAlgebraBlock T₁ T₂ = edgePathCovarianceBlock T₁ T₂ := by
  classical
  rw [edgePathAlgebraBlock, qFullDiagonalBlock_eq_edgePathDiagonalSum,
    sFullBlock_eq_edgePathMixedSum]
  unfold edgePathDiagonalSum edgePathMixedSum edgePathCovarianceBlock
  simp_rw [Finset.mul_sum]
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro e he
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro p hp
  have he' := (T₁.mem_canonicalEdgeFinset e.1 e.2).1 he
  have hp' := (T₂.mem_canonicalLengthTwoPathFinset p.1 p.2.1 p.2.2).1 hp
  simpa only [mul_assoc] using
    (edgePath_local_qs_decomposition T₁ T₂
      he'.1 hp'.1 hp'.2.1 (ne_of_lt hp'.2.2)).symm

/-- The two diagonal `q` faces of every path--edge local polynomial. -/
noncomputable def pathEdgeDiagonalSum
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  ∑ p ∈ T₁.canonicalLengthTwoPathFinset,
    ∑ e ∈ T₂.canonicalEdgeFinset,
      ((qColumnOrientationSum T₁ T₂ p.2.2 p.2.1 e.1 e.2 p.1 p.1 +
            qColumnOrientationSum T₁ T₂ p.2.2 p.2.1 e.2 e.1 p.1 p.1) *
          xCoefficient T₁ T₂ p.2.2 p.2.1 e.1 e.2 ^ 2 +
        (qColumnOrientationSum T₁ T₂ p.1 p.2.1 e.1 e.2 p.2.2 p.2.2 +
            qColumnOrientationSum T₁ T₂ p.1 p.2.1 e.2 e.1 p.2.2 p.2.2) *
          xCoefficient T₁ T₂ p.1 p.2.1 e.1 e.2 ^ 2)

theorem qDiagonalFullBlock_eq_pathEdgeDiagonalSum
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    qDiagonalBlock T₁ T₂ (sourceDiagonalFamily₁ T₁)
        (sourceFullFamily₂ T₂) =
      pathEdgeDiagonalSum T₁ T₂ := by
  classical
  rw [qDiagonalBlock_reindex]
  unfold sourceDiagonalFamily₁ sourceFullFamily₂ pathEdgeDiagonalSum
  rw [T₁.sum_directedEdge_diagonal_eq_sum_canonical_orientations]
  apply Finset.sum_congr rfl
  intro p hp
  simp_rw [T₂.sum_directedEdge_eq_sum_canonical_with_reverse]
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro e he
  simp only [XTree.reverseEdge, XTree.fullIndexFinset, Finset.sum_product,
    Finset.sum_add_distrib, ← Finset.sum_mul, qColumnOrientationSum]
  rw [xCoefficient_reverse_column T₁ T₂ p.2.2 p.2.1 e.1 e.2,
    xCoefficient_reverse_column T₁ T₂ p.1 p.2.1 e.1 e.2]
  ring

/-- The mixed `b` face of every path--edge local polynomial. -/
noncomputable def pathEdgeMixedSum
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  ∑ p ∈ T₁.canonicalLengthTwoPathFinset,
    ∑ e ∈ T₂.canonicalEdgeFinset,
      (qColumnOrientationSum T₁ T₂ p.1 p.2.1 e.1 e.2 p.2.2 p.1 +
          qColumnOrientationSum T₁ T₂ p.1 p.2.1 e.2 e.1 p.2.2 p.1) *
        xCoefficient T₁ T₂ p.2.2 p.2.1 e.1 e.2 *
        xCoefficient T₁ T₂ p.1 p.2.1 e.1 e.2

theorem bFullBlock_eq_pathEdgeMixedSum
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    bMixedBlock T₁ T₂ (sourceFullFamily₂ T₂) =
      pathEdgeMixedSum T₁ T₂ := by
  classical
  unfold bMixedBlock sourceFullFamily₂ pathEdgeMixedSum
  apply Finset.sum_congr rfl
  intro p hp
  rw [T₂.sum_directedEdge_eq_sum_canonical_with_reverse]
  apply Finset.sum_congr rfl
  intro e he
  simp only [XTree.reverseEdge, XTree.fullIndexFinset, Finset.sum_product,
    bCoefficient, qColumnOrientationSum, ← Finset.sum_mul]
  rw [xCoefficient_reverse_column T₁ T₂ p.1 p.2.1 e.1 e.2,
    xCoefficient_reverse_column T₁ T₂ p.2.2 p.2.1 e.1 e.2]
  ring

noncomputable def pathEdgeCovarianceBlock
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  ∑ p ∈ T₁.canonicalLengthTwoPathFinset,
    ∑ e ∈ T₂.canonicalEdgeFinset,
      (1 / 6 : ℝ) * splitQuartetCovariance
        (T₁.sidePairSplit p.1 p.2.1 p.2.2) (T₂.edgeSplit e.1 e.2)

theorem pathEdgeAlgebraBlock_eq_covarianceBlock
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    pathEdgeAlgebraBlock T₁ T₂ = pathEdgeCovarianceBlock T₁ T₂ := by
  classical
  rw [pathEdgeAlgebraBlock, qDiagonalFullBlock_eq_pathEdgeDiagonalSum,
    bFullBlock_eq_pathEdgeMixedSum]
  unfold pathEdgeDiagonalSum pathEdgeMixedSum pathEdgeCovarianceBlock
  simp_rw [Finset.mul_sum]
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro p hp
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro e he
  have hp' := (T₁.mem_canonicalLengthTwoPathFinset p.1 p.2.1 p.2.2).1 hp
  have he' := (T₂.mem_canonicalEdgeFinset e.1 e.2).1 he
  simpa only [mul_assoc] using
    (pathEdge_local_qb_decomposition T₁ T₂
      hp'.1 hp'.2.1 (ne_of_lt hp'.2.2) he'.1).symm

/-! ### Path--path source settlement -/

/-- The four diagonal `q` faces of every path--path local polynomial. -/
noncomputable def pathPathDiagonalSum
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  ∑ p₁ ∈ T₁.canonicalLengthTwoPathFinset,
    ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
      (qCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.1 p₂.2.1
            p₁.2.2 p₁.2.2 p₂.2.2 p₂.2.2 *
          xCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.1 p₂.2.1 ^ 2 +
        qCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.2.2 p₂.2.1
            p₁.2.2 p₁.2.2 p₂.1 p₂.1 *
          xCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.2.2 p₂.2.1 ^ 2 +
        qCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.1 p₂.2.1
            p₁.1 p₁.1 p₂.2.2 p₂.2.2 *
          xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.1 p₂.2.1 ^ 2 +
        qCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.2.2 p₂.2.1
            p₁.1 p₁.1 p₂.1 p₂.1 *
          xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.2.2 p₂.2.1 ^ 2)

/-- The two diagonal source complements in the unrestricted `q` block are
exactly the four diagonal faces in `pathPathDiagonalSum`. -/
theorem qDiagonalDiagonalBlock_eq_pathPathDiagonalSum
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    qDiagonalBlock T₁ T₂ (sourceDiagonalFamily₁ T₁)
        (sourceDiagonalFamily₂ T₂) =
      pathPathDiagonalSum T₁ T₂ := by
  classical
  rw [qDiagonalBlock_reindex]
  unfold sourceDiagonalFamily₁ sourceDiagonalFamily₂ pathPathDiagonalSum
  rw [T₁.sum_directedEdge_diagonal_eq_sum_canonical_orientations]
  apply Finset.sum_congr rfl
  intro p₁ hp₁
  simp_rw [T₂.sum_directedEdge_diagonal_eq_sum_canonical_orientations]
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro p₂ hp₂
  ring

/-- The two same-row `s` faces of every path--path local polynomial. -/
noncomputable def pathPathSMixedSum
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  ∑ p₁ ∈ T₁.canonicalLengthTwoPathFinset,
    ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
      (sCoefficient T₁ T₂ p₁.1 p₁.2.1 p₁.2.2 p₁.2.2
            p₂.1 p₂.2.1 p₂.2.2 *
          xCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.1 p₂.2.1 *
            xCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.2.2 p₂.2.1 +
        sCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₁.1 p₁.1
            p₂.1 p₂.2.1 p₂.2.2 *
          xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.1 p₂.2.1 *
            xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.2.2 p₂.2.1)

theorem sDiagonalBlock_eq_pathPathSMixedSum
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    sMixedBlock T₁ T₂ (sourceDiagonalFamily₁ T₁) =
      pathPathSMixedSum T₁ T₂ := by
  classical
  rw [sMixedBlock_reindex]
  unfold sourceDiagonalFamily₁ pathPathSMixedSum
  rw [T₁.sum_directedEdge_diagonal_eq_sum_canonical_orientations]
  apply Finset.sum_congr rfl
  intro p hp
  rw [← Finset.sum_add_distrib]

/-- The two same-column `b` faces of every path--path local polynomial. -/
noncomputable def pathPathBMixedSum
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  ∑ p₁ ∈ T₁.canonicalLengthTwoPathFinset,
    ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
      (bCoefficient T₁ T₂ p₁.1 p₁.2.1 p₁.2.2
            p₂.1 p₂.2.1 p₂.2.2 p₂.2.2 *
          xCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.1 p₂.2.1 *
            xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.1 p₂.2.1 +
        bCoefficient T₁ T₂ p₁.1 p₁.2.1 p₁.2.2
            p₂.2.2 p₂.2.1 p₂.1 p₂.1 *
          xCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.2.2 p₂.2.1 *
            xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.2.2 p₂.2.1)

theorem bDiagonalBlock_eq_pathPathBMixedSum
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    bMixedBlock T₁ T₂ (sourceDiagonalFamily₂ T₂) =
      pathPathBMixedSum T₁ T₂ := by
  classical
  unfold bMixedBlock sourceDiagonalFamily₂ pathPathBMixedSum
  apply Finset.sum_congr rfl
  intro p₁ hp₁
  rw [T₂.sum_directedEdge_diagonal_eq_sum_canonical_orientations]

/-- The path--path covariance term, indexed once per reversal orbit in both
tree coordinates. -/
noncomputable def pathPathCovarianceBlock
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  ∑ p₁ ∈ T₁.canonicalLengthTwoPathFinset,
    ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
      (1 / 6 : ℝ) * splitQuartetCovariance
        (T₁.sidePairSplit p₁.1 p₁.2.1 p₁.2.2)
        (T₂.sidePairSplit p₂.1 p₂.2.1 p₂.2.2)

/-- Every diagonal source occurrence in the path--path algebra block is
settled exactly once in one of the four local `q,b,s,p` faces. -/
theorem pathPathAlgebraBlock_eq_covarianceBlock
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    pathPathAlgebraBlock T₁ T₂ = pathPathCovarianceBlock T₁ T₂ := by
  classical
  rw [pathPathAlgebraBlock,
    qDiagonalDiagonalBlock_eq_pathPathDiagonalSum,
    sDiagonalBlock_eq_pathPathSMixedSum,
    bDiagonalBlock_eq_pathPathBMixedSum]
  unfold pathPathDiagonalSum pathPathSMixedSum pathPathBMixedSum
    pMixedBlock pathPathCovarianceBlock
  simp_rw [Finset.mul_sum]
  rw [← Finset.sum_sub_distrib, ← Finset.sum_sub_distrib,
    ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro p₁ hp₁
  rw [← Finset.sum_sub_distrib, ← Finset.sum_sub_distrib,
    ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro p₂ hp₂
  have hp₁' :=
    (T₁.mem_canonicalLengthTwoPathFinset p₁.1 p₁.2.1 p₁.2.2).1 hp₁
  have hp₂' :=
    (T₂.mem_canonicalLengthTwoPathFinset p₂.1 p₂.2.1 p₂.2.2).1 hp₂
  have hlocal :=
    (pathPath_local_qbsp_decomposition T₁ T₂
      hp₁'.1 hp₁'.2.1 (ne_of_lt hp₁'.2.2)
      hp₂'.1 hp₂'.2.1 (ne_of_lt hp₂'.2.2)).symm
  convert hlocal using 1 <;> ring

/-! ## The global Theorem 2 identity -/

/-- The four actual local covariance families with the same
inclusion--exclusion signs as the source algebra.  Edges and length-two paths
are indexed once per reversal orbit. -/
noncomputable def inclusionExclusionCovariance
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  edgeEdgeCovarianceBlock T₁ T₂ - edgePathCovarianceBlock T₁ T₂ -
    pathEdgeCovarianceBlock T₁ T₂ + pathPathCovarianceBlock T₁ T₂

/-- The four covariance families settle to the raw `I'` quadratic. -/
theorem inclusionExclusionCovariance_eq_rawQuadratic
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    inclusionExclusionCovariance T₁ T₂ = rawQuadratic T₁ T₂ := by
  rw [inclusionExclusionCovariance,
    ← edgeEdgeAlgebraBlock_eq_covarianceBlock,
    ← edgePathAlgebraBlock_eq_covarianceBlock,
    ← pathEdgeAlgebraBlock_eq_covarianceBlock,
    ← pathPathAlgebraBlock_eq_covarianceBlock]
  change inclusionExclusionAlgebra T₁ T₂ = rawQuadratic T₁ T₂
  exact inclusionExclusionAlgebra_eq_rawQuadratic T₁ T₂

/-- Exact statement of Theorem 2: the four square families equal
the edge/side-pair inclusion--exclusion covariance, with one canonical
representative for every edge and path reversal orbit. -/
theorem sumOfSquaresRhs_eq_inclusionExclusionCovariance
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    sumOfSquaresRhs T₁ T₂ = inclusionExclusionCovariance T₁ T₂ := by
  rw [sumOfSquaresRhs_eq_rawQuadratic,
    inclusionExclusionCovariance_eq_rawQuadratic]

end QDFull
