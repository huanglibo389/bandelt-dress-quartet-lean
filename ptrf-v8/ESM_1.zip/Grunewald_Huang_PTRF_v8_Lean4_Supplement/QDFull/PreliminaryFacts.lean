import QDFull.Preliminaries

/-!
# Geometric facts behind the preliminary definitions

These are the proof obligations implicit in the preliminary definitions in
Section 2 of the locked manuscript: phylogenetic trees have no degree-two vertices, edge and side-pair
splits are genuinely displayed by the tree, and the distance-two index sets
have the advertised graph-theoretic meaning.
-/

open SimpleGraph

namespace QDFull

universe uX uV

namespace XTree

variable {X : Type uX} {V : Type uV} [Fintype X] [Fintype V]

/-- A phylogenetic `X`-tree in the paper's sense has no vertex of degree two. -/
theorem IsPhylogenetic.degree_ne_two (T : XTree X V)
    (hphy : T.IsPhylogenetic) (v : V) :
    Nat.card (T.graph.neighborSet v) ≠ 2 := by
  intro hdeg
  obtain ⟨x, hx⟩ := T.lowDegree_labelled v (by omega)
  have hleaf := hphy.2.1 x
  unfold IsLeaf at hleaf
  rw [hx] at hleaf
  omega

/-- Every edge split is displayed by the tree that defines it. -/
theorem displays_edgeSplit (T : XTree X V) {u v : V}
    (huv : T.graph.Adj u v) :
    T.DisplaysPartialSplit (T.edgeSplit u v) := by
  refine ⟨u, v, huv, ?_⟩
  rw [XTree.edgeSplit, displays_comm_representative]
  exact Or.inl ⟨Finset.Subset.rfl, Finset.Subset.rfl⟩

/-- For a path `u-v-w`, the branch leaving `v` toward `w` lies on the
`v`-side of the edge `uv`. -/
theorem edgeSide_sidePair_subset
    (T : XTree X V) {u v w : V}
    (huv : T.graph.Adj u v) (hvw : T.graph.Adj v w) (huw : u ≠ w) :
    T.edgeSide v w ⊆ T.edgeSide u v := by
  classical
  intro x hxw
  have hcover :
      x ∈ (T.edgeSide u v : Set X) ∪ (T.edgeSide v u : Set X) := by
    rw [T.edgeSide_set_union_reverse_of_adj huv]
    simp
  rcases hcover with hxv | hxu
  · exact hxv
  · exact False.elim <|
      (Finset.disjoint_left.mp (T.edgeSide_disjoint_sidePair huv hvw huw))
        hxu hxw

/-- Every length-two side-pair split is displayed by either adjacent edge of
the same tree. -/
theorem displays_sidePairSplit
    (T : XTree X V) {u v w : V}
    (huv : T.graph.Adj u v) (hvw : T.graph.Adj v w) (huw : u ≠ w) :
    T.DisplaysPartialSplit (T.sidePairSplit u v w) := by
  refine ⟨u, v, huv, ?_⟩
  rw [XTree.edgeSplit, XTree.sidePairSplit, displays_comm_representative]
  exact Or.inr ⟨Finset.Subset.rfl,
    T.edgeSide_sidePair_subset huv hvw huw⟩

@[simp] theorem isDistanceTwoPair_mk (T : XTree X V) (u v : V) :
    T.IsDistanceTwoPair s(u, v) ↔
      ∃ w : V, T.graph.Adj u w ∧ T.graph.Adj w v ∧ u ≠ v := by
  rfl

@[simp] theorem mem_distanceTwoPairs_mk (T : XTree X V) (u v : V) :
    s(u, v) ∈ T.distanceTwoPairs ↔
      ∃ w : V, T.graph.Adj u w ∧ T.graph.Adj w v ∧ u ≠ v := by
  rfl

@[simp] theorem directedEdges_reverse (T : XTree X V) (u v : V) :
    (u, v) ∈ T.directedEdges ↔ (v, u) ∈ T.directedEdges := by
  simp [T.mem_directedEdges, adj_comm]

@[simp] theorem orderedLengthTwoPaths_reverse (T : XTree X V)
    (u v w : V) :
    (u, v, w) ∈ T.orderedLengthTwoPaths ↔
      (w, v, u) ∈ T.orderedLengthTwoPaths := by
  simp only [T.mem_orderedLengthTwoPaths]
  constructor
  · rintro ⟨huv, hvw, huw⟩
    exact ⟨hvw.symm, huv.symm, huw.symm⟩
  · rintro ⟨hwv, hvu, hwu⟩
    exact ⟨hvu.symm, hwv.symm, hwu.symm⟩

end XTree

end QDFull
