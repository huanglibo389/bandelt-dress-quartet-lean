import QDFull.EventCovariance

/-!
# Event covariances as finite averages

The paper defines quartet covariance by probabilities on the ordered sample
space `Fin 4 → X`.  This file removes the probability notation without any
measure-theoretic shortcut: every probability is rewritten as the finite
average of its `0/1` indicator.  These identities are the summation interface
used in the proof of Theorem 1.
-/

open scoped BigOperators

namespace QDFull

universe uX uV₁ uV₂

/-- Real-valued indicator of a proposition. -/
noncomputable def propIndicator (p : Prop) : ℝ := by
  classical
  exact if p then 1 else 0

@[simp] theorem propIndicator_of_true {p : Prop} (hp : p) :
    propIndicator p = 1 := by
  simp [propIndicator, hp]

@[simp] theorem propIndicator_of_false {p : Prop} (hp : ¬p) :
    propIndicator p = 0 := by
  simp [propIndicator, hp]

/-- Indicators turn conjunction into multiplication. -/
theorem propIndicator_and (p q : Prop) :
    propIndicator (p ∧ q) = propIndicator p * propIndicator q := by
  classical
  by_cases hp : p <;> by_cases hq : q <;> simp [propIndicator, hp, hq]

/-- Summing proposition indicators over a finite source set counts exactly
the sources satisfying the proposition. -/
theorem sum_propIndicator_eq_card_filter
    {α : Type*} (S : Finset α) (p : α → Prop) [DecidablePred p] :
    (∑ x ∈ S, propIndicator (p x)) = ((S.filter p).card : ℝ) := by
  classical
  calc
    (∑ x ∈ S, propIndicator (p x)) =
        ∑ x ∈ S, if p x then (1 : ℝ) else 0 := by
      apply Finset.sum_congr rfl
      intro x hx
      simp [propIndicator]
    _ = ∑ x ∈ S.filter p, (1 : ℝ) := by
      rw [Finset.sum_filter]
    _ = ((S.filter p).card : ℝ) := by simp

/-- Average of a real-valued function on the ordered four-draw sample space. -/
noncomputable def fourDrawAverage {X : Type uX} [Fintype X]
    (f : (Fin 4 → X) → ℝ) : ℝ :=
  (∑ draw : Fin 4 → X, f draw) / (Fintype.card X : ℝ) ^ 4

/-- Pointwise contribution of a pair of partial splits to quartet covariance. -/
noncomputable def splitDrawContribution {X : Type uX}
    (P Q : PartialSplit X) (draw : Fin 4 → X) : ℝ :=
  propIndicator (SameSplitQuartetEvent P Q draw) -
    (1 / 2 : ℝ) * propIndicator (DifferentSplitQuartetEvent P Q draw)

/-- Pointwise contribution of a pair of trees to quartet covariance. -/
noncomputable def treeDrawContribution
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (draw : Fin 4 → X) : ℝ :=
  propIndicator (SameTreeQuartetEvent T₁ T₂ draw) -
    (1 / 2 : ℝ) * propIndicator (DifferentTreeQuartetEvent T₁ T₂ draw)

private theorem card_filter_eq_sum_indicator
    {α : Type*} [Fintype α] (p : α → Prop) [DecidablePred p] :
    ((Finset.univ.filter p).card : ℝ) =
      ∑ x : α, propIndicator (p x) := by
  classical
  calc
    ((Finset.univ.filter p).card : ℝ) =
        ∑ x ∈ Finset.univ.filter p, (1 : ℝ) := by simp
    _ = ∑ x ∈ (Finset.univ : Finset α), if p x then 1 else 0 := by
      rw [Finset.sum_filter]
    _ = ∑ x : α, propIndicator (p x) := by
      apply Finset.sum_congr rfl
      intro x hx
      simp [propIndicator]

/-- A four-draw probability is exactly the finite average of its indicator. -/
theorem fourDrawProbability_eq_average_indicator
    {X : Type uX} [Fintype X] (E : (Fin 4 → X) → Prop) :
    fourDrawProbability E = fourDrawAverage (fun draw => propIndicator (E draw)) := by
  classical
  rw [fourDrawProbability_eq]
  unfold fourDrawEventSet fourDrawAverage
  rw [card_filter_eq_sum_indicator]

/-- The event definition of split covariance is the average of the pointwise
same-minus-half-different contribution. -/
theorem splitQuartetCovarianceEvent_eq_average
    {X : Type uX} [Fintype X] (P Q : PartialSplit X) :
    splitQuartetCovarianceEvent P Q =
      fourDrawAverage (splitDrawContribution P Q) := by
  rw [splitQuartetCovarianceEvent, fourDrawProbability_eq_average_indicator,
    fourDrawProbability_eq_average_indicator]
  unfold fourDrawAverage splitDrawContribution
  rw [Finset.sum_sub_distrib, ← Finset.mul_sum]
  ring

/-- The event definition of tree covariance is the average of the pointwise
same-minus-half-different contribution. -/
theorem treeQuartetCovariance_eq_average
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    treeQuartetCovariance T₁ T₂ =
      fourDrawAverage (treeDrawContribution T₁ T₂) := by
  rw [treeQuartetCovariance, fourDrawProbability_eq_average_indicator,
    fourDrawProbability_eq_average_indicator]
  unfold fourDrawAverage treeDrawContribution
  rw [Finset.sum_sub_distrib, ← Finset.mul_sum]
  ring

/-- Finite averaging is additive. -/
theorem fourDrawAverage_add {X : Type uX} [Fintype X]
    (f g : (Fin 4 → X) → ℝ) :
    fourDrawAverage (fun draw => f draw + g draw) =
      fourDrawAverage f + fourDrawAverage g := by
  unfold fourDrawAverage
  rw [Finset.sum_add_distrib]
  ring

/-- Finite averaging commutes with subtraction. -/
theorem fourDrawAverage_sub {X : Type uX} [Fintype X]
    (f g : (Fin 4 → X) → ℝ) :
    fourDrawAverage (fun draw => f draw - g draw) =
      fourDrawAverage f - fourDrawAverage g := by
  unfold fourDrawAverage
  rw [Finset.sum_sub_distrib]
  ring

/-- Finite averaging commutes with scalar multiplication. -/
theorem fourDrawAverage_const_mul {X : Type uX} [Fintype X]
    (c : ℝ) (f : (Fin 4 → X) → ℝ) :
    fourDrawAverage (fun draw => c * f draw) = c * fourDrawAverage f := by
  unfold fourDrawAverage
  rw [← Finset.mul_sum]
  ring

/-- A finite source sum may be interchanged with the four-draw average. -/
theorem fourDrawAverage_sum
    {X : Type uX} [Fintype X] {ι : Type*}
    (S : Finset ι) (f : ι → (Fin 4 → X) → ℝ) :
    fourDrawAverage (fun draw => ∑ i ∈ S, f i draw) =
      ∑ i ∈ S, fourDrawAverage (f i) := by
  classical
  unfold fourDrawAverage
  rw [Finset.sum_comm]
  simp_rw [Finset.sum_div]

end QDFull
