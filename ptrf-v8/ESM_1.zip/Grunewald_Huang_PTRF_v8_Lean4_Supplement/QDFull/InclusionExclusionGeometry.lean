import QDFull.FiniteIndexSets
import QuartetV060.PathLineGraph

/-!
# Geometry behind the inclusion--exclusion theorem

The first theorem of the paper uses the following fact without suppressing
its graph-theoretic content: for a displayed partial split, the displaying
edges are the common segment of all paths joining one taxon on the first side
to one taxon on the second side.  This file proves that characterization for
the paper's general finite vertex-labelled `XTree`; labels may repeat and may
occur at internal vertices.
-/

open SimpleGraph

namespace QDFull

universe uX uV

/-! ## Order-theoretic facts about display -/

/-- Display is transitive: containment of the represented sides composes,
including all four possible choices of representatives of the two unordered
pairs. -/
theorem Displays.trans {X : Type uX} {P Q R : PartialSplit X}
    (hPQ : Displays P Q) (hQR : Displays Q R) :
    Displays P R := by
  classical
  rcases hPQ with ⟨A, B, C, D, rfl, hQ, hCD⟩
  rcases hQR with ⟨C', D', E, F, hQ', rfl, hEF⟩
  have hQQ : s(C, D) = s(C', D') := hQ.symm.trans hQ'
  rw [Sym2.eq_iff] at hQQ
  rcases hQQ with hQQ | hQQ <;>
    rcases hCD with hCD | hCD <;>
    rcases hEF with hEF | hEF
  all_goals
    subst_vars
    rw [displays_comm_representative]
    simp only [Finset.subset_iff] at *
    aesop

/-! ## Universe-polymorphic path-line-graph lemmas -/

namespace PathGeometry

universe uW

/-- In a tree, a nonempty intersection of two connected subgraphs is
connected.  This universe-polymorphic version is needed for the paper's
general vertex type. -/
theorem connected_inf_of_isTree
    {W : Type uW} [DecidableEq W]
    {G : SimpleGraph W}
    (hG : G.IsTree) {H K : G.Subgraph}
    (hH : H.Connected) (hK : K.Connected)
    (hne : (H ⊓ K).verts.Nonempty) :
    (H ⊓ K).Connected := by
  rw [SimpleGraph.Subgraph.connected_iff_forall_exists_walk_subgraph]
  refine ⟨hne, ?_⟩
  intro u v hu hv
  obtain ⟨pH, hpH⟩ :=
    (SimpleGraph.Subgraph.preconnected_iff_forall_exists_walk_subgraph H).mp
      hH.preconnected hu.1 hv.1
  obtain ⟨pK, hpK⟩ :=
    (SimpleGraph.Subgraph.preconnected_iff_forall_exists_walk_subgraph K).mp
      hK.preconnected hu.2 hv.2
  have heq : pH.toPath = pK.toPath :=
    hG.isAcyclic.path_unique pH.toPath pK.toPath
  refine ⟨(pH.toPath : G.Walk u v), ?_⟩
  apply le_inf
  · exact SimpleGraph.Walk.toSubgraph_bypass_le_toSubgraph.trans hpH
  · rw [heq]
    exact SimpleGraph.Walk.toSubgraph_bypass_le_toSubgraph.trans hpK

private theorem edgeReachable_of_walk
    {W : Type uW} {G : SimpleGraph W}
    {u v : W} (p : G.Walk u v)
    (e f : G.edgeSet)
    (hu : u ∈ (e : Sym2 W))
    (hv : v ∈ (f : Sym2 W)) :
    G.lineGraph.Reachable e f := by
  induction p generalizing e f with
  | nil =>
      by_cases hef : e = f
      · exact hef ▸ .refl e
      · exact
          (SimpleGraph.lineGraph_adj_iff_exists.mpr
            ⟨hef, _, hu, hv⟩).reachable
  | @cons u w v h p ih =>
      let g : G.edgeSet := ⟨s(u, w), h⟩
      have heg : G.lineGraph.Reachable e g := by
        by_cases heg : e = g
        · exact heg ▸ .refl e
        · exact
            (SimpleGraph.lineGraph_adj_iff_exists.mpr
              ⟨heg, u, hu, by simp [g]⟩).reachable
      exact heg.trans (ih g f (by simp [g]) hv)

/-- The line graph of a connected graph with at least one edge is connected. -/
theorem lineGraph_connected
    {W : Type uW} {G : SimpleGraph W}
    (hG : G.Connected) (hne : G.edgeSet.Nonempty) :
    G.lineGraph.Connected := by
  letI : Nonempty G.edgeSet := hne.to_subtype
  refine ⟨?_⟩
  intro e f
  rcases e with ⟨e, he⟩
  induction e using Sym2.inductionOn with
  | _ x y =>
      rcases f with ⟨f, hf⟩
      induction f using Sym2.inductionOn with
      | _ z w =>
          rcases hG.preconnected x z with ⟨p⟩
          exact edgeReachable_of_walk p
            ⟨s(x, y), he⟩ ⟨s(z, w), hf⟩ (by simp) (by simp)

/-- An injective graph homomorphism induces one on line graphs. -/
def lineGraphHomOfInjectiveHom
    {W Z : Type*} {G : SimpleGraph W} {G' : SimpleGraph Z}
    (f : G →g G') (hinj : Function.Injective f) :
    G.lineGraph →g G'.lineGraph where
  toFun := f.mapEdgeSet
  map_rel' := by
    intro e g heg
    rw [SimpleGraph.lineGraph_adj_iff_exists] at heg ⊢
    rcases heg with ⟨hne, v, hve, hvg⟩
    refine
      ⟨fun h => hne (SimpleGraph.Hom.mapEdgeSet.injective f hinj h),
        f v, ?_, ?_⟩
    · change f v ∈ Sym2.map f e.1
      exact Sym2.mem_map.mpr ⟨v, hve, rfl⟩
    · change f v ∈ Sym2.map f g.1
      exact Sym2.mem_map.mpr ⟨v, hvg, rfl⟩

theorem lineGraphHomOfInjectiveHom_injective
    {W Z : Type*} {G : SimpleGraph W} {G' : SimpleGraph Z}
    (f : G →g G') (hinj : Function.Injective f) :
    Function.Injective (lineGraphHomOfInjectiveHom f hinj) :=
  SimpleGraph.Hom.mapEdgeSet.injective f hinj

theorem lineGraph_isAcyclic_of_injectiveHom
    {W Z : Type*} {G : SimpleGraph W} {G' : SimpleGraph Z}
    (f : G →g G') (hinj : Function.Injective f)
    (hG' : G'.lineGraph.IsAcyclic) :
    G.lineGraph.IsAcyclic :=
  hG'.comap (lineGraphHomOfInjectiveHom f hinj)
    (lineGraphHomOfInjectiveHom_injective f hinj)

/-- Forget the subtype wrappers on an edge of a subgraph's coefficient graph. -/
def coeEdgeMap
    {W : Type uW} {G : SimpleGraph W}
    (H : G.Subgraph) (e : H.coe.edgeSet) : H.edgeSet :=
  ⟨Sym2.map (fun x : H.verts => (x : W)) e.1, by
    rcases e with ⟨e, he⟩
    induction e using Sym2.inductionOn with
    | _ x y =>
        change s((x : W), (y : W)) ∈ H.edgeSet
        exact (SimpleGraph.Subgraph.mem_edgeSet).2 he⟩

theorem coeEdgeMap_injective
    {W : Type uW} {G : SimpleGraph W} (H : G.Subgraph) :
    Function.Injective (coeEdgeMap H) := by
  intro e f hef
  apply Subtype.ext
  have hmap :
      Sym2.map (fun x : H.verts => (x : W)) e.1 =
        Sym2.map (fun x : H.verts => (x : W)) f.1 :=
    Subtype.mk.inj hef
  exact Sym2.map.injective Subtype.val_injective hmap

theorem coeEdgeMap_surjective
    {W : Type uW} {G : SimpleGraph W} (H : G.Subgraph) :
    Function.Surjective (coeEdgeMap H) := by
  rintro ⟨e, he⟩
  induction e using Sym2.inductionOn with
  | _ x y =>
      have hxy : H.Adj x y :=
        (SimpleGraph.Subgraph.mem_edgeSet).1 he
      let e' : H.coe.edgeSet :=
        ⟨s(⟨x, hxy.fst_mem⟩, ⟨y, hxy.snd_mem⟩), hxy⟩
      refine ⟨e', Subtype.ext ?_⟩
      simp [coeEdgeMap, e']

/-- Edges of a subgraph's coefficient graph are canonically its ambient
subgraph edges. -/
noncomputable def coeEdgeEquiv
    {W : Type uW} {G : SimpleGraph W} (H : G.Subgraph) :
    H.coe.edgeSet ≃ H.edgeSet :=
  Equiv.ofBijective (coeEdgeMap H)
    ⟨coeEdgeMap_injective H, coeEdgeMap_surjective H⟩

/-- The line graph of the subgraph traced by a simple path is acyclic. -/
theorem lineGraph_toSubgraph_isAcyclic
    {W : Type uW} [DecidableEq W]
    {G : SimpleGraph W} {u v : W}
    {p : G.Walk u v} (hp : p.IsPath) :
    p.toSubgraph.coe.lineGraph.IsAcyclic :=
  (hp.pathGraphIsoToSubgraph.lineGraph.isAcyclic_iff).mp
    (QuartetV060.PathLineGraph.lineGraph_pathGraph_succ_isAcyclic p.length)

end PathGeometry

namespace XTree

variable {X : Type uX} {V : Type uV} [Fintype X] [Fintype V]

/-- The unique simple path between two vertices of an `XTree`. -/
noncomputable def vertexPath (T : XTree X V) (x y : V) :
    T.graph.Walk x y :=
  Classical.choose (T.isTree.existsUnique_path x y)

/-- The chosen vertex path is simple. -/
theorem vertexPath_isPath (T : XTree X V) (x y : V) :
    (T.vertexPath x y).IsPath :=
  (Classical.choose_spec (T.isTree.existsUnique_path x y)).1

/-- An edge belongs to the unique path from `x` to `y` exactly when deleting
that edge disconnects `x` from `y`. -/
theorem mem_vertexPath_edges_iff_not_reachable_delete
    (T : XTree X V) (x y : V) (e : Sym2 V) :
    e ∈ (T.vertexPath x y).edges ↔
      ¬(T.graph.deleteEdges {e}).Reachable x y := by
  classical
  constructor
  · intro hmem hreach
    rcases hreach with ⟨w⟩
    let wG : T.graph.Walk x y :=
      w.transfer T.graph (fun f hf =>
        SimpleGraph.edgeSet_mono (SimpleGraph.deleteEdges_le _)
          (w.edges_subset_edgeSet hf))
    have hpath : (wG.toPath : T.graph.Walk x y).IsPath :=
      wG.toPath.property
    have heq : T.vertexPath x y = (wG.toPath : T.graph.Walk x y) :=
      (T.isTree.existsUnique_path x y).unique
        (T.vertexPath_isPath x y) hpath
    have hmem' : e ∈ w.edges := by
      have hsub := wG.edges_toPath_subset_edges
      have hmemPath : e ∈ (wG.toPath : T.graph.Walk x y).edges := by
        simpa [heq] using hmem
      have hmemWG : e ∈ wG.edges := hsub hmemPath
      simpa [wG, SimpleGraph.Walk.edges_transfer] using hmemWG
    have hedge := w.edges_subset_edgeSet hmem'
    simpa using hedge
  · intro hnot
    exact (T.vertexPath x y).mem_edges_of_not_reachable_deleteEdges hnot

/-- The unique path between two taxa, allowing repeated labels and labels at
internal vertices exactly as in the paper's `XTree` definition. -/
noncomputable def taxonPath (T : XTree X V) (a b : X) :
    T.graph.Walk (T.label a) (T.label b) :=
  T.vertexPath (T.label a) (T.label b)

theorem taxonPath_isPath (T : XTree X V) (a b : X) :
    (T.taxonPath a b).IsPath :=
  T.vertexPath_isPath (T.label a) (T.label b)

/-- An actual tree edge lies on the path between two taxa exactly when the
taxa lie in opposite components of that edge. -/
theorem edge_mem_taxonPath_iff_opposite_sides
    (T : XTree X V) {u v : V} (huv : T.graph.Adj u v) (a b : X) :
    s(u, v) ∈ (T.taxonPath a b).edges ↔
      ((a ∈ T.edgeSide u v ∧ b ∈ T.edgeSide v u) ∨
        (a ∈ T.edgeSide v u ∧ b ∈ T.edgeSide u v)) := by
  let H : SimpleGraph V := T.graph.deleteEdges {s(u, v)}
  have haCover : a ∈ T.edgeSide u v ∨ a ∈ T.edgeSide v u := by
    have h := T.mem_vertexSide_or_mem_vertexSide_reverse_of_adj huv (T.label a)
    rcases h with h | h
    · exact Or.inl ((T.mem_edgeSide u v a).2 h)
    · exact Or.inr ((T.mem_edgeSide v u a).2 h)
  have hbCover : b ∈ T.edgeSide u v ∨ b ∈ T.edgeSide v u := by
    have h := T.mem_vertexSide_or_mem_vertexSide_reverse_of_adj huv (T.label b)
    rcases h with h | h
    · exact Or.inl ((T.mem_edgeSide u v b).2 h)
    · exact Or.inr ((T.mem_edgeSide v u b).2 h)
  have hdisj := T.edgeSide_disjoint_reverse_of_adj huv
  change s(u, v) ∈ (T.vertexPath (T.label a) (T.label b)).edges ↔ _
  rw [T.mem_vertexPath_edges_iff_not_reachable_delete]
  constructor
  · intro hnot
    rcases haCover with haV | haU <;> rcases hbCover with hbV | hbU
    · exfalso
      apply hnot
      have hva : H.Reachable v (T.label a) := by
        simpa [H] using (T.mem_edgeSide u v a).mp haV
      have hvb : H.Reachable v (T.label b) := by
        simpa [H] using (T.mem_edgeSide u v b).mp hbV
      exact hva.symm.trans hvb
    · exact Or.inl ⟨haV, hbU⟩
    · exact Or.inr ⟨haU, hbV⟩
    · exfalso
      apply hnot
      have hua : H.Reachable u (T.label a) := by
        simpa only [H, Sym2.eq_swap] using
          (T.mem_edgeSide v u a).mp haU
      have hub : H.Reachable u (T.label b) := by
        simpa only [H, Sym2.eq_swap] using
          (T.mem_edgeSide v u b).mp hbU
      exact hua.symm.trans hub
  · rintro (⟨haV, hbU⟩ | ⟨haU, hbV⟩) hreach
    · have hbV : b ∈ T.edgeSide u v := by
        apply (T.mem_edgeSide u v b).mpr
        have hva : H.Reachable v (T.label a) := by
          simpa [H] using (T.mem_edgeSide u v a).mp haV
        exact hva.trans hreach
      exact (Finset.disjoint_left.mp hdisj) hbV hbU
    · have haV : a ∈ T.edgeSide u v := by
        apply (T.mem_edgeSide u v a).mpr
        have hvb : H.Reachable v (T.label b) := by
          simpa [H] using (T.mem_edgeSide u v b).mp hbV
        exact hvb.trans hreach.symm
      exact (Finset.disjoint_left.mp hdisj) haV haU

/-- For nonempty represented sides, an edge split displays `A | B` exactly
when that edge lies on every path joining a taxon of `A` to a taxon of `B`.
This is the precise common-path formulation used in Theorem 1. -/
theorem displays_edgeSplit_iff_mem_all_cross_paths
    (T : XTree X V) {u v : V} (huv : T.graph.Adj u v)
    (A B : Finset X) (hA : A.Nonempty) (hB : B.Nonempty) :
    Displays (T.edgeSplit u v) s(A, B) ↔
      ∀ a ∈ A, ∀ b ∈ B, s(u, v) ∈ (T.taxonPath a b).edges := by
  classical
  rw [edgeSplit, displays_comm_representative]
  constructor
  · intro h a ha b hb
    apply (T.edge_mem_taxonPath_iff_opposite_sides huv a b).2
    rcases h with h | h
    · exact Or.inl ⟨h.1 ha, h.2 hb⟩
    · exact Or.inr ⟨h.1 ha, h.2 hb⟩
  · intro h
    obtain ⟨a₀, ha₀⟩ := hA
    obtain ⟨b₀, hb₀⟩ := hB
    have h₀ :=
      (T.edge_mem_taxonPath_iff_opposite_sides huv a₀ b₀).1
        (h a₀ ha₀ b₀ hb₀)
    have hdisj := T.edgeSide_disjoint_reverse_of_adj huv
    rcases h₀ with hforward | hreverse
    · left
      constructor
      · intro a ha
        have hab :=
          (T.edge_mem_taxonPath_iff_opposite_sides huv a b₀).1
            (h a ha b₀ hb₀)
        rcases hab with hab | hab
        · exact hab.1
        · exact False.elim
            ((Finset.disjoint_left.mp hdisj) hab.2 hforward.2)
      · intro b hb
        have hab :=
          (T.edge_mem_taxonPath_iff_opposite_sides huv a₀ b).1
            (h a₀ ha₀ b hb)
        rcases hab with hab | hab
        · exact hab.2
        · exact False.elim
            ((Finset.disjoint_left.mp hdisj) hforward.1 hab.1)
    · right
      constructor
      · intro a ha
        have hab :=
          (T.edge_mem_taxonPath_iff_opposite_sides huv a b₀).1
            (h a ha b₀ hb₀)
        rcases hab with hab | hab
        · exact False.elim
            ((Finset.disjoint_left.mp hdisj) hreverse.2 hab.2)
        · exact hab.1
      · intro b hb
        have hab :=
          (T.edge_mem_taxonPath_iff_opposite_sides huv a₀ b).1
            (h a₀ ha₀ b hb)
        rcases hab with hab | hab
        · exact False.elim
            ((Finset.disjoint_left.mp hdisj) hab.1 hreverse.1)
        · exact hab.2

/-- A length-two side-pair split displays a genuine partial split exactly
when each of its two constituent edge splits displays it.  Nonemptiness of
both represented sides rules out the two inconsistent orientations at the
middle vertex. -/
theorem displays_sidePairSplit_iff_displays_both_edges
    (T : XTree X V) {u v w : V}
    (huv : T.graph.Adj u v) (hvw : T.graph.Adj v w) (huw : u ≠ w)
    {P : PartialSplit X} (hP : IsPartialSplit P) :
    Displays (T.sidePairSplit u v w) P ↔
      Displays (T.edgeSplit u v) P ∧ Displays (T.edgeSplit v w) P := by
  classical
  rcases hP with ⟨C, D, rfl, hC, hD, hCD⟩
  let U := T.edgeSide v u
  let W := T.edgeSide v w
  let Uc := T.edgeSide u v
  let Wc := T.edgeSide w v
  have hUW : Disjoint U W := by
    simpa [U, W] using T.edgeSide_disjoint_sidePair huv hvw huw
  have hUunion : (U : Set X) ∪ (Uc : Set X) = Set.univ := by
    simpa [U, Uc] using T.edgeSide_set_union_reverse_of_adj huv.symm
  have hWunion : (W : Set X) ∪ (Wc : Set X) = Set.univ := by
    simpa [W, Wc] using T.edgeSide_set_union_reverse_of_adj hvw
  have hUdisj : Disjoint U Uc := by
    simpa [U, Uc] using T.edgeSide_disjoint_reverse_of_adj huv.symm
  have hWdisj : Disjoint W Wc := by
    simpa [W, Wc] using T.edgeSide_disjoint_reverse_of_adj hvw
  have hWsubUc : W ⊆ Uc := by
    simpa [W, Uc] using T.edgeSide_sidePair_subset huv hvw huw
  have hUsubWc : U ⊆ Wc := by
    simpa [U, Wc] using
      T.edgeSide_sidePair_subset hvw.symm huv.symm huw.symm
  change Displays s(U, W) s(C, D) ↔
    Displays s(Uc, U) s(C, D) ∧ Displays s(W, Wc) s(C, D)
  simp only [displays_comm_representative]
  constructor
  · rintro (h | h)
    · exact ⟨Or.inr ⟨h.1, h.2.trans hWsubUc⟩,
        Or.inr ⟨h.1.trans hUsubWc, h.2⟩⟩
    · exact ⟨Or.inl ⟨h.1.trans hWsubUc, h.2⟩,
        Or.inl ⟨h.1, h.2.trans hUsubWc⟩⟩
  · rintro ⟨hUV, hVW⟩
    rcases hUV with hUV | hUV <;> rcases hVW with hVW | hVW
    · exact Or.inr ⟨hVW.1, hUV.2⟩
    · obtain ⟨d, hd⟩ := hD
      exact False.elim
        ((Finset.disjoint_left.mp hUW) (hUV.2 hd) (hVW.2 hd))
    · obtain ⟨c, hc⟩ := hC
      exact False.elim
        ((Finset.disjoint_left.mp hUW) (hUV.1 hc) (hVW.1 hc))
    · exact Or.inl ⟨hUV.1, hVW.2⟩

end XTree

end QDFull
