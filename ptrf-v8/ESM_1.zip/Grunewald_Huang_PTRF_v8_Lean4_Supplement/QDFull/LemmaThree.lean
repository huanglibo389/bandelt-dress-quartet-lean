import QDFull.CoefficientLowerBound
import QDFull.TheoremOne

/-!
# Lemma 6: the global split-covariance lower bound

This file completes both assertions of Lemma 6.  The local coefficient
estimate proved in `CoefficientLowerBound` is multiplied by the corresponding
edge-coordinate square, summed over the two directed-edge sets, and converted
to split covariance using `Q(S_{tu},S_{vw}) = 6 X^2`.  The other three square
families in Theorem 2 are proved nonnegative term by term; no positivity is
hidden in a scalar surrogate.
-/

open scoped BigOperators

namespace QDFull

universe uX uV₁ uV₂

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]
  [DecidableEq X] [DecidableEq V₁] [DecidableEq V₂]

/-- Every summand in the first square family is nonnegative. -/
theorem qSquareFamily_nonneg
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    0 ≤ qSquareFamily T₁ T₂ := by
  classical
  unfold qSquareFamily qDiagonalBlock
  apply Finset.sum_nonneg
  intro e₁ he₁
  apply Finset.sum_nonneg
  intro e₂ he₂
  apply Finset.sum_nonneg
  intro z₁ hz₁
  apply Finset.sum_nonneg
  intro z₂ hz₂
  exact mul_nonneg
    (qCoefficient_nonneg_of_adj T₁ T₂
      e₁.1 e₁.2 z₁.1 z₁.2
      ((T₂.mem_directedEdgeFinset e₂.1 e₂.2).1 he₂)
      z₂.1 z₂.2)
    (sq_nonneg _)

/-- Every summand in the column-path square family is nonnegative. -/
theorem sSquareFamily_nonneg
    [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    0 ≤ sSquareFamily T₁ T₂ := by
  classical
  unfold sSquareFamily sCoefficient
  apply Finset.sum_nonneg
  intro e₁ he₁
  apply Finset.sum_nonneg
  intro p₂ hp₂
  apply Finset.sum_nonneg
  intro z₁ hz₁
  have hp := (T₂.mem_canonicalLengthTwoPathFinset
    p₂.1 p₂.2.1 p₂.2.2).1 hp₂
  exact mul_nonneg
    (qCoefficient_nonneg_of_adj T₁ T₂
      e₁.1 e₁.2 z₁.1 z₁.2 hp.1 p₂.2.2 p₂.1)
    (sq_nonneg _)

/-- Every summand in the row-path square family is nonnegative. -/
theorem bSquareFamily_nonneg
    [LinearOrder V₁]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    0 ≤ bSquareFamily T₁ T₂ := by
  classical
  unfold bSquareFamily bCoefficient
  apply Finset.sum_nonneg
  intro p₁ hp₁
  apply Finset.sum_nonneg
  intro e₂ he₂
  apply Finset.sum_nonneg
  intro z₂ hz₂
  exact mul_nonneg
    (qCoefficient_nonneg_of_adj T₁ T₂
      p₁.1 p₁.2.1 p₁.2.2 p₁.1
      ((T₂.mem_directedEdgeFinset e₂.1 e₂.2).1 he₂)
      z₂.1 z₂.2)
    (sq_nonneg _)

/-- Every summand in the path--path square family is nonnegative. -/
theorem pSquareFamily_nonneg
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    0 ≤ pSquareFamily T₁ T₂ := by
  classical
  unfold pSquareFamily pCoefficient
  apply Finset.sum_nonneg
  intro p₁ hp₁
  apply Finset.sum_nonneg
  intro p₂ hp₂
  have hp := (T₂.mem_canonicalLengthTwoPathFinset
    p₂.1 p₂.2.1 p₂.2.2).1 hp₂
  exact mul_nonneg
    (qCoefficient_nonneg_of_adj T₁ T₂
      p₁.1 p₁.2.1 p₁.2.2 p₁.1 hp.1 p₂.2.2 p₂.1)
    (sq_nonneg _)

/-- The edge-pair sum on the right-hand side of the second assertion of
Lemma 6, including the paper's factor `1/2`. -/
noncomputable def lemma3GlobalLowerBound
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  ∑ e₁ ∈ T₁.directedEdgeFinset,
    ∑ e₂ ∈ T₂.directedEdgeFinset,
      (1 / 2 : ℝ) * T₂.columnMass e₂.1 e₂.2 e₂.2 *
        T₁.rowMass e₁.1 e₁.2 e₁.2 *
        splitQuartetCovariance
          (T₁.edgeSplit e₁.1 e₁.2) (T₂.edgeSplit e₂.1 e₂.2)

/-- The locally scaled version of the same sum.  Its factor `1/12` is the
product of the coefficient bound `1/2` and the conversion `X² = Q/6`. -/
noncomputable def lemma3ScaledLowerBound
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  ∑ e₁ ∈ T₁.directedEdgeFinset,
    ∑ e₂ ∈ T₂.directedEdgeFinset,
      (1 / 12 : ℝ) * T₂.columnMass e₂.1 e₂.2 e₂.2 *
        T₁.rowMass e₁.1 e₁.2 e₁.2 *
        splitQuartetCovariance
          (T₁.edgeSplit e₁.1 e₁.2) (T₂.edgeSplit e₂.1 e₂.2)

private theorem lemma3_local_square_lower_bound
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w) :
    (1 / 12 : ℝ) * T₂.columnMass v w w * T₁.rowMass t u u *
        splitQuartetCovariance (T₁.edgeSplit t u) (T₂.edgeSplit v w) ≤
      lemma3CoefficientSum T₁ T₂ t u v w *
        xCoefficient T₁ T₂ t u v w ^ 2 := by
  have h := mul_le_mul_of_nonneg_right
    (lemma3_coefficient_lower_bound T₁ T₂ htu hvw)
    (sq_nonneg (xCoefficient T₁ T₂ t u v w))
  rw [edgeSplit_quartetCovariance_eq T₁ T₂ htu hvw]
  calc
    (1 / 12 : ℝ) * T₂.columnMass v w w * T₁.rowMass t u u *
          (6 * xCoefficient T₁ T₂ t u v w ^ 2) =
        ((1 / 2 : ℝ) * T₂.columnMass v w w * T₁.rowMass t u u) *
          xCoefficient T₁ T₂ t u v w ^ 2 := by ring
    _ ≤ lemma3CoefficientSum T₁ T₂ t u v w *
          xCoefficient T₁ T₂ t u v w ^ 2 := h

/-- After summing the direct coefficient bound over all directed edge pairs,
the scaled split-covariance sum is bounded by the first square family. -/
theorem lemma3ScaledLowerBound_le_qSquareFamily
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    lemma3ScaledLowerBound T₁ T₂ ≤ qSquareFamily T₁ T₂ := by
  classical
  unfold lemma3ScaledLowerBound qSquareFamily qDiagonalBlock
  apply Finset.sum_le_sum
  intro e₁ he₁
  apply Finset.sum_le_sum
  intro e₂ he₂
  have hlocal := lemma3_local_square_lower_bound T₁ T₂
    ((T₁.mem_directedEdgeFinset e₁.1 e₁.2).1 he₁)
    ((T₂.mem_directedEdgeFinset e₂.1 e₂.2).1 he₂)
  calc
    (1 / 12 : ℝ) * T₂.columnMass e₂.1 e₂.2 e₂.2 *
          T₁.rowMass e₁.1 e₁.2 e₁.2 *
          splitQuartetCovariance
            (T₁.edgeSplit e₁.1 e₁.2) (T₂.edgeSplit e₂.1 e₂.2) ≤
        lemma3CoefficientSum T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2 *
          xCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2 ^ 2 := hlocal
    _ = ∑ z₁ ∈ T₁.indexIFinset e₁.1 e₁.2,
          ∑ z₂ ∈ T₂.indexIFinset e₂.1 e₂.2,
            qCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2
                z₁.1 z₁.2 z₂.1 z₂.2 *
              xCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2 ^ 2 := by
      unfold lemma3CoefficientSum
      rw [Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro z₁ hz₁
      rw [Finset.sum_mul]

theorem lemma3GlobalLowerBound_eq_six_scaled
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    lemma3GlobalLowerBound T₁ T₂ =
      6 * lemma3ScaledLowerBound T₁ T₂ := by
  classical
  unfold lemma3GlobalLowerBound lemma3ScaledLowerBound
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro e₁ he₁
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro e₂ he₂
  ring

/-- Exact second assertion of Lemma 6.  This is obtained from the first square
family by the local coefficient estimate; the other three square families are
discarded only after their termwise nonnegativity has been proved above. -/
theorem lemma3_global_split_covariance_lower_bound
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    lemma3GlobalLowerBound T₁ T₂ ≤ treeQuartetCovariance T₁ T₂ := by
  have hscaled := lemma3ScaledLowerBound_le_qSquareFamily T₁ T₂
  have hs := sSquareFamily_nonneg T₁ T₂
  have hb := bSquareFamily_nonneg T₁ T₂
  have hp := pSquareFamily_nonneg T₁ T₂
  have hmain := sumOfSquaresRhs_eq_treeQuartetCovariance_div_six T₁ T₂
  rw [lemma3GlobalLowerBound_eq_six_scaled]
  unfold sumOfSquaresRhs at hmain
  nlinarith

end QDFull
