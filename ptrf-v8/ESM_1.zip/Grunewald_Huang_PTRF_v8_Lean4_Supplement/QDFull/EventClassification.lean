import QDFull.FourDrawCounting

/-!
# Classification of the split events on four ordered draws

The paper defines induction by allowing all twenty-four permutations of four
draw positions.  There are only three unordered `2+2` pairings.  We first
prove that finite classification once and then use it to reduce the verbal
same/different-quartet events to disjoint cell patterns.
-/

namespace QDFull

universe uX

/-- The partial split obtained from one ordered pairing of four positions. -/
noncomputable def drawPairSplit {X : Type uX}
    (draw : Fin 4 → X) (i j k l : Fin 4) : PartialSplit X := by
  classical
  exact s({draw i, draw j}, {draw k, draw l})

/-- The three unordered pairings of four positions are exhaustive. -/
private theorem perm_pairing_classification :
    ∀ π : Equiv.Perm (Fin 4),
      s(({π (0 : Fin 4), π 1} : Finset (Fin 4)), {π 2, π 3}) =
          s(({0, 1} : Finset (Fin 4)), {2, 3}) ∨
      s(({π (0 : Fin 4), π 1} : Finset (Fin 4)), {π 2, π 3}) =
          s(({0, 2} : Finset (Fin 4)), {1, 3}) ∨
      s(({π (0 : Fin 4), π 1} : Finset (Fin 4)), {π 2, π 3}) =
          s(({0, 3} : Finset (Fin 4)), {1, 2}) := by
  decide

private theorem map_pairing_equality {X : Type uX} [Fintype X]
    (draw : Fin 4 → X) {i j k l i' j' k' l' : Fin 4}
    (h : s(({i, j} : Finset (Fin 4)), {k, l}) =
      s(({i', j'} : Finset (Fin 4)), {k', l'})) :
    drawPairSplit draw i j k l = drawPairSplit draw i' j' k' l' := by
  classical
  have hm := congrArg (Sym2.map (fun S : Finset (Fin 4) => S.image draw)) h
  simpa [drawPairSplit] using hm

/-- A canonical version of `Induces`, using the three unordered pairings
instead of an existential permutation. -/
noncomputable def CanonicalInduces {X : Type uX} [Fintype X]
    (draw : Fin 4 → X) (P : PartialSplit X) : Prop :=
  IsPartialSplit P ∧
    (P = drawPairSplit draw 0 1 2 3 ∨
     P = drawPairSplit draw 0 2 1 3 ∨
     P = drawPairSplit draw 0 3 1 2)

/-- Exact elimination of the twenty-four-permutation definition of
`Induces`. -/
theorem induces_iff_canonical {X : Type uX} [Fintype X]
    (draw : Fin 4 → X) (P : PartialSplit X) :
    Induces draw P ↔ CanonicalInduces draw P := by
  classical
  constructor
  · rintro ⟨hP, π, hπ⟩
    refine ⟨hP, ?_⟩
    rcases perm_pairing_classification π with h | h | h
    · left
      exact hπ.trans (map_pairing_equality draw h)
    · right; left
      exact hπ.trans (map_pairing_equality draw h)
    · right; right
      exact hπ.trans (map_pairing_equality draw h)
  · rintro ⟨hP, h | h | h⟩
    · refine ⟨hP, Equiv.refl (Fin 4), ?_⟩
      simpa [drawPairSplit] using h
    · refine ⟨hP, Equiv.swap (1 : Fin 4) 2, ?_⟩
      simpa [drawPairSplit, Equiv.swap_apply_def] using h
    · refine ⟨hP, Equiv.swap (1 : Fin 4) 3, ?_⟩
      simpa [drawPairSplit, Equiv.swap_apply_def, Finset.pair_comm] using h

/-- If a two-pair draw split is displayed by a split with disjoint sides, then
the draw split is itself a partial split. -/
theorem drawPairSplit_isPartialSplit_of_displays
    {X : Type uX} [Fintype X]
    (draw : Fin 4 → X) (A B : Finset X) (i j k l : Fin 4)
    (hAB : Disjoint A B)
    (hdisplay : Displays s(A, B) (drawPairSplit draw i j k l)) :
    IsPartialSplit (drawPairSplit draw i j k l) := by
  classical
  refine ⟨{draw i, draw j}, {draw k, draw l}, rfl, by simp, by simp, ?_⟩
  change Displays s(A, B) s({draw i, draw j}, {draw k, draw l}) at hdisplay
  rw [displays_comm_representative] at hdisplay
  rcases hdisplay with h | h
  · exact hAB.mono h.1 h.2
  · exact hAB.symm.mono h.1 h.2

/-- The verbal same-quartet event is the disjunction over the three canonical
pairings, with the same paired split displayed by both partial splits. -/
theorem sameSplitQuartetEvent_iff_canonical
    {X : Type uX} [Fintype X]
    (draw : Fin 4 → X) (A B C D : Finset X) (hAB : Disjoint A B) :
    SameSplitQuartetEvent s(A, B) s(C, D) draw ↔
      (Displays s(A, B) (drawPairSplit draw 0 1 2 3) ∧
        Displays s(C, D) (drawPairSplit draw 0 1 2 3)) ∨
      (Displays s(A, B) (drawPairSplit draw 0 2 1 3) ∧
        Displays s(C, D) (drawPairSplit draw 0 2 1 3)) ∨
      (Displays s(A, B) (drawPairSplit draw 0 3 1 2) ∧
        Displays s(C, D) (drawPairSplit draw 0 3 1 2)) := by
  constructor
  · rintro ⟨R, hR, hAR, hCR⟩
    have hc := (induces_iff_canonical draw R).mp hR
    rcases hc.2 with h | h | h
    · left
      simpa [h] using And.intro hAR hCR
    · right; left
      simpa [h] using And.intro hAR hCR
    · right; right
      simpa [h] using And.intro hAR hCR
  · rintro (h | h | h)
    · refine ⟨drawPairSplit draw 0 1 2 3, ?_, h.1, h.2⟩
      apply (induces_iff_canonical _ _).mpr
      exact ⟨drawPairSplit_isPartialSplit_of_displays
        draw A B 0 1 2 3 hAB h.1, Or.inl rfl⟩
    · refine ⟨drawPairSplit draw 0 2 1 3, ?_, h.1, h.2⟩
      apply (induces_iff_canonical _ _).mpr
      exact ⟨drawPairSplit_isPartialSplit_of_displays
        draw A B 0 2 1 3 hAB h.1, Or.inr (Or.inl rfl)⟩
    · refine ⟨drawPairSplit draw 0 3 1 2, ?_, h.1, h.2⟩
      apply (induces_iff_canonical _ _).mpr
      exact ⟨drawPairSplit_isPartialSplit_of_displays
        draw A B 0 3 1 2 hAB h.1, Or.inr (Or.inr rfl)⟩

/-- Exact cell-pattern form of the verbal same-quartet event.  The two terms
are the two diagonals of the `2 × 2` intersection table. -/
theorem sameSplitQuartetEvent_iff_cellDraws
    {X : Type uX} [Fintype X] [DecidableEq X]
    (draw : Fin 4 → X) (A B C D : Finset X) (hAB : Disjoint A B) :
    SameSplitQuartetEvent s(A, B) s(C, D) draw ↔
      draw ∈ twoTwoDraws (A ∩ C) (B ∩ D) ∪
        twoTwoDraws (A ∩ D) (B ∩ C) := by
  rw [sameSplitQuartetEvent_iff_canonical draw A B C D hAB,
    Finset.mem_union, mem_twoTwoDraws_iff_six,
    mem_twoTwoDraws_iff_six]
  simp only [drawPairSplit, displays_comm_representative,
    Finset.insert_subset_iff, Finset.singleton_subset_iff,
    Finset.mem_inter]
  aesop

private theorem diagonal_cells_disjoint
    {X : Type uX} [Fintype X] [DecidableEq X]
    (A B C D : Finset X) (hAB : Disjoint A B) :
    Disjoint (A ∩ C) (B ∩ D) := by
  classical
  rw [Finset.disjoint_left] at hAB ⊢
  intro x hxAC hxBD
  rw [Finset.mem_inter] at hxAC hxBD
  exact hAB hxAC.1 hxBD.1

private theorem offDiagonal_cells_disjoint
    {X : Type uX} [Fintype X] [DecidableEq X]
    (A B C D : Finset X) (hAB : Disjoint A B) :
    Disjoint (A ∩ D) (B ∩ C) := by
  classical
  rw [Finset.disjoint_left] at hAB ⊢
  intro x hxAD hxBC
  rw [Finset.mem_inter] at hxAD hxBC
  exact hAB hxAD.1 hxBC.1

private theorem two_diagonal_draw_sets_disjoint
    {X : Type uX} [Fintype X] [DecidableEq X]
    (A B C D : Finset X) (hAB : Disjoint A B) (hCD : Disjoint C D) :
    Disjoint
      (twoTwoDraws (A ∩ C) (B ∩ D))
      (twoTwoDraws (A ∩ D) (B ∩ C)) := by
  classical
  rw [Finset.disjoint_left]
  intro draw hdiag hoff
  rw [mem_twoTwoDraws_iff_six] at hdiag hoff
  simp only [Finset.mem_inter] at hdiag hoff
  rw [Finset.disjoint_left] at hAB hCD
  aesop

/-- Exact number of ordered four-draw samples contributing to the positive
(`same quartet`) part of the split covariance. -/
theorem card_sameSplitQuartetEvent
    {X : Type uX} [Fintype X] [DecidableEq X]
    (A B C D : Finset X) (hAB : Disjoint A B) (hCD : Disjoint C D) :
    (fourDrawEventSet (SameSplitQuartetEvent s(A, B) s(C, D))).card =
      6 * (A ∩ C).card ^ 2 * (B ∩ D).card ^ 2 +
      6 * (A ∩ D).card ^ 2 * (B ∩ C).card ^ 2 := by
  classical
  have hevent :
      fourDrawEventSet (SameSplitQuartetEvent s(A, B) s(C, D)) =
        twoTwoDraws (A ∩ C) (B ∩ D) ∪
          twoTwoDraws (A ∩ D) (B ∩ C) := by
    ext draw
    simp [fourDrawEventSet,
      sameSplitQuartetEvent_iff_cellDraws draw A B C D hAB]
  rw [hevent, Finset.card_union_of_disjoint
    (two_diagonal_draw_sets_disjoint A B C D hAB hCD),
    card_twoTwoDraws _ _ (diagonal_cells_disjoint A B C D hAB),
    card_twoTwoDraws _ _ (offDiagonal_cells_disjoint A B C D hAB)]

/-- The four entries of the `2 × 2` intersection table, ordered as
`A∩C, A∩D, B∩C, B∩D`. -/
def fourIntersectionCells
    {X : Type uX} [DecidableEq X]
    (A B C D : Finset X) : Fin 4 → Finset X :=
  ![A ∩ C, A ∩ D, B ∩ C, B ∩ D]

private theorem fourIntersectionCells_pairwiseDisjoint
    {X : Type uX} [Fintype X] [DecidableEq X]
    (A B C D : Finset X) (hAB : Disjoint A B) (hCD : Disjoint C D) :
    (Set.univ : Set (Fin 4)).PairwiseDisjoint
      (fourIntersectionCells A B C D) := by
  rw [Finset.disjoint_left] at hAB hCD
  intro i _ j _ hij
  fin_cases i <;> fin_cases j <;>
    simp_all [fourIntersectionCells, Finset.disjoint_left] <;> aesop

private theorem pairing01_ne_pairing02_of_displays
    {X : Type uX} [Fintype X]
    (draw : Fin 4 → X) (A B C D : Finset X)
    (hAB : Disjoint A B) (hCD : Disjoint C D)
    (hP : Displays s(A, B) (drawPairSplit draw 0 1 2 3))
    (hQ : Displays s(C, D) (drawPairSplit draw 0 2 1 3)) :
    drawPairSplit draw 0 1 2 3 ≠ drawPairSplit draw 0 2 1 3 := by
  classical
  intro heq
  change s({draw 0, draw 1}, {draw 2, draw 3}) =
    s({draw 0, draw 2}, {draw 1, draw 3}) at heq
  rw [Sym2.eq_iff] at heq
  simp [drawPairSplit, displays_comm_representative,
    Finset.insert_subset_iff, Finset.singleton_subset_iff] at hP hQ
  rw [Finset.disjoint_left] at hAB hCD
  rcases heq with heq | heq
  · have hm : draw 1 ∈ ({draw 0, draw 2} : Finset X) := by
      rw [← heq.1]
      simp
    simp at hm
    aesop
  · have hm : draw 0 ∈ ({draw 1, draw 3} : Finset X) := by
      rw [← heq.1]
      simp
    simp at hm
    aesop

private theorem pairing01_ne_pairing03_of_displays
    {X : Type uX} [Fintype X]
    (draw : Fin 4 → X) (A B C D : Finset X)
    (hAB : Disjoint A B) (hCD : Disjoint C D)
    (hP : Displays s(A, B) (drawPairSplit draw 0 1 2 3))
    (hQ : Displays s(C, D) (drawPairSplit draw 0 3 1 2)) :
    drawPairSplit draw 0 1 2 3 ≠ drawPairSplit draw 0 3 1 2 := by
  classical
  intro heq
  change s({draw 0, draw 1}, {draw 2, draw 3}) =
    s({draw 0, draw 3}, {draw 1, draw 2}) at heq
  rw [Sym2.eq_iff] at heq
  simp [drawPairSplit, displays_comm_representative,
    Finset.insert_subset_iff, Finset.singleton_subset_iff] at hP hQ
  rw [Finset.disjoint_left] at hAB hCD
  rcases heq with heq | heq
  · have hm : draw 1 ∈ ({draw 0, draw 3} : Finset X) := by
      rw [← heq.1]
      simp
    simp at hm
    aesop
  · have hm : draw 0 ∈ ({draw 1, draw 2} : Finset X) := by
      rw [← heq.1]
      simp
    simp at hm
    aesop

private theorem pairing02_ne_pairing03_of_displays
    {X : Type uX} [Fintype X]
    (draw : Fin 4 → X) (A B C D : Finset X)
    (hAB : Disjoint A B) (hCD : Disjoint C D)
    (hP : Displays s(A, B) (drawPairSplit draw 0 2 1 3))
    (hQ : Displays s(C, D) (drawPairSplit draw 0 3 1 2)) :
    drawPairSplit draw 0 2 1 3 ≠ drawPairSplit draw 0 3 1 2 := by
  classical
  intro heq
  change s({draw 0, draw 2}, {draw 1, draw 3}) =
    s({draw 0, draw 3}, {draw 1, draw 2}) at heq
  rw [Sym2.eq_iff] at heq
  simp [drawPairSplit, displays_comm_representative,
    Finset.insert_subset_iff, Finset.singleton_subset_iff] at hP hQ
  rw [Finset.disjoint_left] at hAB hCD
  rcases heq with heq | heq
  · have hm : draw 2 ∈ ({draw 0, draw 3} : Finset X) := by
      rw [← heq.1]
      simp
    simp at hm
    aesop
  · have hm : draw 0 ∈ ({draw 1, draw 2} : Finset X) := by
      rw [← heq.1]
      simp
    simp at hm
    aesop

/-- The different-quartet event consists exactly of the six ordered pairs of
distinct canonical pairings.  Under disjoint split sides, the inequality of
the resulting draw splits follows from the two display conditions; it is not
an additional counting assumption. -/
theorem differentSplitQuartetEvent_iff_canonical
    {X : Type uX} [Fintype X]
    (draw : Fin 4 → X) (A B C D : Finset X)
    (hAB : Disjoint A B) (hCD : Disjoint C D) :
    DifferentSplitQuartetEvent s(A, B) s(C, D) draw ↔
      (Displays s(A, B) (drawPairSplit draw 0 1 2 3) ∧
        Displays s(C, D) (drawPairSplit draw 0 2 1 3)) ∨
      (Displays s(A, B) (drawPairSplit draw 0 1 2 3) ∧
        Displays s(C, D) (drawPairSplit draw 0 3 1 2)) ∨
      (Displays s(A, B) (drawPairSplit draw 0 2 1 3) ∧
        Displays s(C, D) (drawPairSplit draw 0 1 2 3)) ∨
      (Displays s(A, B) (drawPairSplit draw 0 2 1 3) ∧
        Displays s(C, D) (drawPairSplit draw 0 3 1 2)) ∨
      (Displays s(A, B) (drawPairSplit draw 0 3 1 2) ∧
        Displays s(C, D) (drawPairSplit draw 0 1 2 3)) ∨
      (Displays s(A, B) (drawPairSplit draw 0 3 1 2) ∧
        Displays s(C, D) (drawPairSplit draw 0 2 1 3)) := by
  constructor
  · rintro ⟨R, S, hR, hS, hPR, hQS, hne⟩
    have hcR := (induces_iff_canonical draw R).mp hR
    have hcS := (induces_iff_canonical draw S).mp hS
    rcases hcR.2 with hR | hR | hR <;>
      rcases hcS.2 with hS | hS | hS
    · exact (hne (hR.trans hS.symm)).elim
    · left
      simpa [hR, hS] using And.intro hPR hQS
    · right; left
      simpa [hR, hS] using And.intro hPR hQS
    · right; right; left
      simpa [hR, hS] using And.intro hPR hQS
    · exact (hne (hR.trans hS.symm)).elim
    · right; right; right; left
      simpa [hR, hS] using And.intro hPR hQS
    · right; right; right; right; left
      simpa [hR, hS] using And.intro hPR hQS
    · right; right; right; right; right
      simpa [hR, hS] using And.intro hPR hQS
    · exact (hne (hR.trans hS.symm)).elim
  · rintro (h | h | h | h | h | h)
    · refine ⟨drawPairSplit draw 0 1 2 3,
        drawPairSplit draw 0 2 1 3, ?_, ?_, h.1, h.2, ?_⟩
      · exact (induces_iff_canonical _ _).mpr
          ⟨drawPairSplit_isPartialSplit_of_displays
            draw A B 0 1 2 3 hAB h.1, Or.inl rfl⟩
      · exact (induces_iff_canonical _ _).mpr
          ⟨drawPairSplit_isPartialSplit_of_displays
            draw C D 0 2 1 3 hCD h.2, Or.inr (Or.inl rfl)⟩
      · exact pairing01_ne_pairing02_of_displays
          draw A B C D hAB hCD h.1 h.2
    · refine ⟨drawPairSplit draw 0 1 2 3,
        drawPairSplit draw 0 3 1 2, ?_, ?_, h.1, h.2, ?_⟩
      · exact (induces_iff_canonical _ _).mpr
          ⟨drawPairSplit_isPartialSplit_of_displays
            draw A B 0 1 2 3 hAB h.1, Or.inl rfl⟩
      · exact (induces_iff_canonical _ _).mpr
          ⟨drawPairSplit_isPartialSplit_of_displays
            draw C D 0 3 1 2 hCD h.2, Or.inr (Or.inr rfl)⟩
      · exact pairing01_ne_pairing03_of_displays
          draw A B C D hAB hCD h.1 h.2
    · refine ⟨drawPairSplit draw 0 2 1 3,
        drawPairSplit draw 0 1 2 3, ?_, ?_, h.1, h.2, ?_⟩
      · exact (induces_iff_canonical _ _).mpr
          ⟨drawPairSplit_isPartialSplit_of_displays
            draw A B 0 2 1 3 hAB h.1, Or.inr (Or.inl rfl)⟩
      · exact (induces_iff_canonical _ _).mpr
          ⟨drawPairSplit_isPartialSplit_of_displays
            draw C D 0 1 2 3 hCD h.2, Or.inl rfl⟩
      · exact (pairing01_ne_pairing02_of_displays
          draw C D A B hCD hAB h.2 h.1).symm
    · refine ⟨drawPairSplit draw 0 2 1 3,
        drawPairSplit draw 0 3 1 2, ?_, ?_, h.1, h.2, ?_⟩
      · exact (induces_iff_canonical _ _).mpr
          ⟨drawPairSplit_isPartialSplit_of_displays
            draw A B 0 2 1 3 hAB h.1, Or.inr (Or.inl rfl)⟩
      · exact (induces_iff_canonical _ _).mpr
          ⟨drawPairSplit_isPartialSplit_of_displays
            draw C D 0 3 1 2 hCD h.2, Or.inr (Or.inr rfl)⟩
      · exact pairing02_ne_pairing03_of_displays
          draw A B C D hAB hCD h.1 h.2
    · refine ⟨drawPairSplit draw 0 3 1 2,
        drawPairSplit draw 0 1 2 3, ?_, ?_, h.1, h.2, ?_⟩
      · exact (induces_iff_canonical _ _).mpr
          ⟨drawPairSplit_isPartialSplit_of_displays
            draw A B 0 3 1 2 hAB h.1, Or.inr (Or.inr rfl)⟩
      · exact (induces_iff_canonical _ _).mpr
          ⟨drawPairSplit_isPartialSplit_of_displays
            draw C D 0 1 2 3 hCD h.2, Or.inl rfl⟩
      · exact (pairing01_ne_pairing03_of_displays
          draw C D A B hCD hAB h.2 h.1).symm
    · refine ⟨drawPairSplit draw 0 3 1 2,
        drawPairSplit draw 0 2 1 3, ?_, ?_, h.1, h.2, ?_⟩
      · exact (induces_iff_canonical _ _).mpr
          ⟨drawPairSplit_isPartialSplit_of_displays
            draw A B 0 3 1 2 hAB h.1, Or.inr (Or.inr rfl)⟩
      · exact (induces_iff_canonical _ _).mpr
          ⟨drawPairSplit_isPartialSplit_of_displays
            draw C D 0 2 1 3 hCD h.2, Or.inr (Or.inl rfl)⟩
      · exact (pairing02_ne_pairing03_of_displays
          draw C D A B hCD hAB h.2 h.1).symm

/-- Exact cell-pattern form of the different-quartet event: each of the four
intersection cells is hit once. -/
theorem differentSplitQuartetEvent_iff_cellDraws
    {X : Type uX} [Fintype X] [DecidableEq X]
    (draw : Fin 4 → X) (A B C D : Finset X)
    (hAB : Disjoint A B) (hCD : Disjoint C D) :
    DifferentSplitQuartetEvent s(A, B) s(C, D) draw ↔
      draw ∈ oneEachDraws (fourIntersectionCells A B C D) := by
  constructor
  · rw [differentSplitQuartetEvent_iff_canonical draw A B C D hAB hCD]
    intro h
    rw [mem_oneEachDraws_iff_hits_all _
      (fourIntersectionCells_pairwiseDisjoint A B C D hAB hCD)]
    rcases h with h | h | h | h | h | h
    all_goals
      simp [drawPairSplit, displays_comm_representative,
        Finset.insert_subset_iff, Finset.singleton_subset_iff] at h
      intro j
      fin_cases j <;>
        simp [fourIntersectionCells, Fin.exists_fin_succ] <;> aesop
  · rw [mem_oneEachDraws]
    rintro ⟨π, hπ⟩
    let ρ : Equiv.Perm (Fin 4) := π.symm
    have h₀ := hπ (ρ 0)
    have h₁ := hπ (ρ 1)
    have h₂ := hπ (ρ 2)
    have h₃ := hπ (ρ 3)
    simp [ρ, fourIntersectionCells] at h₀ h₁ h₂ h₃
    let R : PartialSplit X :=
      drawPairSplit draw (ρ 0) (ρ 1) (ρ 2) (ρ 3)
    let S : PartialSplit X :=
      drawPairSplit draw (ρ 0) (ρ 2) (ρ 1) (ρ 3)
    have hPR : Displays s(A, B) R := by
      dsimp [R, drawPairSplit]
      rw [displays_comm_representative]
      left
      simp only [Finset.insert_subset_iff, Finset.singleton_subset_iff]
      aesop
    have hQS : Displays s(C, D) S := by
      dsimp [S, drawPairSplit]
      rw [displays_comm_representative]
      left
      simp only [Finset.insert_subset_iff, Finset.singleton_subset_iff]
      aesop
    have hRpartial : IsPartialSplit R := by
      exact drawPairSplit_isPartialSplit_of_displays
        draw A B (ρ 0) (ρ 1) (ρ 2) (ρ 3) hAB hPR
    have hSpartial : IsPartialSplit S := by
      exact drawPairSplit_isPartialSplit_of_displays
        draw C D (ρ 0) (ρ 2) (ρ 1) (ρ 3) hCD hQS
    have hRind : Induces draw R := by
      refine ⟨hRpartial, ρ, ?_⟩
      rfl
    have hSind : Induces draw S := by
      refine ⟨hSpartial, (Equiv.swap (1 : Fin 4) 2).trans ρ, ?_⟩
      simp [S, drawPairSplit, Equiv.swap_apply_def]
    let draw' : Fin 4 → X := fun i => draw (ρ i)
    have hPR' : Displays s(A, B) (drawPairSplit draw' 0 1 2 3) := by
      simpa [draw', R, drawPairSplit] using hPR
    have hQS' : Displays s(C, D) (drawPairSplit draw' 0 2 1 3) := by
      simpa [draw', S, drawPairSplit] using hQS
    have hRS : R ≠ S := by
      have hne := pairing01_ne_pairing02_of_displays
        draw' A B C D hAB hCD hPR' hQS'
      simpa [draw', R, S, drawPairSplit] using hne
    exact ⟨R, S, hRind, hSind, hPR, hQS, hRS⟩

/-- Exact number of ordered four-draw samples contributing to the negative
(`different quartets`) part of the split covariance. -/
theorem card_differentSplitQuartetEvent
    {X : Type uX} [Fintype X] [DecidableEq X]
    (A B C D : Finset X) (hAB : Disjoint A B) (hCD : Disjoint C D) :
    (fourDrawEventSet
      (DifferentSplitQuartetEvent s(A, B) s(C, D))).card =
      24 * (A ∩ C).card * (A ∩ D).card *
        (B ∩ C).card * (B ∩ D).card := by
  classical
  have hevent :
      fourDrawEventSet
          (DifferentSplitQuartetEvent s(A, B) s(C, D)) =
        oneEachDraws (fourIntersectionCells A B C D) := by
    ext draw
    simp [fourDrawEventSet,
      differentSplitQuartetEvent_iff_cellDraws draw A B C D hAB hCD]
  rw [hevent, card_oneEachDraws _
    (fourIntersectionCells_pairwiseDisjoint A B C D hAB hCD)]
  simp [fourIntersectionCells, Fin.prod_univ_succ]
  simp only [Nat.mul_assoc]

end QDFull
