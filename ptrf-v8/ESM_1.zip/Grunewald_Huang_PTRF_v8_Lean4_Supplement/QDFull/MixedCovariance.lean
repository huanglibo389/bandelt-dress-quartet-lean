import QDFull.CoefficientPartitions
import QDTauStar.Algebra

/-!
# Mixed edge--path covariance identities

This file formalizes the local determinant calculations in the proof of
Theorem 2 in the locked manuscript.  No determinant entry or complementary edge-side
mass is suppressed.
-/

open scoped BigOperators

namespace QDFull

universe uX uV₁ uV₂

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]

/-- The exact determinant displayed for an edge in the first tree and a
length-two path in the second tree. -/
theorem edgeSidePair_quartetCovariance_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v₁ w v₂ : V₂}
    (htu : T₁.graph.Adj t u)
    (hv₁w : T₂.graph.Adj v₁ w) (hwv₂ : T₂.graph.Adj w v₂)
    (hv₁v₂ : v₁ ≠ v₂) :
    splitQuartetCovariance
        (T₁.edgeSplit t u) (T₂.sidePairSplit v₁ w v₂) =
      6 *
        (jointMass T₁ T₂ t u v₁ w t v₂ *
              jointMass T₁ T₂ u t v₂ w u v₁ -
            jointMass T₁ T₂ t u v₂ w t v₁ *
              jointMass T₁ T₂ u t v₁ w u v₂) ^ 2 := by
  change orientedSplitCovariance
      (T₁.edgeSide t u) (T₁.edgeSide u t)
      (T₂.edgeSide w v₁) (T₂.edgeSide w v₂) = _
  unfold orientedSplitCovariance orientedSplitDeterminant
  unfold jointMass jointBlock
  rw [T₁.rowBlock_of_adj t htu.symm,
    T₁.rowBlock_of_adj u htu,
    T₂.columnBlock_of_adj v₂ hv₁w.symm,
    T₂.columnBlock_of_adj v₁ hwv₂]
  ring

/-- The determinant in `edgeSidePair_quartetCovariance_eq` is the negative of
the weighted neighboring-edge contrast in the manuscript.  The sign disappears
after squaring. -/
theorem edgeSidePair_determinant_eq_neg_weighted_x
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v₁ w v₂ : V₂}
    (htu : T₁.graph.Adj t u)
    (hv₁w : T₂.graph.Adj v₁ w) (hwv₂ : T₂.graph.Adj w v₂) :
    jointMass T₁ T₂ t u v₁ w t v₂ *
          jointMass T₁ T₂ u t v₂ w u v₁ -
        jointMass T₁ T₂ t u v₂ w t v₁ *
          jointMass T₁ T₂ u t v₁ w u v₂ =
      -(T₂.columnMass v₁ w v₂ *
            xCoefficient T₁ T₂ t u v₁ w -
          T₂.columnMass v₂ w v₁ *
            xCoefficient T₁ T₂ t u v₂ w) := by
  let a := jointMass T₁ T₂ t u v₁ w t v₁
  let b := jointMass T₁ T₂ t u v₁ w t v₂
  let c := jointMass T₁ T₂ u t v₁ w u v₁
  let d := jointMass T₁ T₂ u t v₁ w u v₂
  let r₀ := T₁.rowMass t u t
  let r₁ := T₁.rowMass u t u
  let c₁ := T₂.columnMass v₂ w v₁
  let c₂ := T₂.columnMass v₁ w v₂
  have hb_parent :
      jointMass T₁ T₂ t u v₂ w t v₁ = a := by rfl
  have hc_parent :
      jointMass T₁ T₂ u t v₂ w u v₁ = c := by rfl
  have hd_parent :
      jointMass T₁ T₂ u t v₂ w u v₂ = d := by rfl
  have hrow : r₁ + r₀ = 1 := by
    dsimp [r₁, r₀]
    exact rowMass_edgeSide_partition T₁ htu
  have hc₁ : c + a = c₁ := by
    dsimp [c, a, c₁]
    change jointMass T₁ T₂ u t v₁ w u v₁ +
        jointMass T₁ T₂ t u v₁ w t v₁ =
      T₂.columnMass v₁ w v₁
    simpa [add_comm] using
      (jointMass_edgeSide_partition_row T₁ T₂ htu v₁ w v₁)
  have hc₂ : d + b = c₂ := by
    dsimp [d, b, c₂]
    simpa [add_comm] using
      (jointMass_edgeSide_partition_row T₁ T₂ htu v₁ w v₂)
  have hcomp₀₁ :
      jointMass T₁ T₂ t u w v₁ t w = r₀ - a := by
    have h := jointMass_edgeSide_partition_column
      T₁ T₂ t u t hv₁w
    dsimp [r₀, a]
    linarith
  have hcomp₁₁ :
      jointMass T₁ T₂ u t w v₁ u w = r₁ - c := by
    have h := jointMass_edgeSide_partition_column
      T₁ T₂ u t u hv₁w
    dsimp [r₁, c]
    linarith
  have hcomp₀₂ :
      jointMass T₁ T₂ t u w v₂ t w = r₀ - b := by
    have h := jointMass_edgeSide_partition_column
      T₁ T₂ t u t hwv₂.symm
    have hb_self : jointMass T₁ T₂ t u v₂ w t v₂ = b := by rfl
    rw [hb_self] at h
    dsimp [r₀, b]
    linarith
  have hcomp₁₂ :
      jointMass T₁ T₂ u t w v₂ u w = r₁ - d := by
    have h := jointMass_edgeSide_partition_column
      T₁ T₂ u t u hwv₂.symm
    rw [hd_parent] at h
    dsimp [r₁, d]
    linarith
  have hx₁ :
      xCoefficient T₁ T₂ t u v₁ w = a * r₁ - r₀ * c := by
    unfold xCoefficient
    rw [hcomp₁₁, hcomp₀₁]
    dsimp [a, c]
    ring
  have hx₂ :
      xCoefficient T₁ T₂ t u v₂ w = b * r₁ - r₀ * d := by
    unfold xCoefficient
    have hb_self : jointMass T₁ T₂ t u v₂ w t v₂ = b := by rfl
    rw [hb_self, hd_parent, hcomp₁₂, hcomp₀₂]
    dsimp [b, d]
    ring
  rw [hb_parent, hc_parent, hx₁, hx₂]
  change b * c - a * d = -(c₂ * (a * r₁ - r₀ * c) -
    c₁ * (b * r₁ - r₀ * d))
  rw [← hc₁, ← hc₂]
  have hr₁ : r₁ = 1 - r₀ := by linarith [hrow]
  rw [hr₁]
  ring

/-- Equation `(edge-path-square)` in the paper. -/
theorem edgeSidePair_quartetCovariance_weighted_x_square
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v₁ w v₂ : V₂}
    (htu : T₁.graph.Adj t u)
    (hv₁w : T₂.graph.Adj v₁ w) (hwv₂ : T₂.graph.Adj w v₂)
    (hv₁v₂ : v₁ ≠ v₂) :
    (1 / 6 : ℝ) *
        splitQuartetCovariance
          (T₁.edgeSplit t u) (T₂.sidePairSplit v₁ w v₂) =
      (T₂.columnMass v₁ w v₂ *
            xCoefficient T₁ T₂ t u v₁ w -
          T₂.columnMass v₂ w v₁ *
            xCoefficient T₁ T₂ t u v₂ w) ^ 2 := by
  rw [edgeSidePair_quartetCovariance_eq T₁ T₂ htu hv₁w hwv₂ hv₁v₂,
    edgeSidePair_determinant_eq_neg_weighted_x T₁ T₂ htu hv₁w hwv₂]
  ring

/-- The row-oriented coefficient block in the proof of Theorem 2.  The first
row index ranges over the side of `t--u` containing `u`, while the
second ranges over the complete branch partition at `u`. -/
noncomputable def qRowOrientationSum
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u : V₁) (v w z y : V₂) : ℝ :=
  ∑ u' ∈ T₁.awayBranchIndices t u,
    ∑ u'' ∈ T₁.branchIndices u,
      qCoefficient T₁ T₂ t u v w u' u'' z y

/-- Closed form of one row-oriented coefficient block.  This is the exact
finite partition calculation behind the two coefficient identities used in
the proof of Theorem 2. -/
theorem qRowOrientationSum_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w)
    (z y : V₂) :
    qRowOrientationSum T₁ T₂ t u v w z y =
      (1 / 2 : ℝ) * T₂.columnMass v w y *
        (jointMass T₁ T₂ u t v w u z +
          T₂.columnMass v w z *
            jointMass T₁ T₂ u t v w u v /
              T₂.columnMass v w v) := by
  classical
  have hfactor := sum_symmetric_q_kernel
    (T₁.awayBranchIndices t u) (T₁.branchIndices u)
    ({z} : Finset V₂) ({y} : Finset V₂)
    (fun i j => jointMass T₁ T₂ t u v w i j)
    (fun j => T₂.columnMass v w j) v
  simp only [Finset.sum_singleton] at hfactor
  unfold qRowOrientationSum qCoefficient
  rw [hfactor]
  rw [sum_jointMass_awayRowBranches T₁ T₂ htu v w z,
    sum_jointMass_allRowBranches T₁ T₂ t u v w v,
    sum_jointMass_allRowBranches T₁ T₂ t u v w z,
    sum_jointMass_awayRowBranches T₁ T₂ htu v w v]
  have hcv : T₂.columnMass v w v ≠ 0 :=
    ne_of_gt (T₂.columnMass_pos_of_adj hvw)
  field_simp [hcv]

/-- Combining the two orientations of one row edge turns the two first-index
branch families into a partition of all taxa.  Consequently the coefficient
sum is exactly the product of the two selected column masses. -/
theorem two_qRowOrientationSums_eq_columnMass_mul
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w)
    (z y : V₂) :
    qRowOrientationSum T₁ T₂ t u v w z y +
        qRowOrientationSum T₁ T₂ u t v w z y =
      T₂.columnMass v w z * T₂.columnMass v w y := by
  rw [qRowOrientationSum_eq T₁ T₂ htu hvw z y,
    qRowOrientationSum_eq T₁ T₂ htu.symm hvw z y]
  let Auz := jointMass T₁ T₂ u t v w u z
  let Atz := jointMass T₁ T₂ t u v w t z
  let Auv := jointMass T₁ T₂ u t v w u v
  let Atv := jointMass T₁ T₂ t u v w t v
  let cz := T₂.columnMass v w z
  let cy := T₂.columnMass v w y
  let cv := T₂.columnMass v w v
  change
    (1 / 2 : ℝ) * cy * (Auz + cz * Auv / cv) +
        (1 / 2 : ℝ) * cy * (Atz + cz * Atv / cv) = cz * cy
  have hz : Auz + Atz = cz := by
    dsimp [Auz, Atz, cz]
    exact jointMass_edgeSide_partition_row T₁ T₂ htu v w z
  have hv : Auv + Atv = cv := by
    dsimp [Auv, Atv, cv]
    exact jointMass_edgeSide_partition_row T₁ T₂ htu v w v
  have hcv : cv ≠ 0 := by
    dsimp [cv]
    exact ne_of_gt (T₂.columnMass_pos_of_adj hvw)
  calc
    (1 / 2 : ℝ) * cy * (Auz + cz * Auv / cv) +
          (1 / 2 : ℝ) * cy * (Atz + cz * Atv / cv) =
        (1 / 2 : ℝ) * cy *
          ((Auz + Atz) + cz * (Auv + Atv) / cv) := by ring
    _ = (1 / 2 : ℝ) * cy * (cz + cz * cv / cv) := by
      rw [hz, hv]
    _ = cz * cy := by
      field_simp [hcv]
      ring

/-- The diagonal `q`-coefficient identity used in the proof of Theorem 2. -/
theorem edgePath_q_diagonal_sum_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w)
    (z : V₂) :
    (∑ u' ∈ T₁.awayBranchIndices t u,
        ∑ u'' ∈ T₁.branchIndices u,
          qCoefficient T₁ T₂ t u v w u' u'' z z) +
      (∑ t' ∈ T₁.awayBranchIndices u t,
        ∑ t'' ∈ T₁.branchIndices t,
          qCoefficient T₁ T₂ u t v w t' t'' z z) =
      T₂.columnMass v w z ^ 2 := by
  change qRowOrientationSum T₁ T₂ t u v w z z +
      qRowOrientationSum T₁ T₂ u t v w z z = _
  rw [two_qRowOrientationSums_eq_columnMass_mul T₁ T₂ htu hvw]
  ring

/-- The mixed `s`-coefficient identity used in the proof of Theorem 2. -/
theorem edgePath_s_mixed_sum_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w)
    (z : V₂) :
    (∑ u' ∈ T₁.awayBranchIndices t u,
        ∑ u'' ∈ T₁.branchIndices u,
          sCoefficient T₁ T₂ t u u' u'' v w z) +
      (∑ t' ∈ T₁.awayBranchIndices u t,
        ∑ t'' ∈ T₁.branchIndices t,
          sCoefficient T₁ T₂ u t t' t'' v w z) =
      T₂.columnMass v w z * T₂.columnMass v w v := by
  change qRowOrientationSum T₁ T₂ t u v w z v +
      qRowOrientationSum T₁ T₂ u t v w z v = _
  exact two_qRowOrientationSums_eq_columnMass_mul T₁ T₂ htu hvw z v

/-- Fully expanded local edge--path settlement behind equation
`(edge-path)`.  It includes both directed row-edge copies, both diagonal
`q`-families, and the mixed `s`-family. -/
theorem edgePath_local_qs_decomposition
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v₁ w v₂ : V₂}
    (htu : T₁.graph.Adj t u)
    (hv₁w : T₂.graph.Adj v₁ w) (hwv₂ : T₂.graph.Adj w v₂)
    (hv₁v₂ : v₁ ≠ v₂) :
    (1 / 6 : ℝ) *
        splitQuartetCovariance
          (T₁.edgeSplit t u) (T₂.sidePairSplit v₁ w v₂) =
      (qRowOrientationSum T₁ T₂ t u v₁ w v₂ v₂ +
          qRowOrientationSum T₁ T₂ u t v₁ w v₂ v₂) *
            xCoefficient T₁ T₂ t u v₁ w ^ 2 +
      (qRowOrientationSum T₁ T₂ t u v₂ w v₁ v₁ +
          qRowOrientationSum T₁ T₂ u t v₂ w v₁ v₁) *
            xCoefficient T₁ T₂ t u v₂ w ^ 2 -
      2 *
        (qRowOrientationSum T₁ T₂ t u v₁ w v₂ v₁ +
          qRowOrientationSum T₁ T₂ u t v₁ w v₂ v₁) *
            xCoefficient T₁ T₂ t u v₁ w *
              xCoefficient T₁ T₂ t u v₂ w := by
  rw [edgeSidePair_quartetCovariance_weighted_x_square T₁ T₂ htu hv₁w hwv₂
      hv₁v₂,
    two_qRowOrientationSums_eq_columnMass_mul T₁ T₂ htu hv₁w,
    two_qRowOrientationSums_eq_columnMass_mul T₁ T₂ htu hwv₂.symm,
    two_qRowOrientationSums_eq_columnMass_mul T₁ T₂ htu hv₁w]
  have hcparent :
      T₂.columnMass v₁ w v₁ = T₂.columnMass v₂ w v₁ := by rfl
  rw [hcparent]
  ring

end QDFull
