import QDFull.MassPartitionIdentities
import QDFull.SplitCovariance

/-!
# Coefficient partitions in the sum-of-squares proof

This file formalizes the coefficient bookkeeping preceding Theorem 2 in the
locked manuscript.  In particular, it proves rather than assumes that the
four oriented `q`-blocks attached to one unordered edge pair have total mass
one.
-/

open scoped BigOperators

namespace QDFull

universe uX uV₁ uV₂

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]

/-- The first of the four oriented sums in the paper's coefficient partition,
written with the finite branch-index sets. -/
noncomputable def qOrientationSum
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u : V₁) (v w : V₂) : ℝ :=
  ∑ u' ∈ T₁.awayBranchIndices t u,
    ∑ u'' ∈ T₁.branchIndices u,
      ∑ w' ∈ T₂.awayBranchIndices v w,
        ∑ w'' ∈ T₂.branchIndices w,
          qCoefficient T₁ T₂ t u v w u' u'' w' w''

/-- Every individual `q` coefficient used at an actual column edge is
nonnegative. -/
theorem qCoefficient_nonneg_of_adj
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' u'' : V₁) {v w : V₂}
    (hvw : T₂.graph.Adj v w) (w' w'' : V₂) :
    0 ≤ qCoefficient T₁ T₂ t u v w u' u'' w' w'' := by
  have hcpos : 0 < T₂.columnMass v w v :=
    T₂.columnMass_pos_of_adj hvw
  unfold qCoefficient
  have ha₁ : 0 ≤ jointMass T₁ T₂ t u v w u' w' :=
    normalizedCard_nonneg _
  have ha₂ : 0 ≤ jointMass T₁ T₂ t u v w u'' v :=
    normalizedCard_nonneg _
  have ha₃ : 0 ≤ jointMass T₁ T₂ t u v w u'' w' :=
    normalizedCard_nonneg _
  have ha₄ : 0 ≤ jointMass T₁ T₂ t u v w u' v :=
    normalizedCard_nonneg _
  have hc : 0 ≤ T₂.columnMass v w w'' := normalizedCard_nonneg _
  positivity

/-- Pure finite-sum factorization used in the proof of
`qOrientationSum_eq`. -/
theorem sum_symmetric_q_kernel
    {U W : Type*} [DecidableEq U] [DecidableEq W]
    (U₁ U₂ : Finset U) (W₁ W₂ : Finset W)
    (a : U → W → ℝ) (c : W → ℝ) (v : W) :
    (∑ u' ∈ U₁, ∑ u'' ∈ U₂, ∑ w' ∈ W₁, ∑ w'' ∈ W₂,
        (1 / 2 : ℝ) * c w'' *
          (a u' w' * a u'' v / c v + a u'' w' * a u' v / c v)) =
      (1 / 2 : ℝ) * (∑ w'' ∈ W₂, c w'') *
        (((∑ u' ∈ U₁, ∑ w' ∈ W₁, a u' w') *
              (∑ u'' ∈ U₂, a u'' v) / c v) +
          ((∑ w' ∈ W₁, ∑ u'' ∈ U₂, a u'' w') *
              (∑ u' ∈ U₁, a u' v) / c v)) := by
  simp_rw [mul_add]
  simp_rw [Finset.sum_add_distrib]
  simp_rw [Finset.mul_sum, Finset.sum_mul]
  ring_nf
  congr 1
  · simp_rw [Finset.sum_comm (s := W₁) (t := W₂)]
    simp_rw [Finset.sum_comm (s := U₂) (t := W₂)]
    simp_rw [Finset.sum_comm (s := U₁) (t := W₂)]
    simp_rw [Finset.sum_comm (s := U₁) (t := U₂)]
    simp_rw [Finset.mul_sum, Finset.sum_mul]
    simp only [mul_comm, mul_left_comm, mul_assoc]
  · simp_rw [Finset.sum_comm (s := W₁) (t := W₂)]
    simp_rw [Finset.sum_comm (s := U₂) (t := W₂)]
    simp_rw [Finset.sum_comm (s := U₁) (t := W₂)]
    simp_rw [Finset.sum_comm (s := U₂) (t := W₁)]
    simp_rw [Finset.mul_sum, Finset.sum_mul]
    simp only [mul_comm, mul_left_comm, mul_assoc]

/-- Closed form of one oriented `q` block.  The first term is the mass in the
two away sides; the second term is the complementary-column correction. -/
theorem qOrientationSum_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w) :
    qOrientationSum T₁ T₂ t u v w =
      (1 / 2 : ℝ) *
        (jointMass T₁ T₂ u t w v u w +
          T₂.columnMass w v w *
            jointMass T₁ T₂ u t v w u v /
              T₂.columnMass v w v) := by
  classical
  unfold qOrientationSum qCoefficient
  rw [sum_symmetric_q_kernel]
  have hAawayAway :
      (∑ u' ∈ T₁.awayBranchIndices t u,
          ∑ w' ∈ T₂.awayBranchIndices v w,
            jointMass T₁ T₂ t u v w u' w') =
        jointMass T₁ T₂ u t w v u w := by
    rw [Finset.sum_comm]
    calc
      ∑ w' ∈ T₂.awayBranchIndices v w,
          ∑ u' ∈ T₁.awayBranchIndices t u,
            jointMass T₁ T₂ t u v w u' w' =
          ∑ w' ∈ T₂.awayBranchIndices v w,
            jointMass T₁ T₂ u t v w u w' := by
        apply Finset.sum_congr rfl
        intro w' hw'
        exact sum_jointMass_awayRowBranches T₁ T₂ htu v w w'
      _ = jointMass T₁ T₂ u t w v u w :=
        sum_jointMass_awayColumnBranches T₁ T₂ u t u hvw
  have hAallV :
      (∑ u'' ∈ T₁.branchIndices u,
          jointMass T₁ T₂ t u v w u'' v) =
        T₂.columnMass v w v :=
    sum_jointMass_allRowBranches T₁ T₂ t u v w v
  have hCallAway :
      (∑ w' ∈ T₂.awayBranchIndices v w,
          ∑ u'' ∈ T₁.branchIndices u,
            jointMass T₁ T₂ t u v w u'' w') =
        T₂.columnMass w v w := by
    calc
      ∑ w' ∈ T₂.awayBranchIndices v w,
          ∑ u'' ∈ T₁.branchIndices u,
            jointMass T₁ T₂ t u v w u'' w' =
          ∑ w' ∈ T₂.awayBranchIndices v w,
            T₂.columnMass v w w' := by
        apply Finset.sum_congr rfl
        intro w' hw'
        exact sum_jointMass_allRowBranches T₁ T₂ t u v w w'
      _ = T₂.columnMass w v w :=
        sum_columnMass_awayBranches T₂ hvw
  have hAawayV :
      (∑ u' ∈ T₁.awayBranchIndices t u,
          jointMass T₁ T₂ t u v w u' v) =
        jointMass T₁ T₂ u t v w u v :=
    sum_jointMass_awayRowBranches T₁ T₂ htu v w v
  rw [sum_columnMass_allBranches T₂ v w,
    hAawayAway, hAallV, hCallAway, hAawayV]
  have hcv : T₂.columnMass v w v ≠ 0 :=
    ne_of_gt (T₂.columnMass_pos_of_adj hvw)
  field_simp [hcv]

/-- The four oriented coefficient blocks attached to a pair of undirected
edges sum to one, exactly as asserted in the coefficient partition preceding
Theorem 2. -/
theorem four_qOrientationSums_eq_one
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w) :
    qOrientationSum T₁ T₂ t u v w +
        qOrientationSum T₁ T₂ t u w v +
        qOrientationSum T₁ T₂ u t v w +
        qOrientationSum T₁ T₂ u t w v = 1 := by
  rw [qOrientationSum_eq T₁ T₂ htu hvw,
    qOrientationSum_eq T₁ T₂ htu hvw.symm,
    qOrientationSum_eq T₁ T₂ htu.symm hvw,
    qOrientationSum_eq T₁ T₂ htu.symm hvw.symm]
  let A₁₁ := jointMass T₁ T₂ u t w v u w
  let A₁₀ := jointMass T₁ T₂ u t v w u v
  let A₀₁ := jointMass T₁ T₂ t u w v t w
  let A₀₀ := jointMass T₁ T₂ t u v w t v
  let c₁ := T₂.columnMass w v w
  let c₀ := T₂.columnMass v w v
  change
    (1 / 2 : ℝ) * (A₁₁ + c₁ * A₁₀ / c₀) +
        (1 / 2 : ℝ) * (A₁₀ + c₀ * A₁₁ / c₁) +
        (1 / 2 : ℝ) * (A₀₁ + c₁ * A₀₀ / c₀) +
        (1 / 2 : ℝ) * (A₀₀ + c₀ * A₀₁ / c₁) = 1
  have hcv : T₂.columnMass v w v ≠ 0 :=
    ne_of_gt (T₂.columnMass_pos_of_adj hvw)
  have hcw : T₂.columnMass w v w ≠ 0 :=
    ne_of_gt (T₂.columnMass_pos_of_adj hvw.symm)
  have hrowPartition₀ : A₁₀ + A₀₀ = c₀ := by
    dsimp [A₁₀, A₀₀, c₀]
    exact jointMass_edgeSide_partition_row T₁ T₂ htu v w v
  have hrowPartition₁ : A₁₁ + A₀₁ = c₁ := by
    dsimp [A₁₁, A₀₁, c₁]
    exact jointMass_edgeSide_partition_row T₁ T₂ htu w v w
  have hcolumnPartition : c₁ + c₀ = 1 := by
    dsimp [c₁, c₀]
    exact columnMass_edgeSide_partition T₂ hvw
  have hc₀ : c₀ ≠ 0 := by simpa [c₀] using hcv
  have hc₁ : c₁ ≠ 0 := by simpa [c₁] using hcw
  calc
    (1 / 2 : ℝ) * (A₁₁ + c₁ * A₁₀ / c₀) +
          (1 / 2 : ℝ) * (A₁₀ + c₀ * A₁₁ / c₁) +
          (1 / 2 : ℝ) * (A₀₁ + c₁ * A₀₀ / c₀) +
          (1 / 2 : ℝ) * (A₀₀ + c₀ * A₀₁ / c₁) =
        (1 / 2 : ℝ) *
          ((A₁₁ + A₀₁) + (A₁₀ + A₀₀) +
            c₁ * (A₁₀ + A₀₀) / c₀ +
            c₀ * (A₁₁ + A₀₁) / c₁) := by ring
    _ = (1 / 2 : ℝ) *
          (c₁ + c₀ + c₁ * c₀ / c₀ + c₀ * c₁ / c₁) := by
      rw [hrowPartition₀, hrowPartition₁]
    _ = 1 := by
      field_simp [hc₀, hc₁]
      nlinarith [hcolumnPartition]

/-- Local edge--edge settlement behind equation `(edge-edge)`: the four
oriented coefficient blocks carry the four directed copies of the same
undirected edge-pair square. -/
theorem edgeEdge_local_q_decomposition
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w) :
    (1 / 6 : ℝ) *
        splitQuartetCovariance (T₁.edgeSplit t u) (T₂.edgeSplit v w) =
      qOrientationSum T₁ T₂ t u v w *
          xCoefficient T₁ T₂ t u v w ^ 2 +
        qOrientationSum T₁ T₂ t u w v *
          xCoefficient T₁ T₂ t u w v ^ 2 +
        qOrientationSum T₁ T₂ u t v w *
          xCoefficient T₁ T₂ u t v w ^ 2 +
        qOrientationSum T₁ T₂ u t w v *
          xCoefficient T₁ T₂ u t w v ^ 2 := by
  have hsum := four_qOrientationSums_eq_one T₁ T₂ htu hvw
  calc
    (1 / 6 : ℝ) *
          splitQuartetCovariance (T₁.edgeSplit t u) (T₂.edgeSplit v w) =
        xCoefficient T₁ T₂ t u v w ^ 2 := by
      rw [edgeSplit_quartetCovariance_eq T₁ T₂ htu hvw]
      ring
    _ = (qOrientationSum T₁ T₂ t u v w +
          qOrientationSum T₁ T₂ t u w v +
          qOrientationSum T₁ T₂ u t v w +
          qOrientationSum T₁ T₂ u t w v) *
            xCoefficient T₁ T₂ t u v w ^ 2 := by
      rw [hsum]
      ring
    _ = qOrientationSum T₁ T₂ t u v w *
          xCoefficient T₁ T₂ t u v w ^ 2 +
        qOrientationSum T₁ T₂ t u w v *
          xCoefficient T₁ T₂ t u w v ^ 2 +
        qOrientationSum T₁ T₂ u t v w *
          xCoefficient T₁ T₂ u t v w ^ 2 +
        qOrientationSum T₁ T₂ u t w v *
          xCoefficient T₁ T₂ u t w v ^ 2 := by
      rw [xCoefficient_reverse_column T₁ T₂ t u v w,
        xCoefficient_reverse_row T₁ T₂ t u v w,
        xCoefficient_reverse_both T₁ T₂ t u v w]
      ring

end QDFull
