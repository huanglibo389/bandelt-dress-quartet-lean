import QDFull.WeightedApplications

/-!
# Finite negative type and positive weighted tree metrics

The manuscript cites the facts that finite strict-negative-type metrics are
of strong negative type and that finite tree metrics have this property.
This file proves the finite statements directly.  The definitions are stated
for a finite symmetric distance function, so the distinction between a tree
metric and a tree pseudometric remains explicit.
-/

open scoped BigOperators

namespace QDFull

universe uX uV

namespace FiniteNegativeType

variable {X : Type uX} [Fintype X]

/-- The quadratic energy of a signed mass `a` for a finite distance kernel. -/
noncomputable def signedEnergy (d : X → X → ℝ) (a : X → ℝ) : ℝ :=
  ∑ x, ∑ y, a x * a y * d x y

/-- A finite probability mass function. -/
def IsProbabilityMass (mu : X → ℝ) : Prop :=
  (∀ x, 0 ≤ mu x) ∧ ∑ x, mu x = 1

/-- The energy distance between two finite probability masses. -/
noncomputable def energyDistance
    (d : X → X → ℝ) (mu nu : X → ℝ) : ℝ :=
  2 * (∑ x, ∑ y, mu x * nu y * d x y) -
    signedEnergy d mu - signedEnergy d nu

/-- Negative type on a finite set, in its standard zero-total signed-mass
form. -/
def IsNegativeType (d : X → X → ℝ) : Prop :=
  ∀ a : X → ℝ, (∑ x, a x) = 0 → signedEnergy d a ≤ 0

/-- Strict negative type on a finite set. -/
def IsStrictNegativeType (d : X → X → ℝ) : Prop :=
  IsNegativeType d ∧
    ∀ a : X → ℝ, (∑ x, a x) = 0 →
      signedEnergy d a = 0 → ∀ x, a x = 0

/-- Strong negative type for finite probability masses. -/
def IsStrongNegativeType (d : X → X → ℝ) : Prop :=
  IsNegativeType d ∧
    ∀ mu nu : X → ℝ,
      IsProbabilityMass mu → IsProbabilityMass nu →
        energyDistance d mu nu = 0 → mu = nu

/-- Symmetry converts energy distance into minus the signed energy of the
difference of the two masses. -/
theorem energyDistance_eq_neg_signedEnergy_sub
    (d : X → X → ℝ) (hsymm : ∀ x y, d x y = d y x)
    (mu nu : X → ℝ) :
    energyDistance d mu nu = -signedEnergy d (fun x => mu x - nu x) := by
  classical
  unfold energyDistance signedEnergy
  have hcross :
      (∑ x, ∑ y, nu x * mu y * d x y) =
        ∑ x, ∑ y, mu x * nu y * d x y := by
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro x _
    apply Finset.sum_congr rfl
    intro y _
    rw [hsymm]
    ring
  have hexpand :
      (∑ x, ∑ y, (mu x - nu x) * (mu y - nu y) * d x y) =
        (∑ x, ∑ y, mu x * mu y * d x y) -
          (∑ x, ∑ y, mu x * nu y * d x y) -
          (∑ x, ∑ y, nu x * mu y * d x y) +
          (∑ x, ∑ y, nu x * nu y * d x y) := by
    calc
      (∑ x, ∑ y, (mu x - nu x) * (mu y - nu y) * d x y) =
          ∑ x, ∑ y,
            (mu x * mu y * d x y - mu x * nu y * d x y -
              nu x * mu y * d x y + nu x * nu y * d x y) := by
                apply Finset.sum_congr rfl
                intro x _
                apply Finset.sum_congr rfl
                intro y _
                ring
      _ = _ := by
        simp_rw [Finset.sum_add_distrib, Finset.sum_sub_distrib]
  rw [hexpand, hcross]
  ring

/-- Strict negative type implies strong negative type on a finite symmetric
space. -/
theorem strong_of_strict
    (d : X → X → ℝ) (hsymm : ∀ x y, d x y = d y x)
    (hstrict : IsStrictNegativeType d) :
    IsStrongNegativeType d := by
  refine ⟨hstrict.1, ?_⟩
  intro mu nu hmu hnu henergy
  have hsum : ∑ x, (mu x - nu x) = 0 := by
    rw [Finset.sum_sub_distrib, hmu.2, hnu.2]
    ring
  have hsigned : signedEnergy d (fun x => mu x - nu x) = 0 := by
    rw [energyDistance_eq_neg_signedEnergy_sub d hsymm mu nu] at henergy
    linarith
  have hzero := hstrict.2 (fun x => mu x - nu x) hsum hsigned
  funext x
  exact sub_eq_zero.mp (hzero x)

/-- Scaling every signed coefficient scales the quadratic energy by the
square of the scalar. -/
theorem signedEnergy_const_mul
    (d : X → X → ℝ) (c : ℝ) (a : X → ℝ) :
    signedEnergy d (fun x => c * a x) = c ^ 2 * signedEnergy d a := by
  classical
  unfold signedEnergy
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro x _
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro y _
  ring

/-- On a finite symmetric space, strong negative type implies strict
negative type.  Positive and negative parts normalize any nonzero zero-total
signed mass to a pair of probability masses. -/
theorem strict_of_strong
    (d : X → X → ℝ) (hsymm : ∀ x y, d x y = d y x)
    (hstrong : IsStrongNegativeType d) :
    IsStrictNegativeType d := by
  refine ⟨hstrong.1, ?_⟩
  intro a hsum henergy
  have hparts : ∑ x, (a x)⁺ = ∑ x, (a x)⁻ := by
    have h := hsum
    have haParts : a = fun x => (a x)⁺ - (a x)⁻ := by
      funext x
      exact (posPart_sub_negPart (a x)).symm
    rw [haParts] at h
    rw [Finset.sum_sub_distrib] at h
    linarith
  let A : ℝ := ∑ x, (a x)⁺
  by_cases hA : A = 0
  · have hpos : ∀ x, (a x)⁺ = 0 := by
      have hnonneg :
          ∀ x ∈ (Finset.univ : Finset X), 0 ≤ (a x)⁺ := by
        intro x _
        exact posPart_nonneg (a x)
      have hall := (Finset.sum_eq_zero_iff_of_nonneg hnonneg).1
        (by simpa [A] using hA)
      intro x
      exact hall x (Finset.mem_univ x)
    have hnegSum : ∑ x, (a x)⁻ = 0 := by
      rw [← hparts]
      exact hA
    have hneg : ∀ x, (a x)⁻ = 0 := by
      have hnonneg :
          ∀ x ∈ (Finset.univ : Finset X), 0 ≤ (a x)⁻ := by
        intro x _
        exact negPart_nonneg (a x)
      have hall := (Finset.sum_eq_zero_iff_of_nonneg hnonneg).1 hnegSum
      intro x
      exact hall x (Finset.mem_univ x)
    intro x
    rw [← posPart_sub_negPart (a x), hpos x, hneg x]
    ring
  · have hApos : 0 < A := by
      have hnonneg : 0 ≤ A := by
        dsimp [A]
        exact Finset.sum_nonneg fun x _ => posPart_nonneg (a x)
      exact lt_of_le_of_ne hnonneg (Ne.symm hA)
    let mu : X → ℝ := fun x => (a x)⁺ / A
    let nu : X → ℝ := fun x => (a x)⁻ / A
    have hmu : IsProbabilityMass mu := by
      constructor
      · intro x
        exact div_nonneg (posPart_nonneg (a x)) (le_of_lt hApos)
      · dsimp [mu]
        rw [← Finset.sum_div]
        exact div_self hA
    have hnu : IsProbabilityMass nu := by
      constructor
      · intro x
        exact div_nonneg (negPart_nonneg (a x)) (le_of_lt hApos)
      · dsimp [nu]
        rw [← Finset.sum_div, ← hparts]
        exact div_self hA
    have hmunu : (fun x => mu x - nu x) = fun x => A⁻¹ * a x := by
      funext x
      dsimp [mu, nu]
      rw [← sub_div, posPart_sub_negPart]
      field_simp
    have hdist : energyDistance d mu nu = 0 := by
      rw [energyDistance_eq_neg_signedEnergy_sub d hsymm, hmunu,
        signedEnergy_const_mul, henergy]
      ring
    have hmueq : mu = nu := hstrong.2 mu nu hmu hnu hdist
    intro x
    have hx := congrFun hmueq x
    dsimp [mu, nu] at hx
    have hpartEq : (a x)⁺ = (a x)⁻ := by
      exact (div_left_inj' hA).mp hx
    rw [← posPart_sub_negPart (a x), hpartEq]
    ring

/-- Standard finite-space equivalence of strict and strong negative type. -/
theorem strictNegativeType_iff_strongNegativeType
    (d : X → X → ℝ) (hsymm : ∀ x y, d x y = d y x) :
    IsStrictNegativeType d ↔ IsStrongNegativeType d :=
  ⟨strong_of_strict d hsymm, strict_of_strong d hsymm⟩

/-- The signed energy of one split pseudometric is the negative square of the
total signed mass on the chosen side. -/
theorem signedEnergy_splitPseudometric
    [Nonempty X] [DecidableEq X] (P : Finset X) (a : X → ℝ)
    (hsum : ∑ x, a x = 0) :
    signedEnergy
        (QuartetV060.DistanceCovariance.splitPseudometric P) a =
      -2 * (∑ x ∈ P, a x) ^ 2 := by
  classical
  let I : X → ℝ :=
    QuartetV060.DistanceCovariance.sideIndicator P
  have hIa :
      ∑ x, a x * I x = ∑ x ∈ P, a x := by
    simp [I, QuartetV060.DistanceCovariance.sideIndicator]
  unfold signedEnergy
  change
    (∑ x, ∑ y, a x * a y * (I x - I y) ^ 2) = _
  calc
    (∑ x, ∑ y, a x * a y * (I x - I y) ^ 2) =
        ∑ x, ∑ y,
          a x * a y * (I x + I y - 2 * I x * I y) := by
            apply Finset.sum_congr rfl
            intro x _
            apply Finset.sum_congr rfl
            intro y _
            rw [show (I x - I y) ^ 2 =
                I x + I y - 2 * I x * I y by
              change QuartetV060.DistanceCovariance.splitPseudometric P x y = _
              exact QuartetV060.DistanceCovariance.splitPseudometric_expand P x y]
    _ = 2 * (∑ x, a x * I x) * (∑ y, a y) -
          2 * (∑ x, a x * I x) ^ 2 := by
            have hdecomp :
                (∑ x, ∑ y,
                    a x * a y * (I x + I y - 2 * I x * I y)) =
                  (∑ x, ∑ y, a x * a y * I x) +
                    (∑ x, ∑ y, a x * a y * I y) -
                    2 * (∑ x, ∑ y, a x * a y * (I x * I y)) := by
              rw [Finset.mul_sum, ← Finset.sum_add_distrib,
                ← Finset.sum_sub_distrib]
              apply Finset.sum_congr rfl
              intro x _
              rw [Finset.mul_sum, ← Finset.sum_add_distrib,
                ← Finset.sum_sub_distrib]
              apply Finset.sum_congr rfl
              intro y _
              ring
            have hfirst :
                (∑ x, ∑ y, a x * a y * I x) =
                  (∑ x, a x * I x) * (∑ y, a y) := by
              calc
                (∑ x, ∑ y, a x * a y * I x) =
                    ∑ x, (a x * I x) * (∑ y, a y) := by
                      apply Finset.sum_congr rfl
                      intro x _
                      rw [Finset.mul_sum]
                      apply Finset.sum_congr rfl
                      intro y _
                      ring
                _ = _ := by rw [Finset.sum_mul]
            have hsecond :
                (∑ x, ∑ y, a x * a y * I y) =
                  (∑ x, a x) * (∑ y, a y * I y) := by
              calc
                (∑ x, ∑ y, a x * a y * I y) =
                    ∑ x, a x * (∑ y, a y * I y) := by
                      apply Finset.sum_congr rfl
                      intro x _
                      rw [Finset.mul_sum]
                      apply Finset.sum_congr rfl
                      intro y _
                      ring
                _ = _ := by rw [Finset.sum_mul]
            have hthird :
                (∑ x, ∑ y, a x * a y * (I x * I y)) =
                  (∑ x, a x * I x) * (∑ y, a y * I y) := by
              calc
                (∑ x, ∑ y, a x * a y * (I x * I y)) =
                    ∑ x, (a x * I x) * (∑ y, a y * I y) := by
                      apply Finset.sum_congr rfl
                      intro x _
                      rw [Finset.mul_sum]
                      apply Finset.sum_congr rfl
                      intro y _
                      ring
                _ = _ := by rw [Finset.sum_mul]
            rw [hdecomp, hfirst, hsecond, hthird]
            ring
    _ = -2 * (∑ x, a x * I x) ^ 2 := by rw [hsum]; ring
    _ = -2 * (∑ x ∈ P, a x) ^ 2 := by rw [hIa]

end FiniteNegativeType

namespace EdgeWeightedXTree

open FiniteNegativeType
open QuartetV060.DistanceCovariance

variable {X : Type uX} {V : Type uV}
  [Fintype X] [Nonempty X]
  [Fintype V] [LinearOrder V]

noncomputable local instance : DecidableEq X := Classical.decEq X

/-- Signed energy is linear across an arbitrary finite weighted split
system. -/
theorem signedEnergy_weightedSplitPseudometric
    {E : Type*} [Fintype E]
    (P : E → Finset X) (w : E → ℝ) (a : X → ℝ) :
    signedEnergy (weightedSplitPseudometric P w) a =
      ∑ e, w e * signedEnergy (splitPseudometric (P e)) a := by
  classical
  unfold signedEnergy weightedSplitPseudometric
  calc
    (∑ x, ∑ y, a x * a y * ∑ e, w e * splitPseudometric (P e) x y) =
        ∑ x, ∑ y, ∑ e,
          w e * (a x * a y * splitPseudometric (P e) x y) := by
            apply Finset.sum_congr rfl
            intro x _
            apply Finset.sum_congr rfl
            intro y _
            rw [Finset.mul_sum]
            apply Finset.sum_congr rfl
            intro e _
            ring
    _ = ∑ x, ∑ e, ∑ y,
          w e * (a x * a y * splitPseudometric (P e) x y) := by
            apply Finset.sum_congr rfl
            intro x _
            rw [Finset.sum_comm]
    _ = ∑ e, ∑ x, ∑ y,
          w e * (a x * a y * splitPseudometric (P e) x y) := by
            rw [Finset.sum_comm]
    _ = ∑ e, w e *
          (∑ x, ∑ y, a x * a y * splitPseudometric (P e) x y) := by
            apply Finset.sum_congr rfl
            intro e _
            rw [Finset.mul_sum]
            apply Finset.sum_congr rfl
            intro x _
            rw [Finset.mul_sum]

/-- Exact cut-energy identity for the paper's positive edge-weighted tree
pseudometric. -/
theorem signedEnergy_treePseudometric
    (W : EdgeWeightedXTree X V) (a : X → ℝ)
    (hsum : ∑ x, a x = 0) :
    signedEnergy W.treePseudometric a =
      -2 * ∑ e, W.length e * (∑ x ∈ W.edgeSide e, a x) ^ 2 := by
  unfold treePseudometric
  rw [signedEnergy_weightedSplitPseudometric]
  simp_rw [signedEnergy_splitPseudometric _ _ hsum]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro e _
  ring

/-- Every positive edge-weighted tree pseudometric is of negative type. -/
theorem treePseudometric_isNegativeType
    (W : EdgeWeightedXTree X V) :
    IsNegativeType W.treePseudometric := by
  intro a hsum
  rw [W.signedEnergy_treePseudometric a hsum]
  have hnonneg :
      0 ≤ ∑ e, W.length e * (∑ x ∈ W.edgeSide e, a x) ^ 2 :=
    Finset.sum_nonneg fun e _ =>
      mul_nonneg (le_of_lt (W.length_pos e)) (sq_nonneg _)
  nlinarith

/-- Equality in the tree cut-energy identity forces the signed mass on every
canonically oriented edge side to vanish. -/
theorem sum_canonicalEdgeSide_eq_zero_of_energy_eq_zero
    (W : EdgeWeightedXTree X V) (a : X → ℝ)
    (hsum : ∑ x, a x = 0)
    (henergy : signedEnergy W.treePseudometric a = 0) :
    ∀ e : W.tree.canonicalEdgeFinset,
      ∑ x ∈ W.edgeSide e, a x = 0 := by
  have hweighted :
      ∑ e, W.length e * (∑ x ∈ W.edgeSide e, a x) ^ 2 = 0 := by
    rw [W.signedEnergy_treePseudometric a hsum] at henergy
    linarith
  have hnonneg :
      ∀ e ∈ (Finset.univ : Finset W.tree.canonicalEdgeFinset),
        0 ≤ W.length e * (∑ x ∈ W.edgeSide e, a x) ^ 2 := by
    intro e _
    exact mul_nonneg (le_of_lt (W.length_pos e)) (sq_nonneg _)
  have hterm := (Finset.sum_eq_zero_iff_of_nonneg hnonneg).1 hweighted
  intro e
  have heq := hterm e (Finset.mem_univ e)
  have hlength : W.length e ≠ 0 := ne_of_gt (W.length_pos e)
  have hsquare : (∑ x ∈ W.edgeSide e, a x) ^ 2 = 0 :=
    (mul_eq_zero.mp heq).resolve_left hlength
  exact (sq_eq_zero_iff).mp hsquare

/-- The same zero-cut conclusion for either orientation of any actual tree
edge. -/
theorem sum_edgeSide_eq_zero_of_energy_eq_zero
    (W : EdgeWeightedXTree X V) (a : X → ℝ)
    (hsum : ∑ x, a x = 0)
    (henergy : signedEnergy W.treePseudometric a = 0)
    {u v : V} (huv : W.tree.graph.Adj u v) :
    ∑ x ∈ W.tree.edgeSide u v, a x = 0 := by
  classical
  have hcanon := W.sum_canonicalEdgeSide_eq_zero_of_energy_eq_zero
    a hsum henergy
  have hdirected : (u, v) ∈ W.tree.directedEdgeFinset :=
    (W.tree.mem_directedEdgeFinset u v).2 huv
  rcases W.tree.mem_canonical_or_reverse_of_mem_directedEdge hdirected with
    huvC | hvuC
  · exact hcanon ⟨(u, v), huvC⟩
  · have hreverse :
        W.tree.edgeSide u v = (W.tree.edgeSide v u)ᶜ :=
      W.tree.edgeSide_reverse_eq_compl huv.symm
    rw [hreverse]
    have hpartition := Finset.sum_add_sum_compl
      (W.tree.edgeSide v u) a
    have hcanonical : ∑ x ∈ W.tree.edgeSide v u, a x = 0 :=
      hcanon ⟨(v, u), hvuC⟩
    rw [hcanonical, hsum] at hpartition
    linarith

/-- Injective labelling makes the weighted tree pseudometric strictly
negative type.  The proof uses all branches at `label x`; it therefore also
covers labels situated at internal vertices. -/
theorem treePseudometric_isStrictNegativeType_of_label_injective
    (W : EdgeWeightedXTree X V)
    (hinj : Function.Injective W.tree.label) :
    IsStrictNegativeType W.treePseudometric := by
  refine ⟨W.treePseudometric_isNegativeType, ?_⟩
  intro a hsum henergy x
  let centre : V := W.tree.label x
  have hcentre : centre ∈ W.tree.branchIndices centre := by
    rw [W.tree.mem_branchIndices, W.tree.mem_neighborsPlus]
    exact Or.inl rfl
  have hfiber : W.tree.labelFiber centre = {x} := by
    ext y
    simp only [W.tree.mem_labelFiber, Finset.mem_singleton]
    constructor
    · intro hy
      exact hinj (hy.trans rfl.symm)
    · intro hy
      subst y
      rfl
  have hbranchZero :
      ∀ z ∈ (W.tree.branchIndices centre).erase centre,
        ∑ y ∈ W.tree.branchBlock centre z, a y = 0 := by
    intro z hz
    have hzmem : z ∈ W.tree.branchIndices centre :=
      (Finset.mem_erase.mp hz).2
    have hzne : z ≠ centre := (Finset.mem_erase.mp hz).1
    have hzplus := (W.tree.mem_branchIndices centre z).1 hzmem
    rw [W.tree.mem_neighborsPlus] at hzplus
    have hadj : W.tree.graph.Adj centre z := hzplus.resolve_left hzne
    rw [W.tree.branchBlock_of_adj hadj]
    exact W.sum_edgeSide_eq_zero_of_energy_eq_zero a hsum henergy hadj
  have herase :
      ∑ z ∈ (W.tree.branchIndices centre).erase centre,
        ∑ y ∈ W.tree.branchBlock centre z, a y = 0 := by
    exact Finset.sum_eq_zero hbranchZero
  have hcentreBlock :
      ∑ y ∈ W.tree.branchBlock centre centre, a y = a x := by
    rw [W.tree.branchBlock_self, hfiber]
    simp
  have hsplit := Finset.sum_erase_add
    (W.tree.branchIndices centre)
    (fun z => ∑ y ∈ W.tree.branchBlock centre z, a y) hcentre
  have hpartition :
      ∑ y, a y =
        ∑ z ∈ W.tree.branchIndices centre,
          ∑ y ∈ W.tree.branchBlock centre z, a y := by
    calc
      ∑ y, a y = ∑ y ∈ (Finset.univ : Finset X), a y := by simp
      _ = ∑ y ∈
          (W.tree.branchIndices centre).biUnion
            (W.tree.branchBlock centre), a y := by
              rw [W.tree.biUnion_branchBlock_eq_univ]
      _ = ∑ z ∈ W.tree.branchIndices centre,
          ∑ y ∈ W.tree.branchBlock centre z, a y :=
            Finset.sum_biUnion
              (W.tree.branchIndices_pairwiseDisjoint centre)
  rw [herase, hcentreBlock] at hsplit
  rw [hsum] at hpartition
  linarith

/-- Consequently, an injectively labelled positive weighted tree is of
strong negative type for all finite probability masses. -/
theorem treePseudometric_isStrongNegativeType_of_label_injective
    (W : EdgeWeightedXTree X V)
    (hinj : Function.Injective W.tree.label) :
    IsStrongNegativeType W.treePseudometric := by
  apply strong_of_strict W.treePseudometric
  · exact W.treePseudometric_symm
  · exact W.treePseudometric_isStrictNegativeType_of_label_injective hinj

/-- In particular, every positive edge-weighted phylogenetic tree metric is
of strong negative type, because phylogenetic labelling is injective. -/
theorem treePseudometric_isStrongNegativeType_of_phylogenetic
    (W : EdgeWeightedXTree X V)
    (hphy : W.tree.IsPhylogenetic) :
    IsStrongNegativeType W.treePseudometric :=
  W.treePseudometric_isStrongNegativeType_of_label_injective hphy.1

end EdgeWeightedXTree

end QDFull
