import QDFull.BinaryPhylogeneticQuartetCounts

/-!
# Corollary 1: bounds and equality cases

This file formalizes Corollary 1 of the paper.  The first section proves the
lower equality characterization without appealing to the paper's informal
choice of a positive local coefficient: independence kills every edge
coordinate in the four square families, while non-independence makes one
strictly positive summand in the global lower bound of Lemma 6.
-/

open scoped BigOperators

namespace QDFull

universe uX uV₁ uV₂

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]
  [DecidableEq X] [DecidableEq V₁] [DecidableEq V₂]

/-- The exact count of ordered four-draw samples in which no taxon occurs
three or four times, written in the paper's `6/12/24` support-size form. -/
private theorem weighted_choose_identity (n : ℕ) :
    6 * (Nat.choose n 2 : ℝ) +
        36 * (Nat.choose n 3 : ℝ) +
        24 * (Nat.choose n 4 : ℝ) =
      (n : ℝ) ^ 4 - (n : ℝ) * (4 * (n : ℝ) - 3) := by
  by_cases hn : n < 4
  · interval_cases n <;> norm_num
  · have hn4 : 4 ≤ n := by omega
    have h2nat := Nat.descFactorial_eq_factorial_mul_choose n 2
    have h3nat := Nat.descFactorial_eq_factorial_mul_choose n 3
    have h4nat := Nat.descFactorial_eq_factorial_mul_choose n 4
    have h1 : 1 ≤ n := by omega
    have h2 : 2 ≤ n := by omega
    have h3 : 3 ≤ n := by omega
    norm_num [Nat.descFactorial] at h2nat h3nat h4nat
    have h2real := congrArg (fun k : ℕ => (k : ℝ)) h2nat
    have h3real := congrArg (fun k : ℕ => (k : ℝ)) h3nat
    have h4real := congrArg (fun k : ℕ => (k : ℝ)) h4nat
    push_cast [Nat.cast_sub h1, Nat.cast_sub h2, Nat.cast_sub h3] at h2real h3real h4real
    nlinarith

/-! ## The lower equality characterization -/

private theorem qSquareFamily_eq_zero_of_edge_coordinates_eq_zero
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hX : ∀ t u v w, T₁.graph.Adj t u → T₂.graph.Adj v w →
      xCoefficient T₁ T₂ t u v w = 0) :
    qSquareFamily T₁ T₂ = 0 := by
  classical
  unfold qSquareFamily qDiagonalBlock
  apply Finset.sum_eq_zero
  intro e₁ he₁
  apply Finset.sum_eq_zero
  intro e₂ he₂
  have hx := hX e₁.1 e₁.2 e₂.1 e₂.2
    ((T₁.mem_directedEdgeFinset e₁.1 e₁.2).1 he₁)
    ((T₂.mem_directedEdgeFinset e₂.1 e₂.2).1 he₂)
  simp [hx]

private theorem sSquareFamily_eq_zero_of_edge_coordinates_eq_zero
    [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hX : ∀ t u v w, T₁.graph.Adj t u → T₂.graph.Adj v w →
      xCoefficient T₁ T₂ t u v w = 0) :
    sSquareFamily T₁ T₂ = 0 := by
  classical
  unfold sSquareFamily
  apply Finset.sum_eq_zero
  intro e₁ he₁
  apply Finset.sum_eq_zero
  intro p₂ hp₂
  have he₁adj := (T₁.mem_directedEdgeFinset e₁.1 e₁.2).1 he₁
  have hp := (T₂.mem_canonicalLengthTwoPathFinset
    p₂.1 p₂.2.1 p₂.2.2).1 hp₂
  have hxLeft := hX e₁.1 e₁.2 p₂.1 p₂.2.1 he₁adj hp.1
  have hxRight := hX e₁.1 e₁.2 p₂.2.2 p₂.2.1
    he₁adj hp.2.1.symm
  simp [hxLeft, hxRight]

private theorem bSquareFamily_eq_zero_of_edge_coordinates_eq_zero
    [LinearOrder V₁]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hX : ∀ t u v w, T₁.graph.Adj t u → T₂.graph.Adj v w →
      xCoefficient T₁ T₂ t u v w = 0) :
    bSquareFamily T₁ T₂ = 0 := by
  classical
  unfold bSquareFamily
  apply Finset.sum_eq_zero
  intro p₁ hp₁
  apply Finset.sum_eq_zero
  intro e₂ he₂
  have hp := (T₁.mem_canonicalLengthTwoPathFinset
    p₁.1 p₁.2.1 p₁.2.2).1 hp₁
  have he₂adj := (T₂.mem_directedEdgeFinset e₂.1 e₂.2).1 he₂
  have hxLeft := hX p₁.1 p₁.2.1 e₂.1 e₂.2 hp.1 he₂adj
  have hxRight := hX p₁.2.2 p₁.2.1 e₂.1 e₂.2
    hp.2.1.symm he₂adj
  simp [hxLeft, hxRight]

private theorem pSquareFamily_eq_zero_of_edge_coordinates_eq_zero
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hX : ∀ t u v w, T₁.graph.Adj t u → T₂.graph.Adj v w →
      xCoefficient T₁ T₂ t u v w = 0) :
    pSquareFamily T₁ T₂ = 0 := by
  classical
  unfold pSquareFamily
  apply Finset.sum_eq_zero
  intro p₁ hp₁
  apply Finset.sum_eq_zero
  intro p₂ hp₂
  have hp₁' := (T₁.mem_canonicalLengthTwoPathFinset
    p₁.1 p₁.2.1 p₁.2.2).1 hp₁
  have hp₂' := (T₂.mem_canonicalLengthTwoPathFinset
    p₂.1 p₂.2.1 p₂.2.2).1 hp₂
  have hLL := hX p₁.1 p₁.2.1 p₂.1 p₂.2.1 hp₁'.1 hp₂'.1
  have hLR := hX p₁.1 p₁.2.1 p₂.2.2 p₂.2.1
    hp₁'.1 hp₂'.2.1.symm
  have hRL := hX p₁.2.2 p₁.2.1 p₂.1 p₂.2.1
    hp₁'.2.1.symm hp₂'.1
  have hRR := hX p₁.2.2 p₁.2.1 p₂.2.2 p₂.2.1
    hp₁'.2.1.symm hp₂'.2.1.symm
  simp [hLL, hLR, hRL, hRR]

/-- Every retained first branch at a column centre admits a legal second
branch of positive mass.  If the first branch is the centre, the parent
branch works.  Otherwise the centre label works at degree at most two, and a
third graph branch works at larger degree. -/
private theorem exists_indexI_partner_with_positive_columnMass
    (T : XTree X V₂) {parent centre first : V₂}
    (hpc : T.graph.Adj parent centre)
    (hfirst : first ∈ T.awayBranchIndices parent centre) :
    ∃ second : V₂,
      (first, second) ∈ T.indexIFinset parent centre ∧
        0 < T.columnMass parent centre second := by
  classical
  letI : Nonempty X := T.taxon_nonempty
  by_cases hfc : first = centre
  · subst first
    refine ⟨parent, ?_, T.columnMass_pos_of_adj hpc⟩
    rw [T.mem_indexIFinset, T.mem_indexI]
    exact ⟨
      (T.mem_awayBranchIndices_of_adj hpc centre).1 hfirst,
      (T.mem_neighborsPlus parent centre).2 (Or.inr hpc.symm),
      Or.inl rfl⟩
  · have hfirstData :=
      (T.mem_awayBranchIndices_of_adj hpc first).1 hfirst
    have hcf : T.graph.Adj centre first := by
      rcases hfirstData with h | h
      · exact (hfc h).elim
      · exact h.1
    have hfp : first ≠ parent := by
      rcases hfirstData with h | h
      · exact (hfc h).elim
      · exact h.2
    by_cases hdeg : Nat.card (T.graph.neighborSet centre) ≤ 2
    · obtain ⟨x, hx⟩ := T.lowDegree_labelled centre hdeg
      refine ⟨centre, ?_, ?_⟩
      · rw [T.mem_indexIFinset, T.mem_indexI]
        exact ⟨hfirstData, by simp,
          Or.inr ⟨hpc.ne.symm, Ne.symm hfc⟩⟩
      · rw [XTree.columnMass, T.columnBlock_center]
        exact normalizedCard_pos ⟨x, (T.mem_labelFiber centre x).2 hx⟩
    · let N := T.neighborFinset centre
      have hpN : parent ∈ N := by
        simp [N, hpc.symm]
      have hfN : first ∈ N := by
        simp [N, hcf]
      have hfErase : first ∈ N.erase parent := by
        simp [hfN, hfp]
      have hcardN : 3 ≤ N.card := by
        rw [T.card_neighborFinset]
        omega
      have hcardEraseP : 2 ≤ (N.erase parent).card := by
        rw [Finset.card_erase_of_mem hpN]
        omega
      have hcardThird : 1 ≤ ((N.erase parent).erase first).card := by
        rw [Finset.card_erase_of_mem hfErase]
        omega
      obtain ⟨second, hsThird⟩ :
          ((N.erase parent).erase first).Nonempty :=
        Finset.card_pos.mp (by omega)
      have hsN : second ∈ N :=
        Finset.mem_of_mem_erase (Finset.mem_of_mem_erase hsThird)
      have hsp : second ≠ parent :=
        (Finset.mem_erase.mp (Finset.mem_of_mem_erase hsThird)).1
      have hsf : second ≠ first := (Finset.mem_erase.mp hsThird).1
      have hcs : T.graph.Adj centre second := by
        simpa [N] using (T.mem_neighborFinset centre second).1 hsN
      refine ⟨second, ?_, ?_⟩
      · rw [T.mem_indexIFinset, T.mem_indexI]
        exact ⟨hfirstData,
          (T.mem_neighborsPlus second centre).2 (Or.inr hcs),
          Or.inr ⟨hsp, hsf⟩⟩
      · rw [XTree.columnMass, T.columnBlock_of_adj parent hcs]
        exact normalizedCard_pos (T.edgeSide_nonempty_of_adj hcs)

/-- If a positive row edge is chosen with the smallest principal-side
cardinality for one fixed column orientation, its centre cell in that column
side is positive.  Otherwise every noncentral child branch satisfies the
centred-mass inequality, and summing those inequalities contradicts the
strict positivity of the chosen edge coordinate. -/
private theorem central_jointMass_pos_of_minimal_positive_edge
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w)
    (hx : 0 < xCoefficient T₁ T₂ t u v w)
    (hmin : ∀ a b : V₁,
      T₁.graph.Adj a b → 0 < xCoefficient T₁ T₂ a b v w →
        (T₁.edgeSide u t).card ≤ (T₁.edgeSide b a).card) :
    0 < jointMass T₁ T₂ u t v w t v := by
  classical
  by_contra hcentre
  have hcentreZero : jointMass T₁ T₂ u t v w t v = 0 := by
    exact le_antisymm (le_of_not_gt hcentre) (normalizedCard_nonneg _)
  have hbranch : ∀ z ∈ T₁.awayBranchIndices u t,
      jointMass T₁ T₂ u t v w z v ≤
        T₁.rowMass u t z * T₂.columnMass v w v := by
    intro z hz
    by_cases hzt : z = t
    · subst z
      rw [hcentreZero]
      exact mul_nonneg (normalizedCard_nonneg _) (normalizedCard_nonneg _)
    · have hzData :=
        (T₁.mem_awayBranchIndices_of_adj htu.symm z).1 hz
      have htz : T₁.graph.Adj t z := by
        rcases hzData with h | h
        · exact (hzt h).elim
        · exact h.1
      have hzu : z ≠ u := by
        rcases hzData with h | h
        · subst z
          exact htu.ne
        · exact h.2
      have hstrict : T₁.edgeSide t z ⊂ T₁.edgeSide u t :=
        T₁.edgeSide_ssubset_parentSide htu.symm htz (Ne.symm hzu)
      have hcard : (T₁.edgeSide t z).card <
          (T₁.edgeSide u t).card := Finset.card_lt_card hstrict
      have hxChild : xCoefficient T₁ T₂ z t v w ≤ 0 := by
        apply le_of_not_gt
        intro hxChildPos
        have hwrong := hmin z t htz.symm hxChildPos
        omega
      rw [xCoefficient_eq_centered_jointMass T₁ T₂ htz.symm hvw] at hxChild
      calc
        jointMass T₁ T₂ u t v w z v =
            jointMass T₁ T₂ z t v w z v := rfl
        _ ≤ T₁.rowMass z t z * T₂.columnMass v w v := by linarith
        _ = T₁.rowMass u t z * T₂.columnMass v w v := rfl
  have hsumLe :
      (∑ z ∈ T₁.awayBranchIndices u t,
          jointMass T₁ T₂ u t v w z v) ≤
        ∑ z ∈ T₁.awayBranchIndices u t,
          T₁.rowMass u t z * T₂.columnMass v w v := by
    exact Finset.sum_le_sum fun z hz => hbranch z hz
  have hprincipalLe :
      jointMass T₁ T₂ t u v w t v ≤
        T₁.rowMass t u t * T₂.columnMass v w v := by
    calc
      jointMass T₁ T₂ t u v w t v =
          ∑ z ∈ T₁.awayBranchIndices u t,
            jointMass T₁ T₂ u t v w z v := by
        symm
        exact sum_jointMass_awayRowBranches T₁ T₂ htu.symm v w v
      _ ≤ ∑ z ∈ T₁.awayBranchIndices u t,
          T₁.rowMass u t z * T₂.columnMass v w v := hsumLe
      _ = (∑ z ∈ T₁.awayBranchIndices u t,
          T₁.rowMass u t z) * T₂.columnMass v w v := by
        rw [Finset.sum_mul]
      _ = T₁.rowMass t u t * T₂.columnMass v w v := by
        rw [sum_rowMass_awayBranches T₁ htu.symm]
  rw [xCoefficient_eq_centered_jointMass T₁ T₂ htu hvw] at hx
  linarith

/-- The positive centre cell supplied by the minimal-side argument combines
with the opposite positive diagonal cell to give one strictly positive legal
`q` occurrence in the chart obtained by reversing both principal edges. -/
private theorem exists_positive_q_occurrence_of_minimal_positive_edge
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v w : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w)
    (hx : 0 < xCoefficient T₁ T₂ t u v w)
    (hmin : ∀ a b : V₁,
      T₁.graph.Adj a b → 0 < xCoefficient T₁ T₂ a b v w →
        (T₁.edgeSide u t).card ≤ (T₁.edgeSide b a).card) :
    ∃ v' v'' : V₂,
      (t, u) ∈ T₁.indexIFinset u t ∧
      (v', v'') ∈ T₂.indexIFinset w v ∧
      0 < qCoefficient T₁ T₂ u t w v t u v' v'' := by
  classical
  have hcentre := central_jointMass_pos_of_minimal_positive_edge
    T₁ T₂ htu hvw hx hmin
  have hopposite : 0 < jointMass T₁ T₂ u t w v u w := by
    have hA : 0 ≤ jointMass T₁ T₂ t u v w t v :=
      normalizedCard_nonneg _
    have hB : 0 ≤ jointMass T₁ T₂ u t w v u w :=
      normalizedCard_nonneg _
    have hC : 0 ≤ jointMass T₁ T₂ t u w v t w :=
      normalizedCard_nonneg _
    have hD : 0 ≤ jointMass T₁ T₂ u t v w u v :=
      normalizedCard_nonneg _
    unfold xCoefficient at hx
    nlinarith [mul_nonneg hC hD]
  have hcolumnSum :
      (∑ z ∈ T₂.awayBranchIndices w v,
          jointMass T₁ T₂ u t w v t z) =
        jointMass T₁ T₂ u t v w t v :=
    sum_jointMass_awayColumnBranches T₁ T₂ u t t hvw.symm
  have hcolumnSumPos :
      0 < ∑ z ∈ T₂.awayBranchIndices w v,
        jointMass T₁ T₂ u t w v t z := by
    rw [hcolumnSum]
    exact hcentre
  obtain ⟨v', hv'mem, hv'pos⟩ :=
      Finset.exists_lt_of_sum_lt
        (s := T₂.awayBranchIndices w v)
        (f := fun _ => (0 : ℝ))
        (g := fun z => jointMass T₁ T₂ u t w v t z)
        (by simpa using hcolumnSumPos)
  obtain ⟨v'', hv'v''mem, hv''pos⟩ :=
    exists_indexI_partner_with_positive_columnMass T₂ hvw.symm hv'mem
  have hrowmem : (t, u) ∈ T₁.indexIFinset u t := by
    rw [T₁.mem_indexIFinset, T₁.mem_indexI]
    refine ⟨?_, ?_, Or.inl rfl⟩
    · exact (T₁.mem_neighborsAwayPlus t u t).2 (Or.inl rfl)
    · exact (T₁.mem_neighborsPlus u t).2 (Or.inr htu)
  refine ⟨v', v'', hrowmem, hv'v''mem, ?_⟩
  have hcparent : 0 < T₂.columnMass w v w :=
    T₂.columnMass_pos_of_adj hvw.symm
  have hfirst : 0 <
      jointMass T₁ T₂ u t w v t v' *
          jointMass T₁ T₂ u t w v u w /
        T₂.columnMass w v w :=
    div_pos (mul_pos hv'pos hopposite) hcparent
  have hsecond : 0 ≤
      jointMass T₁ T₂ u t w v u v' *
          jointMass T₁ T₂ u t w v t w /
        T₂.columnMass w v w :=
    div_nonneg
      (mul_nonneg (normalizedCard_nonneg _) (normalizedCard_nonneg _))
      hcparent.le
  unfold qCoefficient
  exact mul_pos (mul_pos (by norm_num) hv''pos)
    (add_pos_of_pos_of_nonneg hfirst hsecond)

/-- A strictly positive legal `q X²` occurrence makes the whole first square
family strictly positive, because every other occurrence is nonnegative. -/
private theorem qSquareFamily_pos_of_positive_occurrence
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {t u : V₁} {v w : V₂}
    {u' u'' : V₁} {v' v'' : V₂}
    (htu : T₁.graph.Adj t u) (hvw : T₂.graph.Adj v w)
    (hrow : (u', u'') ∈ T₁.indexIFinset t u)
    (hcolumn : (v', v'') ∈ T₂.indexIFinset v w)
    (hq : 0 < qCoefficient T₁ T₂ t u v w u' u'' v' v'')
    (hx : xCoefficient T₁ T₂ t u v w ≠ 0) :
    0 < qSquareFamily T₁ T₂ := by
  classical
  unfold qSquareFamily qDiagonalBlock
  apply Finset.sum_pos'
  · intro e₁ he₁
    apply Finset.sum_nonneg
    intro e₂ he₂
    have he₂adj :=
      (T₂.mem_directedEdgeFinset e₂.1 e₂.2).1 he₂
    apply Finset.sum_nonneg
    intro z₁ hz₁
    apply Finset.sum_nonneg
    intro z₂ hz₂
    exact mul_nonneg
      (qCoefficient_nonneg_of_adj T₁ T₂
        e₁.1 e₁.2 z₁.1 z₁.2 he₂adj z₂.1 z₂.2)
      (sq_nonneg _)
  · refine ⟨(t, u), (T₁.mem_directedEdgeFinset t u).2 htu, ?_⟩
    apply Finset.sum_pos'
    · intro e₂ he₂
      have he₂adj :=
        (T₂.mem_directedEdgeFinset e₂.1 e₂.2).1 he₂
      apply Finset.sum_nonneg
      intro z₁ hz₁
      apply Finset.sum_nonneg
      intro z₂ hz₂
      exact mul_nonneg
        (qCoefficient_nonneg_of_adj T₁ T₂
          t u z₁.1 z₁.2 he₂adj z₂.1 z₂.2)
        (sq_nonneg _)
    · refine ⟨(v, w), (T₂.mem_directedEdgeFinset v w).2 hvw, ?_⟩
      apply Finset.sum_pos'
      · intro z₁ hz₁
        apply Finset.sum_nonneg
        intro z₂ hz₂
        exact mul_nonneg
          (qCoefficient_nonneg_of_adj T₁ T₂
            t u z₁.1 z₁.2 hvw z₂.1 z₂.2)
          (sq_nonneg _)
      · refine ⟨(u', u''), ?_, ?_⟩
        · change (u', u'') ∈ T₁.indexIFinset t u
          exact hrow
        · apply Finset.sum_pos'
          · intro z₂ hz₂
            exact mul_nonneg
              (qCoefficient_nonneg_of_adj T₁ T₂
                t u u' u'' hvw z₂.1 z₂.2)
              (sq_nonneg _)
          · refine ⟨(v', v''), ?_, ?_⟩
            · change (v', v'') ∈ T₂.indexIFinset v w
              exact hcolumn
            · exact mul_pos hq (sq_pos_of_ne_zero hx)

/-- Directed row edges carrying a positive coordinate for one fixed directed
column edge. -/
private noncomputable def favorableRowEdgeFinset
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (v w : V₂) :
    Finset (V₁ × V₁) := by
  classical
  exact T₁.directedEdgeFinset.filter fun e =>
    0 < xCoefficient T₁ T₂ e.1 e.2 v w

@[simp] private theorem mem_favorableRowEdgeFinset
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u : V₁) (v w : V₂) :
    (t, u) ∈ favorableRowEdgeFinset T₁ T₂ v w ↔
      T₁.graph.Adj t u ∧ 0 < xCoefficient T₁ T₂ t u v w := by
  classical
  simp [favorableRowEdgeFinset, T₁.mem_directedEdgeFinset]

/-- Independence annihilates all four square families and hence the original
four-draw quartet covariance. -/
theorem treeQuartetCovariance_eq_zero_of_treesIndependent
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hInd : TreesIndependent T₁ T₂) :
    treeQuartetCovariance T₁ T₂ = 0 := by
  have hX := (treesIndependent_iff_xCoefficient_eq_zero T₁ T₂).1 hInd
  have hq := qSquareFamily_eq_zero_of_edge_coordinates_eq_zero T₁ T₂ hX
  have hs := sSquareFamily_eq_zero_of_edge_coordinates_eq_zero T₁ T₂ hX
  have hb := bSquareFamily_eq_zero_of_edge_coordinates_eq_zero T₁ T₂ hX
  have hp := pSquareFamily_eq_zero_of_edge_coordinates_eq_zero T₁ T₂ hX
  have hmain := sumOfSquaresRhs_eq_treeQuartetCovariance_div_six T₁ T₂
  unfold sumOfSquaresRhs at hmain
  rw [hq, hs, hb, hp] at hmain
  norm_num at hmain
  exact hmain

/- Failure of tree independence activates a strictly positive legal
occurrence in the first square family, and therefore makes the original
four-draw quartet covariance strictly positive. -/
set_option maxHeartbeats 1000000 in
theorem treeQuartetCovariance_pos_of_not_treesIndependent
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hNotInd : ¬ TreesIndependent T₁ T₂) :
    0 < treeQuartetCovariance T₁ T₂ := by
  classical
  have hNotAll : ¬ ∀ t u v w,
      T₁.graph.Adj t u → T₂.graph.Adj v w →
        xCoefficient T₁ T₂ t u v w = 0 := by
    intro h
    exact hNotInd ((treesIndependent_iff_xCoefficient_eq_zero T₁ T₂).2 h)
  push_neg at hNotAll
  obtain ⟨t₀, u₀, v₀, w₀, htu₀, hvw₀, hx₀ne⟩ := hNotAll
  obtain ⟨v, w, hvw, hx₀⟩ : ∃ v w : V₂,
      T₂.graph.Adj v w ∧ 0 < xCoefficient T₁ T₂ t₀ u₀ v w := by
    by_cases hxpos : 0 < xCoefficient T₁ T₂ t₀ u₀ v₀ w₀
    · exact ⟨v₀, w₀, hvw₀, hxpos⟩
    · have hxle : xCoefficient T₁ T₂ t₀ u₀ v₀ w₀ ≤ 0 :=
        le_of_not_gt hxpos
      have hxneg : xCoefficient T₁ T₂ t₀ u₀ v₀ w₀ < 0 :=
        lt_of_le_of_ne hxle hx₀ne
      refine ⟨w₀, v₀, hvw₀.symm, ?_⟩
      rw [xCoefficient_reverse_column]
      linarith
  have hfavorable :
      (favorableRowEdgeFinset T₁ T₂ v w).Nonempty :=
    ⟨(t₀, u₀),
      (mem_favorableRowEdgeFinset T₁ T₂ t₀ u₀ v w).2 ⟨htu₀, hx₀⟩⟩
  obtain ⟨e, he, heMin⟩ :=
    (favorableRowEdgeFinset T₁ T₂ v w).exists_min_image
    (fun e => (T₁.edgeSide e.2 e.1).card) hfavorable
  rcases e with ⟨t, u⟩
  have heData :
      T₁.graph.Adj t u ∧ 0 < xCoefficient T₁ T₂ t u v w :=
    (mem_favorableRowEdgeFinset T₁ T₂ t u v w).1 he
  have htu : T₁.graph.Adj t u := heData.1
  have hx : 0 < xCoefficient T₁ T₂ t u v w := heData.2
  have hminimal : ∀ a b : V₁,
      T₁.graph.Adj a b → 0 < xCoefficient T₁ T₂ a b v w →
        (T₁.edgeSide u t).card ≤ (T₁.edgeSide b a).card := by
    intro a b hab hxab
    apply heMin (a, b)
    exact (mem_favorableRowEdgeFinset T₁ T₂ a b v w).2 ⟨hab, hxab⟩
  obtain ⟨v', v'', hrow, hcolumn, hq⟩ :=
    exists_positive_q_occurrence_of_minimal_positive_edge
      T₁ T₂ htu hvw hx hminimal
  have hxReversed : xCoefficient T₁ T₂ u t w v ≠ 0 := by
    rw [xCoefficient_reverse_both]
    exact ne_of_gt hx
  have hqFamily : 0 < qSquareFamily T₁ T₂ :=
    qSquareFamily_pos_of_positive_occurrence T₁ T₂
      htu.symm hvw.symm hrow hcolumn hq hxReversed
  have hs := sSquareFamily_nonneg T₁ T₂
  have hb := bSquareFamily_nonneg T₁ T₂
  have hp := pSquareFamily_nonneg T₁ T₂
  have hmain := sumOfSquaresRhs_eq_treeQuartetCovariance_div_six T₁ T₂
  unfold sumOfSquaresRhs at hmain
  nlinarith

/-- Exact lower equality case of Corollary 1. -/
theorem treeQuartetCovariance_eq_zero_iff_treesIndependent
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    treeQuartetCovariance T₁ T₂ = 0 ↔ TreesIndependent T₁ T₂ := by
  constructor
  · intro hzero
    by_contra hNotInd
    have hpos := treeQuartetCovariance_pos_of_not_treesIndependent
      T₁ T₂ hNotInd
    linarith
  · exact treeQuartetCovariance_eq_zero_of_treesIndependent T₁ T₂

/-! ## The universal upper bound -/

/-- The upper inequality in Corollary 1.  It is valid for arbitrary
`X`-trees.  The proof bounds the common support-size `2`, `3`, and `4`
classes independently and retains the nonpositive disagreement term. -/
theorem treeQuartetCovariance_le_universal_bound
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    treeQuartetCovariance T₁ T₂ ≤
      1 - (4 * (Fintype.card X : ℝ) - 3) /
        (Fintype.card X : ℝ) ^ 3 := by
  classical
  let n : ℕ := Fintype.card X
  let N : ℝ := (n : ℝ)
  have hnNat : 0 < n := by
    exact Fintype.card_pos_iff.mpr T₁.taxon_nonempty
  have hn : 0 < N := by
    change 0 < (n : ℝ)
    exact_mod_cast hnNat
  have hq₂ := card_commonDisplayedPartialQuartets_two_le T₁ T₂
  have hq₃ := card_commonDisplayedPartialQuartets_three_le T₁ T₂
  have hq₄ := card_commonDisplayedPartialQuartets_four_le T₁ T₂
  have hq₂real :
      ((commonDisplayedPartialQuartets T₁ T₂ 2).card : ℝ) ≤
        (Nat.choose n 2 : ℝ) := by
    exact_mod_cast hq₂
  have hq₃real :
      ((commonDisplayedPartialQuartets T₁ T₂ 3).card : ℝ) ≤
        3 * (Nat.choose n 3 : ℝ) := by
    exact_mod_cast hq₃
  have hq₄real :
      ((commonDisplayedPartialQuartets T₁ T₂ 4).card : ℝ) ≤
        (Nat.choose n 4 : ℝ) := by
    exact_mod_cast hq₄
  have hdnonneg : 0 ≤ (quartetDistance T₁ T₂ : ℝ) := by positivity
  have hbracket :
      24 * ((commonDisplayedPartialQuartets T₁ T₂ 4).card : ℝ) +
          12 * ((commonDisplayedPartialQuartets T₁ T₂ 3).card : ℝ) +
          6 * ((commonDisplayedPartialQuartets T₁ T₂ 2).card : ℝ) -
          12 * (quartetDistance T₁ T₂ : ℝ) ≤
        6 * (Nat.choose n 2 : ℝ) +
          36 * (Nat.choose n 3 : ℝ) +
          24 * (Nat.choose n 4 : ℝ) := by
    nlinarith
  have hfactor : 0 ≤ (1 / N ^ 4) := by positivity
  have hcount := weighted_choose_identity n
  have hnormalize :
      (1 / N ^ 4) * (N ^ 4 - N * (4 * N - 3)) =
        1 - (4 * N - 3) / N ^ 3 := by
    field_simp [ne_of_gt hn]
    <;> ring
  rw [treeQuartetCovariance_eq_quartetCounts]
  change
    (1 / N ^ 4) *
        (24 * ((commonDisplayedPartialQuartets T₁ T₂ 4).card : ℝ) +
          12 * ((commonDisplayedPartialQuartets T₁ T₂ 3).card : ℝ) +
          6 * ((commonDisplayedPartialQuartets T₁ T₂ 2).card : ℝ) -
          12 * (quartetDistance T₁ T₂ : ℝ)) ≤
      1 - (4 * N - 3) / N ^ 3
  calc
    (1 / N ^ 4) *
        (24 * ((commonDisplayedPartialQuartets T₁ T₂ 4).card : ℝ) +
          12 * ((commonDisplayedPartialQuartets T₁ T₂ 3).card : ℝ) +
          6 * ((commonDisplayedPartialQuartets T₁ T₂ 2).card : ℝ) -
          12 * (quartetDistance T₁ T₂ : ℝ)) ≤
        (1 / N ^ 4) *
          (6 * (Nat.choose n 2 : ℝ) +
            36 * (Nat.choose n 3 : ℝ) +
            24 * (Nat.choose n 4 : ℝ)) :=
      mul_le_mul_of_nonneg_left hbracket hfactor
    _ = (1 / N ^ 4) * (N ^ 4 - N * (4 * N - 3)) := by rw [hcount]
    _ = 1 - (4 * N - 3) / N ^ 3 := hnormalize

/-- Exact equality ledger for the universal upper bound in Corollary 1.

The numerical upper bound is attained exactly when every one of the four
nonnegative deficits used in its proof vanishes: the common support-size
`2`, `3`, and `4` classes attain their respective universal cardinalities,
and the quartet-disagreement count is zero.  This statement is valid even in
the one-taxon boundary case; any further interpretation in terms of binary
phylogenetic reconstruction must therefore be proved separately and needs an
appropriate nondegeneracy hypothesis. -/
theorem treeQuartetCovariance_eq_universal_bound_iff_saturated_counts
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    treeQuartetCovariance T₁ T₂ =
        1 - (4 * (Fintype.card X : ℝ) - 3) /
          (Fintype.card X : ℝ) ^ 3 ↔
      (commonDisplayedPartialQuartets T₁ T₂ 2).card =
          Nat.choose (Fintype.card X) 2 ∧
      (commonDisplayedPartialQuartets T₁ T₂ 3).card =
          3 * Nat.choose (Fintype.card X) 3 ∧
      (commonDisplayedPartialQuartets T₁ T₂ 4).card =
          Nat.choose (Fintype.card X) 4 ∧
      quartetDistance T₁ T₂ = 0 := by
  classical
  let n : ℕ := Fintype.card X
  let N : ℝ := (n : ℝ)
  have hnNat : 0 < n := by
    exact Fintype.card_pos_iff.mpr T₁.taxon_nonempty
  have hn : 0 < N := by
    change 0 < (n : ℝ)
    exact_mod_cast hnNat
  have hq₂ := card_commonDisplayedPartialQuartets_two_le T₁ T₂
  have hq₃ := card_commonDisplayedPartialQuartets_three_le T₁ T₂
  have hq₄ := card_commonDisplayedPartialQuartets_four_le T₁ T₂
  have hq₂real :
      ((commonDisplayedPartialQuartets T₁ T₂ 2).card : ℝ) ≤
        (Nat.choose n 2 : ℝ) := by
    exact_mod_cast hq₂
  have hq₃real :
      ((commonDisplayedPartialQuartets T₁ T₂ 3).card : ℝ) ≤
        3 * (Nat.choose n 3 : ℝ) := by
    exact_mod_cast hq₃
  have hq₄real :
      ((commonDisplayedPartialQuartets T₁ T₂ 4).card : ℝ) ≤
        (Nat.choose n 4 : ℝ) := by
    exact_mod_cast hq₄
  have hdnonneg : 0 ≤ (quartetDistance T₁ T₂ : ℝ) := by positivity
  have hfactorPos : 0 < (1 / N ^ 4) := by positivity
  have hcount := weighted_choose_identity n
  have hnormalize :
      (1 / N ^ 4) * (N ^ 4 - N * (4 * N - 3)) =
        1 - (4 * N - 3) / N ^ 3 := by
    field_simp [ne_of_gt hn]
    <;> ring
  have hupperCount :
      1 - (4 * N - 3) / N ^ 3 =
        (1 / N ^ 4) *
          (6 * (Nat.choose n 2 : ℝ) +
            36 * (Nat.choose n 3 : ℝ) +
            24 * (Nat.choose n 4 : ℝ)) := by
    rw [← hnormalize, hcount]
  constructor
  · intro heq
    rw [treeQuartetCovariance_eq_quartetCounts] at heq
    change
      (1 / N ^ 4) *
          (24 * ((commonDisplayedPartialQuartets T₁ T₂ 4).card : ℝ) +
            12 * ((commonDisplayedPartialQuartets T₁ T₂ 3).card : ℝ) +
            6 * ((commonDisplayedPartialQuartets T₁ T₂ 2).card : ℝ) -
            12 * (quartetDistance T₁ T₂ : ℝ)) =
        1 - (4 * N - 3) / N ^ 3 at heq
    rw [hupperCount] at heq
    have hbracket :
        24 * ((commonDisplayedPartialQuartets T₁ T₂ 4).card : ℝ) +
            12 * ((commonDisplayedPartialQuartets T₁ T₂ 3).card : ℝ) +
            6 * ((commonDisplayedPartialQuartets T₁ T₂ 2).card : ℝ) -
            12 * (quartetDistance T₁ T₂ : ℝ) =
          6 * (Nat.choose n 2 : ℝ) +
            36 * (Nat.choose n 3 : ℝ) +
            24 * (Nat.choose n 4 : ℝ) := by
      nlinarith
    have hq₂eqReal :
        ((commonDisplayedPartialQuartets T₁ T₂ 2).card : ℝ) =
          (Nat.choose n 2 : ℝ) := by
      nlinarith
    have hq₃eqReal :
        ((commonDisplayedPartialQuartets T₁ T₂ 3).card : ℝ) =
          3 * (Nat.choose n 3 : ℝ) := by
      nlinarith
    have hq₄eqReal :
        ((commonDisplayedPartialQuartets T₁ T₂ 4).card : ℝ) =
          (Nat.choose n 4 : ℝ) := by
      nlinarith
    have hdeqReal : (quartetDistance T₁ T₂ : ℝ) = 0 := by
      nlinarith
    refine ⟨?_, ?_, ?_, ?_⟩
    · exact_mod_cast hq₂eqReal
    · exact_mod_cast hq₃eqReal
    · exact_mod_cast hq₄eqReal
    · exact_mod_cast hdeqReal
  · rintro ⟨hq₂eq, hq₃eq, hq₄eq, hdeq⟩
    rw [treeQuartetCovariance_eq_quartetCounts]
    change
      (1 / N ^ 4) *
          (24 * ((commonDisplayedPartialQuartets T₁ T₂ 4).card : ℝ) +
            12 * ((commonDisplayedPartialQuartets T₁ T₂ 3).card : ℝ) +
            6 * ((commonDisplayedPartialQuartets T₁ T₂ 2).card : ℝ) -
            12 * (quartetDistance T₁ T₂ : ℝ)) =
        1 - (4 * N - 3) / N ^ 3
    rw [hupperCount, hq₂eq, hq₃eq, hq₄eq, hdeq]
    push_cast
    ring

end QDFull
