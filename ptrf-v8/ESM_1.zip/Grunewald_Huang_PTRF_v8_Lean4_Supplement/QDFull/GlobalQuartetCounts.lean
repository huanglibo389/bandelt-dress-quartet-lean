import QDFull.QuartetCountIdentity
import QDFull.TreeQuartetUniqueness

/-!
# Global `6/12/24` quartet-event counts

The local fibre theorem in `QuartetCountIdentity` counts the ordered draws
inducing one fixed partial quartet.  This file performs the missing global
settlement: the same-tree event is the *disjoint* union of those fibres over
the partial quartets displayed by both trees.  Disjointness is a theorem,
not a counting convention; it follows from uniqueness of the induced
displayed partial quartet in one tree.
-/

open scoped BigOperators

namespace QDFull

universe uX uV₁ uV₂

/-- The finite set of partial quartets of support size `i` displayed by both
trees.  Its cardinality is the paper's
`|Q_i(T₁) ∩ Q_i(T₂)|`. -/
noncomputable def commonDisplayedPartialQuartets
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (i : ℕ) :
    Finset (PartialSplit X) := by
  classical
  exact Finset.univ.filter fun P =>
    IsPartialQuartet P ∧ T₁.DisplaysPartialSplit P ∧
      T₂.DisplaysPartialSplit P ∧ (partialSplitSupport P).card = i

@[simp] theorem mem_commonDisplayedPartialQuartets
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (i : ℕ)
    (P : PartialSplit X) :
    P ∈ commonDisplayedPartialQuartets T₁ T₂ i ↔
      IsPartialQuartet P ∧ T₁.DisplaysPartialSplit P ∧
        T₂.DisplaysPartialSplit P ∧ (partialSplitSupport P).card = i := by
  classical
  simp [commonDisplayedPartialQuartets]

/-- All partial quartets displayed by both trees, before grouping by support
size. -/
noncomputable def commonDisplayedPartialQuartetsAll
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    Finset (PartialSplit X) := by
  classical
  exact Finset.univ.filter fun P =>
    IsPartialQuartet P ∧ T₁.DisplaysPartialSplit P ∧
      T₂.DisplaysPartialSplit P

@[simp] theorem mem_commonDisplayedPartialQuartetsAll
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (P : PartialSplit X) :
    P ∈ commonDisplayedPartialQuartetsAll T₁ T₂ ↔
      IsPartialQuartet P ∧ T₁.DisplaysPartialSplit P ∧
        T₂.DisplaysPartialSplit P := by
  classical
  simp [commonDisplayedPartialQuartetsAll]

/-- Membership in the ungrouped common set is equivalent to membership in
exactly one of the support-size groups `2`, `3`, and `4`. -/
theorem mem_commonDisplayedPartialQuartetsAll_iff_grouped
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (P : PartialSplit X) :
    P ∈ commonDisplayedPartialQuartetsAll T₁ T₂ ↔
      P ∈ commonDisplayedPartialQuartets T₁ T₂ 2 ∨
      P ∈ commonDisplayedPartialQuartets T₁ T₂ 3 ∨
      P ∈ commonDisplayedPartialQuartets T₁ T₂ 4 := by
  classical
  simp only [mem_commonDisplayedPartialQuartetsAll,
    mem_commonDisplayedPartialQuartets]
  constructor
  · intro h
    rcases partialQuartet_support_card_cases h.1 with hcard | hcard | hcard
    · exact Or.inl ⟨h.1, h.2.1, h.2.2, hcard⟩
    · exact Or.inr (Or.inl ⟨h.1, h.2.1, h.2.2, hcard⟩)
    · exact Or.inr (Or.inr ⟨h.1, h.2.1, h.2.2, hcard⟩)
  · rintro (h | h | h)
    · exact ⟨h.1, h.2.1, h.2.2.1⟩
    · exact ⟨h.1, h.2.1, h.2.2.1⟩
    · exact ⟨h.1, h.2.1, h.2.2.1⟩

private theorem commonDisplayedPartialQuartets_disjoint_of_ne
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {i j : ℕ} (hij : i ≠ j) :
    Disjoint (commonDisplayedPartialQuartets T₁ T₂ i)
      (commonDisplayedPartialQuartets T₁ T₂ j) := by
  classical
  rw [Finset.disjoint_left]
  intro P hi hj
  exact hij (((mem_commonDisplayedPartialQuartets T₁ T₂ i P).1 hi).2.2.2.symm.trans
    ((mem_commonDisplayedPartialQuartets T₁ T₂ j P).1 hj).2.2.2)

/-- Distinct common displayed partial quartets have disjoint inducing-draw
fibres. -/
theorem commonDisplayedPartialQuartetsAll_pairwiseDisjoint_inducing
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    ((commonDisplayedPartialQuartetsAll T₁ T₂ : Finset (PartialSplit X)) :
      Set (PartialSplit X)).PairwiseDisjoint inducingDrawFinset := by
  classical
  intro P hP Q hQ hPQ
  change Disjoint (inducingDrawFinset P) (inducingDrawFinset Q)
  rw [Finset.disjoint_left]
  intro draw hdrawP hdrawQ
  have hPdata := (mem_commonDisplayedPartialQuartetsAll T₁ T₂ P).1 hP
  have hQdata := (mem_commonDisplayedPartialQuartetsAll T₁ T₂ Q).1 hQ
  apply hPQ
  exact T₁.induced_displayed_partialQuartet_unique draw
    ((mem_inducingDrawFinset P draw).1 hdrawP)
    ((mem_inducingDrawFinset Q draw).1 hdrawQ)
    hPdata.2.1 hQdata.2.1

/-- The disjoint union of all inducing-draw fibres indexed by common
displayed partial quartets. -/
noncomputable def sameTreeInducingFiberUnion
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : Finset (Fin 4 → X) := by
  classical
  exact (commonDisplayedPartialQuartetsAll T₁ T₂).biUnion
    inducingDrawFinset

/-- The same-tree event is exactly the union of the inducing-draw fibres of
the common displayed partial quartets. -/
theorem sameTreeQuartetEventSet_eq_biUnion
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    fourDrawEventSet (SameTreeQuartetEvent T₁ T₂) =
      sameTreeInducingFiberUnion T₁ T₂ := by
  classical
  ext draw
  simp only [fourDrawEventSet, sameTreeInducingFiberUnion,
    Finset.mem_filter, Finset.mem_univ, true_and,
    Finset.mem_biUnion, mem_inducingDrawFinset]
  constructor
  · rintro ⟨P, hind, hT₁, hT₂⟩
    exact ⟨P,
      (mem_commonDisplayedPartialQuartetsAll T₁ T₂ P).2
        ⟨hind.isPartialQuartet, hT₁, hT₂⟩,
      hind⟩
  · rintro ⟨P, hP, hind⟩
    have hPdata := (mem_commonDisplayedPartialQuartetsAll T₁ T₂ P).1 hP
    exact ⟨P, hind, hPdata.2.1, hPdata.2.2⟩

/-- Exact cardinality of the positive event as a sum of local fibre
cardinalities. -/
theorem card_sameTreeQuartetEvent_eq_sum_fibres
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    (fourDrawEventSet (SameTreeQuartetEvent T₁ T₂)).card =
      ∑ P ∈ commonDisplayedPartialQuartetsAll T₁ T₂,
        (inducingDrawFinset P).card := by
  classical
  rw [sameTreeQuartetEventSet_eq_biUnion]
  unfold sameTreeInducingFiberUnion
  exact Finset.card_biUnion
    (commonDisplayedPartialQuartetsAll_pairwiseDisjoint_inducing T₁ T₂)

private theorem sum_inducingDrawFinset_card_common_two
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    (∑ P ∈ commonDisplayedPartialQuartets T₁ T₂ 2,
      (inducingDrawFinset P).card) =
        6 * (commonDisplayedPartialQuartets T₁ T₂ 2).card := by
  classical
  calc
    (∑ P ∈ commonDisplayedPartialQuartets T₁ T₂ 2,
        (inducingDrawFinset P).card) =
        ∑ _P ∈ commonDisplayedPartialQuartets T₁ T₂ 2, 6 := by
          apply Finset.sum_congr rfl
          intro P hP
          have hdata := (mem_commonDisplayedPartialQuartets T₁ T₂ 2 P).1 hP
          rw [card_inducingDrawFinset_partialQuartet hdata.1, hdata.2.2.2]
          rfl
    _ = 6 * (commonDisplayedPartialQuartets T₁ T₂ 2).card := by
      simp [Nat.mul_comm]

private theorem sum_inducingDrawFinset_card_common_three
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    (∑ P ∈ commonDisplayedPartialQuartets T₁ T₂ 3,
      (inducingDrawFinset P).card) =
        12 * (commonDisplayedPartialQuartets T₁ T₂ 3).card := by
  classical
  calc
    (∑ P ∈ commonDisplayedPartialQuartets T₁ T₂ 3,
        (inducingDrawFinset P).card) =
        ∑ _P ∈ commonDisplayedPartialQuartets T₁ T₂ 3, 12 := by
          apply Finset.sum_congr rfl
          intro P hP
          have hdata := (mem_commonDisplayedPartialQuartets T₁ T₂ 3 P).1 hP
          rw [card_inducingDrawFinset_partialQuartet hdata.1, hdata.2.2.2]
          rfl
    _ = 12 * (commonDisplayedPartialQuartets T₁ T₂ 3).card := by
      simp [Nat.mul_comm]

private theorem sum_inducingDrawFinset_card_common_four
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    (∑ P ∈ commonDisplayedPartialQuartets T₁ T₂ 4,
      (inducingDrawFinset P).card) =
        24 * (commonDisplayedPartialQuartets T₁ T₂ 4).card := by
  classical
  calc
    (∑ P ∈ commonDisplayedPartialQuartets T₁ T₂ 4,
        (inducingDrawFinset P).card) =
        ∑ _P ∈ commonDisplayedPartialQuartets T₁ T₂ 4, 24 := by
          apply Finset.sum_congr rfl
          intro P hP
          have hdata := (mem_commonDisplayedPartialQuartets T₁ T₂ 4 P).1 hP
          rw [card_inducingDrawFinset_partialQuartet hdata.1, hdata.2.2.2]
          rfl
    _ = 24 * (commonDisplayedPartialQuartets T₁ T₂ 4).card := by
      simp [Nat.mul_comm]

/-- Global positive-event count.  Every coefficient `6`, `12`, or `24`
comes from the proved local fibre theorem, and no draw is counted twice. -/
theorem card_sameTreeQuartetEvent
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    (fourDrawEventSet (SameTreeQuartetEvent T₁ T₂)).card =
      6 * (commonDisplayedPartialQuartets T₁ T₂ 2).card +
      12 * (commonDisplayedPartialQuartets T₁ T₂ 3).card +
      24 * (commonDisplayedPartialQuartets T₁ T₂ 4).card := by
  classical
  rw [card_sameTreeQuartetEvent_eq_sum_fibres,
    show commonDisplayedPartialQuartetsAll T₁ T₂ =
        commonDisplayedPartialQuartets T₁ T₂ 2 ∪
          commonDisplayedPartialQuartets T₁ T₂ 3 ∪
            commonDisplayedPartialQuartets T₁ T₂ 4 by
      ext P
      simp only [Finset.mem_union]
      constructor
      · intro h
        rcases (mem_commonDisplayedPartialQuartetsAll_iff_grouped
          T₁ T₂ P).1 h with h2 | h3 | h4
        · exact Or.inl (Or.inl h2)
        · exact Or.inl (Or.inr h3)
        · exact Or.inr h4
      · rintro ((h2 | h3) | h4)
        · exact (mem_commonDisplayedPartialQuartetsAll_iff_grouped
            T₁ T₂ P).2 (Or.inl h2)
        · exact (mem_commonDisplayedPartialQuartetsAll_iff_grouped
            T₁ T₂ P).2 (Or.inr (Or.inl h3))
        · exact (mem_commonDisplayedPartialQuartetsAll_iff_grouped
            T₁ T₂ P).2 (Or.inr (Or.inr h4))]
  have h23 : Disjoint
      (commonDisplayedPartialQuartets T₁ T₂ 2)
      (commonDisplayedPartialQuartets T₁ T₂ 3) :=
    commonDisplayedPartialQuartets_disjoint_of_ne T₁ T₂ (by omega)
  have h24 : Disjoint
      (commonDisplayedPartialQuartets T₁ T₂ 2)
      (commonDisplayedPartialQuartets T₁ T₂ 4) :=
    commonDisplayedPartialQuartets_disjoint_of_ne T₁ T₂ (by omega)
  have h34 : Disjoint
      (commonDisplayedPartialQuartets T₁ T₂ 3)
      (commonDisplayedPartialQuartets T₁ T₂ 4) :=
    commonDisplayedPartialQuartets_disjoint_of_ne T₁ T₂ (by omega)
  have h234 : Disjoint
      (commonDisplayedPartialQuartets T₁ T₂ 2 ∪
        commonDisplayedPartialQuartets T₁ T₂ 3)
      (commonDisplayedPartialQuartets T₁ T₂ 4) := by
    rw [Finset.disjoint_left]
    intro P hP h4
    rw [Finset.mem_union] at hP
    rcases hP with h2 | h3
    · exact (Finset.disjoint_left.1 h24) h2 h4
    · exact (Finset.disjoint_left.1 h34) h3 h4
  rw [Finset.sum_union h234, Finset.sum_union h23,
    sum_inducingDrawFinset_card_common_two,
    sum_inducingDrawFinset_card_common_three,
    sum_inducingDrawFinset_card_common_four]

/-! ## Four-taxon supports and the negative event -/

/-- The set of taxa occurring in an ordered four-draw sample. -/
noncomputable def fourDrawSupport {X : Type uX} (draw : Fin 4 → X) :
    Finset X := by
  classical
  exact {draw 0, draw 1, draw 2, draw 3}

/-- For a displayed representative `s(A,B)`, being a partial split is
equivalent to the three expected conditions on those very representatives.
This removes any ambiguity caused by the unordered `Sym2` encoding. -/
theorem isPartialSplit_mk_iff
    {X : Type uX} [Fintype X] (A B : Finset X) :
    IsPartialSplit s(A, B) ↔ A.Nonempty ∧ B.Nonempty ∧ Disjoint A B := by
  classical
  constructor
  · rintro ⟨C, D, hCD, hCne, hDne, hdisj⟩
    rw [Sym2.eq_iff] at hCD
    rcases hCD with ⟨hAC, hBD⟩ | ⟨hAD, hBC⟩
    · subst C
      subst D
      exact ⟨hCne, hDne, hdisj⟩
    · subst D
      subst C
      exact ⟨hDne, hCne, hdisj.symm⟩
  · rintro ⟨hA, hB, hAB⟩
    exact ⟨A, B, rfl, hA, hB, hAB⟩

/-- Every partial split induced by a draw has exactly the taxa occurring in
that draw as its support. -/
theorem partialSplitSupport_eq_fourDrawSupport_of_induces
    {X : Type uX} [Fintype X] {draw : Fin 4 → X} {P : PartialSplit X}
    (hind : Induces draw P) :
    partialSplitSupport P = fourDrawSupport draw := by
  classical
  have hcanonical := (induces_iff_canonical draw P).1 hind
  rcases hcanonical.2 with rfl | rfl | rfl <;>
    apply Finset.ext <;> intro x <;>
    simp [drawPairSplit, fourDrawSupport, partialSplitSupport_mk] <;> aesop

/-- A four-draw support contains at most four taxa, independently of repeated
draws. -/
theorem fourDrawSupport_card_le_four
    {X : Type uX} [Fintype X] (draw : Fin 4 → X) :
    (fourDrawSupport draw).card ≤ 4 := by
  classical
  let R : Finset X := Finset.univ.image draw
  have heq : fourDrawSupport draw = R := by
    apply Finset.ext
    intro x
    simp [fourDrawSupport, R]
    constructor
    · aesop
    · rintro ⟨i, hi⟩
      fin_cases i <;> simp_all
  rw [heq]
  calc
    R.card ≤ (Finset.univ : Finset (Fin 4)).card :=
      Finset.card_image_le
    _ = 4 := by simp

private theorem fourDrawSupport_card_four_of_pairwise_ne
    {X : Type uX} [Fintype X] (draw : Fin 4 → X)
    (h01 : draw 0 ≠ draw 1) (h02 : draw 0 ≠ draw 2)
    (h03 : draw 0 ≠ draw 3) (h12 : draw 1 ≠ draw 2)
    (h13 : draw 1 ≠ draw 3) (h23 : draw 2 ≠ draw 3) :
    (fourDrawSupport draw).card = 4 := by
  classical
  simp [fourDrawSupport, h01, h02, h03, h12, h13, h23,
    h01.symm, h02.symm, h03.symm, h12.symm, h13.symm, h23.symm]

private theorem fourDrawSupport_card_four_of_pairing01_pairing02
    {X : Type uX} [Fintype X] (draw : Fin 4 → X)
    (h01 : IsPartialSplit (drawPairSplit draw 0 1 2 3))
    (h02 : IsPartialSplit (drawPairSplit draw 0 2 1 3)) :
    (fourDrawSupport draw).card = 4 := by
  classical
  have hd01 := (isPartialSplit_mk_iff
    ({draw 0, draw 1} : Finset X) {draw 2, draw 3}).1 (by
      simpa [drawPairSplit] using h01)
  have hd02 := (isPartialSplit_mk_iff
    ({draw 0, draw 2} : Finset X) {draw 1, draw 3}).1 (by
      simpa [drawPairSplit] using h02)
  simp only [Finset.disjoint_left, Finset.mem_insert,
    Finset.mem_singleton] at hd01 hd02
  have h01 : draw 0 ≠ draw 1 := by
    intro h
    exact hd02.2.2 (Or.inl rfl) (Or.inl h)
  have h02 : draw 0 ≠ draw 2 := by
    intro h
    exact hd01.2.2 (Or.inl rfl) (Or.inl h)
  have h03 : draw 0 ≠ draw 3 := by
    intro h
    exact hd01.2.2 (Or.inl rfl) (Or.inr h)
  have h12 : draw 1 ≠ draw 2 := by
    intro h
    exact hd01.2.2 (Or.inr rfl) (Or.inl h)
  have h13 : draw 1 ≠ draw 3 := by
    intro h
    exact hd01.2.2 (Or.inr rfl) (Or.inr h)
  have h23 : draw 2 ≠ draw 3 := by
    intro h
    exact hd02.2.2 (Or.inr rfl) (Or.inr h)
  exact fourDrawSupport_card_four_of_pairwise_ne draw
    h01 h02 h03 h12 h13 h23

private theorem fourDrawSupport_card_four_of_pairing01_pairing03
    {X : Type uX} [Fintype X] (draw : Fin 4 → X)
    (h01 : IsPartialSplit (drawPairSplit draw 0 1 2 3))
    (h03 : IsPartialSplit (drawPairSplit draw 0 3 1 2)) :
    (fourDrawSupport draw).card = 4 := by
  classical
  have hd01 := (isPartialSplit_mk_iff
    ({draw 0, draw 1} : Finset X) {draw 2, draw 3}).1 (by
      simpa [drawPairSplit] using h01)
  have hd03 := (isPartialSplit_mk_iff
    ({draw 0, draw 3} : Finset X) {draw 1, draw 2}).1 (by
      simpa [drawPairSplit] using h03)
  simp only [Finset.disjoint_left, Finset.mem_insert,
    Finset.mem_singleton] at hd01 hd03
  have h01 : draw 0 ≠ draw 1 := by
    intro h
    exact hd03.2.2 (Or.inl rfl) (Or.inl h)
  have h02 : draw 0 ≠ draw 2 := by
    intro h
    exact hd01.2.2 (Or.inl rfl) (Or.inl h)
  have h03 : draw 0 ≠ draw 3 := by
    intro h
    exact hd01.2.2 (Or.inl rfl) (Or.inr h)
  have h12 : draw 1 ≠ draw 2 := by
    intro h
    exact hd01.2.2 (Or.inr rfl) (Or.inl h)
  have h13 : draw 1 ≠ draw 3 := by
    intro h
    exact hd01.2.2 (Or.inr rfl) (Or.inr h)
  have h23 : draw 2 ≠ draw 3 := by
    intro h
    exact hd03.2.2 (Or.inr rfl) (Or.inr h.symm)
  exact fourDrawSupport_card_four_of_pairwise_ne draw
    h01 h02 h03 h12 h13 h23

private theorem fourDrawSupport_card_four_of_pairing02_pairing03
    {X : Type uX} [Fintype X] (draw : Fin 4 → X)
    (h02 : IsPartialSplit (drawPairSplit draw 0 2 1 3))
    (h03 : IsPartialSplit (drawPairSplit draw 0 3 1 2)) :
    (fourDrawSupport draw).card = 4 := by
  classical
  have hd02 := (isPartialSplit_mk_iff
    ({draw 0, draw 2} : Finset X) {draw 1, draw 3}).1 (by
      simpa [drawPairSplit] using h02)
  have hd03 := (isPartialSplit_mk_iff
    ({draw 0, draw 3} : Finset X) {draw 1, draw 2}).1 (by
      simpa [drawPairSplit] using h03)
  simp only [Finset.disjoint_left, Finset.mem_insert,
    Finset.mem_singleton] at hd02 hd03
  have h01 : draw 0 ≠ draw 1 := by
    intro h
    exact hd02.2.2 (Or.inl rfl) (Or.inl h)
  have h02 : draw 0 ≠ draw 2 := by
    intro h
    exact hd03.2.2 (Or.inl rfl) (Or.inr h)
  have h03 : draw 0 ≠ draw 3 := by
    intro h
    exact hd02.2.2 (Or.inl rfl) (Or.inr h)
  have h12 : draw 1 ≠ draw 2 := by
    intro h
    exact hd02.2.2 (Or.inr rfl) (Or.inl h.symm)
  have h13 : draw 1 ≠ draw 3 := by
    intro h
    exact hd03.2.2 (Or.inr rfl) (Or.inl h.symm)
  have h23 : draw 2 ≠ draw 3 := by
    intro h
    exact hd02.2.2 (Or.inr rfl) (Or.inr h)
  exact fourDrawSupport_card_four_of_pairwise_ne draw
    h01 h02 h03 h12 h13 h23

/-- Two distinct partial quartets induced by one ordered draw force all four
drawn taxa to be distinct. -/
theorem fourDrawSupport_card_four_of_distinct_induced
    {X : Type uX} [Fintype X] {draw : Fin 4 → X}
    {P Q : PartialSplit X} (hindP : Induces draw P)
    (hindQ : Induces draw Q) (hPQ : P ≠ Q) :
    (fourDrawSupport draw).card = 4 := by
  classical
  have hP := (induces_iff_canonical draw P).1 hindP
  have hQ := (induces_iff_canonical draw Q).1 hindQ
  rcases hP.2 with hP01 | hP02 | hP03 <;>
    rcases hQ.2 with hQ01 | hQ02 | hQ03
  · exact (hPQ (hP01.trans hQ01.symm)).elim
  · exact fourDrawSupport_card_four_of_pairing01_pairing02 draw
      (by simpa [hP01] using hP.1) (by simpa [hQ02] using hQ.1)
  · exact fourDrawSupport_card_four_of_pairing01_pairing03 draw
      (by simpa [hP01] using hP.1) (by simpa [hQ03] using hQ.1)
  · exact fourDrawSupport_card_four_of_pairing01_pairing02 draw
      (by simpa [hQ01] using hQ.1) (by simpa [hP02] using hP.1)
  · exact (hPQ (hP02.trans hQ02.symm)).elim
  · exact fourDrawSupport_card_four_of_pairing02_pairing03 draw
      (by simpa [hP02] using hP.1) (by simpa [hQ03] using hQ.1)
  · exact fourDrawSupport_card_four_of_pairing01_pairing03 draw
      (by simpa [hQ01] using hQ.1) (by simpa [hP03] using hP.1)
  · exact fourDrawSupport_card_four_of_pairing02_pairing03 draw
      (by simpa [hQ02] using hQ.1) (by simpa [hP03] using hP.1)
  · exact (hPQ (hP03.trans hQ03.symm)).elim

/-- A partial quartet on four taxa is a full quartet. -/
theorem IsPartialQuartet.isQuartet_of_support_card_four
    {X : Type uX} [Fintype X] {P : PartialSplit X}
    (hP : IsPartialQuartet P)
    (hcard : (partialSplitSupport P).card = 4) : IsQuartet P := by
  classical
  rcases hP with ⟨hpartial, A, B, hPAB, hA, hB⟩
  subst P
  have hdata := (isPartialSplit_mk_iff A B).1 hpartial
  have hsum : A.card + B.card = 4 := by
    calc
      A.card + B.card = (A ∪ B).card :=
        (Finset.card_union_of_disjoint hdata.2.2).symm
      _ = 4 := by simpa [partialSplitSupport_mk] using hcard
  have hAeq : A.card = 2 := by
    have hApos : 0 < A.card := Finset.card_pos.mpr hdata.1
    have hBpos : 0 < B.card := Finset.card_pos.mpr hdata.2.1
    omega
  have hBeq : B.card = 2 := by omega
  exact ⟨hpartial, A, B, rfl, hAeq, hBeq⟩

/-- Every full quartet has a four-element support. -/
theorem IsQuartet.support_card_four
    {X : Type uX} [Fintype X] {P : PartialSplit X}
    (hP : IsQuartet P) : (partialSplitSupport P).card = 4 := by
  classical
  rcases hP with ⟨hpartial, A, B, hPAB, hA, hB⟩
  subst P
  have hdisj := ((isPartialSplit_mk_iff A B).1 hpartial).2.2
  rw [partialSplitSupport_mk, Finset.card_union_of_disjoint hdisj, hA, hB]

/-- Explicit pair-pair representation of a full quartet, including all six
pairwise inequalities among its taxa. -/
theorem quartet_representation
    {X : Type uX} [Fintype X] [DecidableEq X] {P : PartialSplit X}
    (hP : IsQuartet P) :
    ∃ a b c d : X,
      a ≠ b ∧ a ≠ c ∧ a ≠ d ∧
      b ≠ c ∧ b ≠ d ∧ c ≠ d ∧
      P = s(({a, b} : Finset X), ({c, d} : Finset X)) := by
  classical
  rcases hP with ⟨hpartial, A, B, hPAB, hA, hB⟩
  obtain ⟨a, b, hab, hAeq⟩ := Finset.card_eq_two.mp hA
  obtain ⟨c, d, hcd, hBeq⟩ := Finset.card_eq_two.mp hB
  have hpartial' :
      IsPartialSplit s(({a, b} : Finset X), ({c, d} : Finset X)) := by
    rw [← hAeq, ← hBeq, ← hPAB]
    exact hpartial
  have hdisj := ((isPartialSplit_mk_iff
    ({a, b} : Finset X) ({c, d} : Finset X)).1 hpartial').2.2
  simp only [Finset.disjoint_left, Finset.mem_insert,
    Finset.mem_singleton] at hdisj
  have hac : a ≠ c := by
    intro h
    exact hdisj (Or.inl rfl) (Or.inl h)
  have had : a ≠ d := by
    intro h
    exact hdisj (Or.inl rfl) (Or.inr h)
  have hbc : b ≠ c := by
    intro h
    exact hdisj (Or.inr rfl) (Or.inl h)
  have hbd : b ≠ d := by
    intro h
    exact hdisj (Or.inr rfl) (Or.inr h)
  refine ⟨a, b, c, d, hab, hac, had, hbc, hbd, hcd, ?_⟩
  exact hPAB.trans (congrArg₂ (fun U V : Finset X => s(U, V))
    hAeq hBeq)

/-- The finite fibre of ordered draws having exactly the prescribed support.
-/
noncomputable def drawsWithSupport {X : Type uX} [Fintype X]
    (S : Finset X) : Finset (Fin 4 → X) := by
  classical
  exact Finset.univ.filter fun draw => fourDrawSupport draw = S

@[simp] theorem mem_drawsWithSupport
    {X : Type uX} [Fintype X] (S : Finset X) (draw : Fin 4 → X) :
    draw ∈ drawsWithSupport S ↔ fourDrawSupport draw = S := by
  classical
  simp [drawsWithSupport]

/-- For four pairwise-distinct labels, having that four-element support is
equivalent to drawing once from each of the four singleton cells. -/
theorem drawsWithSupport_four_eq_oneEachDraws
    {X : Type uX} [Fintype X] [DecidableEq X] {a b c d : X}
    (hab : a ≠ b) (hac : a ≠ c) (had : a ≠ d)
    (hbc : b ≠ c) (hbd : b ≠ d) (hcd : c ≠ d) :
    drawsWithSupport ({a, b, c, d} : Finset X) =
      oneEachDraws (fourSingletonCells a b c d) := by
  classical
  ext draw
  rw [mem_drawsWithSupport]
  constructor
  · intro hsupp
    have hposition : ∀ x ∈ ({a, b, c, d} : Finset X),
        ∃ i : Fin 4, draw i = x := by
      intro x hx
      have hmem : x ∈ fourDrawSupport draw := by
        rw [hsupp]
        exact hx
      simp [fourDrawSupport] at hmem
      rcases hmem with h | h | h | h
      · exact ⟨0, h.symm⟩
      · exact ⟨1, h.symm⟩
      · exact ⟨2, h.symm⟩
      · exact ⟨3, h.symm⟩
    rw [mem_oneEachDraws_iff_hits_all _
      (fourSingletonCells_pairwiseDisjoint hab hac had hbc hbd hcd)]
    intro j
    fin_cases j
    · obtain ⟨i, hi⟩ := hposition a (by simp)
      exact ⟨i, by simp [fourSingletonCells, hi]⟩
    · obtain ⟨i, hi⟩ := hposition b (by simp)
      exact ⟨i, by simp [fourSingletonCells, hi]⟩
    · obtain ⟨i, hi⟩ := hposition c (by simp)
      exact ⟨i, by simp [fourSingletonCells, hi]⟩
    · obtain ⟨i, hi⟩ := hposition d (by simp)
      exact ⟨i, by simp [fourSingletonCells, hi]⟩
  · intro hone
    have hhit := (mem_oneEachDraws_iff_hits_all _
      (fourSingletonCells_pairwiseDisjoint hab hac had hbc hbd hcd) draw).1 hone
    have hsub : ({a, b, c, d} : Finset X) ⊆ fourDrawSupport draw := by
      intro x hx
      simp only [Finset.mem_insert, Finset.mem_singleton] at hx
      have hdrawmem (i : Fin 4) : draw i ∈ fourDrawSupport draw := by
        fin_cases i <;> simp [fourDrawSupport]
      rcases hx with hx | hx | hx | hx
      · obtain ⟨i, hi⟩ := hhit 0
        have hi' : draw i = a := by simpa [fourSingletonCells] using hi
        simpa [hx, ← hi'] using hdrawmem i
      · obtain ⟨i, hi⟩ := hhit 1
        have hi' : draw i = b := by simpa [fourSingletonCells] using hi
        simpa [hx, ← hi'] using hdrawmem i
      · obtain ⟨i, hi⟩ := hhit 2
        have hi' : draw i = c := by simpa [fourSingletonCells] using hi
        simpa [hx, ← hi'] using hdrawmem i
      · obtain ⟨i, hi⟩ := hhit 3
        have hi' : draw i = d := by simpa [fourSingletonCells] using hi
        simpa [hx, ← hi'] using hdrawmem i
    have hlabelcard : ({a, b, c, d} : Finset X).card = 4 := by
      simp [hab, hac, had, hbc, hbd, hcd]
    have hsuppcard : (fourDrawSupport draw).card ≤ 4 :=
      fourDrawSupport_card_le_four draw
    exact (Finset.eq_of_subset_of_card_le hsub (by omega)).symm

/-- Every four-element support has exactly `4! = 24` ordered draws. -/
theorem card_drawsWithSupport_of_card_four
    {X : Type uX} [Fintype X] (S : Finset X) (hS : S.card = 4) :
    (drawsWithSupport S).card = 24 := by
  classical
  obtain ⟨a, b, c, d, hab, hac, had, hbc, hbd, hcd, rfl⟩ :=
    Finset.card_eq_four.mp hS
  rw [drawsWithSupport_four_eq_oneEachDraws hab hac had hbc hbd hcd,
    card_oneEachDraws _
      (fourSingletonCells_pairwiseDisjoint hab hac had hbc hbd hcd)]
  simp [fourSingletonCells, Fin.prod_univ_succ]

/-- Any ordered draw whose support equals the support of a full quartet
induces that quartet. -/
theorem induces_of_isQuartet_and_support_eq
    {X : Type uX} [Fintype X] {draw : Fin 4 → X}
    {P : PartialSplit X} (hP : IsQuartet P)
    (hsupp : fourDrawSupport draw = partialSplitSupport P) :
    Induces draw P := by
  classical
  obtain ⟨a, b, c, d, hab, hac, had, hbc, hbd, hcd, hrep⟩ :=
    quartet_representation hP
  have hPsupp : partialSplitSupport P = ({a, b, c, d} : Finset X) := by
    rw [hrep, partialSplitSupport_mk]
    ext x
    simp
    aesop
  have hone : draw ∈ oneEachDraws (fourSingletonCells a b c d) := by
    rw [← drawsWithSupport_four_eq_oneEachDraws hab hac had hbc hbd hcd,
      mem_drawsWithSupport, hsupp, hPsupp]
  rw [mem_oneEachDraws] at hone
  rcases hone with ⟨π, hπ⟩
  have h0 : draw (π.symm 0) = a := by
    simpa [fourSingletonCells] using hπ (π.symm 0)
  have h1 : draw (π.symm 1) = b := by
    simpa [fourSingletonCells] using hπ (π.symm 1)
  have h2 : draw (π.symm 2) = c := by
    simpa [fourSingletonCells] using hπ (π.symm 2)
  have h3 : draw (π.symm 3) = d := by
    simpa [fourSingletonCells] using hπ (π.symm 3)
  refine ⟨hP.1, π.symm, ?_⟩
  rw [hrep, Sym2.eq_iff]
  left
  constructor <;> apply Finset.ext <;> intro x <;>
    simp [h0, h1, h2, h3]

/-- The two trees display distinct full quartets on the same four-taxon
support.  This is the support-level notion counted by quartet distance. -/
def TreesDisagreeOnQuartetSupport
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (S : Finset X) : Prop :=
  S.card = 4 ∧
    ∃ P Q : PartialSplit X,
      IsQuartet P ∧ IsQuartet Q ∧
      T₁.DisplaysPartialSplit P ∧ T₂.DisplaysPartialSplit Q ∧
      partialSplitSupport P = S ∧ partialSplitSupport Q = S ∧ P ≠ Q

/-- The finite set of four-taxon supports on which the two trees display
different quartets. -/
noncomputable def quartetDisagreementSupports
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : Finset (Finset X) := by
  classical
  exact Finset.univ.filter (TreesDisagreeOnQuartetSupport T₁ T₂)

@[simp] theorem mem_quartetDisagreementSupports
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (S : Finset X) :
    S ∈ quartetDisagreementSupports T₁ T₂ ↔
      TreesDisagreeOnQuartetSupport T₁ T₂ S := by
  classical
  simp [quartetDisagreementSupports]

/-- Quartet distance as the number of four-taxon supports on which the two
trees display different full quartets. -/
noncomputable def quartetDistance
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℕ :=
  (quartetDisagreementSupports T₁ T₂).card

/-- Exact semantic bridge: the negative tree event occurs precisely when the
sample support is a quartet-disagreement support. -/
theorem differentTreeQuartetEvent_iff_support_disagreement
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (draw : Fin 4 → X) :
    DifferentTreeQuartetEvent T₁ T₂ draw ↔
      TreesDisagreeOnQuartetSupport T₁ T₂ (fourDrawSupport draw) := by
  classical
  constructor
  · rintro ⟨P, Q, hindP, hindQ, hT₁P, hT₂Q, hPQ⟩
    have hcard := fourDrawSupport_card_four_of_distinct_induced
      hindP hindQ hPQ
    have hPsupp := partialSplitSupport_eq_fourDrawSupport_of_induces hindP
    have hQsupp := partialSplitSupport_eq_fourDrawSupport_of_induces hindQ
    have hPquartet : IsQuartet P :=
      hindP.isPartialQuartet.isQuartet_of_support_card_four (by
        rw [hPsupp]
        exact hcard)
    have hQquartet : IsQuartet Q :=
      hindQ.isPartialQuartet.isQuartet_of_support_card_four (by
        rw [hQsupp]
        exact hcard)
    exact ⟨hcard, P, Q, hPquartet, hQquartet, hT₁P, hT₂Q,
      hPsupp, hQsupp, hPQ⟩
  · rintro ⟨hcard, P, Q, hPquartet, hQquartet, hT₁P, hT₂Q,
      hPsupp, hQsupp, hPQ⟩
    have hindP : Induces draw P :=
      induces_of_isQuartet_and_support_eq hPquartet hPsupp.symm
    have hindQ : Induces draw Q :=
      induces_of_isQuartet_and_support_eq hQquartet hQsupp.symm
    exact ⟨P, Q, hindP, hindQ, hT₁P, hT₂Q, hPQ⟩

/-- Distinct support fibres are disjoint. -/
theorem quartetDisagreementSupports_pairwiseDisjoint_draws
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    ((quartetDisagreementSupports T₁ T₂ : Finset (Finset X)) :
      Set (Finset X)).PairwiseDisjoint drawsWithSupport := by
  classical
  intro S hS R hR hSR
  change Disjoint (drawsWithSupport S) (drawsWithSupport R)
  rw [Finset.disjoint_left]
  intro draw hdrawS hdrawR
  apply hSR
  exact ((mem_drawsWithSupport S draw).1 hdrawS).symm.trans
    ((mem_drawsWithSupport R draw).1 hdrawR)

/-- The union of the support fibres indexed by quartet disagreements. -/
noncomputable def differentTreeSupportFiberUnion
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : Finset (Fin 4 → X) := by
  classical
  exact (quartetDisagreementSupports T₁ T₂).biUnion drawsWithSupport

/-- The negative tree-event set is exactly the disjoint union of the
four-taxon support fibres counted by quartet distance. -/
theorem differentTreeQuartetEventSet_eq_biUnion
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    fourDrawEventSet (DifferentTreeQuartetEvent T₁ T₂) =
      differentTreeSupportFiberUnion T₁ T₂ := by
  classical
  ext draw
  simp only [fourDrawEventSet, differentTreeSupportFiberUnion,
    Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_biUnion,
    mem_quartetDisagreementSupports, mem_drawsWithSupport]
  rw [differentTreeQuartetEvent_iff_support_disagreement]
  constructor
  · intro h
    exact ⟨fourDrawSupport draw, h, rfl⟩
  · rintro ⟨S, hS, hsupp⟩
    simpa [hsupp] using hS

/-- Exact global negative-event count: every quartet disagreement contributes
the `24` permutations of its four-taxon support, once each. -/
theorem card_differentTreeQuartetEvent
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    (fourDrawEventSet (DifferentTreeQuartetEvent T₁ T₂)).card =
      24 * quartetDistance T₁ T₂ := by
  classical
  rw [differentTreeQuartetEventSet_eq_biUnion]
  unfold differentTreeSupportFiberUnion quartetDistance
  rw [Finset.card_biUnion
    (quartetDisagreementSupports_pairwiseDisjoint_draws T₁ T₂)]
  calc
    (∑ S ∈ quartetDisagreementSupports T₁ T₂,
        (drawsWithSupport S).card) =
        ∑ _S ∈ quartetDisagreementSupports T₁ T₂, 24 := by
      apply Finset.sum_congr rfl
      intro S hS
      exact card_drawsWithSupport_of_card_four S
        ((mem_quartetDisagreementSupports T₁ T₂ S).1 hS).1
    _ = 24 * (quartetDisagreementSupports T₁ T₂).card := by
      simp [Nat.mul_comm]

/-- Lemma 5 of the paper: the exact `6/12/24` identity relating quartet
covariance, common displayed partial quartets, and quartet distance. -/
theorem treeQuartetCovariance_eq_quartetCounts
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    treeQuartetCovariance T₁ T₂ =
      (1 / (Fintype.card X : ℝ) ^ 4) *
        (24 * ((commonDisplayedPartialQuartets T₁ T₂ 4).card : ℝ) +
         12 * ((commonDisplayedPartialQuartets T₁ T₂ 3).card : ℝ) +
          6 * ((commonDisplayedPartialQuartets T₁ T₂ 2).card : ℝ) -
         12 * (quartetDistance T₁ T₂ : ℝ)) := by
  classical
  rw [treeQuartetCovariance, fourDrawProbability_eq,
    fourDrawProbability_eq, card_sameTreeQuartetEvent,
    card_differentTreeQuartetEvent]
  push_cast
  ring

end QDFull
