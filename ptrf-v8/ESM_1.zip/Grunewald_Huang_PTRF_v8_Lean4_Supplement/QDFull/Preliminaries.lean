import Mathlib
import QuartetDistance.GraphQuartet

/-!
# Exact preliminary objects for the Grunewald--Huang paper

This file starts the direct formalization of the preliminary definitions in
Section 2 of the locked manuscript.  Unlike the earlier binary-leaf-labelled infrastructure, `XTree`
allows repeated labels at a vertex and labels at internal vertices.
-/

open scoped BigOperators
open SimpleGraph

namespace QDFull

universe uX uV

/-- Deleting one unordered pair can remove at most one neighbour of a fixed
vertex.  This cardinal lemma is stated using `Set.ncard`, so it does not hide a
choice of decidable adjacency relation in its hypotheses. -/
theorem neighbor_ncard_le_deleteEdges_neighbor_ncard_add_one
    {V : Type uV} [Fintype V] (G : SimpleGraph V) (u v y : V) :
    (G.neighborSet y).ncard ≤
      ((G.deleteEdges {s(u, v)}).neighborSet y).ncard + 1 := by
  classical
  let H := G.deleteEdges {s(u, v)}
  let z0 : V := if y = u then v else u
  have hsub : G.neighborSet y ⊆ insert z0 (H.neighborSet y) := by
    intro z hz
    have hG : G.Adj y z := hz
    by_cases hH : H.Adj y z
    · exact Set.mem_insert_iff.mpr (Or.inr hH)
    · have hedge : s(y, z) = s(u, v) := by
        by_contra hne
        apply hH
        simp [H, hG, hne]
      rw [Sym2.eq_iff] at hedge
      rcases hedge with h | h
      · simp [z0, h.1, h.2]
      · by_cases hvu : v = u <;> simp [z0, h.1, h.2, hvu]
  calc
    (G.neighborSet y).ncard ≤ (insert z0 (H.neighborSet y)).ncard :=
      Set.ncard_le_ncard hsub
    _ ≤ (H.neighborSet y).ncard + 1 := Set.ncard_insert_le _ _
    _ = ((G.deleteEdges {s(u, v)}).neighborSet y).ncard + 1 := rfl

/-- A finite vertex-labelled `X`-tree in the sense of the paper.  Vertices of
graph degree at most two must carry at least one taxon; labels need not be
injective and vertices of higher degree may also carry labels. -/
structure XTree (X : Type uX) (V : Type uV) [Fintype X] [Fintype V] where
  graph : SimpleGraph V
  isTree : graph.IsTree
  label : X → V
  lowDegree_labelled :
    ∀ v : V, Nat.card (graph.neighborSet v) ≤ 2 → ∃ x : X, label x = v

namespace XTree

variable {X : Type uX} {V : Type uV} [Fintype X] [Fintype V]

/-- The paper's axioms force the taxon type of an `XTree` to be nonempty.
Indeed, a finite tree has a vertex of degree at most one (or consists of a
single vertex), and every vertex of degree at most two carries a label. -/
theorem taxon_nonempty (T : XTree X V) : Nonempty X := by
  classical
  by_cases hnontrivial : Nontrivial V
  · letI : Nontrivial V := hnontrivial
    obtain ⟨v, hv⟩ := T.isTree.exists_vert_degree_one_of_nontrivial
    have hncard : (T.graph.neighborSet v).ncard = 1 := by
      rw [← Nat.card_coe_set_eq, Nat.card_eq_fintype_card,
        T.graph.card_neighborSet_eq_degree, hv]
    have hlow : Nat.card (T.graph.neighborSet v) ≤ 2 := by
      rw [Nat.card_coe_set_eq, hncard]
      omega
    obtain ⟨x, _⟩ := T.lowDegree_labelled v hlow
    exact ⟨x⟩
  · letI : Subsingleton V := not_nontrivial_iff_subsingleton.mp hnontrivial
    let v : V := Classical.choice T.isTree.connected.nonempty
    have hempty : T.graph.neighborSet v = ∅ := by
      ext w
      simp only [Set.mem_empty_iff_false, iff_false]
      intro hvw
      change T.graph.Adj v w at hvw
      exact (SimpleGraph.Adj.ne hvw) (Subsingleton.elim v w)
    have hlow : Nat.card (T.graph.neighborSet v) ≤ 2 := by
      rw [hempty]
      simp
    obtain ⟨x, _⟩ := T.lowDegree_labelled v hlow
    exact ⟨x⟩

/-- `N(v)` from the paper. -/
def neighbors (T : XTree X V) (v : V) : Set V := T.graph.neighborSet v

/-- `N_+(v) = N(v) ∪ {v}`. -/
def neighborsPlus (T : XTree X V) (v : V) : Set V := insert v (T.neighbors v)

/-- `N_v(w)`, the neighbours of `w` other than `v`. -/
def neighborsAway (T : XTree X V) (v w : V) : Set V := T.neighbors w \ {v}

/-- `N_{v+}(w) = N_v(w) ∪ {w}`. -/
def neighborsAwayPlus (T : XTree X V) (v w : V) : Set V :=
  insert w (T.neighborsAway v w)

/-- The paper's index set `I_{t,u}` as a set of ordered vertex pairs. -/
def indexI (T : XTree X V) (t u : V) : Set (V × V) :=
  {z | z.1 ∈ T.neighborsAwayPlus t u ∧ z.2 ∈ T.neighborsPlus u ∧
    (z.1 = u ∨ (z.2 ≠ t ∧ z.2 ≠ z.1))}

/-- The enlarged index set `I'_{t,u}` used in the raw quadratic expansion. -/
def indexIPrime (T : XTree X V) (t u : V) : Set (V × V) :=
  {z | z.1 ∈ T.neighborsAwayPlus t u ∧ z.2 ∈ T.neighborsPlus u ∧
    (z.1 = u ∨ z.2 ≠ z.1)}

@[simp] theorem mem_neighbors (T : XTree X V) (u v : V) :
    u ∈ T.neighbors v ↔ T.graph.Adj v u := Iff.rfl

@[simp] theorem mem_neighborsPlus (T : XTree X V) (u v : V) :
    u ∈ T.neighborsPlus v ↔ u = v ∨ T.graph.Adj v u := by
  simp [neighborsPlus, neighbors]

@[simp] theorem mem_neighborsAway (T : XTree X V) (u v w : V) :
    u ∈ T.neighborsAway v w ↔ T.graph.Adj w u ∧ u ≠ v := by
  simp [neighborsAway, neighbors]

@[simp] theorem mem_neighborsAwayPlus (T : XTree X V) (u v w : V) :
    u ∈ T.neighborsAwayPlus v w ↔
      u = w ∨ (T.graph.Adj w u ∧ u ≠ v) := by
  simp [neighborsAwayPlus]

@[simp] theorem mem_indexI (T : XTree X V) (t u u' u'' : V) :
    (u', u'') ∈ T.indexI t u ↔
      u' ∈ T.neighborsAwayPlus t u ∧ u'' ∈ T.neighborsPlus u ∧
        (u' = u ∨ (u'' ≠ t ∧ u'' ≠ u')) := Iff.rfl

@[simp] theorem mem_indexIPrime (T : XTree X V) (t u u' u'' : V) :
    (u', u'') ∈ T.indexIPrime t u ↔
      u' ∈ T.neighborsAwayPlus t u ∧ u'' ∈ T.neighborsPlus u ∧
        (u' = u ∨ u'' ≠ u') := Iff.rfl

/-- A graph-theoretic leaf. -/
def IsLeaf (T : XTree X V) (v : V) : Prop :=
  Nat.card (T.graph.neighborSet v) = 1

/-- The paper's phylogenetic specialisation: taxa biject with graph leaves. -/
def IsPhylogenetic (T : XTree X V) : Prop :=
  Function.Injective T.label ∧
    (∀ x : X, T.IsLeaf (T.label x)) ∧
    (∀ v : V, T.IsLeaf v → ∃ x : X, T.label x = v)

/-- The paper's binary specialisation: every non-leaf vertex has degree three. -/
def IsBinaryPhylogenetic (T : XTree X V) : Prop :=
  T.IsPhylogenetic ∧
    ∀ v : V, ¬ T.IsLeaf v → Nat.card (T.graph.neighborSet v) = 3

/-- Vertices in the component of `v` after deleting the edge `{u,v}`.
This is `V^u(v)` in the paper. -/
def vertexSide (T : XTree X V) (u v : V) : Set V :=
  {z | (T.graph.deleteEdges {s(u, v)}).Reachable v z}

/-- Taxa carried by the component `V^u(v)`. -/
noncomputable def edgeSide (T : XTree X V) (u v : V) : Finset X := by
  classical
  exact Finset.univ.filter fun x => T.label x ∈ T.vertexSide u v

@[simp] theorem mem_edgeSide (T : XTree X V) (u v : V) (x : X) :
    x ∈ T.edgeSide u v ↔
      (T.graph.deleteEdges {s(u, v)}).Reachable v (T.label x) := by
  classical
  simp [edgeSide, vertexSide]

/-- Deleting an actual edge of a tree leaves every vertex on one of its two
endpoint sides.  The order in `vertexSide u v` follows the paper: it is the
component containing the second endpoint `v`. -/
theorem mem_vertexSide_or_mem_vertexSide_reverse_of_adj
    (T : XTree X V) {u v : V} (_huv : T.graph.Adj u v) (x : V) :
    x ∈ T.vertexSide u v ∨ x ∈ T.vertexSide v u := by
  have hux : T.graph.Reachable u x := T.isTree.connected u x
  rcases QuartetDistance.GraphQuartet.reachable_endpoint_or_endpoint_after_delete
      T.graph u v x hux with hu | hv
  · right
    change (T.graph.deleteEdges {s(v, u)}).Reachable u x
    rw [Sym2.eq_swap]
    exact hu
  · exact Or.inl hv

/-- The two endpoint components obtained by deleting an edge of a tree are
disjoint. -/
theorem vertexSide_disjoint_reverse_of_adj
    (T : XTree X V) {u v : V} (huv : T.graph.Adj u v) :
    Disjoint (T.vertexSide u v) (T.vertexSide v u) := by
  rw [Set.disjoint_left]
  intro x hvx hux
  change (T.graph.deleteEdges {s(u, v)}).Reachable v x at hvx
  change (T.graph.deleteEdges {s(v, u)}).Reachable u x at hux
  rw [Sym2.eq_swap] at hux
  have hbridge : T.graph.IsBridge s(u, v) :=
    (SimpleGraph.isAcyclic_iff_forall_adj_isBridge.mp T.isTree.isAcyclic) huv
  exact hbridge (hux.trans hvx.symm)

/-- The two taxon sides of an edge cover all taxa. -/
theorem edgeSide_set_union_reverse_of_adj
    (T : XTree X V) {u v : V} (huv : T.graph.Adj u v) :
    (T.edgeSide u v : Set X) ∪ (T.edgeSide v u : Set X) = Set.univ := by
  ext x
  simp only [Set.mem_union, Finset.mem_coe, Set.mem_univ, iff_true]
  rcases T.mem_vertexSide_or_mem_vertexSide_reverse_of_adj huv (T.label x) with h | h
  · exact Or.inl ((T.mem_edgeSide u v x).mpr h)
  · exact Or.inr ((T.mem_edgeSide v u x).mpr h)

/-- The two taxon sides of an edge are disjoint. -/
theorem edgeSide_disjoint_reverse_of_adj
    (T : XTree X V) {u v : V} (huv : T.graph.Adj u v) :
    Disjoint (T.edgeSide u v) (T.edgeSide v u) := by
  classical
  rw [Finset.disjoint_left]
  intro x hxv hxu
  exact (Set.disjoint_left.mp (T.vertexSide_disjoint_reverse_of_adj huv)
    ((T.mem_edgeSide u v x).mp hxv)) ((T.mem_edgeSide v u x).mp hxu)

/-- Every component obtained after deleting one edge contains a taxon.  The
proof takes a leaf of that finite component (or its sole vertex), observes that
restoring the deleted edge raises its degree by at most one, and applies the
paper's low-degree labelling axiom. -/
theorem edgeSide_nonempty_of_adj
    (T : XTree X V) {u v : V} (_huv : T.graph.Adj u v) :
    (T.edgeSide u v).Nonempty := by
  classical
  let H : SimpleGraph V := T.graph.deleteEdges {s(u, v)}
  let C : H.ConnectedComponent := H.connectedComponentMk v
  have hacycH : H.IsAcyclic :=
    T.isTree.isAcyclic.anti (by exact SimpleGraph.deleteEdges_le _)
  have htreeC : C.toSimpleGraph.IsTree := by
    constructor
    · exact SimpleGraph.ConnectedComponent.connected_toSimpleGraph C
    · exact SimpleGraph.IsAcyclic.comap
        (SimpleGraph.ConnectedComponent.toSimpleGraph_hom C)
        Subtype.val_injective hacycH
  have hsmall : ∃ y : C, (C.toSimpleGraph.neighborSet y).ncard ≤ 1 := by
    by_cases hnontrivial : Nontrivial C
    · letI : Nontrivial C := hnontrivial
      obtain ⟨y, hy⟩ := htreeC.exists_vert_degree_one_of_nontrivial
      refine ⟨y, ?_⟩
      rw [← Nat.card_coe_set_eq, Nat.card_eq_fintype_card,
        C.toSimpleGraph.card_neighborSet_eq_degree, hy]
    · letI : Subsingleton C := not_nontrivial_iff_subsingleton.mp hnontrivial
      let y : C := ⟨v, rfl⟩
      refine ⟨y, ?_⟩
      have hempty : C.toSimpleGraph.neighborSet y = ∅ := by
        ext z
        simp only [Set.mem_empty_iff_false, iff_false]
        intro hz
        change C.toSimpleGraph.Adj y z at hz
        exact (SimpleGraph.Adj.ne hz) (Subsingleton.elim y z)
      rw [hempty]
      simp
  obtain ⟨y, hy⟩ := hsmall
  let e : C.toSimpleGraph.neighborSet y ≃ H.neighborSet y.1 :=
    { toFun := fun z => ⟨z.1.1, z.2⟩
      invFun := fun z =>
        ⟨⟨z.1, (C.mem_supp_congr_adj z.2).mp y.2⟩, z.2⟩
      left_inv := by
        intro z
        apply Subtype.ext
        apply Subtype.ext
        rfl
      right_inv := by
        intro z
        apply Subtype.ext
        rfl }
  have hncardEq :
      (C.toSimpleGraph.neighborSet y).ncard = (H.neighborSet y.1).ncard := by
    rw [← Nat.card_coe_set_eq, ← Nat.card_coe_set_eq]
    exact Nat.card_congr e
  have hHsmall : (H.neighborSet y.1).ncard ≤ 1 := by
    rwa [← hncardEq]
  have hGsmall : (T.graph.neighborSet y.1).ncard ≤ 2 := by
    calc
      (T.graph.neighborSet y.1).ncard ≤ (H.neighborSet y.1).ncard + 1 :=
        neighbor_ncard_le_deleteEdges_neighbor_ncard_add_one T.graph u v y.1
      _ ≤ 1 + 1 := Nat.add_le_add_right hHsmall 1
      _ = 2 := rfl
  have hlow : Nat.card (T.graph.neighborSet y.1) ≤ 2 := by
    rw [Nat.card_coe_set_eq]
    exact hGsmall
  obtain ⟨x, hx⟩ := T.lowDegree_labelled y.1 hlow
  refine ⟨x, (T.mem_edgeSide u v x).mpr ?_⟩
  change H.Reachable v (T.label x)
  rw [hx]
  exact SimpleGraph.ConnectedComponent.exact y.2.symm

end XTree

/-! ## Unordered partial splits -/

/-- The carrier of an unordered pair of taxon subsets. -/
abbrev PartialSplit (X : Type uX) := Sym2 (Finset X)

/-- The two represented sides are nonempty and disjoint. -/
def IsPartialSplit {X : Type uX} (P : PartialSplit X) : Prop :=
  ∃ A B : Finset X,
    P = s(A, B) ∧ A.Nonempty ∧ B.Nonempty ∧ Disjoint A B

/-- A partial split whose two sides exhaust `X`. -/
def IsFullSplit {X : Type uX} (P : PartialSplit X) : Prop :=
  IsPartialSplit P ∧
    ∃ A B : Finset X,
      P = s(A, B) ∧ (A : Set X) ∪ (B : Set X) = Set.univ

/-- A partial quartet has at most two taxa on each represented side. -/
def IsPartialQuartet {X : Type uX} (P : PartialSplit X) : Prop :=
  IsPartialSplit P ∧
    ∃ A B : Finset X, P = s(A, B) ∧ A.card ≤ 2 ∧ B.card ≤ 2

/-- A full quartet has exactly two taxa on each side. -/
def IsQuartet {X : Type uX} (P : PartialSplit X) : Prop :=
  IsPartialSplit P ∧
    ∃ A B : Finset X, P = s(A, B) ∧ A.card = 2 ∧ B.card = 2

/-- `P` displays `Q`: after choosing representatives for the two unordered
pairs, the sides of `Q` are contained in opposite sides of `P`. -/
def Displays {X : Type uX} (P Q : PartialSplit X) : Prop :=
  ∃ A B C D : Finset X,
    P = s(A, B) ∧ Q = s(C, D) ∧
      ((C ⊆ A ∧ D ⊆ B) ∨ (C ⊆ B ∧ D ⊆ A))

theorem displays_comm_representative {X : Type uX}
    (A B C D : Finset X) :
    Displays s(A, B) s(C, D) ↔
      ((C ⊆ A ∧ D ⊆ B) ∨ (C ⊆ B ∧ D ⊆ A)) := by
  constructor
  · rintro ⟨A', B', C', D', hAB, hCD, h⟩
    rw [Sym2.eq_iff] at hAB hCD
    rcases hAB with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ <;>
      rcases hCD with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ <;> aesop
  · intro h
    exact ⟨A, B, C, D, rfl, rfl, h⟩

/-- The taxa occurring on either represented side of a partial split. -/
noncomputable def partialSplitSupport {X : Type uX}
    (P : PartialSplit X) : Finset X := by
  classical
  exact Sym2.lift ⟨fun A B => A ∪ B, Finset.union_comm⟩ P

@[simp] theorem partialSplitSupport_mk {X : Type uX} [DecidableEq X]
    (A B : Finset X) :
    partialSplitSupport s(A, B) = A ∪ B := by
  classical
  ext x
  simp [partialSplitSupport]

/-- A four-draw ordered sample induces `P` if some permutation puts its first
two draws on one side and its last two draws on the other.  Repeated draws are
automatically collapsed by the finite-set notation, matching the paper's
`x x | y z` convention for partial quartets. -/
noncomputable def Induces {X : Type uX}
    (draw : Fin 4 → X) (P : PartialSplit X) : Prop := by
  classical
  exact IsPartialSplit P ∧
    ∃ π : Equiv.Perm (Fin 4),
      P = s({draw (π 0), draw (π 1)}, {draw (π 2), draw (π 3)})

namespace XTree

variable {X : Type uX} {V : Type uV} [Fintype X] [Fintype V]

/-- The unordered split corresponding to the oriented edge `u -> v`. -/
noncomputable def edgeSplit (T : XTree X V) (u v : V) : PartialSplit X :=
  s(T.edgeSide u v, T.edgeSide v u)

/-- The partial split corresponding to the length-two path `u-v-w`. -/
noncomputable def sidePairSplit (T : XTree X V) (u v w : V) : PartialSplit X :=
  s(T.edgeSide v u, T.edgeSide v w)

@[simp] theorem edgeSplit_comm (T : XTree X V) (u v : V) :
    T.edgeSplit u v = T.edgeSplit v u := by
  simp [edgeSplit]

@[simp] theorem sidePairSplit_reverse (T : XTree X V) (u v w : V) :
    T.sidePairSplit u v w = T.sidePairSplit w v u := by
    simp [sidePairSplit]

/-- For a length-two path `u-v-w`, the two outward components at `v` are
disjoint.  The proof constructs two paths from a hypothetical common vertex
to `v`; their penultimate vertices would be `u` and `w`, contradicting path
uniqueness in a tree. -/
theorem vertexSide_disjoint_sidePair
    (T : XTree X V) {u v w : V}
    (huv : T.graph.Adj u v) (hvw : T.graph.Adj v w) (huw : u ≠ w) :
    Disjoint (T.vertexSide v u) (T.vertexSide v w) := by
  classical
  rw [Set.disjoint_left]
  intro x hxu hxw
  let Huv : SimpleGraph V := T.graph.deleteEdges {s(u, v)}
  let Hvw : SimpleGraph V := T.graph.deleteEdges {s(v, w)}
  have hux : Huv.Reachable u x := by
    change (T.graph.deleteEdges {s(v, u)}).Reachable u x at hxu
    simpa only [Huv, Sym2.eq_swap] using hxu
  have hwx : Hvw.Reachable w x := hxw
  have hbridgeUV : ¬Huv.Reachable u v :=
    (SimpleGraph.isAcyclic_iff_forall_adj_isBridge.mp T.isTree.isAcyclic huv)
  have hbridgeVW : ¬Hvw.Reachable v w :=
    (SimpleGraph.isAcyclic_iff_forall_adj_isBridge.mp T.isTree.isAcyclic hvw)
  obtain ⟨pH, hpH⟩ := hux.symm.exists_isPath
  have hvnot : v ∉ pH.support := by
    intro hvp
    have hxv : Huv.Reachable x v := (pH.takeUntil v hvp).reachable
    exact hbridgeUV (hux.trans hxv)
  let p0 : T.graph.Walk x u := pH.mapLe (SimpleGraph.deleteEdges_le _)
  let p : T.graph.Walk x v := p0.concat huv
  have hp : p.IsPath := by
    apply (hpH.mapLe (SimpleGraph.deleteEdges_le _)).concat
    simpa [p0, SimpleGraph.Walk.support_mapLe_eq_support] using hvnot
  obtain ⟨qH, hqH⟩ := hwx.symm.exists_isPath
  have hvnot' : v ∉ qH.support := by
    intro hvp
    have hxv : Hvw.Reachable x v := (qH.takeUntil v hvp).reachable
    exact hbridgeVW (hxv.symm.trans hwx.symm)
  let q0 : T.graph.Walk x w := qH.mapLe (SimpleGraph.deleteEdges_le _)
  let q : T.graph.Walk x v := q0.concat hvw.symm
  have hq : q.IsPath := by
    apply (hqH.mapLe (SimpleGraph.deleteEdges_le _)).concat
    simpa [q0, SimpleGraph.Walk.support_mapLe_eq_support] using hvnot'
  have hpq : p = q := Subtype.mk.inj
    (T.isTree.isAcyclic.path_unique ⟨p, hp⟩ ⟨q, hq⟩)
  apply huw
  calc
    u = p.penultimate := by simp [p, p0]
    _ = q.penultimate := congrArg SimpleGraph.Walk.penultimate hpq
    _ = w := by simp [q, q0]

/-- The two taxon sides of a side-pair split are disjoint. -/
theorem edgeSide_disjoint_sidePair
    (T : XTree X V) {u v w : V}
    (huv : T.graph.Adj u v) (hvw : T.graph.Adj v w) (huw : u ≠ w) :
    Disjoint (T.edgeSide v u) (T.edgeSide v w) := by
  classical
  rw [Finset.disjoint_left]
  intro x hxu hxw
  exact (Set.disjoint_left.mp (T.vertexSide_disjoint_sidePair huv hvw huw)
    ((T.mem_edgeSide v u x).mp hxu)) ((T.mem_edgeSide v w x).mp hxw)

/-- Every ordered length-two path defines the paper's corresponding partial
split. -/
theorem sidePairSplit_isPartialSplit
    (T : XTree X V) {u v w : V}
    (huv : T.graph.Adj u v) (hvw : T.graph.Adj v w) (huw : u ≠ w) :
    IsPartialSplit (T.sidePairSplit u v w) := by
  refine ⟨T.edgeSide v u, T.edgeSide v w, rfl,
    T.edgeSide_nonempty_of_adj huv.symm,
    T.edgeSide_nonempty_of_adj hvw,
    T.edgeSide_disjoint_sidePair huv hvw huw⟩

/-- A partial split is displayed by a tree when it is displayed by one of the
tree's edge splits. -/
def DisplaysPartialSplit (T : XTree X V) (P : PartialSplit X) : Prop :=
  ∃ u v : V, T.graph.Adj u v ∧ Displays (T.edgeSplit u v) P

/-- `Q_i(T)`: displayed partial quartets involving precisely `i` taxa. -/
noncomputable def displayedPartialQuartets
    (T : XTree X V) (i : ℕ) : Set (PartialSplit X) :=
  {P | IsPartialQuartet P ∧ T.DisplaysPartialSplit P ∧
    (partialSplitSupport P).card = i}

/-- `D(T)`, the set of ordered adjacent vertex pairs. -/
def directedEdges (T : XTree X V) : Set (V × V) :=
  {e | T.graph.Adj e.1 e.2}

/-- An unordered pair is at distance two when it has a common adjacent middle
vertex and has distinct endpoints. -/
def IsDistanceTwoPair (T : XTree X V) (e : Sym2 V) : Prop :=
  Sym2.lift
    ⟨fun u v => ∃ w : V,
        T.graph.Adj u w ∧ T.graph.Adj w v ∧ u ≠ v,
      by
        intro u v
        apply propext
        constructor
        · rintro ⟨w, huw, hwv, huv⟩
          exact ⟨w, hwv.symm, huw.symm, huv.symm⟩
        · rintro ⟨w, hvw, hwu, hvu⟩
          exact ⟨w, hwu.symm, hvw.symm, hvu.symm⟩⟩ e

/-- `E^2(T)`, the set of unordered vertex pairs at distance two. -/
def distanceTwoPairs (T : XTree X V) : Set (Sym2 V) :=
  {e | T.IsDistanceTwoPair e}

/-- `D^2(T)=P(T)`, the set of ordered paths of length two.  A triple is
represented as `(start, middle, finish)`. -/
def orderedLengthTwoPaths (T : XTree X V) : Set (V × V × V) :=
  {p | T.graph.Adj p.1 p.2.1 ∧ T.graph.Adj p.2.1 p.2.2 ∧ p.1 ≠ p.2.2}

@[simp] theorem mem_directedEdges (T : XTree X V) (u v : V) :
    (u, v) ∈ T.directedEdges ↔ T.graph.Adj u v := Iff.rfl

@[simp] theorem mem_orderedLengthTwoPaths (T : XTree X V) (u v w : V) :
    (u, v, w) ∈ T.orderedLengthTwoPaths ↔
      T.graph.Adj u v ∧ T.graph.Adj v w ∧ u ≠ w := Iff.rfl

/-- Once nonemptiness of both endpoint components is supplied, the edge
partition is a full split.  A separate finite-tree lemma below will discharge
these nonemptiness hypotheses from the paper's low-degree labelling axiom. -/
theorem edgeSplit_isFullSplit_of_nonempty
    (T : XTree X V) {u v : V} (huv : T.graph.Adj u v)
    (hu : (T.edgeSide u v).Nonempty) (hv : (T.edgeSide v u).Nonempty) :
    IsFullSplit (T.edgeSplit u v) := by
  classical
  constructor
  · exact ⟨T.edgeSide u v, T.edgeSide v u, rfl, hu, hv,
      T.edgeSide_disjoint_reverse_of_adj huv⟩
  · refine ⟨T.edgeSide u v, T.edgeSide v u, rfl, ?_⟩
    exact T.edgeSide_set_union_reverse_of_adj huv

/-- Every actual tree edge defines a full split of the entire taxon set. -/
theorem edgeSplit_isFullSplit
    (T : XTree X V) {u v : V} (huv : T.graph.Adj u v) :
    IsFullSplit (T.edgeSplit u v) :=
  T.edgeSplit_isFullSplit_of_nonempty huv
    (T.edgeSide_nonempty_of_adj huv)
    (T.edgeSide_nonempty_of_adj huv.symm)

end XTree

end QDFull
