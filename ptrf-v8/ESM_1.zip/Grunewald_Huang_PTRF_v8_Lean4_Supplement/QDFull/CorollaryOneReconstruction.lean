import QDFull.RootedClusterReconstruction
import QDFull.UpperEqualityReconstruction

/-!
# The upper-equality characterization in Corollary 1

The numerical equality ledger was proved in `CorollaryOne`, and saturation
was converted into binary phylogenetic structure and equality of all full
quartets in `UpperEqualityReconstruction`.  This file closes the remaining
interfaces without appealing to an external reconstruction theorem:

* equality of edge-split systems transports every displayed partial split;
* equality of all displayed full quartets makes quartet distance zero;
* the rooted-cluster reconstruction yields a label-preserving graph
  isomorphism; and
* conversely, such an isomorphism gives all four saturated ledger entries.

The hypothesis `4 <= |X|` in the current locked manuscript is essential; the
one-taxon boundary regression is formalized in `CorollaryOneCounterexample`.
-/

namespace QDFull

universe uX uV₁ uV₂

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]

/-- Equality of the complete edge-split systems transports the display of
every partial split in both directions.  The witness edge itself need not be
the same: equality of the split systems supplies a corresponding edge in the
other tree with exactly the same full split. -/
theorem displaysPartialSplit_iff_of_edgeSplitSet_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hsplit : T₁.edgeSplitSet = T₂.edgeSplitSet)
    (P : PartialSplit X) :
    T₁.DisplaysPartialSplit P ↔ T₂.DisplaysPartialSplit P := by
  constructor
  · rintro ⟨u, v, huv, hdisplay⟩
    have hmem₁ : T₁.edgeSplit u v ∈ T₁.edgeSplitSet :=
      ⟨u, v, huv, rfl⟩
    have hmem₂ : T₁.edgeSplit u v ∈ T₂.edgeSplitSet := by
      rw [← hsplit]
      exact hmem₁
    obtain ⟨p, q, hpq, heq⟩ := hmem₂
    refine ⟨p, q, hpq, ?_⟩
    rw [← heq]
    exact hdisplay
  · rintro ⟨p, q, hpq, hdisplay⟩
    have hmem₂ : T₂.edgeSplit p q ∈ T₂.edgeSplitSet :=
      ⟨p, q, hpq, rfl⟩
    have hmem₁ : T₂.edgeSplit p q ∈ T₁.edgeSplitSet := by
      rw [hsplit]
      exact hmem₂
    obtain ⟨u, v, huv, heq⟩ := hmem₁
    refine ⟨u, v, huv, ?_⟩
    rw [← heq]
    exact hdisplay

/-- If the two trees display exactly the same full quartets, then there is no
four-taxon support on which their displayed resolutions disagree. -/
theorem quartetDistance_eq_zero_of_same_full_quartets
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hsame : ∀ P : PartialSplit X, IsQuartet P →
      (T₁.DisplaysPartialSplit P ↔ T₂.DisplaysPartialSplit P)) :
    quartetDistance T₁ T₂ = 0 := by
  classical
  unfold quartetDistance
  rw [Finset.card_eq_zero]
  apply Finset.eq_empty_iff_forall_notMem.mpr
  intro S hS
  obtain ⟨_hcard, P, Q, hP, hQ, hT₁P, hT₂Q,
      hPS, hQS, hPQ⟩ :=
    (mem_quartetDisagreementSupports T₁ T₂ S).1 hS
  have hT₂P : T₂.DisplaysPartialSplit P := (hsame P hP).1 hT₁P
  have hPeqQ : P = Q :=
    T₂.displayed_quartet_unique_on_support
      hP hQ hT₂P hT₂Q (hPS.trans hQS.symm)
  exact hPQ hPeqQ

/-- The paper's phrase “identical binary phylogenetic trees”, made explicit:
both source objects are binary phylogenetic and there exists a graph
isomorphism which fixes every named taxon. -/
def IdenticalBinaryPhylogeneticTrees
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : Prop :=
  T₁.IsBinaryPhylogenetic ∧ T₂.IsBinaryPhylogenetic ∧
    Nonempty (LabelPreservingXTreeIso T₁ T₂)

/-- Corrected upper-equality characterization in Corollary 1.  For at least
four taxa, the universal numerical upper bound is attained exactly by
identical binary phylogenetic trees in the explicit label-preserving sense
above. -/
theorem treeQuartetCovariance_eq_universal_bound_iff_identical
    [DecidableEq X] [DecidableEq V₁] [DecidableEq V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hX : 4 ≤ Fintype.card X) :
    treeQuartetCovariance T₁ T₂ =
        1 - (4 * (Fintype.card X : ℝ) - 3) /
          (Fintype.card X : ℝ) ^ 3 ↔
      IdenticalBinaryPhylogeneticTrees T₁ T₂ := by
  classical
  constructor
  · intro heq
    obtain ⟨hcard₂, hcard₃, hcard₄, _hdistance⟩ :=
      (treeQuartetCovariance_eq_universal_bound_iff_saturated_counts
        T₁ T₂).1 heq
    have hbin₁ : T₁.IsBinaryPhylogenetic :=
      first_isBinaryPhylogenetic_of_common_two_three_four_card_eq
        T₁ T₂ hX hcard₂ hcard₃ hcard₄
    have hbin₂ : T₂.IsBinaryPhylogenetic :=
      second_isBinaryPhylogenetic_of_common_two_three_four_card_eq
        T₁ T₂ hX hcard₂ hcard₃ hcard₄
    have hsame : ∀ P : PartialSplit X, IsQuartet P →
        (T₁.DisplaysPartialSplit P ↔ T₂.DisplaysPartialSplit P) := by
      intro P hP
      exact displaysFullQuartet_iff_of_common_four_card_eq
        T₁ T₂ hcard₄ hP
    have hnonempty : Nonempty X :=
      Fintype.card_pos_iff.mp (by omega)
    let r : X := Classical.choice hnonempty
    refine ⟨hbin₁, hbin₂, ?_⟩
    exact ⟨labelPreservingXTreeIsoOfSameFullQuartets
      T₁ T₂ hbin₁ hbin₂ hsame r⟩
  · rintro ⟨hbin₁, hbin₂, ⟨F⟩⟩
    have hsplit : T₁.edgeSplitSet = T₂.edgeSplitSet := F.edgeSplitSet_eq
    have hsame : ∀ P : PartialSplit X, IsQuartet P →
        (T₁.DisplaysPartialSplit P ↔ T₂.DisplaysPartialSplit P) := by
      intro P _hP
      exact displaysPartialSplit_iff_of_edgeSplitSet_eq T₁ T₂ hsplit P
    have hdistance : quartetDistance T₁ T₂ = 0 :=
      quartetDistance_eq_zero_of_same_full_quartets T₁ T₂ hsame
    have hcard₂ :
        (commonDisplayedPartialQuartets T₁ T₂ 2).card =
          Nat.choose (Fintype.card X) 2 :=
      card_commonDisplayedPartialQuartets_two T₁ T₂ hbin₁ hbin₂
    have hcard₃ :
        (commonDisplayedPartialQuartets T₁ T₂ 3).card =
          3 * Nat.choose (Fintype.card X) 3 :=
      card_commonDisplayedPartialQuartets_three T₁ T₂ hbin₁ hbin₂
    have hsettlement :=
      card_commonQuartets_add_quartetDistance T₁ T₂ hbin₁ hbin₂
    have hcard₄ :
        (commonDisplayedPartialQuartets T₁ T₂ 4).card =
          Nat.choose (Fintype.card X) 4 := by
      omega
    exact
      (treeQuartetCovariance_eq_universal_bound_iff_saturated_counts
        T₁ T₂).2 ⟨hcard₂, hcard₃, hcard₄, hdistance⟩

end QDFull
