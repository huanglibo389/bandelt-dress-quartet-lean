import QDFull.BinaryPhylogeneticQuartets
import QDFull.LemmaThree

/-!
# Exact partial-quartet counts for binary phylogenetic trees

This file supplies the finite bijections used in Corollary 2 of the paper.
No displayed-partial-quartet count is assumed: support-size two objects are
indexed by non-diagonal unordered taxon pairs; support-size three objects are
indexed by a three-taxon support together with its singleton-side taxon; and
support-size four objects are settled support by support using the existence
and uniqueness theorem in `BinaryPhylogeneticQuartets`.
-/

open scoped BigOperators

namespace QDFull

universe uX uV₁ uV₂

/-! ## The support-size two class -/

/-- Turn an unordered pair of taxa into the corresponding `1|1` partial
quartet by applying the singleton embedding to both entries. -/
noncomputable def pairPartialQuartet {X : Type uX} (p : Sym2 X) :
    PartialSplit X :=
  Sym2.map (fun x : X => ({x} : Finset X)) p

private theorem pairPartialQuartet_injective {X : Type uX} :
    Function.Injective (pairPartialQuartet : Sym2 X → PartialSplit X) := by
  intro p
  refine Sym2.inductionOn p ?_
  intro a b q
  refine Sym2.inductionOn q ?_
  intro c d h
  simp only [pairPartialQuartet, Sym2.map_pair_eq, Sym2.eq_iff] at h ⊢
  rcases h with h | h
  · exact Or.inl ⟨Finset.singleton_inj.mp h.1,
      Finset.singleton_inj.mp h.2⟩
  · exact Or.inr ⟨Finset.singleton_inj.mp h.1,
      Finset.singleton_inj.mp h.2⟩

/-- For two binary phylogenetic trees, their common support-size two partial
quartets are in bijection with the two-element subsets of the taxon set. -/
theorem card_commonDisplayedPartialQuartets_two
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hbin₁ : T₁.IsBinaryPhylogenetic)
    (hbin₂ : T₂.IsBinaryPhylogenetic) :
    (commonDisplayedPartialQuartets T₁ T₂ 2).card =
      Nat.choose (Fintype.card X) 2 := by
  classical
  let source : Finset {p : Sym2 X // ¬p.IsDiag} := Finset.univ
  have hbij : source.card =
      (commonDisplayedPartialQuartets T₁ T₂ 2).card := by
    apply Finset.card_bij
        (fun p (_hp : p ∈ source) => pairPartialQuartet p.1)
    · intro p hp
      rcases p with ⟨p, hpdiag⟩
      revert hpdiag
      refine Sym2.inductionOn p ?_
      intro a b hpdiag _hp
      have hab : a ≠ b := by
        simpa [Sym2.IsDiag] using hpdiag
      have hpartial :
          IsPartialSplit s(({a} : Finset X), ({b} : Finset X)) := by
        exact ⟨{a}, {b}, rfl, by simp, by simp,
          by simp [Finset.disjoint_left, hab]⟩
      have hquart :
          IsPartialQuartet s(({a} : Finset X), ({b} : Finset X)) :=
        ⟨hpartial, {a}, {b}, rfl, by simp, by simp⟩
      have hdisp₁ := hbin₁.1.displays_singleton_partialSplit
        T₁ a ({b} : Finset X) (by simp [hab])
      have hdisp₂ := hbin₂.1.displays_singleton_partialSplit
        T₂ a ({b} : Finset X) (by simp [hab])
      apply (mem_commonDisplayedPartialQuartets T₁ T₂ 2 _).2
      have htarget :
          IsPartialQuartet s(({a} : Finset X), ({b} : Finset X)) ∧
          T₁.DisplaysPartialSplit s(({a} : Finset X), ({b} : Finset X)) ∧
          T₂.DisplaysPartialSplit s(({a} : Finset X), ({b} : Finset X)) ∧
          (partialSplitSupport
            s(({a} : Finset X), ({b} : Finset X))).card = 2 :=
        ⟨hquart, hdisp₁, hdisp₂,
          show (partialSplitSupport
            s(({a} : Finset X), ({b} : Finset X))).card = 2 by
            simp [partialSplitSupport_mk, hab]⟩
      simpa [pairPartialQuartet] using htarget
    · intro p hp q hq hpq
      apply Subtype.ext
      exact pairPartialQuartet_injective hpq
    · intro P hP
      have hdata :=
        (mem_commonDisplayedPartialQuartets T₁ T₂ 2 P).1 hP
      rcases partialQuartet_representation_cases hdata.1 with
          ⟨a, b, hab, hrep⟩ |
          ⟨a, b, c, hab, hac, hbc, hrep⟩ |
          ⟨a, b, c, d, hab, hac, had, hbc, hbd, hcd, hrep⟩
      · let p : {q : Sym2 X // ¬q.IsDiag} :=
          ⟨s(a, b), by simpa [Sym2.IsDiag] using hab⟩
        refine ⟨p, Finset.mem_univ _, ?_⟩
        rw [hrep]
        simp [p, pairPartialQuartet]
      · have hthree :
            (partialSplitSupport
              s(({a} : Finset X), ({b, c} : Finset X))).card = 3 := by
          have hdisj : Disjoint ({a} : Finset X) {b, c} := by
            simp [Finset.disjoint_left, hab, hac]
          rw [partialSplitSupport_mk,
            Finset.card_union_of_disjoint hdisj]
          simp [Finset.card_pair hbc]
        rw [hrep] at hdata
        omega
      · have hfour :
            (partialSplitSupport
              s(({a, b} : Finset X), ({c, d} : Finset X))).card = 4 := by
          have hdisj : Disjoint ({a, b} : Finset X) {c, d} := by
            simp [Finset.disjoint_left, hac, had, hbc, hbd]
          rw [partialSplitSupport_mk,
            Finset.card_union_of_disjoint hdisj]
          simp [Finset.card_pair hab, Finset.card_pair hcd]
        rw [hrep] at hdata
        omega
  calc
    (commonDisplayedPartialQuartets T₁ T₂ 2).card = source.card :=
      hbij.symm
    _ = Fintype.card {p : Sym2 X // ¬p.IsDiag} := Finset.card_univ
    _ = Nat.choose (Fintype.card X) 2 := Sym2.card_subtype_not_diag

/-- For arbitrary `X`-trees, the common support-size two class is bounded by
the set of non-diagonal unordered taxon pairs.  No phylogenetic or binary
hypothesis is used. -/
theorem card_commonDisplayedPartialQuartets_two_le
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    (commonDisplayedPartialQuartets T₁ T₂ 2).card ≤
      Nat.choose (Fintype.card X) 2 := by
  classical
  let source : Finset {p : Sym2 X // ¬p.IsDiag} := Finset.univ
  let target : Finset (PartialSplit X) :=
    source.image (fun p => pairPartialQuartet p.1)
  have hsub : commonDisplayedPartialQuartets T₁ T₂ 2 ⊆ target := by
    intro P hP
    have hdata :=
      (mem_commonDisplayedPartialQuartets T₁ T₂ 2 P).1 hP
    rcases partialQuartet_representation_cases hdata.1 with
        ⟨a, b, hab, hrep⟩ |
        ⟨a, b, c, hab, hac, hbc, hrep⟩ |
        ⟨a, b, c, d, hab, hac, had, hbc, hbd, hcd, hrep⟩
    · let p : {q : Sym2 X // ¬q.IsDiag} :=
        ⟨s(a, b), by simpa [Sym2.IsDiag] using hab⟩
      change P ∈ source.image (fun p => pairPartialQuartet p.1)
      rw [Finset.mem_image]
      refine ⟨p, Finset.mem_univ _, ?_⟩
      rw [hrep]
      simp [p, pairPartialQuartet]
    · have hthree :
          (partialSplitSupport
            s(({a} : Finset X), ({b, c} : Finset X))).card = 3 := by
        have hdisj : Disjoint ({a} : Finset X) {b, c} := by
          simp [Finset.disjoint_left, hab, hac]
        rw [partialSplitSupport_mk,
          Finset.card_union_of_disjoint hdisj]
        simp [Finset.card_pair hbc]
      rw [hrep] at hdata
      omega
    · have hfour :
          (partialSplitSupport
            s(({a, b} : Finset X), ({c, d} : Finset X))).card = 4 := by
        have hdisj : Disjoint ({a, b} : Finset X) {c, d} := by
          simp [Finset.disjoint_left, hac, had, hbc, hbd]
        rw [partialSplitSupport_mk,
          Finset.card_union_of_disjoint hdisj]
        simp [Finset.card_pair hab, Finset.card_pair hcd]
      rw [hrep] at hdata
      omega
  calc
    (commonDisplayedPartialQuartets T₁ T₂ 2).card ≤ target.card :=
      Finset.card_le_card hsub
    _ = source.card := by
      change (source.image (fun p => pairPartialQuartet p.1)).card = source.card
      rw [Finset.card_image_iff.mpr]
      intro p _hp q _hq hpq
      apply Subtype.ext
      exact pairPartialQuartet_injective hpq
    _ = Fintype.card {p : Sym2 X // ¬p.IsDiag} := Finset.card_univ
    _ = Nat.choose (Fintype.card X) 2 := Sym2.card_subtype_not_diag

/-! ## The support-size three class -/

/-- A three-element support together with the taxon occupying the singleton
side of a `1|2` partial quartet. -/
abbrev MarkedThreeSupport (X : Type uX) :=
  Sigma (fun _S : Finset X => X)

/-- The finite set of all pairs `(S,a)` with `|S|=3` and `a∈S`. -/
noncomputable def markedThreeSupports {X : Type uX} [Fintype X] :
    Finset (MarkedThreeSupport X) := by
  classical
  exact (Finset.univ.powersetCard 3).sigma (fun S => S)

@[simp] theorem mem_markedThreeSupports
    {X : Type uX} [Fintype X] (z : MarkedThreeSupport X) :
    z ∈ markedThreeSupports ↔ z.1.card = 3 ∧ z.2 ∈ z.1 := by
  classical
  simp [markedThreeSupports, Finset.mem_powersetCard]

/-- The `1|2` partial quartet represented by a marked three-support. -/
noncomputable def markedThreePartialQuartet {X : Type uX}
    (z : MarkedThreeSupport X) : PartialSplit X := by
  classical
  exact s(({z.2} : Finset X), z.1.erase z.2)

private theorem markedThreePartialQuartet_support
    {X : Type uX} [Fintype X] {z : MarkedThreeSupport X}
    (hz : z ∈ markedThreeSupports) :
    partialSplitSupport (markedThreePartialQuartet z) = z.1 := by
  classical
  have hmem := (mem_markedThreeSupports z).1 hz
  rw [markedThreePartialQuartet, partialSplitSupport_mk,
    Finset.singleton_union, Finset.insert_erase hmem.2]

private theorem markedThreePartialQuartet_isPartialQuartet
    {X : Type uX} [Fintype X] {z : MarkedThreeSupport X}
    (hz : z ∈ markedThreeSupports) :
    IsPartialQuartet (markedThreePartialQuartet z) := by
  classical
  have hmem := (mem_markedThreeSupports z).1 hz
  have herase : (z.1.erase z.2).card = 2 := by
    rw [Finset.card_erase_of_mem hmem.2, hmem.1]
  have hpartial : IsPartialSplit
      s(({z.2} : Finset X), z.1.erase z.2) := by
    exact ⟨{z.2}, z.1.erase z.2, rfl, by simp,
      Finset.card_pos.mp (by omega), by simp⟩
  exact ⟨hpartial, {z.2}, z.1.erase z.2, rfl, by simp,
    by omega⟩

private theorem markedThreePartialQuartet_injOn
    {X : Type uX} [Fintype X] :
    Set.InjOn (markedThreePartialQuartet :
      MarkedThreeSupport X → PartialSplit X)
        ((markedThreeSupports : Finset (MarkedThreeSupport X)) :
          Set (MarkedThreeSupport X)) := by
  classical
  intro z hz w hw hzw
  rcases z with ⟨S, a⟩
  rcases w with ⟨T, b⟩
  have hzdata := (mem_markedThreeSupports ⟨S, a⟩).1 hz
  have hwdata := (mem_markedThreeSupports ⟨T, b⟩).1 hw
  have hsupport := congrArg partialSplitSupport hzw
  have hST : S = T := by
    simpa [markedThreePartialQuartet_support hz,
      markedThreePartialQuartet_support hw] using hsupport
  subst T
  change s(({a} : Finset X), S.erase a) =
    s(({b} : Finset X), S.erase b) at hzw
  rw [Sym2.eq_iff] at hzw
  have hab : a = b := by
    rcases hzw with hdirect | hswap
    · exact Finset.singleton_inj.mp hdirect.1
    · have hleft : ({a} : Finset X).card = 1 := by simp
      have hright : (S.erase b).card = 2 := by
        rw [Finset.card_erase_of_mem hwdata.2, hwdata.1]
      rw [hswap.1] at hleft
      omega
  subst b
  rfl

/-- The marked three-support index set has cardinality
`3 * choose |X| 3`. -/
theorem card_markedThreeSupports {X : Type uX} [Fintype X] :
    (markedThreeSupports (X := X)).card =
      3 * Nat.choose (Fintype.card X) 3 := by
  classical
  rw [markedThreeSupports, Finset.card_sigma]
  calc
    (∑ S ∈ Finset.univ.powersetCard 3, S.card) =
        ∑ _S ∈ Finset.univ.powersetCard 3, 3 := by
      apply Finset.sum_congr rfl
      intro S hS
      exact (Finset.mem_powersetCard.mp hS).2
    _ = (Finset.univ.powersetCard 3).card * 3 := by
      exact Finset.sum_const_nat (fun _S _hS => rfl)
    _ = 3 * Nat.choose (Fintype.card X) 3 := by
      rw [Finset.card_powersetCard, Finset.card_univ]
      omega

/-- For two binary phylogenetic trees, their common support-size three
partial quartets are counted by `3 * choose |X| 3`. -/
theorem card_commonDisplayedPartialQuartets_three
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hbin₁ : T₁.IsBinaryPhylogenetic)
    (hbin₂ : T₂.IsBinaryPhylogenetic) :
    (commonDisplayedPartialQuartets T₁ T₂ 3).card =
      3 * Nat.choose (Fintype.card X) 3 := by
  classical
  have hbij : (markedThreeSupports (X := X)).card =
      (commonDisplayedPartialQuartets T₁ T₂ 3).card := by
    apply Finset.card_bij
        (fun z (_hz : z ∈ markedThreeSupports) =>
          markedThreePartialQuartet z)
    · intro z hz
      have hquart := markedThreePartialQuartet_isPartialQuartet hz
      have hsupp := markedThreePartialQuartet_support hz
      have hzdata := (mem_markedThreeSupports z).1 hz
      have hdisp₁ := hbin₁.1.displays_singleton_partialSplit
        T₁ z.2 (z.1.erase z.2) (by simp)
      have hdisp₂ := hbin₂.1.displays_singleton_partialSplit
        T₂ z.2 (z.1.erase z.2) (by simp)
      exact (mem_commonDisplayedPartialQuartets T₁ T₂ 3 _).2
        ⟨hquart, hdisp₁, hdisp₂, by simpa [hsupp] using hzdata.1⟩
    · intro z hz w hw hzw
      exact markedThreePartialQuartet_injOn hz hw hzw
    · intro P hP
      have hdata :=
        (mem_commonDisplayedPartialQuartets T₁ T₂ 3 P).1 hP
      rcases partialQuartet_representation_cases hdata.1 with
          ⟨a, b, hab, hrep⟩ |
          ⟨a, b, c, hab, hac, hbc, hrep⟩ |
          ⟨a, b, c, d, hab, hac, had, hbc, hbd, hcd, hrep⟩
      · have htwo :
            (partialSplitSupport
              s(({a} : Finset X), ({b} : Finset X))).card = 2 := by
          simp [partialSplitSupport_mk, hab]
        rw [hrep] at hdata
        omega
      · let z : MarkedThreeSupport X := ⟨({a, b, c} : Finset X), a⟩
        have hz : z ∈ markedThreeSupports := by
          simp [z, hab, hac, hbc]
        refine ⟨z, hz, ?_⟩
        rw [hrep]
        simp [z, markedThreePartialQuartet, hab, hac]
      · have hfour :
            (partialSplitSupport
              s(({a, b} : Finset X), ({c, d} : Finset X))).card = 4 := by
          have hdisj : Disjoint ({a, b} : Finset X) {c, d} := by
            simp [Finset.disjoint_left, hac, had, hbc, hbd]
          rw [partialSplitSupport_mk,
            Finset.card_union_of_disjoint hdisj]
          simp [Finset.card_pair hab, Finset.card_pair hcd]
        rw [hrep] at hdata
        omega
  rw [← hbij, card_markedThreeSupports]

/-- For arbitrary `X`-trees, the common support-size three class is bounded
by the marked three-support index set.  Each partial quartet has one uniquely
determined singleton-side taxon. -/
theorem card_commonDisplayedPartialQuartets_three_le
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    (commonDisplayedPartialQuartets T₁ T₂ 3).card ≤
      3 * Nat.choose (Fintype.card X) 3 := by
  classical
  let target : Finset (PartialSplit X) :=
    markedThreeSupports.image markedThreePartialQuartet
  have hsub : commonDisplayedPartialQuartets T₁ T₂ 3 ⊆ target := by
    intro P hP
    have hdata :=
      (mem_commonDisplayedPartialQuartets T₁ T₂ 3 P).1 hP
    rcases partialQuartet_representation_cases hdata.1 with
        ⟨a, b, hab, hrep⟩ |
        ⟨a, b, c, hab, hac, hbc, hrep⟩ |
        ⟨a, b, c, d, hab, hac, had, hbc, hbd, hcd, hrep⟩
    · have htwo :
          (partialSplitSupport
            s(({a} : Finset X), ({b} : Finset X))).card = 2 := by
        simp [partialSplitSupport_mk, hab]
      rw [hrep] at hdata
      omega
    · let z : MarkedThreeSupport X := ⟨({a, b, c} : Finset X), a⟩
      have hz : z ∈ markedThreeSupports := by
        simp [z, hab, hac, hbc]
      change P ∈ markedThreeSupports.image markedThreePartialQuartet
      rw [Finset.mem_image]
      refine ⟨z, hz, ?_⟩
      rw [hrep]
      simp [z, markedThreePartialQuartet, hab, hac]
    · have hfour :
          (partialSplitSupport
            s(({a, b} : Finset X), ({c, d} : Finset X))).card = 4 := by
        have hdisj : Disjoint ({a, b} : Finset X) {c, d} := by
          simp [Finset.disjoint_left, hac, had, hbc, hbd]
        rw [partialSplitSupport_mk,
          Finset.card_union_of_disjoint hdisj]
        simp [Finset.card_pair hab, Finset.card_pair hcd]
      rw [hrep] at hdata
      omega
  calc
    (commonDisplayedPartialQuartets T₁ T₂ 3).card ≤ target.card :=
      Finset.card_le_card hsub
    _ = (markedThreeSupports (X := X)).card := by
      change (markedThreeSupports.image markedThreePartialQuartet).card =
        (markedThreeSupports (X := X)).card
      rw [Finset.card_image_iff.mpr]
      intro z hz w hw hzw
      exact markedThreePartialQuartet_injOn hz hw hzw
    _ = 3 * Nat.choose (Fintype.card X) 3 := card_markedThreeSupports

/-! ## The support-size four partition -/

/-- A full quartet is, in particular, a partial quartet. -/
theorem IsQuartet.isPartialQuartet
    {X : Type uX} [Fintype X] {P : PartialSplit X}
    (hP : IsQuartet P) : IsPartialQuartet P := by
  rcases hP with ⟨hpartial, A, B, hrep, hA, hB⟩
  exact ⟨hpartial, A, B, hrep, by omega, by omega⟩

/-- Four-taxon supports on which the two trees display a common full
quartet. -/
noncomputable def commonQuartetSupports
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : Finset (Finset X) := by
  classical
  exact (commonDisplayedPartialQuartets T₁ T₂ 4).image
    partialSplitSupport

@[simp] theorem mem_commonQuartetSupports
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (S : Finset X) :
    S ∈ commonQuartetSupports T₁ T₂ ↔
      ∃ P : PartialSplit X,
        IsQuartet P ∧ T₁.DisplaysPartialSplit P ∧
          T₂.DisplaysPartialSplit P ∧ partialSplitSupport P = S := by
  classical
  rw [commonQuartetSupports, Finset.mem_image]
  constructor
  · rintro ⟨P, hP, hPS⟩
    have hdata :=
      (mem_commonDisplayedPartialQuartets T₁ T₂ 4 P).1 hP
    exact ⟨P, hdata.1.isQuartet_of_support_card_four hdata.2.2.2,
      hdata.2.1, hdata.2.2.1, hPS⟩
  · rintro ⟨P, hquart, hT₁, hT₂, hPS⟩
    refine ⟨P, ?_, hPS⟩
    exact (mem_commonDisplayedPartialQuartets T₁ T₂ 4 P).2
      ⟨hquart.isPartialQuartet, hT₁, hT₂,
        hquart.support_card_four⟩

/-- The support map is injective on the common full quartets, because a
single tree cannot display two different quartets on one support. -/
theorem card_commonQuartetSupports
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    (commonQuartetSupports T₁ T₂).card =
      (commonDisplayedPartialQuartets T₁ T₂ 4).card := by
  classical
  rw [commonQuartetSupports, Finset.card_image_iff]
  intro P hP Q hQ hsupp
  have hPdata :=
    (mem_commonDisplayedPartialQuartets T₁ T₂ 4 P).1 hP
  have hQdata :=
    (mem_commonDisplayedPartialQuartets T₁ T₂ 4 Q).1 hQ
  exact T₁.displayed_quartet_unique_on_support
    (hPdata.1.isQuartet_of_support_card_four hPdata.2.2.2)
    (hQdata.1.isQuartet_of_support_card_four hQdata.2.2.2)
    hPdata.2.1 hQdata.2.1 hsupp

/-- For arbitrary `X`-trees, at most one common full quartet can occur on
each four-taxon support. -/
theorem card_commonDisplayedPartialQuartets_four_le
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    (commonDisplayedPartialQuartets T₁ T₂ 4).card ≤
      Nat.choose (Fintype.card X) 4 := by
  classical
  have hsub : commonQuartetSupports T₁ T₂ ⊆
      Finset.univ.powersetCard 4 := by
    intro S hS
    obtain ⟨P, hP, _hT₁, _hT₂, hPS⟩ :=
      (mem_commonQuartetSupports T₁ T₂ S).1 hS
    exact Finset.mem_powersetCard.mpr ⟨Finset.subset_univ S, by
      simpa [← hPS] using hP.support_card_four⟩
  calc
    (commonDisplayedPartialQuartets T₁ T₂ 4).card =
        (commonQuartetSupports T₁ T₂).card :=
      (card_commonQuartetSupports T₁ T₂).symm
    _ ≤ (Finset.univ.powersetCard 4).card := Finset.card_le_card hsub
    _ = Nat.choose (Fintype.card X) 4 := by
      rw [Finset.card_powersetCard, Finset.card_univ]

/-- On binary phylogenetic trees, every four-taxon support belongs either to
the common-quartet class or to the disagreement class. -/
theorem commonQuartetSupports_union_disagreement
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂] [DecidableEq X]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hbin₁ : T₁.IsBinaryPhylogenetic)
    (hbin₂ : T₂.IsBinaryPhylogenetic) :
    commonQuartetSupports T₁ T₂ ∪
        quartetDisagreementSupports T₁ T₂ =
      Finset.univ.powersetCard 4 := by
  classical
  ext S
  simp only [Finset.mem_union, mem_commonQuartetSupports,
    mem_quartetDisagreementSupports, Finset.mem_powersetCard,
    Finset.subset_univ, true_and]
  constructor
  · rintro (⟨P, hP, _hT₁, _hT₂, hPS⟩ | hdis)
    · simpa [← hPS] using hP.support_card_four
    · exact hdis.1
  · intro hS
    obtain ⟨P, hP, hT₁, hPS⟩ :=
      T₁.exists_displayed_quartet_on_support hbin₁ S hS
    obtain ⟨Q, hQ, hT₂, hQS⟩ :=
      T₂.exists_displayed_quartet_on_support hbin₂ S hS
    by_cases hPQ : P = Q
    · left
      subst Q
      exact ⟨P, hP, hT₁, hT₂, hPS⟩
    · right
      exact ⟨hS, P, Q, hP, hQ, hT₁, hT₂,
        hPS, hQS, hPQ⟩

/-- The common-support and disagreement-support classes are disjoint. -/
theorem commonQuartetSupports_disjoint_disagreement
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    Disjoint (commonQuartetSupports T₁ T₂)
      (quartetDisagreementSupports T₁ T₂) := by
  classical
  rw [Finset.disjoint_left]
  intro S hcommon hdisagree
  obtain ⟨P, hP, hT₁P, hT₂P, hPS⟩ :=
    (mem_commonQuartetSupports T₁ T₂ S).1 hcommon
  obtain ⟨_hS, Q, R, hQ, hR, hT₁Q, hT₂R,
      hQS, hRS, hQR⟩ :=
    (mem_quartetDisagreementSupports T₁ T₂ S).1 hdisagree
  have hPQ : P = Q := T₁.displayed_quartet_unique_on_support
    hP hQ hT₁P hT₁Q (hPS.trans hQS.symm)
  have hPR : P = R := T₂.displayed_quartet_unique_on_support
    hP hR hT₂P hT₂R (hPS.trans hRS.symm)
  exact hQR (hPQ.symm.trans hPR)

/-- Exact four-support settlement:
`common full quartets + disagreements = choose |X| 4`. -/
theorem card_commonQuartets_add_quartetDistance
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hbin₁ : T₁.IsBinaryPhylogenetic)
    (hbin₂ : T₂.IsBinaryPhylogenetic) :
    (commonDisplayedPartialQuartets T₁ T₂ 4).card +
        quartetDistance T₁ T₂ =
      Nat.choose (Fintype.card X) 4 := by
  classical
  have hunion := commonQuartetSupports_union_disagreement
    T₁ T₂ hbin₁ hbin₂
  have hcard := congrArg Finset.card hunion
  rw [Finset.card_union_of_disjoint
      (commonQuartetSupports_disjoint_disagreement T₁ T₂),
    Finset.card_powersetCard, Finset.card_univ] at hcard
  rw [← card_commonQuartetSupports T₁ T₂]
  exact hcard

/-! ## Corollary 2 -/

/-- The sum-of-squares theorem implies nonnegativity of the original
four-draw quartet covariance. -/
theorem treeQuartetCovariance_nonneg
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    [DecidableEq X] [DecidableEq V₁] [DecidableEq V₂]
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    0 ≤ treeQuartetCovariance T₁ T₂ := by
  have hq := qSquareFamily_nonneg T₁ T₂
  have hs := sSquareFamily_nonneg T₁ T₂
  have hb := bSquareFamily_nonneg T₁ T₂
  have hp := pSquareFamily_nonneg T₁ T₂
  have heq := sumOfSquaresRhs_eq_treeQuartetCovariance_div_six T₁ T₂
  unfold sumOfSquaresRhs at heq
  nlinarith

/-- Corollary 2 of the paper, with the rational right-hand side interpreted
in `ℝ`. -/
theorem quartetDistance_le_twoThirds_bound
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hbin₁ : T₁.IsBinaryPhylogenetic)
    (hbin₂ : T₂.IsBinaryPhylogenetic) :
    (quartetDistance T₁ T₂ : ℝ) ≤
      (2 / 3 : ℝ) * Nat.choose (Fintype.card X) 4 +
        Nat.choose (Fintype.card X) 3 +
        (1 / 6 : ℝ) * Nat.choose (Fintype.card X) 2 := by
  classical
  letI : LinearOrder V₁ :=
    LinearOrder.lift' (Fintype.equivFin V₁)
      (Fintype.equivFin V₁).injective
  letI : LinearOrder V₂ :=
    LinearOrder.lift' (Fintype.equivFin V₂)
      (Fintype.equivFin V₂).injective
  have hnonneg : 0 ≤ treeQuartetCovariance T₁ T₂ :=
    treeQuartetCovariance_nonneg T₁ T₂
  have hformula := treeQuartetCovariance_eq_quartetCounts T₁ T₂
  have hq₂ := card_commonDisplayedPartialQuartets_two
    T₁ T₂ hbin₁ hbin₂
  have hq₃ := card_commonDisplayedPartialQuartets_three
    T₁ T₂ hbin₁ hbin₂
  have hq₄ := card_commonQuartets_add_quartetDistance
    T₁ T₂ hbin₁ hbin₂
  rw [hq₂, hq₃] at hformula
  push_cast at hformula
  have hq₄real :
      ((commonDisplayedPartialQuartets T₁ T₂ 4).card : ℝ) +
          (quartetDistance T₁ T₂ : ℝ) =
        (Nat.choose (Fintype.card X) 4 : ℝ) := by
    exact_mod_cast hq₄
  have hn : 0 < (Fintype.card X : ℝ) := by
    exact_mod_cast (Fintype.card_pos_iff.mpr T₁.taxon_nonempty)
  have hfactor : 0 < (1 / (Fintype.card X : ℝ) ^ 4) :=
    one_div_pos.mpr (pow_pos hn 4)
  have hbracket :
      0 ≤
        24 * ((commonDisplayedPartialQuartets T₁ T₂ 4).card : ℝ) +
          12 * (3 * Nat.choose (Fintype.card X) 3 : ℝ) +
          6 * (Nat.choose (Fintype.card X) 2 : ℝ) -
          12 * (quartetDistance T₁ T₂ : ℝ) := by
    have hmul :
        0 ≤ (1 / (Fintype.card X : ℝ) ^ 4) *
          (24 * ((commonDisplayedPartialQuartets T₁ T₂ 4).card : ℝ) +
            12 * (3 * Nat.choose (Fintype.card X) 3 : ℝ) +
            6 * (Nat.choose (Fintype.card X) 2 : ℝ) -
            12 * (quartetDistance T₁ T₂ : ℝ)) := by
      rw [← hformula]
      exact hnonneg
    exact nonneg_of_mul_nonneg_right hmul hfactor
  nlinarith

end QDFull
