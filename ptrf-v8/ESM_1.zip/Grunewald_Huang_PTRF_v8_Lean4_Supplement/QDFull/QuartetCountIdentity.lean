import QDFull.PhylogeneticNonindependence

/-!
# Exact `6/12/24` counting identity

This file formalizes Lemma 5 of the manuscript.  The proof first counts the
ordered four-draw fibre of one fixed displayed partial quartet.  It then
partitions the positive and negative tree events by their unique induced
displayed quartet(s), so no multiplicity is hidden in the final sum.
-/

open scoped BigOperators

namespace QDFull

universe uX uV₁ uV₂

/-- The finite set of ordered draws inducing one fixed partial split. -/
noncomputable def inducingDrawFinset {X : Type uX} [Fintype X]
    (P : PartialSplit X) : Finset (Fin 4 → X) := by
  classical
  exact Finset.univ.filter fun draw => Induces draw P

@[simp] theorem mem_inducingDrawFinset {X : Type uX} [Fintype X]
    (P : PartialSplit X) (draw : Fin 4 → X) :
    draw ∈ inducingDrawFinset P ↔ Induces draw P := by
  classical
  simp [inducingDrawFinset]

/-- A `2+1+1` position pattern: two positions carry the repeated value and
one of the two remaining positions is distinguished for the second value. -/
abbrev TwoOneOneIndex :=
  {p : Finset (Fin 4) × Fin 4 // p.1.card = 2 ∧ p.2 ∉ p.1}

/-- There are exactly `choose(4,2) * 2 = 12` `2+1+1` position patterns. -/
theorem card_twoOneOneIndex : Fintype.card TwoOneOneIndex = 12 := by
  decide

/-- The draw encoded by a `2+1+1` position pattern. -/
def twoOneOnePatternDraw {X : Type uX}
    (a b c : X) (p : TwoOneOneIndex) (i : Fin 4) : X :=
  if i ∈ p.1.1 then a else if i = p.1.2 then b else c

theorem twoOneOnePatternDraw_eq_a_iff
    {X : Type uX} {a b c : X}
    (hab : a ≠ b) (hac : a ≠ c) (p : TwoOneOneIndex) (i : Fin 4) :
    twoOneOnePatternDraw a b c p i = a ↔ i ∈ p.1.1 := by
  by_cases hi : i ∈ p.1.1
  · simp [twoOneOnePatternDraw, hi]
  · by_cases hij : i = p.1.2
    · simp [twoOneOnePatternDraw, hi, hij, hab.symm]
    · simp [twoOneOnePatternDraw, hi, hij, hac.symm]

theorem twoOneOnePatternDraw_eq_b_iff
    {X : Type uX} {a b c : X}
    (hab : a ≠ b) (hbc : b ≠ c) (p : TwoOneOneIndex) (i : Fin 4) :
    twoOneOnePatternDraw a b c p i = b ↔ i = p.1.2 := by
  by_cases hi : i ∈ p.1.1
  · have hij : i ≠ p.1.2 := by
      intro h
      exact p.2.2 (h ▸ hi)
    simp [twoOneOnePatternDraw, hi, hab, hij]
  · simp [twoOneOnePatternDraw, hi, hbc.symm]

/-- Distinct labels make the `2+1+1` position encoding injective. -/
theorem twoOneOnePatternDraw_injective
    {X : Type uX} {a b c : X}
    (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) :
    Function.Injective (twoOneOnePatternDraw a b c) := by
  intro p q hpq
  apply Subtype.ext
  apply Prod.ext
  · ext i
    rw [← twoOneOnePatternDraw_eq_a_iff hab hac p,
      ← twoOneOnePatternDraw_eq_a_iff hab hac q]
    exact Iff.of_eq (congrArg (fun f => f i = a) hpq)
  · have hb : twoOneOnePatternDraw a b c q p.1.2 = b := by
      rw [← hpq]
      exact (twoOneOnePatternDraw_eq_b_iff hab hbc p p.1.2).2 rfl
    exact (twoOneOnePatternDraw_eq_b_iff hab hbc q p.1.2).1 hb

/-- All ordered draws with multiplicities `2,1,1` for the three displayed
values `a,b,c`, with `a` the repeated value. -/
noncomputable def twoOneOneDraws {X : Type uX} [Fintype X]
    (a b c : X) : Finset (Fin 4 → X) := by
  classical
  exact Finset.univ.image (twoOneOnePatternDraw a b c)

@[simp] theorem mem_twoOneOneDraws {X : Type uX} [Fintype X]
    (a b c : X) (draw : Fin 4 → X) :
    draw ∈ twoOneOneDraws a b c ↔
      ∃ p : TwoOneOneIndex, twoOneOnePatternDraw a b c p = draw := by
  classical
  simp [twoOneOneDraws]

theorem card_twoOneOneDraws {X : Type uX} [Fintype X]
    {a b c : X} (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) :
    (twoOneOneDraws a b c).card = 12 := by
  classical
  rw [twoOneOneDraws,
    Finset.card_image_of_injective Finset.univ
      (twoOneOnePatternDraw_injective hab hac hbc),
    Finset.card_univ, card_twoOneOneIndex]

private theorem fin4_eq_perm_cases (i : Fin 4) (pi : Equiv.Perm (Fin 4)) :
    i = pi 0 ∨ i = pi 1 ∨ i = pi 2 ∨ i = pi 3 := by
  have h := pi.surjective i
  obtain ⟨j, rfl⟩ := h
  fin_cases j <;> simp

private noncomputable def twoOneOneIndex_of_perm
    (pi : Equiv.Perm (Fin 4)) : TwoOneOneIndex := by
  classical
  exact ⟨({pi 0, pi 1}, pi 2), by
    constructor
    · simp [pi.injective.eq_iff]
    · simp [pi.injective.eq_iff]⟩

private theorem twoOneOnePatternDraw_of_perm
    {X : Type uX} (a b c : X) (pi : Equiv.Perm (Fin 4)) :
    twoOneOnePatternDraw a b c (twoOneOneIndex_of_perm pi) =
      fun i => if i = pi 0 ∨ i = pi 1 then a else if i = pi 2 then b else c := by
  funext i
  change (if i ∈ ({pi 0, pi 1} : Finset (Fin 4)) then a
    else if i = pi 2 then b else c) = _
  simp only [Finset.mem_insert, Finset.mem_singleton]

private theorem exists_twoOneOnePattern_of_perm_values
    {X : Type uX} {a b c : X} (draw : Fin 4 → X)
    (pi : Equiv.Perm (Fin 4))
    (h₀ : draw (pi 0) = a) (h₁ : draw (pi 1) = a)
    (h₂ : draw (pi 2) = b) (h₃ : draw (pi 3) = c) :
    ∃ p : TwoOneOneIndex, twoOneOnePatternDraw a b c p = draw := by
  refine ⟨twoOneOneIndex_of_perm pi, ?_⟩
  funext i
  rw [twoOneOnePatternDraw_of_perm]
  rcases fin4_eq_perm_cases i pi with rfl | rfl | rfl | rfl <;>
    simp [pi.injective.eq_iff, h₀, h₁, h₂, h₃]

private theorem singleton_eq_pair_iff
    {X : Type uX} [DecidableEq X] (a x y : X) :
    ({a} : Finset X) = {x, y} ↔ x = a ∧ y = a := by
  constructor
  · intro h
    constructor
    · have hx : x ∈ ({a} : Finset X) := by rw [h]; simp
      simpa using hx
    · have hy : y ∈ ({a} : Finset X) := by rw [h]; simp
      simpa using hy
  · rintro ⟨rfl, rfl⟩
    simp

private theorem pair_eq_pair_iff_of_ne
    {X : Type uX} [DecidableEq X] {b c x y : X} (hbc : b ≠ c) :
    ({b, c} : Finset X) = {x, y} ↔
      (x = b ∧ y = c) ∨ (x = c ∧ y = b) := by
  constructor
  · intro h
    have hx : x = b ∨ x = c := by
      have : x ∈ ({b, c} : Finset X) := by rw [h]; simp
      simpa [eq_comm] using this
    have hy : y = b ∨ y = c := by
      have : y ∈ ({b, c} : Finset X) := by rw [h]; simp
      simpa [eq_comm] using this
    have hb : b = x ∨ b = y := by
      have : b ∈ ({x, y} : Finset X) := by rw [← h]; simp
      simpa using this
    have hc : c = x ∨ c = y := by
      have : c ∈ ({x, y} : Finset X) := by rw [← h]; simp
      simpa using this
    aesop
  · rintro (⟨rfl, rfl⟩ | ⟨rfl, rfl⟩)
    · rfl
    · exact Finset.pair_comm _ _

/-- Extract the two values from an equality between an abstract singleton-like
finite set and an abstract pair-like finite set.  This formulation is
independent of the `DecidableEq` instances used to construct the two sets. -/
private theorem singletonLike_eq_pairLike_values
    {X : Type uX} {S T : Finset X} {a x y : X}
    (hST : S = T)
    (hS : ∀ z, z ∈ S ↔ z = a)
    (hT : ∀ z, z ∈ T ↔ z = x ∨ z = y) :
    x = a ∧ y = a := by
  have hxT : x ∈ T := (hT x).2 (Or.inl rfl)
  have hyT : y ∈ T := (hT y).2 (Or.inr rfl)
  constructor
  · exact (hS x).1 (by simpa [hST] using hxT)
  · exact (hS y).1 (by simpa [hST] using hyT)

/-- Extract the orientation of an equality between two abstract pair-like
finite sets.  Distinctness of the first pair excludes the collapsed cases. -/
private theorem distinctPairLike_eq_pairLike_values
    {X : Type uX} {S T : Finset X} {b c x y : X}
    (hbc : b ≠ c) (hST : S = T)
    (hS : ∀ z, z ∈ S ↔ z = b ∨ z = c)
    (hT : ∀ z, z ∈ T ↔ z = x ∨ z = y) :
    (x = b ∧ y = c) ∨ (x = c ∧ y = b) := by
  have hxS : x ∈ S := by
    rw [hST]
    exact (hT x).2 (Or.inl rfl)
  have hyS : y ∈ S := by
    rw [hST]
    exact (hT y).2 (Or.inr rfl)
  have hbT : b ∈ T := by
    rw [← hST]
    exact (hS b).2 (Or.inl rfl)
  have hcT : c ∈ T := by
    rw [← hST]
    exact (hS c).2 (Or.inr rfl)
  have hx := (hS x).1 hxS
  have hy := (hS y).1 hyS
  have hb := (hT b).1 hbT
  have hc := (hT c).1 hcT
  aesop

/-- Every encoded `2+1+1` draw induces the partial quartet whose singleton
side is the repeated value. -/
theorem twoOneOnePatternDraw_induces
    {X : Type uX} [Fintype X] [DecidableEq X] {a b c : X}
    (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c)
    (p : TwoOneOneIndex) :
    Induces (twoOneOnePatternDraw a b c p)
      s(({a} : Finset X), {b, c}) := by
  classical
  have hpartial : IsPartialSplit s(({a} : Finset X), {b, c}) := by
    exact ⟨{a}, {b, c}, rfl, by simp, by simp, by
      simp [Finset.disjoint_left, hab, hac]⟩
  rcases p with ⟨⟨S, j⟩, hS, hj⟩
  have hclass := fin4_card_two_classification S hS
  rcases hclass with rfl | rfl | rfl | rfl | rfl | rfl <;>
    fin_cases j <;> simp at hj
  all_goals
    apply (induces_iff_canonical _ _).2
    refine ⟨hpartial, ?_⟩
    simp [drawPairSplit, twoOneOnePatternDraw, Finset.pair_comm,
      hab, hab.symm, hac, hac.symm, hbc, hbc.symm]
    aesop

/-- The original permutation-based induction predicate for a `1|2` partial
quartet is exactly the explicit twelve-pattern draw set. -/
theorem inducingDrawFinset_singleton_pair
    {X : Type uX} [Fintype X] [DecidableEq X] {a b c : X}
    (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) :
    inducingDrawFinset s(({a} : Finset X), {b, c}) =
      twoOneOneDraws a b c := by
  classical
  ext draw
  rw [mem_inducingDrawFinset, mem_twoOneOneDraws]
  constructor
  · rintro ⟨_hpartial, pi, hpi⟩
    rw [Sym2.eq_iff] at hpi
    rcases hpi with ⟨ha, hbcPair⟩ | ⟨ha, hbcPair⟩
    · have haa := singletonLike_eq_pairLike_values
          (a := a) (x := draw (pi 0)) (y := draw (pi 1)) ha
          (by intro z; simp) (by intro z; simp [eq_comm])
      have hpairs := distinctPairLike_eq_pairLike_values
        (b := b) (c := c) (x := draw (pi 2)) (y := draw (pi 3)) hbc hbcPair
        (by intro z; simp [eq_comm]) (by intro z; simp [eq_comm])
      rcases hpairs with hpair | hpair
      · obtain ⟨p, hp⟩ := exists_twoOneOnePattern_of_perm_values
          draw pi haa.1 haa.2 hpair.1 hpair.2
        exact ⟨p, hp⟩
      · let pi' : Equiv.Perm (Fin 4) := (Equiv.swap 2 3).trans pi
        have heval₀ : pi' 0 = pi 0 := by
          dsimp [pi']
          congr 1
        have heval₁ : pi' 1 = pi 1 := by
          dsimp [pi']
          congr 1
        have heval₂ : pi' 2 = pi 3 := by
          dsimp [pi']
          congr 1
        have heval₃ : pi' 3 = pi 2 := by
          dsimp [pi']
          congr 1
        have h₀ : draw (pi' 0) = a := by simpa [heval₀] using haa.1
        have h₁ : draw (pi' 1) = a := by simpa [heval₁] using haa.2
        have h₂ : draw (pi' 2) = b := by
          simpa [heval₂] using hpair.2
        have h₃ : draw (pi' 3) = c := by
          simpa [heval₃] using hpair.1
        obtain ⟨p, hp⟩ := exists_twoOneOnePattern_of_perm_values
          draw pi' h₀ h₁ h₂ h₃
        exact ⟨p, hp⟩
    · have haa := singletonLike_eq_pairLike_values
          (a := a) (x := draw (pi 2)) (y := draw (pi 3)) ha
          (by intro z; simp) (by intro z; simp [eq_comm])
      have hpairs := distinctPairLike_eq_pairLike_values
        (b := b) (c := c) (x := draw (pi 0)) (y := draw (pi 1)) hbc hbcPair
        (by intro z; simp [eq_comm]) (by intro z; simp [eq_comm])
      rcases hpairs with hpair | hpair
      · let pi' : Equiv.Perm (Fin 4) :=
          (Equiv.addRight (2 : Fin 4)).trans pi
        have heval₀ : pi' 0 = pi 2 := by
          dsimp [pi']
        have heval₁ : pi' 1 = pi 3 := by
          dsimp [pi']
        have heval₂ : pi' 2 = pi 0 := by
          dsimp [pi']
        have heval₃ : pi' 3 = pi 1 := by
          dsimp [pi']
        have h₀ : draw (pi' 0) = a := by
          simpa [heval₀] using haa.1
        have h₁ : draw (pi' 1) = a := by
          simpa [heval₁] using haa.2
        have h₂ : draw (pi' 2) = b := by
          simpa [heval₂] using hpair.1
        have h₃ : draw (pi' 3) = c := by
          simpa [heval₃] using hpair.2
        obtain ⟨p, hp⟩ := exists_twoOneOnePattern_of_perm_values
          draw pi' h₀ h₁ h₂ h₃
        exact ⟨p, hp⟩
      · let pi' : Equiv.Perm (Fin 4) :=
          ((Equiv.swap 2 3).trans (Equiv.addRight (2 : Fin 4))).trans pi
        have heval₀ : pi' 0 = pi 2 := by
          dsimp [pi']
          congr 1
        have heval₁ : pi' 1 = pi 3 := by
          dsimp [pi']
          congr 1
        have heval₂ : pi' 2 = pi 1 := by
          dsimp [pi']
          congr 1
        have heval₃ : pi' 3 = pi 0 := by
          dsimp [pi']
          congr 1
        have h₀ : draw (pi' 0) = a := by
          simpa [heval₀] using haa.1
        have h₁ : draw (pi' 1) = a := by
          simpa [heval₁] using haa.2
        have h₂ : draw (pi' 2) = b := by
          simpa [heval₂] using hpair.2
        have h₃ : draw (pi' 3) = c := by
          simpa [heval₃] using hpair.1
        obtain ⟨p, hp⟩ := exists_twoOneOnePattern_of_perm_values
          draw pi' h₀ h₁ h₂ h₃
        exact ⟨p, hp⟩
  · rintro ⟨p, rfl⟩
    exact twoOneOnePatternDraw_induces hab hac hbc p

theorem card_inducingDrawFinset_singleton_pair
    {X : Type uX} [Fintype X] [DecidableEq X] {a b c : X}
    (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) :
    (inducingDrawFinset s(({a} : Finset X), {b, c})).card = 12 := by
  rw [inducingDrawFinset_singleton_pair hab hac hbc,
    card_twoOneOneDraws hab hac hbc]

/-- A fixed `1|1` partial quartet has exactly the six ordered `2+2` draws. -/
theorem inducingDrawFinset_singleton_singleton
    {X : Type uX} [Fintype X] {a b : X} (hab : a ≠ b) :
    inducingDrawFinset s(({a} : Finset X), {b}) =
      twoTwoDraws {a} {b} := by
  classical
  ext draw
  rw [mem_inducingDrawFinset, mem_twoTwoDraws_iff_six]
  simp only [Finset.mem_singleton]
  constructor
  · intro hind
    have hc := (induces_iff_canonical draw
      s(({a} : Finset X), {b})).1 hind
    rcases hc.2 with h | h | h
    · change s(({a} : Finset X), {b}) =
        s({draw 0, draw 1}, {draw 2, draw 3}) at h
      rw [Sym2.eq_iff] at h
      rcases h with ⟨ha, hb⟩ | ⟨ha, hb⟩
      · exact Or.inl ⟨(singleton_eq_pair_iff a _ _).1 ha |>.1,
          (singleton_eq_pair_iff a _ _).1 ha |>.2,
          (singleton_eq_pair_iff b _ _).1 hb |>.1,
          (singleton_eq_pair_iff b _ _).1 hb |>.2⟩
      · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr
          ⟨(singleton_eq_pair_iff a _ _).1 ha |>.1,
            (singleton_eq_pair_iff a _ _).1 ha |>.2,
            (singleton_eq_pair_iff b _ _).1 hb |>.1,
            (singleton_eq_pair_iff b _ _).1 hb |>.2⟩))))
    · change s(({a} : Finset X), {b}) =
        s({draw 0, draw 2}, {draw 1, draw 3}) at h
      rw [Sym2.eq_iff] at h
      rcases h with ⟨ha, hb⟩ | ⟨ha, hb⟩
      · exact Or.inr (Or.inl
          ⟨(singleton_eq_pair_iff a _ _).1 ha |>.1,
            (singleton_eq_pair_iff a _ _).1 ha |>.2,
            (singleton_eq_pair_iff b _ _).1 hb |>.1,
            (singleton_eq_pair_iff b _ _).1 hb |>.2⟩)
      · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inl
          ⟨(singleton_eq_pair_iff a _ _).1 ha |>.1,
            (singleton_eq_pair_iff a _ _).1 ha |>.2,
            (singleton_eq_pair_iff b _ _).1 hb |>.1,
            (singleton_eq_pair_iff b _ _).1 hb |>.2⟩))))
    · change s(({a} : Finset X), {b}) =
        s({draw 0, draw 3}, {draw 1, draw 2}) at h
      rw [Sym2.eq_iff] at h
      rcases h with ⟨ha, hb⟩ | ⟨ha, hb⟩
      · exact Or.inr (Or.inr (Or.inl
          ⟨(singleton_eq_pair_iff a _ _).1 ha |>.1,
            (singleton_eq_pair_iff a _ _).1 ha |>.2,
            (singleton_eq_pair_iff b _ _).1 hb |>.1,
            (singleton_eq_pair_iff b _ _).1 hb |>.2⟩))
      · exact Or.inr (Or.inr (Or.inr (Or.inl
          ⟨(singleton_eq_pair_iff a _ _).1 ha |>.1,
            (singleton_eq_pair_iff a _ _).1 ha |>.2,
            (singleton_eq_pair_iff b _ _).1 hb |>.1,
            (singleton_eq_pair_iff b _ _).1 hb |>.2⟩)))
  · intro hdraw
    have hpartial : IsPartialSplit s(({a} : Finset X), {b}) := by
      exact ⟨{a}, {b}, rfl, by simp, by simp, by
        simp [Finset.disjoint_left, hab]⟩
    apply (induces_iff_canonical draw _).2
    refine ⟨hpartial, ?_⟩
    rcases hdraw with h | h | h | h | h | h
    · left; rcases h with ⟨h₀, h₁, h₂, h₃⟩
      simp [drawPairSplit, h₀, h₁, h₂, h₃]
    · right; left; rcases h with ⟨h₀, h₂, h₁, h₃⟩
      simp [drawPairSplit, h₀, h₁, h₂, h₃]
    · right; right; rcases h with ⟨h₀, h₃, h₁, h₂⟩
      simp [drawPairSplit, h₀, h₁, h₂, h₃]
    · right; right; rcases h with ⟨h₁, h₂, h₀, h₃⟩
      simp [drawPairSplit, h₀, h₁, h₂, h₃]
    · right; left; rcases h with ⟨h₁, h₃, h₀, h₂⟩
      simp [drawPairSplit, h₀, h₁, h₂, h₃]
    · left; rcases h with ⟨h₂, h₃, h₀, h₁⟩
      simp [drawPairSplit, h₀, h₁, h₂, h₃]

theorem card_inducingDrawFinset_singleton_singleton
    {X : Type uX} [Fintype X] {a b : X} (hab : a ≠ b) :
    (inducingDrawFinset s(({a} : Finset X), {b})).card = 6 := by
  classical
  rw [inducingDrawFinset_singleton_singleton hab,
    card_twoTwoDraws]
  · simp
  · simp [Finset.disjoint_left, hab]

/-! ### The four-taxon fibre -/

/-- Four singleton cells, one for each taxon of a full quartet. -/
noncomputable def fourSingletonCells {X : Type uX}
    (a b c d : X) : Fin 4 → Finset X :=
  ![{a}, {b}, {c}, {d}]

/-- Pairwise-distinct labels give pairwise-disjoint singleton cells. -/
theorem fourSingletonCells_pairwiseDisjoint
    {X : Type uX} {a b c d : X}
    (hab : a ≠ b) (hac : a ≠ c) (had : a ≠ d)
    (hbc : b ≠ c) (hbd : b ≠ d) (hcd : c ≠ d) :
    (Set.univ : Set (Fin 4)).PairwiseDisjoint
      (fourSingletonCells a b c d) := by
  classical
  intro i _ j _ hij
  fin_cases i <;> fin_cases j <;>
    simp_all [fourSingletonCells, Finset.disjoint_left,
      hab, hab.symm, hac, hac.symm, had, had.symm,
      hbc, hbc.symm, hbd, hbd.symm, hcd, hcd.symm]

/-- Four explicitly witnessed values hit all four singleton cells. -/
private theorem hits_fourSingletonCells
    {X : Type uX} {a b c d : X} (draw : Fin 4 → X)
    (ia ib ic id : Fin 4)
    (ha : draw ia = a) (hb : draw ib = b)
    (hc : draw ic = c) (hd : draw id = d) :
    ∀ j : Fin 4, ∃ i : Fin 4,
      draw i ∈ fourSingletonCells a b c d j := by
  intro j
  fin_cases j
  · exact ⟨ia, by simpa [fourSingletonCells] using ha⟩
  · exact ⟨ib, by simpa [fourSingletonCells] using hb⟩
  · exact ⟨ic, by simpa [fourSingletonCells] using hc⟩
  · exact ⟨id, by simpa [fourSingletonCells] using hd⟩

/-- A fixed full quartet on four distinct taxa is induced exactly by the
ordered draws that contain each of the four taxa once. -/
theorem inducingDrawFinset_pair_pair
    {X : Type uX} [Fintype X] [DecidableEq X] {a b c d : X}
    (hab : a ≠ b) (hac : a ≠ c) (had : a ≠ d)
    (hbc : b ≠ c) (hbd : b ≠ d) (hcd : c ≠ d) :
    inducingDrawFinset s(({a, b} : Finset X), {c, d}) =
      oneEachDraws (fourSingletonCells a b c d) := by
  classical
  have hdisj := fourSingletonCells_pairwiseDisjoint
    hab hac had hbc hbd hcd
  ext draw
  rw [mem_inducingDrawFinset,
    mem_oneEachDraws_iff_hits_all _ hdisj]
  constructor
  · rintro ⟨_hpartial, pi, hpi⟩
    rw [Sym2.eq_iff] at hpi
    rcases hpi with ⟨hAB, hCD⟩ | ⟨hAB, hCD⟩
    · have hpAB := distinctPairLike_eq_pairLike_values
          (b := a) (c := b) (x := draw (pi 0)) (y := draw (pi 1)) hab hAB
          (by intro z; simp [eq_comm]) (by intro z; simp [eq_comm])
      have hpCD := distinctPairLike_eq_pairLike_values
          (b := c) (c := d) (x := draw (pi 2)) (y := draw (pi 3)) hcd hCD
          (by intro z; simp [eq_comm]) (by intro z; simp [eq_comm])
      rcases hpAB with hpAB | hpAB <;> rcases hpCD with hpCD | hpCD
      · exact hits_fourSingletonCells draw (pi 0) (pi 1) (pi 2) (pi 3)
          hpAB.1 hpAB.2 hpCD.1 hpCD.2
      · exact hits_fourSingletonCells draw (pi 0) (pi 1) (pi 3) (pi 2)
          hpAB.1 hpAB.2 hpCD.2 hpCD.1
      · exact hits_fourSingletonCells draw (pi 1) (pi 0) (pi 2) (pi 3)
          hpAB.2 hpAB.1 hpCD.1 hpCD.2
      · exact hits_fourSingletonCells draw (pi 1) (pi 0) (pi 3) (pi 2)
          hpAB.2 hpAB.1 hpCD.2 hpCD.1
    · have hpAB := distinctPairLike_eq_pairLike_values
          (b := a) (c := b) (x := draw (pi 2)) (y := draw (pi 3)) hab hAB
          (by intro z; simp [eq_comm]) (by intro z; simp [eq_comm])
      have hpCD := distinctPairLike_eq_pairLike_values
          (b := c) (c := d) (x := draw (pi 0)) (y := draw (pi 1)) hcd hCD
          (by intro z; simp [eq_comm]) (by intro z; simp [eq_comm])
      rcases hpAB with hpAB | hpAB <;> rcases hpCD with hpCD | hpCD
      · exact hits_fourSingletonCells draw (pi 2) (pi 3) (pi 0) (pi 1)
          hpAB.1 hpAB.2 hpCD.1 hpCD.2
      · exact hits_fourSingletonCells draw (pi 2) (pi 3) (pi 1) (pi 0)
          hpAB.1 hpAB.2 hpCD.2 hpCD.1
      · exact hits_fourSingletonCells draw (pi 3) (pi 2) (pi 0) (pi 1)
          hpAB.2 hpAB.1 hpCD.1 hpCD.2
      · exact hits_fourSingletonCells draw (pi 3) (pi 2) (pi 1) (pi 0)
          hpAB.2 hpAB.1 hpCD.2 hpCD.1
  · intro hdraw
    have hone : draw ∈ oneEachDraws (fourSingletonCells a b c d) :=
      (mem_oneEachDraws_iff_hits_all _ hdisj draw).2 hdraw
    rw [mem_oneEachDraws] at hone
    rcases hone with ⟨pi, hpi⟩
    let rho : Equiv.Perm (Fin 4) := pi.symm
    have h₀ := hpi (rho 0)
    have h₁ := hpi (rho 1)
    have h₂ := hpi (rho 2)
    have h₃ := hpi (rho 3)
    have ha : draw (rho 0) = a := by
      simpa [rho, fourSingletonCells] using h₀
    have hb : draw (rho 1) = b := by
      simpa [rho, fourSingletonCells] using h₁
    have hc : draw (rho 2) = c := by
      simpa [rho, fourSingletonCells] using h₂
    have hd : draw (rho 3) = d := by
      simpa [rho, fourSingletonCells] using h₃
    have hpartial : IsPartialSplit s(({a, b} : Finset X), {c, d}) := by
      exact ⟨{a, b}, {c, d}, rfl, by simp, by simp, by
        simp [Finset.disjoint_left, hac, had, hbc, hbd]⟩
    refine ⟨hpartial, rho, ?_⟩
    rw [Sym2.eq_iff]
    left
    constructor <;> apply Finset.ext <;> intro z <;>
      simp [ha, hb, hc, hd, eq_comm]

/-- A fixed full quartet has exactly `4! = 24` ordered inducing draws. -/
theorem card_inducingDrawFinset_pair_pair
    {X : Type uX} [Fintype X] [DecidableEq X] {a b c d : X}
    (hab : a ≠ b) (hac : a ≠ c) (had : a ≠ d)
    (hbc : b ≠ c) (hbd : b ≠ d) (hcd : c ≠ d) :
    (inducingDrawFinset s(({a, b} : Finset X), {c, d})).card = 24 := by
  rw [inducingDrawFinset_pair_pair hab hac had hbc hbd hcd,
    card_oneEachDraws _
      (fourSingletonCells_pairwiseDisjoint hab hac had hbc hbd hcd)]
  simp [fourSingletonCells, Fin.prod_univ_succ]

/-! ### Uniform fibre theorem for an arbitrary partial quartet -/

/-- A represented partial quartet has exactly one of the three possible side
cardinality types.  In the middle case the singleton side is placed first,
using the unordered nature of `PartialSplit`. -/
private theorem representedPartialQuartet_cases
    {X : Type uX} [DecidableEq X] (A B : Finset X)
    (hAne : A.Nonempty) (hBne : B.Nonempty) (hAB : Disjoint A B)
    (hAcard : A.card ≤ 2) (hBcard : B.card ≤ 2) :
    (∃ a b : X, a ≠ b ∧ s(A, B) = s(({a} : Finset X), {b})) ∨
    (∃ a b c : X, a ≠ b ∧ a ≠ c ∧ b ≠ c ∧
      s(A, B) = s(({a} : Finset X), {b, c})) ∨
    (∃ a b c d : X,
      a ≠ b ∧ a ≠ c ∧ a ≠ d ∧
      b ≠ c ∧ b ≠ d ∧ c ≠ d ∧
      s(A, B) = s(({a, b} : Finset X), {c, d})) := by
  have hAcases : A.card = 1 ∨ A.card = 2 := by
    have hApos : 0 < A.card := Finset.card_pos.mpr hAne
    omega
  have hBcases : B.card = 1 ∨ B.card = 2 := by
    have hBpos : 0 < B.card := Finset.card_pos.mpr hBne
    omega
  rcases hAcases with hAone | hAtwo <;>
    rcases hBcases with hBone | hBtwo
  · obtain ⟨a, hAeq⟩ := Finset.card_eq_one.mp hAone
    obtain ⟨b, hBeq⟩ := Finset.card_eq_one.mp hBone
    have hAB' : Disjoint ({a} : Finset X) {b} := by
      simpa [hAeq, hBeq] using hAB
    have hab : a ≠ b := by
      intro h
      subst b
      exact (Finset.disjoint_left.mp hAB') (a := a) (by simp) (by simp)
    have hsplit : s(A, B) = s(({a} : Finset X), {b}) :=
      congrArg₂ (fun U V : Finset X => s(U, V)) hAeq hBeq
    exact Or.inl ⟨a, b, hab, hsplit⟩
  · obtain ⟨a, hAeq⟩ := Finset.card_eq_one.mp hAone
    obtain ⟨b, c, hbc, hBeq⟩ := Finset.card_eq_two.mp hBtwo
    have hAB' : Disjoint ({a} : Finset X) {b, c} := by
      simpa [hAeq, hBeq] using hAB
    have hab : a ≠ b := by
      intro h
      subst b
      exact (Finset.disjoint_left.mp hAB') (a := a) (by simp) (by simp)
    have hac : a ≠ c := by
      intro h
      subst c
      exact (Finset.disjoint_left.mp hAB') (a := a) (by simp) (by simp)
    have hsplit : s(A, B) = s(({a} : Finset X), {b, c}) :=
      congrArg₂ (fun U V : Finset X => s(U, V)) hAeq hBeq
    exact Or.inr (Or.inl ⟨a, b, c, hab, hac, hbc, hsplit⟩)
  · obtain ⟨a, b, hab, hAeq⟩ := Finset.card_eq_two.mp hAtwo
    obtain ⟨c, hBeq⟩ := Finset.card_eq_one.mp hBone
    have hAB' : Disjoint ({a, b} : Finset X) {c} := by
      simpa [hAeq, hBeq] using hAB
    have hac : a ≠ c := by
      intro h
      subst c
      exact (Finset.disjoint_left.mp hAB') (a := a) (by simp) (by simp)
    have hbc : b ≠ c := by
      intro h
      subst c
      exact (Finset.disjoint_left.mp hAB') (a := b) (by simp) (by simp)
    have hsplit₀ : s(A, B) = s(({a, b} : Finset X), {c}) :=
      congrArg₂ (fun U V : Finset X => s(U, V)) hAeq hBeq
    have hsplit : s(A, B) = s(({c} : Finset X), {a, b}) :=
      hsplit₀.trans Sym2.eq_swap
    exact Or.inr (Or.inl ⟨c, a, b, hac.symm, hbc.symm, hab,
      hsplit⟩)
  · obtain ⟨a, b, hab, hAeq⟩ := Finset.card_eq_two.mp hAtwo
    obtain ⟨c, d, hcd, hBeq⟩ := Finset.card_eq_two.mp hBtwo
    have hAB' : Disjoint ({a, b} : Finset X) {c, d} := by
      simpa [hAeq, hBeq] using hAB
    have hac : a ≠ c := by
      intro h
      subst c
      exact (Finset.disjoint_left.mp hAB') (a := a) (by simp) (by simp)
    have had : a ≠ d := by
      intro h
      subst d
      exact (Finset.disjoint_left.mp hAB') (a := a) (by simp) (by simp)
    have hbc : b ≠ c := by
      intro h
      subst c
      exact (Finset.disjoint_left.mp hAB') (a := b) (by simp) (by simp)
    have hbd : b ≠ d := by
      intro h
      subst d
      exact (Finset.disjoint_left.mp hAB') (a := b) (by simp) (by simp)
    have hsplit : s(A, B) = s(({a, b} : Finset X), {c, d}) :=
      congrArg₂ (fun U V : Finset X => s(U, V)) hAeq hBeq
    exact Or.inr (Or.inr ⟨a, b, c, d, hab, hac, had,
      hbc, hbd, hcd, hsplit⟩)

/-- Intrinsic classification of any partial quartet into `1|1`, `1|2`, or
`2|2`, with all labels made explicit and pairwise distinct where required. -/
theorem partialQuartet_representation_cases
    {X : Type uX} [Fintype X] [DecidableEq X]
    {P : PartialSplit X} (hP : IsPartialQuartet P) :
    (∃ a b : X, a ≠ b ∧ P = s(({a} : Finset X), {b})) ∨
    (∃ a b c : X, a ≠ b ∧ a ≠ c ∧ b ≠ c ∧
      P = s(({a} : Finset X), {b, c})) ∨
    (∃ a b c d : X,
      a ≠ b ∧ a ≠ c ∧ a ≠ d ∧
      b ≠ c ∧ b ≠ d ∧ c ≠ d ∧
      P = s(({a, b} : Finset X), {c, d})) := by
  rcases hP with
    ⟨⟨C, D, hPCD, hCne, hDne, hCD⟩,
      A, B, hPAB, hAcard, hBcard⟩
  have hrep : s(A, B) = s(C, D) := hPAB.symm.trans hPCD
  rw [Sym2.eq_iff] at hrep
  rcases hrep with ⟨hAC, hBD⟩ | ⟨hAD, hBC⟩
  · subst C
    subst D
    simpa [hPAB] using
      representedPartialQuartet_cases A B hCne hDne hCD hAcard hBcard
  · subst D
    subst C
    simpa [hPAB] using
      representedPartialQuartet_cases A B hDne hCne hCD.symm hAcard hBcard

/-- The factorial multiplicity attached to a partial-quartet support size. -/
def partialQuartetFiberMultiplicity : ℕ → ℕ
  | 2 => 6
  | 3 => 12
  | 4 => 24
  | _ => 0

private theorem support_card_singleton_singleton
    {X : Type uX} [DecidableEq X] {a b : X} (hab : a ≠ b) :
    (partialSplitSupport s(({a} : Finset X), {b})).card = 2 := by
  have hdisj : Disjoint ({a} : Finset X) {b} := by
    simp [Finset.disjoint_left, hab]
  rw [partialSplitSupport_mk, Finset.card_union_of_disjoint hdisj]
  simp

private theorem support_card_singleton_pair
    {X : Type uX} [DecidableEq X] {a b c : X}
    (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) :
    (partialSplitSupport s(({a} : Finset X), {b, c})).card = 3 := by
  have hdisj : Disjoint ({a} : Finset X) {b, c} := by
    simp [Finset.disjoint_left, hab, hac]
  rw [partialSplitSupport_mk, Finset.card_union_of_disjoint hdisj]
  simp [Finset.card_pair hbc]

private theorem support_card_pair_pair
    {X : Type uX} [DecidableEq X] {a b c d : X}
    (hab : a ≠ b) (hac : a ≠ c) (had : a ≠ d)
    (hbc : b ≠ c) (hbd : b ≠ d) (hcd : c ≠ d) :
    (partialSplitSupport s(({a, b} : Finset X), {c, d})).card = 4 := by
  have hdisj : Disjoint ({a, b} : Finset X) {c, d} := by
    simp [Finset.disjoint_left, hac, had, hbc, hbd]
  rw [partialSplitSupport_mk, Finset.card_union_of_disjoint hdisj]
  simp [Finset.card_pair hab, Finset.card_pair hcd]

/-- Exact uniform fibre theorem: a fixed partial quartet has `6`, `12`, or
`24` ordered inducing draws according as its support has size `2`, `3`, or
`4`. -/
theorem card_inducingDrawFinset_partialQuartet
    {X : Type uX} [Fintype X] [DecidableEq X]
    {P : PartialSplit X} (hP : IsPartialQuartet P) :
    (inducingDrawFinset P).card =
      partialQuartetFiberMultiplicity (partialSplitSupport P).card := by
  rcases partialQuartet_representation_cases hP with
    ⟨a, b, hab, hPab⟩ |
    ⟨a, b, c, hab, hac, hbc, hPabc⟩ |
    ⟨a, b, c, d, hab, hac, had, hbc, hbd, hcd, hPabcd⟩
  · subst P
    rw [support_card_singleton_singleton hab]
    simpa [partialQuartetFiberMultiplicity] using
      card_inducingDrawFinset_singleton_singleton (X := X) hab
  · subst P
    rw [support_card_singleton_pair hab hac hbc]
    simpa [partialQuartetFiberMultiplicity] using
      card_inducingDrawFinset_singleton_pair (X := X) hab hac hbc
  · subst P
    rw [support_card_pair_pair hab hac had hbc hbd hcd]
    simpa [partialQuartetFiberMultiplicity] using
      card_inducingDrawFinset_pair_pair (X := X)
        hab hac had hbc hbd hcd

/-- A partial quartet necessarily involves exactly two, three, or four taxa. -/
theorem partialQuartet_support_card_cases
    {X : Type uX} [Fintype X] [DecidableEq X]
    {P : PartialSplit X} (hP : IsPartialQuartet P) :
    (partialSplitSupport P).card = 2 ∨
    (partialSplitSupport P).card = 3 ∨
    (partialSplitSupport P).card = 4 := by
  rcases partialQuartet_representation_cases hP with
    ⟨a, b, hab, rfl⟩ |
    ⟨a, b, c, hab, hac, hbc, rfl⟩ |
    ⟨a, b, c, d, hab, hac, had, hbc, hbd, hcd, rfl⟩
  · left
    exact support_card_singleton_singleton hab
  · right; left
    exact support_card_singleton_pair hab hac hbc
  · right; right
    exact support_card_pair_pair hab hac had hbc hbd hcd

end QDFull
