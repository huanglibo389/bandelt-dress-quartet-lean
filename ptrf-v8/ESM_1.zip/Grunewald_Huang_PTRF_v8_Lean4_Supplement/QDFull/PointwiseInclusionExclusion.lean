import QDFull.TreeEventClassification
import QDFull.InclusionExclusionCoefficient

/-!
# Pointwise inclusion--exclusion on one ordered four-draw sample

The four source blocks are expanded before taking probabilities.  In the
same-quartet case every source pair contributes `1`; in the different-quartet
case it contributes `-1/2`; and otherwise it contributes zero.  The signed
source counts then factor as

`(edges₁ - paths₁) * (edges₂ - paths₂) = 1 * 1`.

Thus the paper's inclusion--exclusion identity is proved sample by sample,
including repeated taxa and vertex labels at internal tree vertices.
-/

open scoped BigOperators

namespace QDFull

universe uX uV₁ uV₂

section Definitions

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]

/-- Pointwise edge--edge source block. -/
noncomputable def edgeEdgeDrawBlock
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (draw : Fin 4 → X) : ℝ :=
  ∑ e₁ ∈ T₁.canonicalEdgeFinset,
    ∑ e₂ ∈ T₂.canonicalEdgeFinset,
      splitDrawContribution
        (T₁.edgeSplit e₁.1 e₁.2) (T₂.edgeSplit e₂.1 e₂.2) draw

/-- Pointwise edge--path source block. -/
noncomputable def edgePathDrawBlock
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (draw : Fin 4 → X) : ℝ :=
  ∑ e₁ ∈ T₁.canonicalEdgeFinset,
    ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
      splitDrawContribution
        (T₁.edgeSplit e₁.1 e₁.2)
        (T₂.sidePairSplit p₂.1 p₂.2.1 p₂.2.2) draw

/-- Pointwise path--edge source block. -/
noncomputable def pathEdgeDrawBlock
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (draw : Fin 4 → X) : ℝ :=
  ∑ p₁ ∈ T₁.canonicalLengthTwoPathFinset,
    ∑ e₂ ∈ T₂.canonicalEdgeFinset,
      splitDrawContribution
        (T₁.sidePairSplit p₁.1 p₁.2.1 p₁.2.2)
        (T₂.edgeSplit e₂.1 e₂.2) draw

/-- Pointwise path--path source block. -/
noncomputable def pathPathDrawBlock
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (draw : Fin 4 → X) : ℝ :=
  ∑ p₁ ∈ T₁.canonicalLengthTwoPathFinset,
    ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
      splitDrawContribution
        (T₁.sidePairSplit p₁.1 p₁.2.1 p₁.2.2)
        (T₂.sidePairSplit p₂.1 p₂.2.1 p₂.2.2) draw

/-- The four pointwise source blocks with the paper's signs. -/
noncomputable def inclusionExclusionDrawContribution
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (draw : Fin 4 → X) : ℝ :=
  edgeEdgeDrawBlock T₁ T₂ draw - edgePathDrawBlock T₁ T₂ draw -
    pathEdgeDrawBlock T₁ T₂ draw + pathPathDrawBlock T₁ T₂ draw

/-- Number of canonical edge sources displaying `P`, cast to `ℝ`. -/
noncomputable def edgeDisplayCount
    [LinearOrder V₁] (T : XTree X V₁) (P : PartialSplit X) : ℝ :=
  ∑ e ∈ T.canonicalEdgeFinset,
    propIndicator (Displays (T.edgeSplit e.1 e.2) P)

/-- Number of canonical length-two-path sources displaying `P`, cast to
`ℝ`. -/
noncomputable def pathDisplayCount
    [LinearOrder V₁] (T : XTree X V₁) (P : PartialSplit X) : ℝ :=
  ∑ p ∈ T.canonicalLengthTwoPathFinset,
    propIndicator (Displays (T.sidePairSplit p.1 p.2.1 p.2.2) P)

end Definitions

section Counts

variable {X : Type uX} {V : Type*}
  [Fintype X] [Fintype V] [DecidableEq X] [DecidableEq V]

theorem edgeDisplayCount_eq_card [LinearOrder V]
    (T : XTree X V) (P : PartialSplit X) :
    edgeDisplayCount T P = ((T.displayingEdgeFinset P).card : ℝ) := by
  classical
  unfold edgeDisplayCount XTree.displayingEdgeFinset
  exact sum_propIndicator_eq_card_filter _ _

theorem pathDisplayCount_eq_card [LinearOrder V]
    (T : XTree X V) (P : PartialSplit X) :
    pathDisplayCount T P =
      ((T.displayingLengthTwoPathFinset P).card : ℝ) := by
  classical
  unfold pathDisplayCount XTree.displayingLengthTwoPathFinset
  exact sum_propIndicator_eq_card_filter _ _

/-- The real-valued version of `k - (k-1) = 1`. -/
theorem edgeDisplayCount_sub_pathDisplayCount_eq_one [LinearOrder V]
    (T : XTree X V) {draw : Fin 4 → X} {P : PartialSplit X}
    (hind : Induces draw P) (hdisplay : T.DisplaysPartialSplit P) :
    edgeDisplayCount T P - pathDisplayCount T P = 1 := by
  rw [edgeDisplayCount_eq_card, pathDisplayCount_eq_card]
  have h := T.signedDisplayMultiplicity_eq_one_of_induces hind hdisplay
  unfold XTree.signedDisplayMultiplicity at h
  exact_mod_cast h

end Counts

section GenericSums

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]

private theorem biSum_product {α β : Type*}
    (A : Finset α) (B : Finset β) (f : α → ℝ) (g : β → ℝ) :
    (∑ a ∈ A, ∑ b ∈ B, f a * g b) =
      (∑ a ∈ A, f a) * (∑ b ∈ B, g b) := by
  rw [Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro a ha
  rw [Finset.mul_sum]

private theorem sourceBlock_eq_mul_of_sameWitness
    {α β : Type*} (A : Finset α) (B : Finset β)
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (S₁ : α → PartialSplit X) (S₂ : β → PartialSplit X)
    {P : PartialSplit X} {draw : Fin 4 → X}
    (hsource₁ : ∀ a ∈ A, T₁.DisplaysPartialSplit (S₁ a))
    (hsource₂ : ∀ b ∈ B, T₂.DisplaysPartialSplit (S₂ b))
    (hindP : Induces draw P)
    (hT₁P : T₁.DisplaysPartialSplit P)
    (hT₂P : T₂.DisplaysPartialSplit P) :
    (∑ a ∈ A, ∑ b ∈ B, splitDrawContribution (S₁ a) (S₂ b) draw) =
      (∑ a ∈ A, propIndicator (Displays (S₁ a) P)) *
        (∑ b ∈ B, propIndicator (Displays (S₂ b) P)) := by
  calc
    _ = ∑ a ∈ A, ∑ b ∈ B,
          propIndicator (Displays (S₁ a) P) *
            propIndicator (Displays (S₂ b) P) := by
        apply Finset.sum_congr rfl
        intro a ha
        apply Finset.sum_congr rfl
        intro b hb
        exact splitDrawContribution_eq_mul_of_sameTreeWitness
          T₁ T₂ (hsource₁ a ha) (hsource₂ b hb) hindP hT₁P hT₂P
    _ = _ := biSum_product A B _ _

private theorem sourceBlock_eq_negHalf_mul_of_differentWitness
    {α β : Type*} (A : Finset α) (B : Finset β)
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (S₁ : α → PartialSplit X) (S₂ : β → PartialSplit X)
    {P Q : PartialSplit X} {draw : Fin 4 → X}
    (hsource₁ : ∀ a ∈ A, T₁.DisplaysPartialSplit (S₁ a))
    (hsource₂ : ∀ b ∈ B, T₂.DisplaysPartialSplit (S₂ b))
    (hindP : Induces draw P) (hindQ : Induces draw Q)
    (hT₁P : T₁.DisplaysPartialSplit P)
    (hT₂Q : T₂.DisplaysPartialSplit Q) (hPQ : P ≠ Q) :
    (∑ a ∈ A, ∑ b ∈ B, splitDrawContribution (S₁ a) (S₂ b) draw) =
      -(1 / 2 : ℝ) *
        ((∑ a ∈ A, propIndicator (Displays (S₁ a) P)) *
          (∑ b ∈ B, propIndicator (Displays (S₂ b) Q))) := by
  calc
    _ = ∑ a ∈ A, ∑ b ∈ B,
          -(1 / 2 : ℝ) *
            (propIndicator (Displays (S₁ a) P) *
              propIndicator (Displays (S₂ b) Q)) := by
        apply Finset.sum_congr rfl
        intro a ha
        apply Finset.sum_congr rfl
        intro b hb
        exact splitDrawContribution_eq_negHalf_mul_of_differentTreeWitness
          T₁ T₂ (hsource₁ a ha) (hsource₂ b hb)
            hindP hindQ hT₁P hT₂Q hPQ
    _ = (∑ a ∈ A,
          -(1 / 2 : ℝ) * propIndicator (Displays (S₁ a) P)) *
          (∑ b ∈ B, propIndicator (Displays (S₂ b) Q)) := by
        calc
          _ = ∑ a ∈ A, ∑ b ∈ B,
                (-(1 / 2 : ℝ) * propIndicator (Displays (S₁ a) P)) *
                  propIndicator (Displays (S₂ b) Q) := by
              apply Finset.sum_congr rfl
              intro a ha
              apply Finset.sum_congr rfl
              intro b hb
              ring
          _ = _ := biSum_product A B _ _
    _ = _ := by
      rw [← Finset.mul_sum]
      ring

private theorem sourceBlock_eq_zero_of_noTreeEvent
    {α β : Type*} (A : Finset α) (B : Finset β)
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (S₁ : α → PartialSplit X) (S₂ : β → PartialSplit X)
    {draw : Fin 4 → X}
    (hsource₁ : ∀ a ∈ A, T₁.DisplaysPartialSplit (S₁ a))
    (hsource₂ : ∀ b ∈ B, T₂.DisplaysPartialSplit (S₂ b))
    (hSame : ¬SameTreeQuartetEvent T₁ T₂ draw)
    (hDiff : ¬DifferentTreeQuartetEvent T₁ T₂ draw) :
    (∑ a ∈ A, ∑ b ∈ B, splitDrawContribution (S₁ a) (S₂ b) draw) = 0 := by
  apply Finset.sum_eq_zero
  intro a ha
  apply Finset.sum_eq_zero
  intro b hb
  exact splitDrawContribution_eq_zero_of_noTreeEvent
    T₁ T₂ (hsource₁ a ha) (hsource₂ b hb) hSame hDiff

end GenericSums

section SourceFacts

variable {X : Type uX} {V : Type*}
  [Fintype X] [Fintype V] [DecidableEq X] [DecidableEq V]

private theorem canonicalEdge_source_displayed [LinearOrder V]
    (T : XTree X V) (e : V × V) (he : e ∈ T.canonicalEdgeFinset) :
    T.DisplaysPartialSplit (T.edgeSplit e.1 e.2) := by
  exact T.displays_edgeSplit ((T.mem_canonicalEdgeFinset e.1 e.2).1 he).1

private theorem canonicalPath_source_displayed [LinearOrder V]
    (T : XTree X V) (p : V × V × V)
    (hp : p ∈ T.canonicalLengthTwoPathFinset) :
    T.DisplaysPartialSplit (T.sidePairSplit p.1 p.2.1 p.2.2) := by
  have h := (T.mem_canonicalLengthTwoPathFinset p.1 p.2.1 p.2.2).1 hp
  exact T.displays_sidePairSplit h.1 h.2.1 (ne_of_lt h.2.2)

end SourceFacts

section PointwiseSettlement

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]
  [DecidableEq X] [DecidableEq V₁] [DecidableEq V₂]
  [LinearOrder V₁] [LinearOrder V₂]

private theorem fourBlocks_of_sameWitness
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {P : PartialSplit X} {draw : Fin 4 → X}
    (hindP : Induces draw P)
    (hT₁P : T₁.DisplaysPartialSplit P)
    (hT₂P : T₂.DisplaysPartialSplit P) :
    edgeEdgeDrawBlock T₁ T₂ draw = edgeDisplayCount T₁ P * edgeDisplayCount T₂ P ∧
    edgePathDrawBlock T₁ T₂ draw = edgeDisplayCount T₁ P * pathDisplayCount T₂ P ∧
    pathEdgeDrawBlock T₁ T₂ draw = pathDisplayCount T₁ P * edgeDisplayCount T₂ P ∧
    pathPathDrawBlock T₁ T₂ draw = pathDisplayCount T₁ P * pathDisplayCount T₂ P := by
  classical
  refine ⟨?_, ?_, ?_, ?_⟩
  · unfold edgeEdgeDrawBlock edgeDisplayCount
    exact sourceBlock_eq_mul_of_sameWitness
      T₁.canonicalEdgeFinset T₂.canonicalEdgeFinset T₁ T₂
      (fun e => T₁.edgeSplit e.1 e.2) (fun e => T₂.edgeSplit e.1 e.2)
      (canonicalEdge_source_displayed T₁) (canonicalEdge_source_displayed T₂)
      hindP hT₁P hT₂P
  · unfold edgePathDrawBlock edgeDisplayCount pathDisplayCount
    exact sourceBlock_eq_mul_of_sameWitness
      T₁.canonicalEdgeFinset T₂.canonicalLengthTwoPathFinset T₁ T₂
      (fun e => T₁.edgeSplit e.1 e.2)
      (fun p => T₂.sidePairSplit p.1 p.2.1 p.2.2)
      (canonicalEdge_source_displayed T₁) (canonicalPath_source_displayed T₂)
      hindP hT₁P hT₂P
  · unfold pathEdgeDrawBlock edgeDisplayCount pathDisplayCount
    exact sourceBlock_eq_mul_of_sameWitness
      T₁.canonicalLengthTwoPathFinset T₂.canonicalEdgeFinset T₁ T₂
      (fun p => T₁.sidePairSplit p.1 p.2.1 p.2.2)
      (fun e => T₂.edgeSplit e.1 e.2)
      (canonicalPath_source_displayed T₁) (canonicalEdge_source_displayed T₂)
      hindP hT₁P hT₂P
  · unfold pathPathDrawBlock pathDisplayCount
    exact sourceBlock_eq_mul_of_sameWitness
      T₁.canonicalLengthTwoPathFinset T₂.canonicalLengthTwoPathFinset T₁ T₂
      (fun p => T₁.sidePairSplit p.1 p.2.1 p.2.2)
      (fun p => T₂.sidePairSplit p.1 p.2.1 p.2.2)
      (canonicalPath_source_displayed T₁) (canonicalPath_source_displayed T₂)
      hindP hT₁P hT₂P

private theorem fourBlocks_of_differentWitness
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {P Q : PartialSplit X} {draw : Fin 4 → X}
    (hindP : Induces draw P) (hindQ : Induces draw Q)
    (hT₁P : T₁.DisplaysPartialSplit P)
    (hT₂Q : T₂.DisplaysPartialSplit Q) (hPQ : P ≠ Q) :
    edgeEdgeDrawBlock T₁ T₂ draw = -(1 / 2 : ℝ) *
        (edgeDisplayCount T₁ P * edgeDisplayCount T₂ Q) ∧
    edgePathDrawBlock T₁ T₂ draw = -(1 / 2 : ℝ) *
        (edgeDisplayCount T₁ P * pathDisplayCount T₂ Q) ∧
    pathEdgeDrawBlock T₁ T₂ draw = -(1 / 2 : ℝ) *
        (pathDisplayCount T₁ P * edgeDisplayCount T₂ Q) ∧
    pathPathDrawBlock T₁ T₂ draw = -(1 / 2 : ℝ) *
        (pathDisplayCount T₁ P * pathDisplayCount T₂ Q) := by
  classical
  refine ⟨?_, ?_, ?_, ?_⟩
  · unfold edgeEdgeDrawBlock edgeDisplayCount
    exact sourceBlock_eq_negHalf_mul_of_differentWitness
      T₁.canonicalEdgeFinset T₂.canonicalEdgeFinset T₁ T₂
      (fun e => T₁.edgeSplit e.1 e.2) (fun e => T₂.edgeSplit e.1 e.2)
      (canonicalEdge_source_displayed T₁) (canonicalEdge_source_displayed T₂)
      hindP hindQ hT₁P hT₂Q hPQ
  · unfold edgePathDrawBlock edgeDisplayCount pathDisplayCount
    exact sourceBlock_eq_negHalf_mul_of_differentWitness
      T₁.canonicalEdgeFinset T₂.canonicalLengthTwoPathFinset T₁ T₂
      (fun e => T₁.edgeSplit e.1 e.2)
      (fun p => T₂.sidePairSplit p.1 p.2.1 p.2.2)
      (canonicalEdge_source_displayed T₁) (canonicalPath_source_displayed T₂)
      hindP hindQ hT₁P hT₂Q hPQ
  · unfold pathEdgeDrawBlock edgeDisplayCount pathDisplayCount
    exact sourceBlock_eq_negHalf_mul_of_differentWitness
      T₁.canonicalLengthTwoPathFinset T₂.canonicalEdgeFinset T₁ T₂
      (fun p => T₁.sidePairSplit p.1 p.2.1 p.2.2)
      (fun e => T₂.edgeSplit e.1 e.2)
      (canonicalPath_source_displayed T₁) (canonicalEdge_source_displayed T₂)
      hindP hindQ hT₁P hT₂Q hPQ
  · unfold pathPathDrawBlock pathDisplayCount
    exact sourceBlock_eq_negHalf_mul_of_differentWitness
      T₁.canonicalLengthTwoPathFinset T₂.canonicalLengthTwoPathFinset T₁ T₂
      (fun p => T₁.sidePairSplit p.1 p.2.1 p.2.2)
      (fun p => T₂.sidePairSplit p.1 p.2.1 p.2.2)
      (canonicalPath_source_displayed T₁) (canonicalPath_source_displayed T₂)
      hindP hindQ hT₁P hT₂Q hPQ

private theorem fourBlocks_eq_zero_of_noTreeEvent
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (draw : Fin 4 → X)
    (hSame : ¬SameTreeQuartetEvent T₁ T₂ draw)
    (hDiff : ¬DifferentTreeQuartetEvent T₁ T₂ draw) :
    edgeEdgeDrawBlock T₁ T₂ draw = 0 ∧ edgePathDrawBlock T₁ T₂ draw = 0 ∧
      pathEdgeDrawBlock T₁ T₂ draw = 0 ∧ pathPathDrawBlock T₁ T₂ draw = 0 := by
  classical
  refine ⟨?_, ?_, ?_, ?_⟩
  · unfold edgeEdgeDrawBlock
    exact sourceBlock_eq_zero_of_noTreeEvent
      T₁.canonicalEdgeFinset T₂.canonicalEdgeFinset T₁ T₂
      (fun e => T₁.edgeSplit e.1 e.2) (fun e => T₂.edgeSplit e.1 e.2)
      (canonicalEdge_source_displayed T₁) (canonicalEdge_source_displayed T₂)
      hSame hDiff
  · unfold edgePathDrawBlock
    exact sourceBlock_eq_zero_of_noTreeEvent
      T₁.canonicalEdgeFinset T₂.canonicalLengthTwoPathFinset T₁ T₂
      (fun e => T₁.edgeSplit e.1 e.2)
      (fun p => T₂.sidePairSplit p.1 p.2.1 p.2.2)
      (canonicalEdge_source_displayed T₁) (canonicalPath_source_displayed T₂)
      hSame hDiff
  · unfold pathEdgeDrawBlock
    exact sourceBlock_eq_zero_of_noTreeEvent
      T₁.canonicalLengthTwoPathFinset T₂.canonicalEdgeFinset T₁ T₂
      (fun p => T₁.sidePairSplit p.1 p.2.1 p.2.2)
      (fun e => T₂.edgeSplit e.1 e.2)
      (canonicalPath_source_displayed T₁) (canonicalEdge_source_displayed T₂)
      hSame hDiff
  · unfold pathPathDrawBlock
    exact sourceBlock_eq_zero_of_noTreeEvent
      T₁.canonicalLengthTwoPathFinset T₂.canonicalLengthTwoPathFinset T₁ T₂
      (fun p => T₁.sidePairSplit p.1 p.2.1 p.2.2)
      (fun p => T₂.sidePairSplit p.1 p.2.1 p.2.2)
      (canonicalPath_source_displayed T₁) (canonicalPath_source_displayed T₂)
      hSame hDiff

/-- Exact samplewise form of Theorem 1. -/
theorem inclusionExclusionDrawContribution_eq_treeDrawContribution
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (draw : Fin 4 → X) :
    inclusionExclusionDrawContribution T₁ T₂ draw =
      treeDrawContribution T₁ T₂ draw := by
  classical
  by_cases hSame : SameTreeQuartetEvent T₁ T₂ draw
  · have hSame' := hSame
    rcases hSame with ⟨P, hindP, hT₁P, hT₂P⟩
    have hDiff := not_differentTreeQuartetEvent_of_sameWitness
      T₁ T₂ hindP hT₁P hT₂P
    rcases fourBlocks_of_sameWitness T₁ T₂ hindP hT₁P hT₂P with
      ⟨hee, hep, hpe, hpp⟩
    have h₁ := edgeDisplayCount_sub_pathDisplayCount_eq_one
      T₁ hindP hT₁P
    have h₂ := edgeDisplayCount_sub_pathDisplayCount_eq_one
      T₂ hindP hT₂P
    have htree : treeDrawContribution T₁ T₂ draw = 1 := by
      simp [treeDrawContribution, propIndicator, hSame', hDiff]
    rw [inclusionExclusionDrawContribution, hee, hep, hpe, hpp, htree]
    calc
      edgeDisplayCount T₁ P * edgeDisplayCount T₂ P -
            edgeDisplayCount T₁ P * pathDisplayCount T₂ P -
            pathDisplayCount T₁ P * edgeDisplayCount T₂ P +
            pathDisplayCount T₁ P * pathDisplayCount T₂ P =
          (edgeDisplayCount T₁ P - pathDisplayCount T₁ P) *
            (edgeDisplayCount T₂ P - pathDisplayCount T₂ P) := by ring
      _ = 1 := by rw [h₁, h₂]; norm_num
  · by_cases hDiff : DifferentTreeQuartetEvent T₁ T₂ draw
    · have hDiff' := hDiff
      rcases hDiff with ⟨P, Q, hindP, hindQ, hT₁P, hT₂Q, hPQ⟩
      have hSame' := not_sameTreeQuartetEvent_of_differentWitness
        T₁ T₂ hindP hindQ hT₁P hT₂Q hPQ
      rcases fourBlocks_of_differentWitness T₁ T₂
          hindP hindQ hT₁P hT₂Q hPQ with ⟨hee, hep, hpe, hpp⟩
      have h₁ := edgeDisplayCount_sub_pathDisplayCount_eq_one
        T₁ hindP hT₁P
      have h₂ := edgeDisplayCount_sub_pathDisplayCount_eq_one
        T₂ hindQ hT₂Q
      have htree : treeDrawContribution T₁ T₂ draw = -(1 / 2 : ℝ) := by
        simp [treeDrawContribution, propIndicator, hSame', hDiff']
      rw [inclusionExclusionDrawContribution, hee, hep, hpe, hpp, htree]
      calc
        -(1 / 2 : ℝ) * (edgeDisplayCount T₁ P * edgeDisplayCount T₂ Q) -
              (-(1 / 2 : ℝ) *
                (edgeDisplayCount T₁ P * pathDisplayCount T₂ Q)) -
              (-(1 / 2 : ℝ) *
                (pathDisplayCount T₁ P * edgeDisplayCount T₂ Q)) +
              (-(1 / 2 : ℝ) *
                (pathDisplayCount T₁ P * pathDisplayCount T₂ Q)) =
            -(1 / 2 : ℝ) *
              ((edgeDisplayCount T₁ P - pathDisplayCount T₁ P) *
                (edgeDisplayCount T₂ Q - pathDisplayCount T₂ Q)) := by ring
        _ = -(1 / 2 : ℝ) := by rw [h₁, h₂]; norm_num
    · rcases fourBlocks_eq_zero_of_noTreeEvent T₁ T₂ draw hSame hDiff with
        ⟨hee, hep, hpe, hpp⟩
      unfold inclusionExclusionDrawContribution treeDrawContribution
      rw [hee, hep, hpe, hpp]
      simp [propIndicator, hSame, hDiff]

end PointwiseSettlement

end QDFull
