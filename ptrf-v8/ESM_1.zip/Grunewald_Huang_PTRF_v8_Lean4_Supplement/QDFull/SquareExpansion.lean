import QDFull.PathPathCovariance

/-!
# Exact expansion of the three nontrivial square families

The last paragraph of the proof of Theorem 2 says that expanding the four
square families reproduces the raw quadratic.  This file records the local
algebra that statement suppresses.  Every diagonal and mixed monomial is
identified with the corresponding `q`, `b`, `s`, or `p` occurrence before
any global reindexing is attempted.
-/

namespace QDFull

universe uX uV₁ uV₂

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]

/-- Expanding one row-path square creates the two row-extension `q`
diagonals and the `b` mixed monomial. -/
theorem bSquare_expansion
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t₁ u t₂ : V₁) (v w w' w'' : V₂) :
    bCoefficient T₁ T₂ t₁ u t₂ v w w' w'' *
        (xCoefficient T₁ T₂ t₁ u v w +
          xCoefficient T₁ T₂ t₂ u v w) ^ 2 =
      qCoefficient T₁ T₂ t₁ u v w t₂ t₁ w' w'' *
          xCoefficient T₁ T₂ t₁ u v w ^ 2 +
      qCoefficient T₁ T₂ t₂ u v w t₁ t₂ w' w'' *
          xCoefficient T₁ T₂ t₂ u v w ^ 2 +
      2 * bCoefficient T₁ T₂ t₁ u t₂ v w w' w'' *
          xCoefficient T₁ T₂ t₁ u v w *
            xCoefficient T₁ T₂ t₂ u v w := by
  have hq₁ :
      qCoefficient T₁ T₂ t₁ u v w t₂ t₁ w' w'' =
        bCoefficient T₁ T₂ t₁ u t₂ v w w' w'' := rfl
  have hq₂ :
      qCoefficient T₁ T₂ t₂ u v w t₁ t₂ w' w'' =
        bCoefficient T₁ T₂ t₁ u t₂ v w w' w'' := by
    symm
    unfold bCoefficient
    exact qCoefficient_row_reindex T₁ T₂ t₁ u t₂ v w w' w''
  rw [hq₁, hq₂]
  ring

/-- Expanding one column-path square creates the two column-extension `q`
diagonals and the `s` mixed monomial. -/
theorem sSquare_expansion
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t u u' u'' : V₁) (v₁ w v₂ : V₂)
    (hv₁w : T₂.graph.Adj v₁ w) (hwv₂ : T₂.graph.Adj w v₂) :
    sCoefficient T₁ T₂ t u u' u'' v₁ w v₂ *
        (xCoefficient T₁ T₂ t u v₁ w +
          xCoefficient T₁ T₂ t u v₂ w) ^ 2 =
      qCoefficient T₁ T₂ t u v₁ w u' u'' v₂ v₁ *
          xCoefficient T₁ T₂ t u v₁ w ^ 2 +
      qCoefficient T₁ T₂ t u v₂ w u' u'' v₁ v₂ *
          xCoefficient T₁ T₂ t u v₂ w ^ 2 +
      2 * sCoefficient T₁ T₂ t u u' u'' v₁ w v₂ *
          xCoefficient T₁ T₂ t u v₁ w *
            xCoefficient T₁ T₂ t u v₂ w := by
  have hq₁ :
      qCoefficient T₁ T₂ t u v₁ w u' u'' v₂ v₁ =
        sCoefficient T₁ T₂ t u u' u'' v₁ w v₂ := rfl
  have hq₂ :
      qCoefficient T₁ T₂ t u v₂ w u' u'' v₁ v₂ =
        sCoefficient T₁ T₂ t u u' u'' v₁ w v₂ := by
    symm
    unfold sCoefficient
    exact qCoefficient_column_reindex T₁ T₂ t u u' u''
      v₁ w v₂ hv₁w hwv₂.symm
  rw [hq₁, hq₂]
  ring

/-- Full sixteen-monomial expansion of one path--path square.  The four
diagonal monomials are the four doubly extended `q` occurrences; the two
same-row and two same-column cross terms are the corresponding `s` and `b`
occurrences; the remaining two cross-diagonal products carry `p` itself. -/
theorem pSquare_expansion
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (t₁ u t₂ : V₁) (v₁ w v₂ : V₂)
    (hv₁w : T₂.graph.Adj v₁ w) (hwv₂ : T₂.graph.Adj w v₂) :
    pCoefficient T₁ T₂ t₁ u t₂ v₁ w v₂ *
        (xCoefficient T₁ T₂ t₁ u v₁ w +
          xCoefficient T₁ T₂ t₁ u v₂ w +
          xCoefficient T₁ T₂ t₂ u v₁ w +
          xCoefficient T₁ T₂ t₂ u v₂ w) ^ 2 =
      qCoefficient T₁ T₂ t₁ u v₁ w t₂ t₁ v₂ v₁ *
          xCoefficient T₁ T₂ t₁ u v₁ w ^ 2 +
      qCoefficient T₁ T₂ t₁ u v₂ w t₂ t₁ v₁ v₂ *
          xCoefficient T₁ T₂ t₁ u v₂ w ^ 2 +
      qCoefficient T₁ T₂ t₂ u v₁ w t₁ t₂ v₂ v₁ *
          xCoefficient T₁ T₂ t₂ u v₁ w ^ 2 +
      qCoefficient T₁ T₂ t₂ u v₂ w t₁ t₂ v₁ v₂ *
          xCoefficient T₁ T₂ t₂ u v₂ w ^ 2 +
      2 * sCoefficient T₁ T₂ t₁ u t₂ t₁ v₁ w v₂ *
          xCoefficient T₁ T₂ t₁ u v₁ w *
            xCoefficient T₁ T₂ t₁ u v₂ w +
      2 * sCoefficient T₁ T₂ t₂ u t₁ t₂ v₁ w v₂ *
          xCoefficient T₁ T₂ t₂ u v₁ w *
            xCoefficient T₁ T₂ t₂ u v₂ w +
      2 * bCoefficient T₁ T₂ t₁ u t₂ v₁ w v₂ v₁ *
          xCoefficient T₁ T₂ t₁ u v₁ w *
            xCoefficient T₁ T₂ t₂ u v₁ w +
      2 * bCoefficient T₁ T₂ t₁ u t₂ v₂ w v₁ v₂ *
          xCoefficient T₁ T₂ t₁ u v₂ w *
            xCoefficient T₁ T₂ t₂ u v₂ w +
      2 * pCoefficient T₁ T₂ t₁ u t₂ v₁ w v₂ *
        (xCoefficient T₁ T₂ t₁ u v₁ w *
            xCoefficient T₁ T₂ t₂ u v₂ w +
          xCoefficient T₁ T₂ t₁ u v₂ w *
            xCoefficient T₁ T₂ t₂ u v₁ w) := by
  let p := pCoefficient T₁ T₂ t₁ u t₂ v₁ w v₂
  have hq₁₁ :
      qCoefficient T₁ T₂ t₁ u v₁ w t₂ t₁ v₂ v₁ = p := rfl
  have hq₁₂ :
      qCoefficient T₁ T₂ t₁ u v₂ w t₂ t₁ v₁ v₂ = p :=
    (pCoefficient_eq_q_column T₁ T₂ t₁ u t₂ v₁ w v₂
      hv₁w hwv₂.symm).symm
  have hq₂₁ :
      qCoefficient T₁ T₂ t₂ u v₁ w t₁ t₂ v₂ v₁ = p :=
    (pCoefficient_eq_q_row T₁ T₂ t₁ u t₂ v₁ w v₂).symm
  have hq₂₂ :
      qCoefficient T₁ T₂ t₂ u v₂ w t₁ t₂ v₁ v₂ = p :=
    (pCoefficient_eq_q_row_column T₁ T₂ t₁ u t₂ v₁ w v₂
      hv₁w hwv₂.symm).symm
  have hs₁ :
      sCoefficient T₁ T₂ t₁ u t₂ t₁ v₁ w v₂ = p :=
    (pCoefficient_eq_s T₁ T₂ t₁ u t₂ v₁ w v₂).symm
  have hs₂ :
      sCoefficient T₁ T₂ t₂ u t₁ t₂ v₁ w v₂ = p :=
    (pCoefficient_eq_s_row T₁ T₂ t₁ u t₂ v₁ w v₂).symm
  have hb₁ :
      bCoefficient T₁ T₂ t₁ u t₂ v₁ w v₂ v₁ = p :=
    (pCoefficient_eq_b T₁ T₂ t₁ u t₂ v₁ w v₂).symm
  have hb₂ :
      bCoefficient T₁ T₂ t₁ u t₂ v₂ w v₁ v₂ = p :=
    (pCoefficient_eq_b_column T₁ T₂ t₁ u t₂ v₁ w v₂
      hv₁w hwv₂.symm).symm
  rw [hq₁₁, hq₁₂, hq₂₁, hq₂₂, hs₁, hs₂, hb₁, hb₂]
  dsimp [p]
  ring

end QDFull
