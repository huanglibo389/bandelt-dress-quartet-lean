import QDFull.PointwiseInclusionExclusion
import QDFull.RawQuadraticAssembly

/-!
# Theorem 1: global tree inclusion--exclusion

This file lifts the samplewise identity to the uniform four-draw probability
space.  Every exchange of a source sum with a draw sum is a finite `Finset`
identity.  The four local covariance blocks used by Theorem 2 are therefore
identified exactly with one sixth of the tree quartet covariance.
-/

open scoped BigOperators

namespace QDFull

universe uX uV₁ uV₂

private theorem biSum_const_mul {α β : Type*}
    (A : Finset α) (B : Finset β) (c : ℝ) (f : α → β → ℝ) :
    (∑ a ∈ A, ∑ b ∈ B, c * f a b) =
      c * (∑ a ∈ A, ∑ b ∈ B, f a b) := by
  calc
    _ = ∑ a ∈ A, c * (∑ b ∈ B, f a b) := by
      apply Finset.sum_congr rfl
      intro a ha
      rw [Finset.mul_sum]
    _ = _ := by rw [Finset.mul_sum]

/-- A finite sum of split covariances is the average of the corresponding
pointwise source contributions. -/
private theorem sourceCovarianceSum_eq_average
    {X : Type uX} [Fintype X] [Nonempty X]
    {α β : Type*} (A : Finset α) (B : Finset β)
    (S₁ : α → PartialSplit X) (S₂ : β → PartialSplit X)
    (hS₁ : ∀ a ∈ A, IsPartialSplit (S₁ a))
    (hS₂ : ∀ b ∈ B, IsPartialSplit (S₂ b)) :
    (∑ a ∈ A, ∑ b ∈ B, splitQuartetCovariance (S₁ a) (S₂ b)) =
      fourDrawAverage (fun draw =>
        ∑ a ∈ A, ∑ b ∈ B, splitDrawContribution (S₁ a) (S₂ b) draw) := by
  classical
  calc
    _ = ∑ a ∈ A, ∑ b ∈ B,
          splitQuartetCovarianceEvent (S₁ a) (S₂ b) := by
        apply Finset.sum_congr rfl
        intro a ha
        apply Finset.sum_congr rfl
        intro b hb
        rw [splitQuartetCovarianceEvent_eq_splitQuartetCovariance
          (S₁ a) (S₂ b) (hS₁ a ha) (hS₂ b hb)]
    _ = ∑ a ∈ A, ∑ b ∈ B,
          fourDrawAverage (splitDrawContribution (S₁ a) (S₂ b)) := by
        apply Finset.sum_congr rfl
        intro a ha
        apply Finset.sum_congr rfl
        intro b hb
        exact splitQuartetCovarianceEvent_eq_average (S₁ a) (S₂ b)
    _ = _ := by
      symm
      rw [fourDrawAverage_sum]
      apply Finset.sum_congr rfl
      intro a ha
      rw [fourDrawAverage_sum]

section Blocks

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]
  [DecidableEq X] [DecidableEq V₁] [DecidableEq V₂]
  [LinearOrder V₁] [LinearOrder V₂]

theorem edgeEdgeCovarianceBlock_eq_average
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    edgeEdgeCovarianceBlock T₁ T₂ =
      (1 / 6 : ℝ) * fourDrawAverage (edgeEdgeDrawBlock T₁ T₂) := by
  letI : Nonempty X := T₁.taxon_nonempty
  classical
  unfold edgeEdgeCovarianceBlock edgeEdgeDrawBlock
  rw [biSum_const_mul]
  congr 1
  exact sourceCovarianceSum_eq_average
    T₁.canonicalEdgeFinset T₂.canonicalEdgeFinset
    (fun e => T₁.edgeSplit e.1 e.2) (fun e => T₂.edgeSplit e.1 e.2)
    (fun e he => (T₁.edgeSplit_isFullSplit
      ((T₁.mem_canonicalEdgeFinset e.1 e.2).1 he).1).1)
    (fun e he => (T₂.edgeSplit_isFullSplit
      ((T₂.mem_canonicalEdgeFinset e.1 e.2).1 he).1).1)

theorem edgePathCovarianceBlock_eq_average
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    edgePathCovarianceBlock T₁ T₂ =
      (1 / 6 : ℝ) * fourDrawAverage (edgePathDrawBlock T₁ T₂) := by
  letI : Nonempty X := T₁.taxon_nonempty
  classical
  unfold edgePathCovarianceBlock edgePathDrawBlock
  rw [biSum_const_mul]
  congr 1
  apply sourceCovarianceSum_eq_average
  · intro e he
    exact (T₁.edgeSplit_isFullSplit
      ((T₁.mem_canonicalEdgeFinset e.1 e.2).1 he).1).1
  · intro p hp
    have h := (T₂.mem_canonicalLengthTwoPathFinset
      p.1 p.2.1 p.2.2).1 hp
    exact T₂.sidePairSplit_isPartialSplit h.1 h.2.1 (ne_of_lt h.2.2)

theorem pathEdgeCovarianceBlock_eq_average
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    pathEdgeCovarianceBlock T₁ T₂ =
      (1 / 6 : ℝ) * fourDrawAverage (pathEdgeDrawBlock T₁ T₂) := by
  letI : Nonempty X := T₁.taxon_nonempty
  classical
  unfold pathEdgeCovarianceBlock pathEdgeDrawBlock
  rw [biSum_const_mul]
  congr 1
  apply sourceCovarianceSum_eq_average
  · intro p hp
    have h := (T₁.mem_canonicalLengthTwoPathFinset
      p.1 p.2.1 p.2.2).1 hp
    exact T₁.sidePairSplit_isPartialSplit h.1 h.2.1 (ne_of_lt h.2.2)
  · intro e he
    exact (T₂.edgeSplit_isFullSplit
      ((T₂.mem_canonicalEdgeFinset e.1 e.2).1 he).1).1

theorem pathPathCovarianceBlock_eq_average
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    pathPathCovarianceBlock T₁ T₂ =
      (1 / 6 : ℝ) * fourDrawAverage (pathPathDrawBlock T₁ T₂) := by
  letI : Nonempty X := T₁.taxon_nonempty
  classical
  unfold pathPathCovarianceBlock pathPathDrawBlock
  rw [biSum_const_mul]
  congr 1
  apply sourceCovarianceSum_eq_average
  · intro p hp
    have h := (T₁.mem_canonicalLengthTwoPathFinset
      p.1 p.2.1 p.2.2).1 hp
    exact T₁.sidePairSplit_isPartialSplit h.1 h.2.1 (ne_of_lt h.2.2)
  · intro p hp
    have h := (T₂.mem_canonicalLengthTwoPathFinset
      p.1 p.2.1 p.2.2).1 hp
    exact T₂.sidePairSplit_isPartialSplit h.1 h.2.1 (ne_of_lt h.2.2)

/-! ## Theorem 1 and the completed main identity -/

/-- Exact normalized version of Theorem 1, in the normalization already used
by the four covariance blocks of Theorem 2. -/
theorem inclusionExclusionCovariance_eq_treeQuartetCovariance_div_six
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    inclusionExclusionCovariance T₁ T₂ =
      (1 / 6 : ℝ) * treeQuartetCovariance T₁ T₂ := by
  have hsum :
      (∑ draw : Fin 4 → X, inclusionExclusionDrawContribution T₁ T₂ draw) =
        ∑ draw : Fin 4 → X, treeDrawContribution T₁ T₂ draw := by
    apply Finset.sum_congr rfl
    intro draw hdraw
    exact inclusionExclusionDrawContribution_eq_treeDrawContribution
      T₁ T₂ draw
  rw [inclusionExclusionCovariance,
    edgeEdgeCovarianceBlock_eq_average,
    edgePathCovarianceBlock_eq_average,
    pathEdgeCovarianceBlock_eq_average,
    pathPathCovarianceBlock_eq_average,
    treeQuartetCovariance_eq_average]
  unfold fourDrawAverage
  rw [← hsum]
  simp only [inclusionExclusionDrawContribution,
    Finset.sum_sub_distrib, Finset.sum_add_distrib]
  ring

/-- The paper's unnormalized Theorem 1. -/
theorem treeQuartetCovariance_eq_six_mul_inclusionExclusionCovariance
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    treeQuartetCovariance T₁ T₂ =
      6 * inclusionExclusionCovariance T₁ T₂ := by
  rw [inclusionExclusionCovariance_eq_treeQuartetCovariance_div_six]
  ring

/-- The completed main sum-of-squares theorem, now linked to the original
four-draw tree covariance rather than only to the intermediate source
inclusion--exclusion expression. -/
theorem sumOfSquaresRhs_eq_treeQuartetCovariance_div_six
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    sumOfSquaresRhs T₁ T₂ =
      (1 / 6 : ℝ) * treeQuartetCovariance T₁ T₂ := by
  rw [sumOfSquaresRhs_eq_inclusionExclusionCovariance,
    inclusionExclusionCovariance_eq_treeQuartetCovariance_div_six]

end Blocks

end QDFull
