import QDFull.BinaryPhylogeneticQuartetCounts
import QuartetV060.Sharpness
import QuartetDistance.GraphQuartet

/-!
# Bridge from the syntax model to graph-theoretic `XTree`s

The sharpness development represents an unrooted binary phylogenetic tree by
cutting at one distinguished leaf.  The paper itself uses finite labelled
graphs.  This file proves that the two representations give the same binary
phylogenetic object and the same quartet distance; no identification of the
two types is assumed.
-/

open SimpleGraph

namespace QDFull

namespace PhyloSyntaxBridge

open QuartetDistance
open QuartetDistance.GraphQuartet

noncomputable section

variable {X : Type} [Fintype X] [DecidableEq X]

noncomputable local instance finiteNeighborSet
    {V : Type*} [Fintype V] (G : SimpleGraph V) (v : V) :
    Fintype (G.neighborSet v) := Fintype.ofFinite _

abbrev Vertex (T : Tree.PhyloTree X) :=
  QuartetDistance.TreeAdequacy.PhyloTree.Vertex T

/-- The unique realization vertex carrying the taxon `x`. -/
def realizedLabel (T : Tree.PhyloTree X) (x : X) : Vertex T :=
  Classical.choose
    (QuartetDistance.TreeAdequacy.PhyloTree.exists_vertex_label T x)

@[simp] theorem label?_realizedLabel (T : Tree.PhyloTree X) (x : X) :
    QuartetDistance.TreeAdequacy.PhyloTree.label? T
        (realizedLabel T x) = some x :=
  Classical.choose_spec
    (QuartetDistance.TreeAdequacy.PhyloTree.exists_vertex_label T x)

theorem realizedLabel_eq_of_label?_eq (T : Tree.PhyloTree X)
    {x : X} {v : Vertex T}
    (hv : QuartetDistance.TreeAdequacy.PhyloTree.label? T v = some x) :
    realizedLabel T x = v :=
  QuartetDistance.GraphQuartet.PhyloTree.label_vertex_unique
    (α := X) T (a := x) (label?_realizedLabel T x) hv

theorem realizedLabel_injective (T : Tree.PhyloTree X) :
    Function.Injective (realizedLabel T) := by
  intro x y hxy
  have h := congrArg
    (QuartetDistance.TreeAdequacy.PhyloTree.label? T) hxy
  simpa using h

/-- The graph realization of a syntax tree, regarded as an `XTree`. -/
def realizedXTree (T : Tree.PhyloTree X) : XTree X (Vertex T) where
  graph := QuartetDistance.TreeAdequacy.PhyloTree.graph T
  isTree := QuartetDistance.TreeAdequacy.PhyloTree.graph_isTree T
  label := realizedLabel T
  lowDegree_labelled := by
    intro v hv
    have hdegree : Nat.card
        ((QuartetDistance.TreeAdequacy.PhyloTree.graph T).neighborSet v) =
        if (QuartetDistance.TreeAdequacy.PhyloTree.label? T v).isSome
          then 1 else 3 := by
      rw [Nat.card_eq_fintype_card,
        SimpleGraph.card_neighborSet_eq_degree]
      exact QuartetDistance.TreeAdequacy.PhyloTree.degree_profile T v
    cases hlabel : QuartetDistance.TreeAdequacy.PhyloTree.label? T v with
    | none =>
        have hthree : Nat.card
            ((QuartetDistance.TreeAdequacy.PhyloTree.graph T).neighborSet v) =
            3 := by simpa [hlabel] using hdegree
        have hnot : ¬ Nat.card
            ((QuartetDistance.TreeAdequacy.PhyloTree.graph T).neighborSet v) ≤
            2 := by omega
        exact False.elim (hnot hv)
    | some x =>
        refine ⟨x, ?_⟩
        exact realizedLabel_eq_of_label?_eq T hlabel

@[simp] theorem realizedXTree_graph (T : Tree.PhyloTree X) :
    (realizedXTree T).graph =
      QuartetDistance.TreeAdequacy.PhyloTree.graph T := rfl

@[simp] theorem realizedXTree_label (T : Tree.PhyloTree X) (x : X) :
    (realizedXTree T).label x = realizedLabel T x := rfl

theorem realizedXTree_isPhylogenetic (T : Tree.PhyloTree X) :
    (realizedXTree T).IsPhylogenetic := by
  refine ⟨realizedLabel_injective T, ?_, ?_⟩
  · intro x
    unfold XTree.IsLeaf
    have hdegree : Nat.card
        ((QuartetDistance.TreeAdequacy.PhyloTree.graph T).neighborSet
          (realizedLabel T x)) =
        if (QuartetDistance.TreeAdequacy.PhyloTree.label? T
          (realizedLabel T x)).isSome then 1 else 3 := by
      rw [Nat.card_eq_fintype_card,
        SimpleGraph.card_neighborSet_eq_degree]
      exact QuartetDistance.TreeAdequacy.PhyloTree.degree_profile T
        (realizedLabel T x)
    simpa using hdegree
  · intro v hv
    unfold XTree.IsLeaf at hv
    have hdegree : Nat.card
        ((QuartetDistance.TreeAdequacy.PhyloTree.graph T).neighborSet v) =
        if (QuartetDistance.TreeAdequacy.PhyloTree.label? T v).isSome
          then 1 else 3 := by
      rw [Nat.card_eq_fintype_card,
        SimpleGraph.card_neighborSet_eq_degree]
      exact QuartetDistance.TreeAdequacy.PhyloTree.degree_profile T v
    cases hlabel : QuartetDistance.TreeAdequacy.PhyloTree.label? T v with
    | none =>
        have hthree : Nat.card
            ((QuartetDistance.TreeAdequacy.PhyloTree.graph T).neighborSet v) =
            3 := by simpa [hlabel] using hdegree
        have hfalse : (1 : Nat) = 3 := hv.symm.trans hthree
        exact False.elim (by omega)
    | some x =>
        exact ⟨x, realizedLabel_eq_of_label?_eq T hlabel⟩

theorem realizedXTree_isBinaryPhylogenetic (T : Tree.PhyloTree X) :
    (realizedXTree T).IsBinaryPhylogenetic := by
  refine ⟨realizedXTree_isPhylogenetic T, ?_⟩
  intro v hv
  have hdegree : Nat.card
      ((QuartetDistance.TreeAdequacy.PhyloTree.graph T).neighborSet v) =
      if (QuartetDistance.TreeAdequacy.PhyloTree.label? T v).isSome
        then 1 else 3 := by
    rw [Nat.card_eq_fintype_card,
      SimpleGraph.card_neighborSet_eq_degree]
    exact QuartetDistance.TreeAdequacy.PhyloTree.degree_profile T v
  cases hlabel : QuartetDistance.TreeAdequacy.PhyloTree.label? T v with
  | none => simpa [hlabel] using hdegree
  | some x =>
      exfalso
      apply hv
      unfold XTree.IsLeaf
      simpa [hlabel] using hdegree

/-- The `XTree` taxon side of a rooted syntax edge is exactly its leaf
cluster. -/
theorem edgeSide_position_eq_cluster (T : Tree.PhyloTree X)
    (p : GraphQuartet.PhyloTree.EdgePosition T) :
    (realizedXTree T).edgeSide p.parent p.child = p.cluster := by
  classical
  ext x
  rw [XTree.mem_edgeSide]
  constructor
  · intro hx
    apply (p.exists_label_reachable_iff x).1
    exact ⟨realizedLabel T x, label?_realizedLabel T x, hx⟩
  · intro hx
    obtain ⟨v, hvlabel, hvreach⟩ :=
      (p.exists_label_reachable_iff x).2 hx
    have hv : v = realizedLabel T x :=
      (realizedLabel_eq_of_label?_eq T hvlabel).symm
    simpa [hv] using hvreach

theorem edgeSide_position_reverse_eq_compl (T : Tree.PhyloTree X)
    (p : GraphQuartet.PhyloTree.EdgePosition T) :
    (realizedXTree T).edgeSide p.child p.parent = p.clusterᶜ := by
  letI : Nonempty X := ⟨T.root⟩
  rw [(realizedXTree T).edgeSide_reverse_eq_compl
    p.adj_parent_child, edgeSide_position_eq_cluster T p]
  apply Finset.ext
  intro x
  simp

/-- A pair of taxon sets is separated by an edge of the syntax realization
exactly when the corresponding unordered partial split is displayed by the
realized `XTree`.  Both orientations of the deleting edge are retained in the
proof. -/
theorem realized_displaysPartialSplit_iff_edgeSeparates
    (T : Tree.PhyloTree X) (A B : Finset X) :
    (realizedXTree T).DisplaysPartialSplit s(A, B) ↔
      EdgeSeparates
        (QuartetDistance.TreeAdequacy.PhyloTree.graph T)
        (QuartetDistance.TreeAdequacy.PhyloTree.label? T) A B := by
  classical
  letI : Nonempty X := ⟨T.root⟩
  rw [QuartetDistance.GraphQuartet.PhyloTree.edgeSeparates_iff_exists_position_cluster
    T A B]
  constructor
  · rintro ⟨u, v, huv, hdisplay⟩
    obtain ⟨p, hp | hp⟩ :=
      QuartetDistance.GraphQuartet.PhyloTree.exists_edgePosition_of_adj T huv
    · rcases hp with ⟨rfl, rfl⟩
      rw [XTree.edgeSplit, edgeSide_position_eq_cluster,
        edgeSide_position_reverse_eq_compl,
        displays_comm_representative] at hdisplay
      refine ⟨p, ?_⟩
      simp only [Finset.subset_iff, Finset.mem_compl] at hdisplay
      rcases hdisplay with h | h
      · exact Or.inl h
      · exact Or.inr ⟨h.2, h.1⟩
    · rcases hp with ⟨rfl, rfl⟩
      rw [XTree.edgeSplit, edgeSide_position_eq_cluster,
        edgeSide_position_reverse_eq_compl,
        displays_comm_representative] at hdisplay
      refine ⟨p, ?_⟩
      simp only [Finset.subset_iff, Finset.mem_compl] at hdisplay
      rcases hdisplay with h | h
      · exact Or.inr ⟨h.2, h.1⟩
      · exact Or.inl h
  · rintro ⟨p, hp | hp⟩
    · refine ⟨p.parent, p.child, p.adj_parent_child, ?_⟩
      rw [XTree.edgeSplit, edgeSide_position_eq_cluster,
        edgeSide_position_reverse_eq_compl,
        displays_comm_representative]
      simpa only [Finset.subset_iff, Finset.mem_compl] using Or.inl hp
    · refine ⟨p.parent, p.child, p.adj_parent_child, ?_⟩
      rw [XTree.edgeSplit, edgeSide_position_eq_cluster,
        edgeSide_position_reverse_eq_compl,
        displays_comm_representative]
      simp only [Finset.subset_iff, Finset.mem_compl]
      exact Or.inr ⟨hp.2, hp.1⟩

/-- Convert the two sides of a well-formed circular quartet split to the
paper's unordered `Sym2` representation. -/
noncomputable def partialSplitOfQuartetSplit
    (s : Circular.QuartetSplit X) : PartialSplit X := by
  classical
  if h : s.Nonempty then
    let A := h.choose
    exact s(A, s.biUnion id \ A)
  else
    exact s(∅, ∅)

-- A concrete two-side form avoids any dependence on the chosen side.
theorem partialSplitOfQuartetSplit_pair (A B : Finset X)
    (hdisj : Disjoint A B) :
    partialSplitOfQuartetSplit ({A, B} : Circular.QuartetSplit X) = s(A, B) := by
  classical
  simp only [partialSplitOfQuartetSplit]
  split_ifs with h
  · have hC : h.choose = A ∨ h.choose = B := by
      simpa using h.choose_spec
    rcases hC with hCA | hCB
    · rw [hCA]
      have hUnion : ({A, B} : Finset (Finset X)).biUnion id = A ∪ B := by
        ext x
        simp
      have hrest : (A ∪ B) \ A = B := by
        ext x
        simp only [Finset.mem_sdiff, Finset.mem_union]
        constructor
        · rintro ⟨hxA | hxB, hxnotA⟩
          · exact False.elim (hxnotA hxA)
          · exact hxB
        · intro hxB
          exact ⟨Or.inr hxB,
            fun hxA => Finset.disjoint_left.mp hdisj hxA hxB⟩
      rw [hUnion, hrest]
    · rw [hCB]
      have hUnion : ({A, B} : Finset (Finset X)).biUnion id = A ∪ B := by
        ext x
        simp
      have hrest : (A ∪ B) \ B = A := by
        ext x
        simp only [Finset.mem_sdiff, Finset.mem_union]
        constructor
        · rintro ⟨hxA | hxB, hxnotB⟩
          · exact hxA
          · exact False.elim (hxnotB hxB)
        · intro hxA
          exact ⟨Or.inl hxA,
            fun hxB => Finset.disjoint_left.mp hdisj hxA hxB⟩
      rw [hUnion, hrest]
      exact Sym2.eq_swap
  · simp at h

/-- Every well-formed circular quartet split has two distinct represented
sides. -/
theorem isQuartetSplit_exists_distinct_sides
    {Q : Finset X} {S : Circular.QuartetSplit X}
    (hS : Circular.IsQuartetSplit Q S) :
    ∃ A ∈ S, ∃ B ∈ S, A ≠ B := by
  rcases hS with ⟨q, rfl, rfl⟩
  refine ⟨{q 0, q 2}, ?_, {q 1, q 3}, ?_, ?_⟩
  · simp [Circular.crossing, Circular.canonicalCrossing,
      Circular.mapSplit, Circular.splitOf, Circular.pair]
  · simp [Circular.crossing, Circular.canonicalCrossing,
      Circular.mapSplit, Circular.splitOf, Circular.pair]
  · intro h
    have hmem : q 0 ∈ ({q 1, q 3} : Finset X) := by
      rw [← h]
      simp
    simp [q.injective.eq_iff] at hmem

/-- On a well-formed quartet split, the conversion is the unordered pair of
either two distinct represented sides. -/
theorem partialSplitOfQuartetSplit_eq_of_sides
    {Q : Finset X} {S : Circular.QuartetSplit X}
    (hS : Circular.IsQuartetSplit Q S)
    {A B : Finset X} (hA : A ∈ S) (hB : B ∈ S) (hAB : A ≠ B) :
    partialSplitOfQuartetSplit S = s(A, B) := by
  rw [QuartetDistance.GraphQuartet.PhyloTree.isQuartetSplit_eq_pair_of_mem
    hS hA hB hAB]
  exact partialSplitOfQuartetSplit_pair A B
    (QuartetDistance.GraphQuartet.PhyloTree.isQuartetSplit_sides_disjoint
      hS hA hB hAB)

theorem partialSplitOfQuartetSplit_isQuartet
    {Q : Finset X} {S : Circular.QuartetSplit X}
    (hS : Circular.IsQuartetSplit Q S) :
    IsQuartet (partialSplitOfQuartetSplit S) := by
  classical
  obtain ⟨A, hA, B, hB, hAB⟩ :=
    isQuartetSplit_exists_distinct_sides hS
  have hEq := partialSplitOfQuartetSplit_eq_of_sides hS hA hB hAB
  have hAcard :=
    QuartetDistance.GraphQuartet.PhyloTree.isQuartetSplit_side_card hS hA
  have hBcard :=
    QuartetDistance.GraphQuartet.PhyloTree.isQuartetSplit_side_card hS hB
  have hdisj :=
    QuartetDistance.GraphQuartet.PhyloTree.isQuartetSplit_sides_disjoint
      hS hA hB hAB
  refine ⟨⟨A, B, hEq, ?_, ?_, hdisj⟩, A, B, hEq, hAcard, hBcard⟩
  · exact Finset.card_pos.mp (by omega)
  · exact Finset.card_pos.mp (by omega)

theorem partialSplitSupport_partialSplitOfQuartetSplit
    {Q : Finset X} {S : Circular.QuartetSplit X}
    (hS : Circular.IsQuartetSplit Q S) :
    partialSplitSupport (partialSplitOfQuartetSplit S) = Q := by
  classical
  obtain ⟨A, hA, B, hB, hAB⟩ :=
    isQuartetSplit_exists_distinct_sides hS
  rw [partialSplitOfQuartetSplit_eq_of_sides hS hA hB hAB,
    partialSplitSupport_mk]
  exact QuartetDistance.GraphQuartet.PhyloTree.isQuartetSplit_union_sides
    hS hA hB hAB

/-- The syntax graph and the realized `XTree` display exactly the same
well-formed quartet split. -/
theorem graphDisplaysSplit_iff_realizedDisplays
    (T : Tree.PhyloTree X) (Q : Finset X)
    (S : Circular.QuartetSplit X)
    (hS : Circular.IsQuartetSplit Q S) :
    GraphQuartet.PhyloTree.GraphDisplaysSplit T Q S ↔
      (realizedXTree T).DisplaysPartialSplit
        (partialSplitOfQuartetSplit S) := by
  classical
  obtain ⟨A, hA, B, hB, hAB⟩ :=
    isQuartetSplit_exists_distinct_sides hS
  have hEq := partialSplitOfQuartetSplit_eq_of_sides hS hA hB hAB
  constructor
  · rintro ⟨_, A', hA', B', hB', hA'B', hsep⟩
    have hEq' := partialSplitOfQuartetSplit_eq_of_sides
      hS hA' hB' hA'B'
    rw [hEq']
    exact (realized_displaysPartialSplit_iff_edgeSeparates T A' B').2 hsep
  · intro hdisplay
    refine ⟨hS, A, hA, B, hB, hAB, ?_⟩
    rw [hEq] at hdisplay
    exact (realized_displaysPartialSplit_iff_edgeSeparates T A B).1 hdisplay

/-- The paper-style full quartet carried by a syntax tree on `q`. -/
noncomputable def displayedPartialQuartet {n : ℕ}
    (T : Tree.PhyloTree (Fin n)) (q : Upper.Quartet n) :
    PartialSplit (Fin n) :=
  partialSplitOfQuartetSplit (T.displayedSplitOn q.1 q.2)

theorem displayedPartialQuartet_isQuartet {n : ℕ}
    (T : Tree.PhyloTree (Fin n)) (q : Upper.Quartet n) :
    IsQuartet (displayedPartialQuartet T q) :=
  partialSplitOfQuartetSplit_isQuartet
    (Upper.displayedSplitOn_isQuartetSplit T q)

theorem displayedPartialQuartet_support {n : ℕ}
    (T : Tree.PhyloTree (Fin n)) (q : Upper.Quartet n) :
    partialSplitSupport (displayedPartialQuartet T q) = q.1 :=
  partialSplitSupport_partialSplitOfQuartetSplit
    (Upper.displayedSplitOn_isQuartetSplit T q)

theorem realizedXTree_displays_displayedPartialQuartet {n : ℕ}
    (T : Tree.PhyloTree (Fin n)) (q : Upper.Quartet n) :
    (realizedXTree T).DisplaysPartialSplit
      (displayedPartialQuartet T q) := by
  apply (graphDisplaysSplit_iff_realizedDisplays T q.1
    (T.displayedSplitOn q.1 q.2)
    (Upper.displayedSplitOn_isQuartetSplit T q)).1
  exact (GraphQuartet.PhyloTree.graphDisplaysSplit_iff_eq_displayedSplitOn
    T q.1 q.2 _).2 rfl

/-- On well-formed quartet splits, conversion to the unordered `Sym2`
representation is injective. -/
theorem partialSplitOfQuartetSplit_injective_of_isQuartetSplit
    {Q : Finset X} {S₁ S₂ : Circular.QuartetSplit X}
    (hS₁ : Circular.IsQuartetSplit Q S₁)
    (hS₂ : Circular.IsQuartetSplit Q S₂)
    (hEq : partialSplitOfQuartetSplit S₁ =
      partialSplitOfQuartetSplit S₂) :
    S₁ = S₂ := by
  classical
  obtain ⟨A, hA, B, hB, hAB⟩ :=
    isQuartetSplit_exists_distinct_sides hS₁
  obtain ⟨C, hC, D, hD, hCD⟩ :=
    isQuartetSplit_exists_distinct_sides hS₂
  have hrep₁ :=
    QuartetDistance.GraphQuartet.PhyloTree.isQuartetSplit_eq_pair_of_mem
      hS₁ hA hB hAB
  have hrep₂ :=
    QuartetDistance.GraphQuartet.PhyloTree.isQuartetSplit_eq_pair_of_mem
      hS₂ hC hD hCD
  rw [partialSplitOfQuartetSplit_eq_of_sides hS₁ hA hB hAB,
    partialSplitOfQuartetSplit_eq_of_sides hS₂ hC hD hCD,
    Sym2.eq_iff] at hEq
  rcases hEq with ⟨hAC, hBD⟩ | ⟨hAD, hBC⟩
  · subst C
    subst D
    exact hrep₁.trans hrep₂.symm
  · subst D
    subst C
    rw [hrep₁, hrep₂, Finset.pair_comm]

/-- Exact supportwise bridge between the two quartet-distance predicates. -/
theorem treesDisagreeOnQuartetSupport_iff_displayedTopology_ne {n : ℕ}
    (T₁ T₂ : Tree.PhyloTree (Fin n)) (q : Upper.Quartet n) :
    TreesDisagreeOnQuartetSupport (realizedXTree T₁) (realizedXTree T₂) q.1 ↔
      Upper.displayedTopology T₁ q ≠ Upper.displayedTopology T₂ q := by
  classical
  let P₁ := displayedPartialQuartet T₁ q
  let P₂ := displayedPartialQuartet T₂ q
  have hP₁q : IsQuartet P₁ := displayedPartialQuartet_isQuartet T₁ q
  have hP₂q : IsQuartet P₂ := displayedPartialQuartet_isQuartet T₂ q
  have hT₁P₁ : (realizedXTree T₁).DisplaysPartialSplit P₁ :=
    realizedXTree_displays_displayedPartialQuartet T₁ q
  have hT₂P₂ : (realizedXTree T₂).DisplaysPartialSplit P₂ :=
    realizedXTree_displays_displayedPartialQuartet T₂ q
  have hP₁supp : partialSplitSupport P₁ = q.1 :=
    displayedPartialQuartet_support T₁ q
  have hP₂supp : partialSplitSupport P₂ = q.1 :=
    displayedPartialQuartet_support T₂ q
  constructor
  · rintro ⟨_, P, Q, hPq, hQq, hT₁P, hT₂Q,
      hPsupp, hQsupp, hPQ⟩ htop
    have hPP₁ : P = P₁ :=
      XTree.displayed_quartet_unique_on_support (realizedXTree T₁)
        hPq hP₁q hT₁P hT₁P₁ (hPsupp.trans hP₁supp.symm)
    have hQP₂ : Q = P₂ :=
      XTree.displayed_quartet_unique_on_support (realizedXTree T₂)
        hQq hP₂q hT₂Q hT₂P₂ (hQsupp.trans hP₂supp.symm)
    apply hPQ
    rw [hPP₁, hQP₂]
    unfold P₁ P₂ displayedPartialQuartet
    apply congrArg partialSplitOfQuartetSplit
    rw [← Upper.splitOfTopology_displayedTopology T₁ q,
      ← Upper.splitOfTopology_displayedTopology T₂ q, htop]
  · intro htop
    refine ⟨q.2, P₁, P₂, hP₁q, hP₂q, hT₁P₁, hT₂P₂,
      hP₁supp, hP₂supp, ?_⟩
    intro hP
    have hsplit : T₁.displayedSplitOn q.1 q.2 =
        T₂.displayedSplitOn q.1 q.2 := by
      apply partialSplitOfQuartetSplit_injective_of_isQuartetSplit
        (Upper.displayedSplitOn_isQuartetSplit T₁ q)
        (Upper.displayedSplitOn_isQuartetSplit T₂ q)
      simpa [P₁, P₂, displayedPartialQuartet] using hP
    apply htop
    apply Upper.splitOfTopology_injective q
    rw [Upper.splitOfTopology_displayedTopology T₁ q,
      Upper.splitOfTopology_displayedTopology T₂ q]
    exact hsplit

theorem quartetDisagreementSupports_realized_eq_image {n : ℕ}
    (T₁ T₂ : Tree.PhyloTree (Fin n)) :
    quartetDisagreementSupports (realizedXTree T₁) (realizedXTree T₂) =
      ((Finset.univ.filter fun q : Upper.Quartet n =>
          Upper.displayedTopology T₁ q ≠ Upper.displayedTopology T₂ q).image
        fun q => q.1) := by
  classical
  ext S
  rw [mem_quartetDisagreementSupports, Finset.mem_image]
  constructor
  · intro hS
    let q : Upper.Quartet n := ⟨S, hS.1⟩
    refine ⟨q, ?_, rfl⟩
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    exact (treesDisagreeOnQuartetSupport_iff_displayedTopology_ne
      T₁ T₂ q).1 hS
  · rintro ⟨q, hq, rfl⟩
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hq
    exact (treesDisagreeOnQuartetSupport_iff_displayedTopology_ne
      T₁ T₂ q).2 hq

/-- Exact equality of the paper's graph-theoretic quartet distance and the
syntax distance used by the finite sharpness development. -/
theorem quartetDistance_realized_eq_upper {n : ℕ}
    (T₁ T₂ : Tree.PhyloTree (Fin n)) :
    QDFull.quartetDistance (realizedXTree T₁) (realizedXTree T₂) =
      Upper.quartetDistance T₁ T₂ := by
  classical
  rw [QDFull.quartetDistance,
    quartetDisagreementSupports_realized_eq_image]
  unfold Upper.quartetDistance QuartetDistance.Counting.truthDistance
  rw [Finset.card_image_of_injective]
  exact Subtype.val_injective

/-- Maximum graph-theoretic quartet distance among the explicitly realized
syntax trees on `Fin n`. -/
noncomputable def realizedMaximumDistance (n : ℕ) : ℕ :=
  QuartetDistance.maxPairValue
    (fun T₁ T₂ : Tree.PhyloTree (Fin n) =>
      QDFull.quartetDistance (realizedXTree T₁) (realizedXTree T₂))

theorem realizedMaximumDistance_eq_sharpnessMaximum (n : ℕ) :
    realizedMaximumDistance n = QuartetV060.Sharpness.maximumDistance n := by
  unfold realizedMaximumDistance QuartetV060.Sharpness.maximumDistance
  congr 1
  funext T₁ T₂
  rw [quartetDistance_realized_eq_upper,
    QuartetV060.Sharpness.diffCount_eq_upper_quartetDistance]

/-- Normalized maximum expressed entirely with the paper's graph-theoretic
quartet distance on the realized binary phylogenetic trees. -/
noncomputable def realizedNormalizedMaximum (n : ℕ) : ℝ :=
  (realizedMaximumDistance n : ℝ) / (Nat.choose n 4 : ℝ)

theorem realizedNormalizedMaximum_eq_sharpness (n : ℕ) :
    realizedNormalizedMaximum n =
      QuartetV060.Sharpness.normalizedMaximum n := by
  rw [realizedNormalizedMaximum,
    QuartetV060.Sharpness.normalizedMaximum,
    realizedMaximumDistance_eq_sharpnessMaximum]

/-- The exact syntax-to-graph bridge transports the sharp asymptotic value
without changing either the numerator or the denominator. -/
theorem realizedNormalizedMaximum_tendsto_two_thirds :
    Filter.Tendsto realizedNormalizedMaximum Filter.atTop
      (nhds ((2 : ℝ) / 3)) := by
  apply QuartetV060.Sharpness.normalizedMaximum_tendsto_two_thirds.congr'
  filter_upwards with n
  exact (realizedNormalizedMaximum_eq_sharpness n).symm

end

end PhyloSyntaxBridge

end QDFull
