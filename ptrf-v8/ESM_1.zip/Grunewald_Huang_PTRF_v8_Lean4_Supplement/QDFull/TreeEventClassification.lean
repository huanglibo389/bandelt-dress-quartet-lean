import QDFull.EventAverages
import QDFull.TreeQuartetUniqueness

/-!
# Source events under the unique tree quartet

For a fixed ordered draw, a tree displays at most one induced partial
quartet.  Consequently, once the quartet displayed by each tree is fixed,
every edge or length-two-path source event is controlled solely by whether
that source displays the fixed quartet.  This is the event-level bridge
between the paper's four inclusion--exclusion blocks and its tree covariance.
-/

namespace QDFull

universe uX uV₁ uV₂

namespace XTree

/-- Display by a tree is closed under further display containment. -/
theorem DisplaysPartialSplit.trans
    {X : Type uX} {V : Type*} [Fintype X] [Fintype V]
    {T : XTree X V} {P Q : PartialSplit X}
    (hTP : T.DisplaysPartialSplit P) (hPQ : Displays P Q) :
    T.DisplaysPartialSplit Q := by
  rcases hTP with ⟨u, v, huv, hEP⟩
  exact ⟨u, v, huv, hEP.trans hPQ⟩

end XTree

/-- A same-quartet event for two source splits displayed by the two trees
implies the corresponding same-tree event. -/
theorem sameSplitQuartetEvent_imp_sameTreeQuartetEvent
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {S₁ S₂ : PartialSplit X} {draw : Fin 4 → X}
    (hS₁ : T₁.DisplaysPartialSplit S₁)
    (hS₂ : T₂.DisplaysPartialSplit S₂)
    (h : SameSplitQuartetEvent S₁ S₂ draw) :
    SameTreeQuartetEvent T₁ T₂ draw := by
  rcases h with ⟨P, hind, h₁, h₂⟩
  exact ⟨P, hind, hS₁.trans h₁, hS₂.trans h₂⟩

/-- A different-quartet event for two source splits displayed by the two
trees implies the corresponding different-tree event. -/
theorem differentSplitQuartetEvent_imp_differentTreeQuartetEvent
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {S₁ S₂ : PartialSplit X} {draw : Fin 4 → X}
    (hS₁ : T₁.DisplaysPartialSplit S₁)
    (hS₂ : T₂.DisplaysPartialSplit S₂)
    (h : DifferentSplitQuartetEvent S₁ S₂ draw) :
    DifferentTreeQuartetEvent T₁ T₂ draw := by
  rcases h with ⟨P, Q, hindP, hindQ, h₁, h₂, hne⟩
  exact ⟨P, Q, hindP, hindQ, hS₁.trans h₁, hS₂.trans h₂, hne⟩

/-- Under a fixed common displayed quartet, a source-pair same event is
equivalent to both sources displaying that quartet. -/
theorem sameSplitQuartetEvent_iff_of_sameTreeWitness
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {S₁ S₂ P : PartialSplit X} {draw : Fin 4 → X}
    (hS₁ : T₁.DisplaysPartialSplit S₁)
    (hS₂ : T₂.DisplaysPartialSplit S₂)
    (hindP : Induces draw P)
    (hT₁P : T₁.DisplaysPartialSplit P)
    (hT₂P : T₂.DisplaysPartialSplit P) :
    SameSplitQuartetEvent S₁ S₂ draw ↔
      Displays S₁ P ∧ Displays S₂ P := by
  classical
  constructor
  · rintro ⟨R, hindR, hS₁R, hS₂R⟩
    have hRP := T₁.induced_displayed_partialQuartet_unique draw
      hindR hindP (hS₁.trans hS₁R) hT₁P
    simpa only [hRP] using And.intro hS₁R hS₂R
  · rintro ⟨h₁, h₂⟩
    exact ⟨P, hindP, h₁, h₂⟩

/-- Under a fixed common displayed quartet, no source pair can contribute a
different-quartet event. -/
theorem not_differentSplitQuartetEvent_of_sameTreeWitness
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {S₁ S₂ P : PartialSplit X} {draw : Fin 4 → X}
    (hS₁ : T₁.DisplaysPartialSplit S₁)
    (hS₂ : T₂.DisplaysPartialSplit S₂)
    (hindP : Induces draw P)
    (hT₁P : T₁.DisplaysPartialSplit P)
    (hT₂P : T₂.DisplaysPartialSplit P) :
    ¬DifferentSplitQuartetEvent S₁ S₂ draw := by
  classical
  rintro ⟨R, Q, hindR, hindQ, hS₁R, hS₂Q, hRQ⟩
  have hRP := T₁.induced_displayed_partialQuartet_unique draw
    hindR hindP (hS₁.trans hS₁R) hT₁P
  have hQP := T₂.induced_displayed_partialQuartet_unique draw
    hindQ hindP (hS₂.trans hS₂Q) hT₂P
  exact hRQ (hRP.trans hQP.symm)

/-- Under two fixed distinct displayed quartets, a source-pair different
event is equivalent to the first source displaying the first quartet and the
second source displaying the second quartet. -/
theorem differentSplitQuartetEvent_iff_of_differentTreeWitness
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {S₁ S₂ P Q : PartialSplit X} {draw : Fin 4 → X}
    (hS₁ : T₁.DisplaysPartialSplit S₁)
    (hS₂ : T₂.DisplaysPartialSplit S₂)
    (hindP : Induces draw P) (hindQ : Induces draw Q)
    (hT₁P : T₁.DisplaysPartialSplit P)
    (hT₂Q : T₂.DisplaysPartialSplit Q) (hPQ : P ≠ Q) :
    DifferentSplitQuartetEvent S₁ S₂ draw ↔
      Displays S₁ P ∧ Displays S₂ Q := by
  classical
  constructor
  · rintro ⟨R, S, hindR, hindS, hS₁R, hS₂S, hRS⟩
    have hRP := T₁.induced_displayed_partialQuartet_unique draw
      hindR hindP (hS₁.trans hS₁R) hT₁P
    have hSQ := T₂.induced_displayed_partialQuartet_unique draw
      hindS hindQ (hS₂.trans hS₂S) hT₂Q
    simpa only [hRP, hSQ] using And.intro hS₁R hS₂S
  · rintro ⟨h₁, h₂⟩
    exact ⟨P, Q, hindP, hindQ, h₁, h₂, hPQ⟩

/-- Under two fixed distinct displayed quartets, no source pair can
contribute a same-quartet event. -/
theorem not_sameSplitQuartetEvent_of_differentTreeWitness
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {S₁ S₂ P Q : PartialSplit X} {draw : Fin 4 → X}
    (hS₁ : T₁.DisplaysPartialSplit S₁)
    (hS₂ : T₂.DisplaysPartialSplit S₂)
    (hindP : Induces draw P) (hindQ : Induces draw Q)
    (hT₁P : T₁.DisplaysPartialSplit P)
    (hT₂Q : T₂.DisplaysPartialSplit Q) (hPQ : P ≠ Q) :
    ¬SameSplitQuartetEvent S₁ S₂ draw := by
  classical
  rintro ⟨R, hindR, hS₁R, hS₂R⟩
  have hRP := T₁.induced_displayed_partialQuartet_unique draw
    hindR hindP (hS₁.trans hS₁R) hT₁P
  have hRQ := T₂.induced_displayed_partialQuartet_unique draw
    hindR hindQ (hS₂.trans hS₂R) hT₂Q
  exact hPQ (hRP.symm.trans hRQ)

/-- A common displayed quartet excludes a different-tree event. -/
theorem not_differentTreeQuartetEvent_of_sameWitness
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {P : PartialSplit X} {draw : Fin 4 → X}
    (hindP : Induces draw P)
    (hT₁P : T₁.DisplaysPartialSplit P)
    (hT₂P : T₂.DisplaysPartialSplit P) :
    ¬DifferentTreeQuartetEvent T₁ T₂ draw := by
  classical
  rintro ⟨R, Q, hindR, hindQ, hT₁R, hT₂Q, hRQ⟩
  have hRP := T₁.induced_displayed_partialQuartet_unique draw
    hindR hindP hT₁R hT₁P
  have hQP := T₂.induced_displayed_partialQuartet_unique draw
    hindQ hindP hT₂Q hT₂P
  exact hRQ (hRP.trans hQP.symm)

/-- Two distinct displayed quartets exclude a same-tree event. -/
theorem not_sameTreeQuartetEvent_of_differentWitness
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {P Q : PartialSplit X} {draw : Fin 4 → X}
    (hindP : Induces draw P) (hindQ : Induces draw Q)
    (hT₁P : T₁.DisplaysPartialSplit P)
    (hT₂Q : T₂.DisplaysPartialSplit Q) (hPQ : P ≠ Q) :
    ¬SameTreeQuartetEvent T₁ T₂ draw := by
  classical
  rintro ⟨R, hindR, hT₁R, hT₂R⟩
  have hRP := T₁.induced_displayed_partialQuartet_unique draw
    hindR hindP hT₁R hT₁P
  have hRQ := T₂.induced_displayed_partialQuartet_unique draw
    hindR hindQ hT₂R hT₂Q
  exact hPQ (hRP.symm.trans hRQ)

/-! ## Pointwise source contributions -/

/-- In the common-quartet case, a displayed source pair contributes the
product of its two display indicators. -/
theorem splitDrawContribution_eq_mul_of_sameTreeWitness
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {S₁ S₂ P : PartialSplit X} {draw : Fin 4 → X}
    (hS₁ : T₁.DisplaysPartialSplit S₁)
    (hS₂ : T₂.DisplaysPartialSplit S₂)
    (hindP : Induces draw P)
    (hT₁P : T₁.DisplaysPartialSplit P)
    (hT₂P : T₂.DisplaysPartialSplit P) :
    splitDrawContribution S₁ S₂ draw =
      propIndicator (Displays S₁ P) * propIndicator (Displays S₂ P) := by
  rw [splitDrawContribution,
    sameSplitQuartetEvent_iff_of_sameTreeWitness
      T₁ T₂ hS₁ hS₂ hindP hT₁P hT₂P,
    propIndicator_and,
    propIndicator_of_false
      (not_differentSplitQuartetEvent_of_sameTreeWitness
        T₁ T₂ hS₁ hS₂ hindP hT₁P hT₂P)]
  ring

/-- In the different-quartet case, a displayed source pair contributes
minus one half of the product of its display indicators. -/
theorem splitDrawContribution_eq_negHalf_mul_of_differentTreeWitness
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {S₁ S₂ P Q : PartialSplit X} {draw : Fin 4 → X}
    (hS₁ : T₁.DisplaysPartialSplit S₁)
    (hS₂ : T₂.DisplaysPartialSplit S₂)
    (hindP : Induces draw P) (hindQ : Induces draw Q)
    (hT₁P : T₁.DisplaysPartialSplit P)
    (hT₂Q : T₂.DisplaysPartialSplit Q) (hPQ : P ≠ Q) :
    splitDrawContribution S₁ S₂ draw =
      -(1 / 2 : ℝ) *
        (propIndicator (Displays S₁ P) * propIndicator (Displays S₂ Q)) := by
  rw [splitDrawContribution,
    propIndicator_of_false
      (not_sameSplitQuartetEvent_of_differentTreeWitness
        T₁ T₂ hS₁ hS₂ hindP hindQ hT₁P hT₂Q hPQ),
    differentSplitQuartetEvent_iff_of_differentTreeWitness
      T₁ T₂ hS₁ hS₂ hindP hindQ hT₁P hT₂Q hPQ,
    propIndicator_and]
  ring

/-- If neither tree event occurs, every source pair displayed by the two
trees has zero pointwise contribution. -/
theorem splitDrawContribution_eq_zero_of_noTreeEvent
    {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
    [Fintype X] [Fintype V₁] [Fintype V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {S₁ S₂ : PartialSplit X} {draw : Fin 4 → X}
    (hS₁ : T₁.DisplaysPartialSplit S₁)
    (hS₂ : T₂.DisplaysPartialSplit S₂)
    (hSame : ¬SameTreeQuartetEvent T₁ T₂ draw)
    (hDiff : ¬DifferentTreeQuartetEvent T₁ T₂ draw) :
    splitDrawContribution S₁ S₂ draw = 0 := by
  have hs : ¬SameSplitQuartetEvent S₁ S₂ draw := fun h =>
    hSame (sameSplitQuartetEvent_imp_sameTreeQuartetEvent T₁ T₂ hS₁ hS₂ h)
  have hd : ¬DifferentSplitQuartetEvent S₁ S₂ draw := fun h =>
    hDiff (differentSplitQuartetEvent_imp_differentTreeQuartetEvent
      T₁ T₂ hS₁ hS₂ h)
  simp [splitDrawContribution, propIndicator, hs, hd]

end QDFull
