import QDFull.InclusionExclusionCounting

/-!
# Pointwise inclusion--exclusion coefficients for Theorem 1

For one partial quartet induced by a four-draw sample, the signed number of
tree occurrences is the number of displaying edges minus the number of
displaying canonical length-two paths.  The path-counting theorem proves that
this integer is exactly the indicator that the tree displays the quartet.

This is the precise coefficient statement behind the paper's
`k - (k - 1) = 1` argument.  It is kept separate from the later uniqueness
argument saying that one tree cannot display two different pairings of the
same four-draw sample.
-/

namespace QDFull

universe uX uV uV₁ uV₂

namespace XTree

variable {X : Type uX} {V : Type uV}
  [Fintype X] [Fintype V] [DecidableEq X] [DecidableEq V]

/-- The signed occurrence multiplicity of `P` in one tree: one copy for every
displaying edge and minus one copy for every displaying length-two path. -/
noncomputable def signedDisplayMultiplicity [LinearOrder V]
    (T : XTree X V) (P : PartialSplit X) : ℤ :=
  ((T.displayingEdgeFinset P).card : ℤ) -
    ((T.displayingLengthTwoPathFinset P).card : ℤ)

/-- Integer-valued display indicator, packaged noncomputably so later theorem
statements do not depend on a particular `Decidable` implementation. -/
noncomputable def displayIndicator
    (T : XTree X V) (P : PartialSplit X) : ℤ := by
  classical
  exact if T.DisplaysPartialSplit P then 1 else 0

/-- The exact `k - (k - 1) = 1` identity for any induced partial quartet
displayed by the tree. -/
theorem signedDisplayMultiplicity_eq_one_of_induces [LinearOrder V]
    (T : XTree X V) {draw : Fin 4 → X} {P : PartialSplit X}
    (hind : Induces draw P) (hdisplay : T.DisplaysPartialSplit P) :
    T.signedDisplayMultiplicity P = 1 := by
  classical
  letI : DecidableEq X := Classical.decEq X
  rcases hind with ⟨hP, π, rfl⟩
  have hcount := T.card_displayingLengthTwoPathFinset_add_one_eq_edges
    (draw (π 0)) (draw (π 1)) (draw (π 2)) (draw (π 3)) hP hdisplay
  unfold signedDisplayMultiplicity
  omega

/-- If a partial split is not displayed by the tree, no canonical edge
occurrence can display it. -/
theorem displayingEdgeFinset_eq_empty_of_not_displays [LinearOrder V]
    (T : XTree X V) (P : PartialSplit X)
    (hnot : ¬ T.DisplaysPartialSplit P) :
    T.displayingEdgeFinset P = ∅ := by
  classical
  ext e
  rcases e with ⟨u, v⟩
  constructor
  · intro huv
    have h := (T.mem_displayingEdgeFinset P u v).1 huv
    exact False.elim (hnot ⟨u, v, h.1, h.2.2⟩)
  · simp

/-- For a genuine partial split, a displaying side-pair would force each of
its constituent edges to display the same split.  Hence no side-pair
occurrence exists when the tree does not display the split. -/
theorem displayingLengthTwoPathFinset_eq_empty_of_not_displays
    [LinearOrder V] (T : XTree X V) (P : PartialSplit X)
    (hP : IsPartialSplit P) (hnot : ¬ T.DisplaysPartialSplit P) :
    T.displayingLengthTwoPathFinset P = ∅ := by
  classical
  ext p
  rcases p with ⟨u, v, w⟩
  constructor
  · intro hp
    have h := (T.mem_displayingLengthTwoPathFinset P u v w).1 hp
    have hboth := (T.displays_sidePairSplit_iff_displays_both_edges
      h.1 h.2.1 (ne_of_lt h.2.2.1) hP).1 h.2.2.2
    exact False.elim (hnot ⟨u, v, h.1, hboth.1⟩)
  · simp

/-- The signed multiplicity vanishes for an induced partial quartet not
displayed by the tree. -/
theorem signedDisplayMultiplicity_eq_zero_of_induces_not_displays
    [LinearOrder V] (T : XTree X V)
    {draw : Fin 4 → X} {P : PartialSplit X}
    (hind : Induces draw P) (hnot : ¬ T.DisplaysPartialSplit P) :
    T.signedDisplayMultiplicity P = 0 := by
  rw [signedDisplayMultiplicity,
    T.displayingEdgeFinset_eq_empty_of_not_displays P hnot,
    T.displayingLengthTwoPathFinset_eq_empty_of_not_displays
      P hind.1 hnot]
  simp

/-- On the support of one four-draw sample, signed occurrence multiplicity is
exactly the Boolean display indicator. -/
theorem signedDisplayMultiplicity_eq_indicator [LinearOrder V]
    (T : XTree X V) {draw : Fin 4 → X} {P : PartialSplit X}
    (hind : Induces draw P) :
    T.signedDisplayMultiplicity P = T.displayIndicator P := by
  classical
  by_cases hdisplay : T.DisplaysPartialSplit P
  · simp [displayIndicator, hdisplay,
      T.signedDisplayMultiplicity_eq_one_of_induces hind hdisplay]
  · simp [displayIndicator, hdisplay,
      T.signedDisplayMultiplicity_eq_zero_of_induces_not_displays
        hind hdisplay]

end XTree

section TwoTrees

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]
  [DecidableEq X] [DecidableEq V₁] [DecidableEq V₂]

/-- The literal four-term coefficient in the paper for one ordered pair of
induced partial quartets.  Cardinalities are cast to integers so that the two
subtractions are genuine algebraic inclusion--exclusion. -/
noncomputable def fourBlockOccurrenceCoefficient
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (P Q : PartialSplit X) : ℤ :=
  let e₁ : ℤ := (T₁.displayingEdgeFinset P).card
  let p₁ : ℤ := (T₁.displayingLengthTwoPathFinset P).card
  let e₂ : ℤ := (T₂.displayingEdgeFinset Q).card
  let p₂ : ℤ := (T₂.displayingLengthTwoPathFinset Q).card
  e₁ * e₂ - e₁ * p₂ - p₁ * e₂ + p₁ * p₂

/-- The four edge/path blocks factor into the signed multiplicity in each
tree coordinate. -/
theorem fourBlockOccurrenceCoefficient_eq_mul
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (P Q : PartialSplit X) :
    fourBlockOccurrenceCoefficient T₁ T₂ P Q =
      T₁.signedDisplayMultiplicity P *
        T₂.signedDisplayMultiplicity Q := by
  unfold fourBlockOccurrenceCoefficient XTree.signedDisplayMultiplicity
  ring

/-- Exact pointwise settlement of the paper's four occurrence classes.  For
two partial quartets induced by the same ordered draw, their four-block
coefficient is the product of the two tree-display indicators. -/
theorem fourBlockOccurrenceCoefficient_eq_indicators
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {draw : Fin 4 → X} {P Q : PartialSplit X}
    (hindP : Induces draw P) (hindQ : Induces draw Q) :
    fourBlockOccurrenceCoefficient T₁ T₂ P Q =
      T₁.displayIndicator P * T₂.displayIndicator Q := by
  rw [fourBlockOccurrenceCoefficient_eq_mul,
    T₁.signedDisplayMultiplicity_eq_indicator hindP,
    T₂.signedDisplayMultiplicity_eq_indicator hindQ]

/-- In particular, two displayed induced partial quartets receive coefficient
one, exactly as in the paper's arithmetic line. -/
theorem fourBlockOccurrenceCoefficient_eq_one
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    {draw : Fin 4 → X} {P Q : PartialSplit X}
    (hindP : Induces draw P) (hindQ : Induces draw Q)
    (hdisplayP : T₁.DisplaysPartialSplit P)
    (hdisplayQ : T₂.DisplaysPartialSplit Q) :
    fourBlockOccurrenceCoefficient T₁ T₂ P Q = 1 := by
  classical
  rw [fourBlockOccurrenceCoefficient_eq_indicators T₁ T₂ hindP hindQ]
  simp [XTree.displayIndicator, hdisplayP, hdisplayQ]

end TwoTrees

end QDFull
