import QDFull.SquareExpansion

/-!
# Global assembly of the four square families

This file formalizes the finite-sum reindexing suppressed by the final
paragraph of the proof of Theorem 2.  It keeps the base part `I`, the new
part `I' \ I`, and both path-reversal orientations separate until every
coefficient occurrence has been settled.
-/

open scoped BigOperators

namespace QDFull

universe uX uV₁ uV₂

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]

/-- A diagonal `q X²` block with independently specified row and column
branch-pair index families. -/
noncomputable def qDiagonalBlock
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (J₁ : V₁ × V₁ → Finset (V₁ × V₁))
    (J₂ : V₂ × V₂ → Finset (V₂ × V₂)) : ℝ :=
  ∑ e₁ ∈ T₁.directedEdgeFinset,
    ∑ e₂ ∈ T₂.directedEdgeFinset,
      ∑ z₁ ∈ J₁ e₁,
        ∑ z₂ ∈ J₂ e₂,
          qCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2
              z₁.1 z₁.2 z₂.1 z₂.2 *
            xCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2 ^ 2

/-- Exchange the independent column-edge and row-pair sums.  This is the
order in which the two `I' = I \sqcup (I' \ I)` decompositions are applied. -/
theorem qDiagonalBlock_reindex
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (J₁ : V₁ × V₁ → Finset (V₁ × V₁))
    (J₂ : V₂ × V₂ → Finset (V₂ × V₂)) :
    qDiagonalBlock T₁ T₂ J₁ J₂ =
      ∑ e₁ ∈ T₁.directedEdgeFinset,
        ∑ z₁ ∈ J₁ e₁,
          ∑ e₂ ∈ T₂.directedEdgeFinset,
            ∑ z₂ ∈ J₂ e₂,
              qCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2
                  z₁.1 z₁.2 z₂.1 z₂.2 *
                xCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2 ^ 2 := by
  classical
  unfold qDiagonalBlock
  apply Finset.sum_congr rfl
  intro e₁ he₁
  exact Finset.sum_comm

/-- The `s XX` block with a specified row branch-pair family and one
representative from each column-path reversal orbit. -/
noncomputable def sMixedBlock
    [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (J₁ : V₁ × V₁ → Finset (V₁ × V₁)) : ℝ :=
  ∑ e₁ ∈ T₁.directedEdgeFinset,
    ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
      ∑ z₁ ∈ J₁ e₁,
        sCoefficient T₁ T₂ e₁.1 e₁.2 z₁.1 z₁.2
            p₂.1 p₂.2.1 p₂.2.2 *
          xCoefficient T₁ T₂ e₁.1 e₁.2 p₂.1 p₂.2.1 *
          xCoefficient T₁ T₂ e₁.1 e₁.2 p₂.2.2 p₂.2.1

/-- Exchange the independent path and row-pair sums. -/
theorem sMixedBlock_reindex
    [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (J₁ : V₁ × V₁ → Finset (V₁ × V₁)) :
    sMixedBlock T₁ T₂ J₁ =
      ∑ e₁ ∈ T₁.directedEdgeFinset,
        ∑ z₁ ∈ J₁ e₁,
          ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
            sCoefficient T₁ T₂ e₁.1 e₁.2 z₁.1 z₁.2
                p₂.1 p₂.2.1 p₂.2.2 *
              xCoefficient T₁ T₂ e₁.1 e₁.2 p₂.1 p₂.2.1 *
              xCoefficient T₁ T₂ e₁.1 e₁.2 p₂.2.2 p₂.2.1 := by
  classical
  unfold sMixedBlock
  apply Finset.sum_congr rfl
  intro e₁ he₁
  exact Finset.sum_comm

/-- The `b XX` block with one representative from each row-path reversal
orbit and a specified column branch-pair family. -/
noncomputable def bMixedBlock
    [LinearOrder V₁]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (J₂ : V₂ × V₂ → Finset (V₂ × V₂)) : ℝ :=
  ∑ p₁ ∈ T₁.canonicalLengthTwoPathFinset,
    ∑ e₂ ∈ T₂.directedEdgeFinset,
      ∑ z₂ ∈ J₂ e₂,
        bCoefficient T₁ T₂ p₁.1 p₁.2.1 p₁.2.2
            e₂.1 e₂.2 z₂.1 z₂.2 *
          xCoefficient T₁ T₂ p₁.1 p₁.2.1 e₂.1 e₂.2 *
          xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 e₂.1 e₂.2

/-- The cross-diagonal `p` block. -/
noncomputable def pMixedBlock
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  ∑ p₁ ∈ T₁.canonicalLengthTwoPathFinset,
    ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
      pCoefficient T₁ T₂ p₁.1 p₁.2.1 p₁.2.2
          p₂.1 p₂.2.1 p₂.2.2 *
        (xCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.1 p₂.2.1 *
            xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.2.2 p₂.2.1 +
          xCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.2.2 p₂.2.1 *
            xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.1 p₂.2.1)

private noncomputable def baseFamily₁
    (T : XTree X V₁) (e : V₁ × V₁) : Finset (V₁ × V₁) :=
  T.indexIFinset e.1 e.2

private noncomputable def primeFamily₁
    (T : XTree X V₁) (e : V₁ × V₁) : Finset (V₁ × V₁) :=
  T.indexIPrimeFinset e.1 e.2

private noncomputable def extraFamily₁
    (T : XTree X V₁) (e : V₁ × V₁) : Finset (V₁ × V₁) :=
  T.indexIExtraFinset e.1 e.2

private noncomputable def baseFamily₂
    (T : XTree X V₂) (e : V₂ × V₂) : Finset (V₂ × V₂) :=
  T.indexIFinset e.1 e.2

private noncomputable def primeFamily₂
    (T : XTree X V₂) (e : V₂ × V₂) : Finset (V₂ × V₂) :=
  T.indexIPrimeFinset e.1 e.2

private noncomputable def extraFamily₂
    (T : XTree X V₂) (e : V₂ × V₂) : Finset (V₂ × V₂) :=
  T.indexIExtraFinset e.1 e.2

/-- Exact four-cell decomposition of the diagonal raw block under
`I' = I \sqcup (I' \ I)` in both coordinates. -/
theorem qDiagonalBlock_prime_decomposition
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    qDiagonalBlock T₁ T₂ (primeFamily₁ T₁) (primeFamily₂ T₂) =
      qDiagonalBlock T₁ T₂ (baseFamily₁ T₁) (baseFamily₂ T₂) +
      qDiagonalBlock T₁ T₂ (extraFamily₁ T₁) (baseFamily₂ T₂) +
      qDiagonalBlock T₁ T₂ (baseFamily₁ T₁) (extraFamily₂ T₂) +
      qDiagonalBlock T₁ T₂ (extraFamily₁ T₁) (extraFamily₂ T₂) := by
  classical
  let F := fun (e₁ : V₁ × V₁) (z₁ : V₁ × V₁)
      (e₂ : V₂ × V₂) (z₂ : V₂ × V₂) =>
    qCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2
        z₁.1 z₁.2 z₂.1 z₂.2 *
      xCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2 ^ 2
  simp only [qDiagonalBlock_reindex]
  unfold primeFamily₁ primeFamily₂ baseFamily₁ baseFamily₂
    extraFamily₁ extraFamily₂
  change (∑ e₁ ∈ T₁.directedEdgeFinset,
      ∑ z₁ ∈ T₁.indexIPrimeFinset e₁.1 e₁.2,
        ∑ e₂ ∈ T₂.directedEdgeFinset,
          ∑ z₂ ∈ T₂.indexIPrimeFinset e₂.1 e₂.2,
            F e₁ z₁ e₂ z₂) = _
  calc
    _ = ∑ e₁ ∈ T₁.directedEdgeFinset,
          ∑ z₁ ∈ T₁.indexIPrimeFinset e₁.1 e₁.2,
            ((∑ e₂ ∈ T₂.directedEdgeFinset,
                ∑ z₂ ∈ T₂.indexIFinset e₂.1 e₂.2,
                  F e₁ z₁ e₂ z₂) +
              ∑ e₂ ∈ T₂.directedEdgeFinset,
                ∑ z₂ ∈ T₂.indexIExtraFinset e₂.1 e₂.2,
                  F e₁ z₁ e₂ z₂) := by
      apply Finset.sum_congr rfl
      intro e₁ he₁
      apply Finset.sum_congr rfl
      intro z₁ hz₁
      exact T₂.sum_directedEdge_indexIPrime_eq_indexI_add_extra
        (fun e₂ z₂ => F e₁ z₁ e₂ z₂)
    _ = _ := by
      simp_rw [Finset.sum_add_distrib]
      rw [T₁.sum_directedEdge_indexIPrime_eq_indexI_add_extra]
      rw [T₁.sum_directedEdge_indexIPrime_eq_indexI_add_extra]
      simp only [F]
      ac_rfl

/-- The row-indexed mixed block splits into its retained and new source
occurrences. -/
theorem sMixedBlock_prime_decomposition
    [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    sMixedBlock T₁ T₂ (primeFamily₁ T₁) =
      sMixedBlock T₁ T₂ (baseFamily₁ T₁) +
        sMixedBlock T₁ T₂ (extraFamily₁ T₁) := by
  classical
  simp only [sMixedBlock_reindex]
  unfold primeFamily₁ baseFamily₁ extraFamily₁
  exact T₁.sum_directedEdge_indexIPrime_eq_indexI_add_extra
    (fun e₁ z₁ =>
      ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
        sCoefficient T₁ T₂ e₁.1 e₁.2 z₁.1 z₁.2
            p₂.1 p₂.2.1 p₂.2.2 *
          xCoefficient T₁ T₂ e₁.1 e₁.2 p₂.1 p₂.2.1 *
          xCoefficient T₁ T₂ e₁.1 e₁.2 p₂.2.2 p₂.2.1)

/-- The column-indexed mixed block splits into its retained and new source
occurrences. -/
theorem bMixedBlock_prime_decomposition
    [LinearOrder V₁]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    bMixedBlock T₁ T₂ (primeFamily₂ T₂) =
      bMixedBlock T₁ T₂ (baseFamily₂ T₂) +
        bMixedBlock T₁ T₂ (extraFamily₂ T₂) := by
  classical
  unfold bMixedBlock primeFamily₂ baseFamily₂ extraFamily₂
  calc
    _ = ∑ p₁ ∈ T₁.canonicalLengthTwoPathFinset,
          ((∑ e₂ ∈ T₂.directedEdgeFinset,
              ∑ z₂ ∈ T₂.indexIFinset e₂.1 e₂.2,
                bCoefficient T₁ T₂ p₁.1 p₁.2.1 p₁.2.2
                    e₂.1 e₂.2 z₂.1 z₂.2 *
                  xCoefficient T₁ T₂ p₁.1 p₁.2.1 e₂.1 e₂.2 *
                  xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 e₂.1 e₂.2) +
            ∑ e₂ ∈ T₂.directedEdgeFinset,
              ∑ z₂ ∈ T₂.indexIExtraFinset e₂.1 e₂.2,
                bCoefficient T₁ T₂ p₁.1 p₁.2.1 p₁.2.2
                    e₂.1 e₂.2 z₂.1 z₂.2 *
                  xCoefficient T₁ T₂ p₁.1 p₁.2.1 e₂.1 e₂.2 *
                  xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 e₂.1 e₂.2) := by
      apply Finset.sum_congr rfl
      intro p₁ hp₁
      exact T₂.sum_directedEdge_indexIPrime_eq_indexI_add_extra
        (fun e₂ z₂ =>
          bCoefficient T₁ T₂ p₁.1 p₁.2.1 p₁.2.2
              e₂.1 e₂.2 z₂.1 z₂.2 *
            xCoefficient T₁ T₂ p₁.1 p₁.2.1 e₂.1 e₂.2 *
            xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 e₂.1 e₂.2)
    _ = _ := Finset.sum_add_distrib

/-- The row-extra diagonal block is exactly the pair of diagonal monomials
attached to the two orientations of every canonical row path. -/
theorem qRowExtra_eq_b_diagonal_orientations
    [LinearOrder V₁]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    qDiagonalBlock T₁ T₂ (extraFamily₁ T₁) (baseFamily₂ T₂) =
      ∑ p₁ ∈ T₁.canonicalLengthTwoPathFinset,
        ∑ e₂ ∈ T₂.directedEdgeFinset,
          ∑ z₂ ∈ T₂.indexIFinset e₂.1 e₂.2,
            (qCoefficient T₁ T₂ p₁.1 p₁.2.1 e₂.1 e₂.2
                  p₁.2.2 p₁.1 z₂.1 z₂.2 *
                xCoefficient T₁ T₂ p₁.1 p₁.2.1 e₂.1 e₂.2 ^ 2 +
              qCoefficient T₁ T₂ p₁.2.2 p₁.2.1 e₂.1 e₂.2
                  p₁.1 p₁.2.2 z₂.1 z₂.2 *
                xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 e₂.1 e₂.2 ^ 2) := by
  classical
  rw [qDiagonalBlock_reindex]
  unfold extraFamily₁ baseFamily₂
  rw [T₁.sum_directedEdge_indexIExtra_eq_sum_canonical_orientations]
  simp only [Finset.sum_add_distrib]

/-- The column-extra diagonal block is exactly the pair of diagonal
monomials attached to the two orientations of every canonical column path. -/
theorem qColumnExtra_eq_s_diagonal_orientations
    [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    qDiagonalBlock T₁ T₂ (baseFamily₁ T₁) (extraFamily₂ T₂) =
      ∑ e₁ ∈ T₁.directedEdgeFinset,
        ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
          ∑ z₁ ∈ T₁.indexIFinset e₁.1 e₁.2,
            (qCoefficient T₁ T₂ e₁.1 e₁.2 p₂.1 p₂.2.1
                  z₁.1 z₁.2 p₂.2.2 p₂.1 *
                xCoefficient T₁ T₂ e₁.1 e₁.2 p₂.1 p₂.2.1 ^ 2 +
              qCoefficient T₁ T₂ e₁.1 e₁.2 p₂.2.2 p₂.2.1
                  z₁.1 z₁.2 p₂.1 p₂.2.2 *
                xCoefficient T₁ T₂ e₁.1 e₁.2 p₂.2.2 p₂.2.1 ^ 2) := by
  classical
  rw [qDiagonalBlock_reindex]
  unfold baseFamily₁ extraFamily₂
  apply Finset.sum_congr rfl
  intro e₁ he₁
  calc
    _ = ∑ z₁ ∈ T₁.indexIFinset e₁.1 e₁.2,
          ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
            (qCoefficient T₁ T₂ e₁.1 e₁.2 p₂.1 p₂.2.1
                  z₁.1 z₁.2 p₂.2.2 p₂.1 *
                xCoefficient T₁ T₂ e₁.1 e₁.2 p₂.1 p₂.2.1 ^ 2 +
              qCoefficient T₁ T₂ e₁.1 e₁.2 p₂.2.2 p₂.2.1
                  z₁.1 z₁.2 p₂.1 p₂.2.2 *
                xCoefficient T₁ T₂ e₁.1 e₁.2 p₂.2.2 p₂.2.1 ^ 2) := by
      apply Finset.sum_congr rfl
      intro z₁ hz₁
      rw [T₂.sum_directedEdge_indexIExtra_eq_sum_canonical_orientations]
    _ = _ := Finset.sum_comm

/-- The double-extra diagonal block gives the four diagonal monomials of
each canonical path-pair square. -/
theorem qBothExtra_eq_p_diagonal_orientations
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    qDiagonalBlock T₁ T₂ (extraFamily₁ T₁) (extraFamily₂ T₂) =
      ∑ p₁ ∈ T₁.canonicalLengthTwoPathFinset,
        ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
          (qCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.1 p₂.2.1
                p₁.2.2 p₁.1 p₂.2.2 p₂.1 *
              xCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.1 p₂.2.1 ^ 2 +
            qCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.2.2 p₂.2.1
                p₁.2.2 p₁.1 p₂.1 p₂.2.2 *
              xCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.2.2 p₂.2.1 ^ 2 +
            qCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.1 p₂.2.1
                p₁.1 p₁.2.2 p₂.2.2 p₂.1 *
              xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.1 p₂.2.1 ^ 2 +
            qCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.2.2 p₂.2.1
                p₁.1 p₁.2.2 p₂.1 p₂.2.2 *
              xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.2.2 p₂.2.1 ^ 2) := by
  classical
  rw [qDiagonalBlock_reindex]
  unfold extraFamily₁ extraFamily₂
  rw [T₁.sum_two_indexIExtra_eq_sum_two_canonical_orientations T₂]

/-- The row-extra part of the `s` mixed block consists of the two row
orientations of every canonical row path, paired with every canonical
column path. -/
theorem sMixedBlock_extra_eq_p_same_row_terms
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    sMixedBlock T₁ T₂ (extraFamily₁ T₁) =
      ∑ p₁ ∈ T₁.canonicalLengthTwoPathFinset,
        ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
          (sCoefficient T₁ T₂ p₁.1 p₁.2.1 p₁.2.2 p₁.1
                p₂.1 p₂.2.1 p₂.2.2 *
              xCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.1 p₂.2.1 *
              xCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.2.2 p₂.2.1 +
            sCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₁.1 p₁.2.2
                p₂.1 p₂.2.1 p₂.2.2 *
              xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.1 p₂.2.1 *
              xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.2.2 p₂.2.1) := by
  classical
  rw [sMixedBlock_reindex]
  unfold extraFamily₁
  rw [T₁.sum_directedEdge_indexIExtra_eq_sum_canonical_orientations]
  simp only [Finset.sum_add_distrib]

/-- The column-extra part of the `b` mixed block consists of the two column
orientations of every canonical column path. -/
theorem bMixedBlock_extra_eq_p_same_column_terms
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    bMixedBlock T₁ T₂ (extraFamily₂ T₂) =
      ∑ p₁ ∈ T₁.canonicalLengthTwoPathFinset,
        ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
          (bCoefficient T₁ T₂ p₁.1 p₁.2.1 p₁.2.2
                p₂.1 p₂.2.1 p₂.2.2 p₂.1 *
              xCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.1 p₂.2.1 *
              xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.1 p₂.2.1 +
            bCoefficient T₁ T₂ p₁.1 p₁.2.1 p₁.2.2
                p₂.2.2 p₂.2.1 p₂.1 p₂.2.2 *
              xCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.2.2 p₂.2.1 *
              xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.2.2 p₂.2.1) := by
  classical
  unfold bMixedBlock extraFamily₂
  apply Finset.sum_congr rfl
  intro p₁ hp₁
  rw [T₂.sum_directedEdge_indexIExtra_eq_sum_canonical_orientations]

/-! ## The four square families -/

/-- The first square family in Theorem 2. -/
noncomputable def qSquareFamily
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  qDiagonalBlock T₁ T₂ (baseFamily₁ T₁) (baseFamily₂ T₂)

/-- The column-path square family in Theorem 2, with one representative
from each path-reversal orbit. -/
noncomputable def sSquareFamily
    [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  ∑ e₁ ∈ T₁.directedEdgeFinset,
    ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
      ∑ z₁ ∈ T₁.indexIFinset e₁.1 e₁.2,
        sCoefficient T₁ T₂ e₁.1 e₁.2 z₁.1 z₁.2
            p₂.1 p₂.2.1 p₂.2.2 *
          (xCoefficient T₁ T₂ e₁.1 e₁.2 p₂.1 p₂.2.1 +
            xCoefficient T₁ T₂ e₁.1 e₁.2 p₂.2.2 p₂.2.1) ^ 2

/-- The row-path square family in Theorem 2, with one representative from
each path-reversal orbit. -/
noncomputable def bSquareFamily
    [LinearOrder V₁]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  ∑ p₁ ∈ T₁.canonicalLengthTwoPathFinset,
    ∑ e₂ ∈ T₂.directedEdgeFinset,
      ∑ z₂ ∈ T₂.indexIFinset e₂.1 e₂.2,
        bCoefficient T₁ T₂ p₁.1 p₁.2.1 p₁.2.2
            e₂.1 e₂.2 z₂.1 z₂.2 *
          (xCoefficient T₁ T₂ p₁.1 p₁.2.1 e₂.1 e₂.2 +
            xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 e₂.1 e₂.2) ^ 2

/-- The path--path square family in Theorem 2. -/
noncomputable def pSquareFamily
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  ∑ p₁ ∈ T₁.canonicalLengthTwoPathFinset,
    ∑ p₂ ∈ T₂.canonicalLengthTwoPathFinset,
      pCoefficient T₁ T₂ p₁.1 p₁.2.1 p₁.2.2
          p₂.1 p₂.2.1 p₂.2.2 *
        (xCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.1 p₂.2.1 +
          xCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.2.2 p₂.2.1 +
          xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.1 p₂.2.1 +
          xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.2.2 p₂.2.1) ^ 2

/-- Expanding every row-path square pays exactly the row-extra diagonal
block and twice the retained `b` mixed block. -/
theorem bSquareFamily_expansion
    [LinearOrder V₁]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    bSquareFamily T₁ T₂ =
      qDiagonalBlock T₁ T₂ (extraFamily₁ T₁) (baseFamily₂ T₂) +
        2 * bMixedBlock T₁ T₂ (baseFamily₂ T₂) := by
  classical
  rw [qRowExtra_eq_b_diagonal_orientations]
  unfold bSquareFamily bMixedBlock baseFamily₂
  simp_rw [bSquare_expansion]
  simp only [Finset.mul_sum, ← Finset.sum_add_distrib]
  simp only [mul_assoc]

/-- Expanding every column-path square pays exactly the column-extra
diagonal block and twice the retained `s` mixed block. -/
theorem sSquareFamily_expansion
    [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    sSquareFamily T₁ T₂ =
      qDiagonalBlock T₁ T₂ (baseFamily₁ T₁) (extraFamily₂ T₂) +
        2 * sMixedBlock T₁ T₂ (baseFamily₁ T₁) := by
  classical
  rw [qColumnExtra_eq_s_diagonal_orientations]
  unfold sSquareFamily sMixedBlock baseFamily₁
  simp only [Finset.mul_sum, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro e₁ he₁
  apply Finset.sum_congr rfl
  intro p₂ hp₂
  apply Finset.sum_congr rfl
  intro z₁ hz₁
  have hp := (T₂.mem_canonicalLengthTwoPathFinset
    p₂.1 p₂.2.1 p₂.2.2).1 hp₂
  simpa only [mul_assoc] using
    (sSquare_expansion T₁ T₂
      e₁.1 e₁.2 z₁.1 z₁.2
      p₂.1 p₂.2.1 p₂.2.2 hp.1 hp.2.1)

/-- Expanding every path--path square pays the double-extra diagonal block,
the two extra mixed blocks, and twice the cross-diagonal `p` block. -/
theorem pSquareFamily_expansion
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    pSquareFamily T₁ T₂ =
      qDiagonalBlock T₁ T₂ (extraFamily₁ T₁) (extraFamily₂ T₂) +
        2 * sMixedBlock T₁ T₂ (extraFamily₁ T₁) +
        2 * bMixedBlock T₁ T₂ (extraFamily₂ T₂) +
        2 * pMixedBlock T₁ T₂ := by
  classical
  rw [qBothExtra_eq_p_diagonal_orientations,
    sMixedBlock_extra_eq_p_same_row_terms,
    bMixedBlock_extra_eq_p_same_column_terms]
  unfold pSquareFamily pMixedBlock
  simp only [Finset.mul_sum, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro p₁ hp₁
  apply Finset.sum_congr rfl
  intro p₂ hp₂
  have hp := (T₂.mem_canonicalLengthTwoPathFinset
    p₂.1 p₂.2.1 p₂.2.2).1 hp₂
  simpa only [mul_add, mul_assoc, add_assoc] using
    (pSquare_expansion T₁ T₂
      p₁.1 p₁.2.1 p₁.2.2
      p₂.1 p₂.2.1 p₂.2.2 hp.1 hp.2.1)

/-! ## Global settlement -/

/-- The four raw coefficient blocks in equation `(raw-quadratic)`, with the
paper's formerly ambiguous path index interpreted as one representative per
path-reversal orbit. -/
noncomputable def rawQuadratic
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  qDiagonalBlock T₁ T₂ (primeFamily₁ T₁) (primeFamily₂ T₂) +
    2 * sMixedBlock T₁ T₂ (primeFamily₁ T₁) +
    2 * bMixedBlock T₁ T₂ (primeFamily₂ T₂) +
    2 * pMixedBlock T₁ T₂

/-- The right-hand side of the sum-of-squares display in Theorem 2. -/
noncomputable def sumOfSquaresRhs
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) : ℝ :=
  qSquareFamily T₁ T₂ + sSquareFamily T₁ T₂ +
    bSquareFamily T₁ T₂ + pSquareFamily T₁ T₂

/-- Complete finite-sum assembly suppressed by the final paragraph of the
paper's proof of Theorem 2.  Every raw `I'` occurrence appears exactly once
in one of the four square families. -/
theorem sumOfSquaresRhs_eq_rawQuadratic
    [LinearOrder V₁] [LinearOrder V₂]
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    sumOfSquaresRhs T₁ T₂ = rawQuadratic T₁ T₂ := by
  rw [sumOfSquaresRhs, rawQuadratic,
    sSquareFamily_expansion, bSquareFamily_expansion,
    pSquareFamily_expansion,
    qDiagonalBlock_prime_decomposition,
    sMixedBlock_prime_decomposition,
    bMixedBlock_prime_decomposition]
  unfold qSquareFamily
  ring

end QDFull
