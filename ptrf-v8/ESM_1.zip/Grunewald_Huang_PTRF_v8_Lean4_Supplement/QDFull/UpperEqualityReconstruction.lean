import QDFull.CorollaryOne

/-!
# Reconstruction from equality in the universal upper bound

The numerical equality theorem in `CorollaryOne` records only cardinalities.
This file first turns those saturated cardinalities into pointwise statements:
every two-taxon partial quartet, every marked three-taxon partial quartet, and
every four-taxon support occurs in the common displayed ledger.  These are the
interfaces needed for the subsequent graph-theoretic reconstruction.
-/

namespace QDFull

universe uX uV₁ uV₂

variable {X : Type uX} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V₁] [Fintype V₂]

/-! ## Saturation of the support-size two ledger -/

/-- The universal finite set of all non-diagonal `1|1` partial quartets. -/
noncomputable def allPairPartialQuartets : Finset (PartialSplit X) := by
  classical
  exact (Finset.univ : Finset {p : Sym2 X // ¬p.IsDiag}).image
    (fun p => pairPartialQuartet p.1)

private theorem pairPartialQuartet_injective' :
    Function.Injective (pairPartialQuartet : Sym2 X → PartialSplit X) := by
  intro p
  refine Sym2.inductionOn p ?_
  intro a b q
  refine Sym2.inductionOn q ?_
  intro c d h
  simp only [pairPartialQuartet, Sym2.map_pair_eq, Sym2.eq_iff] at h ⊢
  rcases h with h | h
  · exact Or.inl ⟨Finset.singleton_inj.mp h.1,
      Finset.singleton_inj.mp h.2⟩
  · exact Or.inr ⟨Finset.singleton_inj.mp h.1,
      Finset.singleton_inj.mp h.2⟩

theorem card_allPairPartialQuartets :
    (allPairPartialQuartets (X := X)).card =
      Nat.choose (Fintype.card X) 2 := by
  classical
  rw [allPairPartialQuartets, Finset.card_image_iff.mpr]
  · exact Sym2.card_subtype_not_diag
  · intro p _hp q _hq hpq
    apply Subtype.ext
    exact pairPartialQuartet_injective' hpq

theorem commonDisplayedPartialQuartets_two_subset_allPairs
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    commonDisplayedPartialQuartets T₁ T₂ 2 ⊆
      allPairPartialQuartets := by
  classical
  intro P hP
  have hdata :=
    (mem_commonDisplayedPartialQuartets T₁ T₂ 2 P).1 hP
  rcases partialQuartet_representation_cases hdata.1 with
      ⟨a, b, hab, hrep⟩ |
      ⟨a, b, c, hab, hac, hbc, hrep⟩ |
      ⟨a, b, c, d, hab, hac, had, hbc, hbd, hcd, hrep⟩
  · let p : {q : Sym2 X // ¬q.IsDiag} :=
      ⟨s(a, b), by simpa [Sym2.IsDiag] using hab⟩
    rw [allPairPartialQuartets, Finset.mem_image]
    refine ⟨p, Finset.mem_univ _, ?_⟩
    rw [hrep]
    simp [p, pairPartialQuartet]
  · have hthree :
        (partialSplitSupport
          s(({a} : Finset X), ({b, c} : Finset X))).card = 3 := by
      have hdisj : Disjoint ({a} : Finset X) {b, c} := by
        simp [Finset.disjoint_left, hab, hac]
      rw [partialSplitSupport_mk, Finset.card_union_of_disjoint hdisj]
      simp [Finset.card_pair hbc]
    rw [hrep] at hdata
    omega
  · have hfour :
        (partialSplitSupport
          s(({a, b} : Finset X), ({c, d} : Finset X))).card = 4 := by
      have hdisj : Disjoint ({a, b} : Finset X) {c, d} := by
        simp [Finset.disjoint_left, hac, had, hbc, hbd]
      rw [partialSplitSupport_mk, Finset.card_union_of_disjoint hdisj]
      simp [Finset.card_pair hab, Finset.card_pair hcd]
    rw [hrep] at hdata
    omega

theorem commonDisplayedPartialQuartets_two_eq_allPairs_of_card_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hcard : (commonDisplayedPartialQuartets T₁ T₂ 2).card =
      Nat.choose (Fintype.card X) 2) :
    commonDisplayedPartialQuartets T₁ T₂ 2 =
      allPairPartialQuartets := by
  apply Finset.eq_of_subset_of_card_le
    (commonDisplayedPartialQuartets_two_subset_allPairs T₁ T₂)
  rw [card_allPairPartialQuartets, hcard]

/-- Saturating the support-size two count means that every prescribed pair
of distinct taxa is displayed by both trees. -/
theorem pairPartialQuartet_mem_common_of_card_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hcard : (commonDisplayedPartialQuartets T₁ T₂ 2).card =
      Nat.choose (Fintype.card X) 2)
    {a b : X} (hab : a ≠ b) :
    pairPartialQuartet s(a, b) ∈
      commonDisplayedPartialQuartets T₁ T₂ 2 := by
  classical
  rw [commonDisplayedPartialQuartets_two_eq_allPairs_of_card_eq T₁ T₂ hcard,
    allPairPartialQuartets, Finset.mem_image]
  let p : {q : Sym2 X // ¬q.IsDiag} :=
    ⟨s(a, b), by simpa [Sym2.IsDiag] using hab⟩
  exact ⟨p, Finset.mem_univ _, rfl⟩

/-- If a tree displays the `1|1` partial quartet on two taxa, their labels
cannot occupy the same graph vertex. -/
theorem label_ne_of_displays_pairPartialQuartet
    (T : XTree X V₁) {a b : X}
    (hdisplay : T.DisplaysPartialSplit (pairPartialQuartet s(a, b))) :
    T.label a ≠ T.label b := by
  classical
  intro habLabel
  rcases hdisplay with ⟨u, v, huv, hdisplay⟩
  rw [XTree.edgeSplit] at hdisplay
  have hpair : pairPartialQuartet s(a, b) =
      s(({a} : Finset X), ({b} : Finset X)) := by
    simp [pairPartialQuartet]
  rw [hpair, displays_comm_representative] at hdisplay
  simp only [Finset.singleton_subset_iff] at hdisplay
  have hsameUV : a ∈ T.edgeSide u v ↔ b ∈ T.edgeSide u v := by
    simp only [T.mem_edgeSide]
    rw [habLabel]
  have hsameVU : a ∈ T.edgeSide v u ↔ b ∈ T.edgeSide v u := by
    simp only [T.mem_edgeSide]
    rw [habLabel]
  rcases hdisplay with h | h
  · have hbUV : b ∈ T.edgeSide u v := hsameUV.mp h.1
    exact (Finset.disjoint_left.mp
      (T.edgeSide_disjoint_reverse_of_adj huv)) hbUV h.2
  · have hbVU : b ∈ T.edgeSide v u := hsameVU.mp h.1
    exact (Finset.disjoint_left.mp
      (T.edgeSide_disjoint_reverse_of_adj huv).symm) hbVU h.2

/-- Saturating the common support-size two ledger forces the first tree's
taxon labelling map to be injective. -/
theorem first_label_injective_of_common_two_card_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hcard : (commonDisplayedPartialQuartets T₁ T₂ 2).card =
      Nat.choose (Fintype.card X) 2) :
    Function.Injective T₁.label := by
  intro a b habLabel
  by_contra hab
  have hmem := pairPartialQuartet_mem_common_of_card_eq T₁ T₂ hcard hab
  have hdisplay :=
    ((mem_commonDisplayedPartialQuartets T₁ T₂ 2 _).1 hmem).2.1
  exact label_ne_of_displays_pairPartialQuartet T₁ hdisplay habLabel

/-- Saturating the common support-size two ledger forces the second tree's
taxon labelling map to be injective. -/
theorem second_label_injective_of_common_two_card_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hcard : (commonDisplayedPartialQuartets T₁ T₂ 2).card =
      Nat.choose (Fintype.card X) 2) :
    Function.Injective T₂.label := by
  intro a b habLabel
  by_contra hab
  have hmem := pairPartialQuartet_mem_common_of_card_eq T₁ T₂ hcard hab
  have hdisplay :=
    ((mem_commonDisplayedPartialQuartets T₁ T₂ 2 _).1 hmem).2.2.1
  exact label_ne_of_displays_pairPartialQuartet T₂ hdisplay habLabel

/-! ## Saturation of the support-size three ledger -/

/-- The universal finite set of marked `1|2` partial quartets. -/
noncomputable def allMarkedThreePartialQuartets : Finset (PartialSplit X) := by
  classical
  exact (markedThreeSupports (X := X)).image
    (markedThreePartialQuartet (X := X))

private theorem markedThreePartialQuartet_support'
    {z : MarkedThreeSupport X} (hz : z ∈ markedThreeSupports) :
    partialSplitSupport (markedThreePartialQuartet z) = z.1 := by
  classical
  have hmem := (mem_markedThreeSupports z).1 hz
  rw [markedThreePartialQuartet, partialSplitSupport_mk,
    Finset.singleton_union, Finset.insert_erase hmem.2]

private theorem markedThreePartialQuartet_injOn' :
    Set.InjOn (markedThreePartialQuartet :
      MarkedThreeSupport X → PartialSplit X)
        ((markedThreeSupports : Finset (MarkedThreeSupport X)) :
          Set (MarkedThreeSupport X)) := by
  classical
  intro z hz w hw hzw
  rcases z with ⟨S, a⟩
  rcases w with ⟨T, b⟩
  have hzdata := (mem_markedThreeSupports ⟨S, a⟩).1 hz
  have hwdata := (mem_markedThreeSupports ⟨T, b⟩).1 hw
  have hsupport := congrArg partialSplitSupport hzw
  have hST : S = T := by
    simpa [markedThreePartialQuartet_support' hz,
      markedThreePartialQuartet_support' hw] using hsupport
  subst T
  change s(({a} : Finset X), S.erase a) =
    s(({b} : Finset X), S.erase b) at hzw
  rw [Sym2.eq_iff] at hzw
  have hab : a = b := by
    rcases hzw with hdirect | hswap
    · exact Finset.singleton_inj.mp hdirect.1
    · have hleft : ({a} : Finset X).card = 1 := by simp
      have hright : (S.erase b).card = 2 := by
        rw [Finset.card_erase_of_mem hwdata.2, hwdata.1]
      rw [hswap.1] at hleft
      omega
  subst b
  rfl

theorem card_allMarkedThreePartialQuartets :
    (allMarkedThreePartialQuartets (X := X)).card =
      3 * Nat.choose (Fintype.card X) 3 := by
  classical
  rw [allMarkedThreePartialQuartets, Finset.card_image_iff.mpr]
  · exact card_markedThreeSupports
  · intro z hz w hw hzw
    exact markedThreePartialQuartet_injOn' hz hw hzw

theorem commonDisplayedPartialQuartets_three_subset_allMarked
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    commonDisplayedPartialQuartets T₁ T₂ 3 ⊆
      allMarkedThreePartialQuartets (X := X) := by
  classical
  intro P hP
  have hdata :=
    (mem_commonDisplayedPartialQuartets T₁ T₂ 3 P).1 hP
  rcases partialQuartet_representation_cases hdata.1 with
      ⟨a, b, hab, hrep⟩ |
      ⟨a, b, c, hab, hac, hbc, hrep⟩ |
      ⟨a, b, c, d, hab, hac, had, hbc, hbd, hcd, hrep⟩
  · have htwo :
        (partialSplitSupport
          s(({a} : Finset X), ({b} : Finset X))).card = 2 := by
      simp [partialSplitSupport_mk, hab]
    rw [hrep] at hdata
    omega
  · let z : MarkedThreeSupport X := ⟨({a, b, c} : Finset X), a⟩
    have hz : z ∈ markedThreeSupports := by
      simp [z, hab, hac, hbc]
    rw [allMarkedThreePartialQuartets, Finset.mem_image]
    refine ⟨z, hz, ?_⟩
    rw [hrep]
    simp [z, markedThreePartialQuartet, hab, hac]
  · have hfour :
        (partialSplitSupport
          s(({a, b} : Finset X), ({c, d} : Finset X))).card = 4 := by
      have hdisj : Disjoint ({a, b} : Finset X) {c, d} := by
        simp [Finset.disjoint_left, hac, had, hbc, hbd]
      rw [partialSplitSupport_mk, Finset.card_union_of_disjoint hdisj]
      simp [Finset.card_pair hab, Finset.card_pair hcd]
    rw [hrep] at hdata
    omega

theorem commonDisplayedPartialQuartets_three_eq_allMarked_of_card_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hcard : (commonDisplayedPartialQuartets T₁ T₂ 3).card =
      3 * Nat.choose (Fintype.card X) 3) :
    commonDisplayedPartialQuartets T₁ T₂ 3 =
      allMarkedThreePartialQuartets (X := X) := by
  apply Finset.eq_of_subset_of_card_le
    (commonDisplayedPartialQuartets_three_subset_allMarked T₁ T₂)
  rw [card_allMarkedThreePartialQuartets, hcard]

/-- Saturating the support-size three count means that every prescribed
singleton-versus-pair partial quartet is displayed by both trees. -/
theorem markedThreePartialQuartet_mem_common_of_card_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hcard : (commonDisplayedPartialQuartets T₁ T₂ 3).card =
      3 * Nat.choose (Fintype.card X) 3)
    {z : MarkedThreeSupport X} (hz : z ∈ markedThreeSupports) :
    markedThreePartialQuartet z ∈
      commonDisplayedPartialQuartets T₁ T₂ 3 := by
  classical
  rw [commonDisplayedPartialQuartets_three_eq_allMarked_of_card_eq T₁ T₂ hcard,
    allMarkedThreePartialQuartets, Finset.mem_image]
  exact ⟨z, hz, rfl⟩

/-! ## The branch-divergence geometry -/

/-- Once the unique path from `centre` enters the component selected by the
incident edge `centre--branch`, every later vertex remains in that component.
The proof constructs the path inside the deleted-edge component and then uses
uniqueness of paths in a tree. -/
theorem mem_vertexSide_of_mem_vertexPath_tail
    (T : XTree X V₁) {centre branch target z : V₁}
    (hcb : T.graph.Adj centre branch)
    (htarget : target ∈ T.vertexSide centre branch)
    (hz : z ∈ (T.vertexPath centre target).support.tail) :
    z ∈ T.vertexSide centre branch := by
  classical
  let H : SimpleGraph V₁ := T.graph.deleteEdges {s(centre, branch)}
  have hreach : H.Reachable branch target := by
    change (T.graph.deleteEdges {s(centre, branch)}).Reachable branch target at htarget
    exact htarget
  obtain ⟨pH, hpH⟩ := hreach.exists_isPath
  have hbridgeCB : ¬H.Reachable centre branch := by
    have hbridge :=
      (SimpleGraph.isAcyclic_iff_forall_adj_isBridge.mp
        T.isTree.isAcyclic hcb)
    change ¬(T.graph.deleteEdges {s(centre, branch)}).Reachable
      centre branch at hbridge
    exact hbridge
  have hcentreNot : centre ∉ pH.support := by
    intro hc
    have hbc : H.Reachable branch centre :=
      (pH.takeUntil centre hc).reachable
    exact hbridgeCB hbc.symm
  let p₀ : T.graph.Walk branch target :=
    pH.mapLe (SimpleGraph.deleteEdges_le _)
  have hcentreNot₀ : centre ∉ p₀.support := by
    simpa [p₀, SimpleGraph.Walk.support_mapLe_eq_support] using hcentreNot
  let p : T.graph.Walk centre target := SimpleGraph.Walk.cons hcb p₀
  have hp : p.IsPath :=
    (hpH.mapLe (SimpleGraph.deleteEdges_le _)).cons hcentreNot₀
  have heq : T.vertexPath centre target = p :=
    (T.isTree.existsUnique_path centre target).unique
      (T.vertexPath_isPath centre target) hp
  have hz₀ : z ∈ p₀.support := by
    rw [heq] at hz
    simpa [p] using hz
  have hzH : z ∈ pH.support := by
    simpa [p₀, SimpleGraph.Walk.support_mapLe_eq_support] using hz₀
  change H.Reachable branch z
  exact (pH.takeUntil z hzH).reachable

/-- Two simple paths with the same initial vertex and disjoint tail supports
have disjoint edge lists. -/
theorem walk_edges_disjoint_of_tail_support_disjoint
    {G : SimpleGraph V₁} {centre y z : V₁}
    (p : G.Walk centre y) (q : G.Walk centre z)
    (hdisj : p.support.tail.Disjoint q.support.tail) :
    p.edges.Disjoint q.edges := by
  classical
  rw [List.disjoint_left]
  intro e hep heq
  induction e using Sym2.inductionOn with
  | _ a b =>
      have hab : a ≠ b := (p.adj_of_mem_edges hep).ne
      have haP : a ∈ p.support := p.fst_mem_support_of_mem_edges hep
      have hbP : b ∈ p.support := p.snd_mem_support_of_mem_edges hep
      have haQ : a ∈ q.support := q.fst_mem_support_of_mem_edges heq
      have hbQ : b ∈ q.support := q.snd_mem_support_of_mem_edges heq
      by_cases hac : a = centre
      · have hbc : b ≠ centre := by
          intro hbc
          exact hab (hac.trans hbc.symm)
        have hbPTail : b ∈ p.support.tail := by
          rw [← p.cons_tail_support] at hbP
          have hb : b = centre ∨ b ∈ p.support.tail := by
            simpa only [List.mem_cons] using hbP
          exact hb.resolve_left hbc
        have hbQTail : b ∈ q.support.tail := by
          rw [← q.cons_tail_support] at hbQ
          have hb : b = centre ∨ b ∈ q.support.tail := by
            simpa only [List.mem_cons] using hbQ
          exact hb.resolve_left hbc
        exact (List.disjoint_left.mp hdisj) hbPTail hbQTail
      · have haPTail : a ∈ p.support.tail := by
          rw [← p.cons_tail_support] at haP
          have ha : a = centre ∨ a ∈ p.support.tail := by
            simpa only [List.mem_cons] using haP
          exact ha.resolve_left hac
        have haQTail : a ∈ q.support.tail := by
          rw [← q.cons_tail_support] at haQ
          have ha : a = centre ∨ a ∈ q.support.tail := by
            simpa only [List.mem_cons] using haQ
          exact ha.resolve_left hac
        exact (List.disjoint_left.mp hdisj) haPTail haQTail

/-- Taxon paths from a labelled centre into two distinct incident branches
share no edge. -/
theorem taxonPath_edges_disjoint_of_distinct_branches
    (T : XTree X V₁) {x y z : X} {centre left right : V₁}
    (hx : T.label x = centre)
    (hleft : T.graph.Adj centre left)
    (hright : T.graph.Adj centre right)
    (hlr : left ≠ right)
    (hy : y ∈ T.edgeSide centre left)
    (hz : z ∈ T.edgeSide centre right) :
    (T.taxonPath x y).edges.Disjoint (T.taxonPath x z).edges := by
  classical
  have hyVertex : T.label y ∈ T.vertexSide centre left :=
    (T.mem_edgeSide centre left y).1 hy
  have hzVertex : T.label z ∈ T.vertexSide centre right :=
    (T.mem_edgeSide centre right z).1 hz
  have htailDisjoint :
      (T.vertexPath centre (T.label y)).support.tail.Disjoint
        (T.vertexPath centre (T.label z)).support.tail := by
    rw [List.disjoint_left]
    intro w hwy hwz
    exact (Set.disjoint_left.mp
      (T.vertexSide_disjoint_sidePair hleft.symm hright hlr))
      (mem_vertexSide_of_mem_vertexPath_tail T hleft hyVertex hwy)
      (mem_vertexSide_of_mem_vertexPath_tail T hright hzVertex hwz)
  unfold XTree.taxonPath
  rw [hx]
  exact walk_edges_disjoint_of_tail_support_disjoint _ _ htailDisjoint

/-- The tails of the two paths which leave a centre through distinct incident
branches are disjoint. -/
theorem vertexPath_tail_disjoint_of_distinct_branches
    (T : XTree X V₁) {centre left right targetLeft targetRight : V₁}
    (hleft : T.graph.Adj centre left)
    (hright : T.graph.Adj centre right)
    (hlr : left ≠ right)
    (htargetLeft : targetLeft ∈ T.vertexSide centre left)
    (htargetRight : targetRight ∈ T.vertexSide centre right) :
    (T.vertexPath centre targetLeft).support.tail.Disjoint
      (T.vertexPath centre targetRight).support.tail := by
  classical
  rw [List.disjoint_left]
  intro w hwLeft hwRight
  exact (Set.disjoint_left.mp
    (T.vertexSide_disjoint_sidePair hleft.symm hright hlr))
    (mem_vertexSide_of_mem_vertexPath_tail T hleft htargetLeft hwLeft)
    (mem_vertexSide_of_mem_vertexPath_tail T hright htargetRight hwRight)

/-- Paths from a common centre into two distinct incident branches have
disjoint edge lists. -/
theorem vertexPath_edges_disjoint_of_distinct_branches
    (T : XTree X V₁) {centre left right targetLeft targetRight : V₁}
    (hleft : T.graph.Adj centre left)
    (hright : T.graph.Adj centre right)
    (hlr : left ≠ right)
    (htargetLeft : targetLeft ∈ T.vertexSide centre left)
    (htargetRight : targetRight ∈ T.vertexSide centre right) :
    (T.vertexPath centre targetLeft).edges.Disjoint
      (T.vertexPath centre targetRight).edges := by
  exact walk_edges_disjoint_of_tail_support_disjoint _ _
    (vertexPath_tail_disjoint_of_distinct_branches T
      hleft hright hlr htargetLeft htargetRight)

/-- If two targets lie in distinct branches at `centre`, their unique path is
the reverse of the first centre path followed by the second centre path. -/
theorem vertexPath_eq_reverse_append_of_distinct_branches
    (T : XTree X V₁) {centre left right targetLeft targetRight : V₁}
    (hleft : T.graph.Adj centre left)
    (hright : T.graph.Adj centre right)
    (hlr : left ≠ right)
    (htargetLeft : targetLeft ∈ T.vertexSide centre left)
    (htargetRight : targetRight ∈ T.vertexSide centre right) :
    T.vertexPath targetLeft targetRight =
      (T.vertexPath centre targetLeft).reverse.append
        (T.vertexPath centre targetRight) := by
  classical
  let pLeft := T.vertexPath centre targetLeft
  let pRight := T.vertexPath centre targetRight
  have htail : pLeft.support.tail.Disjoint pRight.support.tail :=
    vertexPath_tail_disjoint_of_distinct_branches T
      hleft hright hlr htargetLeft htargetRight
  have hcentreNotRight : centre ∉ pRight.support.tail := by
    have hn := (T.vertexPath_isPath centre targetRight).support_nodup
    change pRight.support.Nodup at hn
    rw [← pRight.cons_tail_support] at hn
    exact (List.nodup_cons.mp hn).1
  have hsupport : pLeft.support.Disjoint pRight.support.tail := by
    rw [List.disjoint_left]
    intro w hwLeft hwRight
    rw [← pLeft.cons_tail_support] at hwLeft
    rcases (List.mem_cons.mp hwLeft) with hwCentre | hwTail
    · subst w
      exact hcentreNotRight hwRight
    · exact (List.disjoint_left.mp htail) hwTail hwRight
  have happ : (pLeft.reverse.append pRight).IsPath := by
    rw [SimpleGraph.Walk.isPath_def, SimpleGraph.Walk.support_append]
    apply List.Nodup.append
    · exact (T.vertexPath_isPath centre targetLeft).reverse.support_nodup
    · exact (T.vertexPath_isPath centre targetRight).support_nodup.tail
    · rw [SimpleGraph.Walk.support_reverse, List.disjoint_reverse_left]
      exact hsupport
  exact (T.isTree.existsUnique_path targetLeft targetRight).unique
    (T.vertexPath_isPath targetLeft targetRight) happ

/-- If four taxa lie in four pairwise distinct incident branches at a common
centre, the two paths joining the first pair of opposite branches and the
second pair use disjoint graph edges. -/
theorem taxonPath_edges_disjoint_of_four_distinct_branches
    (T : XTree X V₁)
    {x₁ x₂ x₃ x₄ : X} {centre b₁ b₂ b₃ b₄ : V₁}
    (hb₁ : T.graph.Adj centre b₁) (hb₂ : T.graph.Adj centre b₂)
    (hb₃ : T.graph.Adj centre b₃) (hb₄ : T.graph.Adj centre b₄)
    (hb₁₂ : b₁ ≠ b₂) (hb₁₃ : b₁ ≠ b₃) (hb₁₄ : b₁ ≠ b₄)
    (hb₂₃ : b₂ ≠ b₃) (hb₂₄ : b₂ ≠ b₄) (hb₃₄ : b₃ ≠ b₄)
    (hx₁ : x₁ ∈ T.edgeSide centre b₁)
    (hx₂ : x₂ ∈ T.edgeSide centre b₂)
    (hx₃ : x₃ ∈ T.edgeSide centre b₃)
    (hx₄ : x₄ ∈ T.edgeSide centre b₄) :
    (T.taxonPath x₁ x₃).edges.Disjoint
      (T.taxonPath x₂ x₄).edges := by
  classical
  have hv₁ := (T.mem_edgeSide centre b₁ x₁).1 hx₁
  have hv₂ := (T.mem_edgeSide centre b₂ x₂).1 hx₂
  have hv₃ := (T.mem_edgeSide centre b₃ x₃).1 hx₃
  have hv₄ := (T.mem_edgeSide centre b₄ x₄).1 hx₄
  have h₁₃ := vertexPath_eq_reverse_append_of_distinct_branches T
    hb₁ hb₃ hb₁₃ hv₁ hv₃
  have h₂₄ := vertexPath_eq_reverse_append_of_distinct_branches T
    hb₂ hb₄ hb₂₄ hv₂ hv₄
  have h₁₂ := vertexPath_edges_disjoint_of_distinct_branches T
    hb₁ hb₂ hb₁₂ hv₁ hv₂
  have h₁₄ := vertexPath_edges_disjoint_of_distinct_branches T
    hb₁ hb₄ hb₁₄ hv₁ hv₄
  have h₃₂ := vertexPath_edges_disjoint_of_distinct_branches T
    hb₃ hb₂ hb₂₃.symm hv₃ hv₂
  have h₃₄ := vertexPath_edges_disjoint_of_distinct_branches T
    hb₃ hb₄ hb₃₄ hv₃ hv₄
  unfold XTree.taxonPath
  rw [h₁₃, h₂₄, SimpleGraph.Walk.edges_append,
    SimpleGraph.Walk.edges_append, SimpleGraph.Walk.edges_reverse,
    SimpleGraph.Walk.edges_reverse]
  rw [List.disjoint_append_left, List.disjoint_append_right,
    List.disjoint_append_right]
  constructor
  · constructor
    · simpa using h₁₂
    · simpa using h₁₄
  · constructor
    · simpa using h₃₂
    · exact h₃₄

/-- Taxa chosen from two distinct incident branches at a centre are distinct. -/
theorem taxon_ne_of_mem_distinct_branches
    (T : XTree X V₁) {centre left right : V₁} {x y : X}
    (hleft : T.graph.Adj centre left)
    (hright : T.graph.Adj centre right)
    (hlr : left ≠ right)
    (hx : x ∈ T.edgeSide centre left)
    (hy : y ∈ T.edgeSide centre right) :
    x ≠ y := by
  intro hxy
  subst y
  exact (Finset.disjoint_left.mp
    (T.edgeSide_disjoint_sidePair hleft.symm hright hlr)) hx hy

/-- If at least three taxa are injectively labelled and every marked
three-support partial quartet is displayed, then every labelled vertex is a
graph leaf.  A non-leaf labelled centre has two distinct incident branches;
choosing one taxon from each branch makes the required `x | yz` displaying
edge belong to two branch-divergent paths, a contradiction. -/
theorem labels_are_leaves_of_all_marked_three_displayed
    (T : XTree X V₁) (hX : 3 ≤ Fintype.card X)
    (hinj : Function.Injective T.label)
    (hall : ∀ z : MarkedThreeSupport X, z ∈ markedThreeSupports →
      T.DisplaysPartialSplit (markedThreePartialQuartet z)) :
    ∀ x : X, T.IsLeaf (T.label x) := by
  classical
  letI : Nontrivial X :=
    Fintype.one_lt_card_iff_nontrivial.mp (by omega)
  letI : Nontrivial V₁ := hinj.nontrivial
  intro x
  by_contra hnotLeaf
  let centre : V₁ := T.label x
  let N : Finset V₁ := T.neighborFinset centre
  have hdegreePos : 0 < Nat.card (T.graph.neighborSet centre) := by
    rw [Nat.card_eq_fintype_card,
      T.graph.card_neighborSet_eq_degree]
    exact T.isTree.preconnected.degree_pos_of_nontrivial centre
  have hdegreeNeOne : Nat.card (T.graph.neighborSet centre) ≠ 1 := by
    simpa [XTree.IsLeaf, centre] using hnotLeaf
  have hNcard : 2 ≤ N.card := by
    change 2 ≤ (T.neighborFinset centre).card
    rw [T.card_neighborFinset]
    omega
  obtain ⟨left, hleftN⟩ : N.Nonempty :=
    Finset.card_pos.mp (by omega)
  have hErasePos : 0 < (N.erase left).card := by
    rw [Finset.card_erase_of_mem hleftN]
    omega
  obtain ⟨right, hrightErase⟩ : (N.erase left).Nonempty :=
    Finset.card_pos.mp hErasePos
  have hrightN : right ∈ N := Finset.mem_of_mem_erase hrightErase
  have hrightNeLeft : right ≠ left := (Finset.mem_erase.mp hrightErase).1
  have hleft : T.graph.Adj centre left := by
    simpa [N] using (T.mem_neighborFinset centre left).1 hleftN
  have hright : T.graph.Adj centre right := by
    simpa [N] using (T.mem_neighborFinset centre right).1 hrightN
  obtain ⟨y, hy⟩ := T.edgeSide_nonempty_of_adj hleft
  obtain ⟨z, hz⟩ := T.edgeSide_nonempty_of_adj hright
  have hyx : y ≠ x := by
    intro hyx
    subst y
    have hxFiber : x ∈ T.labelFiber centre := by
      simp [XTree.mem_labelFiber, centre]
    exact (Finset.disjoint_left.mp
      (T.labelFiber_disjoint_branch hleft)) hxFiber hy
  have hzx : z ≠ x := by
    intro hzx
    subst z
    have hxFiber : x ∈ T.labelFiber centre := by
      simp [XTree.mem_labelFiber, centre]
    exact (Finset.disjoint_left.mp
      (T.labelFiber_disjoint_branch hright)) hxFiber hz
  have hyz : y ≠ z := by
    intro hyz
    subst z
    exact (Finset.disjoint_left.mp
      (T.edgeSide_disjoint_sidePair hleft.symm hright
        hrightNeLeft.symm)) hy hz
  let m : MarkedThreeSupport X :=
    ⟨({x, y, z} : Finset X), x⟩
  have hm : m ∈ markedThreeSupports := by
    rw [mem_markedThreeSupports]
    constructor
    · have hxnot : x ∉ ({y, z} : Finset X) := by
        simp [hyx.symm, hzx.symm]
      change ({x, y, z} : Finset X).card = 3
      rw [Finset.card_insert_of_notMem hxnot]
      simp [hyz]
    · simp [m]
  have hdisplay := hall m hm
  have hmForm : markedThreePartialQuartet m =
      s(({x} : Finset X), ({y, z} : Finset X)) := by
    have herase : ({x, y, z} : Finset X).erase x = {y, z} := by
      ext t
      simp only [Finset.mem_erase, Finset.mem_insert, Finset.mem_singleton]
      constructor
      · rintro ⟨ht_ne, htx | htyz⟩
        · exact (ht_ne htx).elim
        · exact htyz
      · intro htyz
        constructor
        · intro htx
          subst t
          exact htyz.elim (fun hxy => hyx hxy.symm) (fun hxz => hzx hxz.symm)
        · exact Or.inr htyz
    change s(({x} : Finset X), ({x, y, z} : Finset X).erase x) =
      s(({x} : Finset X), ({y, z} : Finset X))
    rw [herase]
  rw [hmForm] at hdisplay
  rcases hdisplay with ⟨a, b, hab, hdispEdge⟩
  have hallPaths :=
    (T.displays_edgeSplit_iff_mem_all_cross_paths hab
      ({x} : Finset X) ({y, z} : Finset X) (by simp) (by simp)).1
      hdispEdge
  have hxy : s(a, b) ∈ (T.taxonPath x y).edges :=
    hallPaths x (by simp) y (by simp)
  have hxz : s(a, b) ∈ (T.taxonPath x z).edges :=
    hallPaths x (by simp) z (by simp)
  have hpathDisjoint :=
    taxonPath_edges_disjoint_of_distinct_branches T
      (show T.label x = centre from rfl) hleft hright
      hrightNeLeft.symm hy hz
  exact (List.disjoint_left.mp hpathDisjoint) hxy hxz

theorem first_labels_are_leaves_of_common_three_card_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hX : 3 ≤ Fintype.card X)
    (hcard₂ : (commonDisplayedPartialQuartets T₁ T₂ 2).card =
      Nat.choose (Fintype.card X) 2)
    (hcard₃ : (commonDisplayedPartialQuartets T₁ T₂ 3).card =
      3 * Nat.choose (Fintype.card X) 3) :
    ∀ x : X, T₁.IsLeaf (T₁.label x) := by
  apply labels_are_leaves_of_all_marked_three_displayed T₁ hX
    (first_label_injective_of_common_two_card_eq T₁ T₂ hcard₂)
  intro z hz
  have hmem :=
    markedThreePartialQuartet_mem_common_of_card_eq T₁ T₂ hcard₃ hz
  exact ((mem_commonDisplayedPartialQuartets T₁ T₂ 3 _).1 hmem).2.1

theorem second_labels_are_leaves_of_common_three_card_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hX : 3 ≤ Fintype.card X)
    (hcard₂ : (commonDisplayedPartialQuartets T₁ T₂ 2).card =
      Nat.choose (Fintype.card X) 2)
    (hcard₃ : (commonDisplayedPartialQuartets T₁ T₂ 3).card =
      3 * Nat.choose (Fintype.card X) 3) :
    ∀ x : X, T₂.IsLeaf (T₂.label x) := by
  apply labels_are_leaves_of_all_marked_three_displayed T₂ hX
    (second_label_injective_of_common_two_card_eq T₁ T₂ hcard₂)
  intro z hz
  have hmem :=
    markedThreePartialQuartet_mem_common_of_card_eq T₁ T₂ hcard₃ hz
  exact ((mem_commonDisplayedPartialQuartets T₁ T₂ 3 _).1 hmem).2.2.1

/-- Injective labels which all lie on graph leaves already give the complete
phylogenetic specialization.  The reverse surjectivity onto graph leaves is
not an additional assumption: every leaf has degree one, so the defining
low-degree axiom of an `XTree` supplies a taxon at that vertex. -/
theorem isPhylogenetic_of_injective_and_labels_are_leaves
    (T : XTree X V₁)
    (hinj : Function.Injective T.label)
    (hleaf : ∀ x : X, T.IsLeaf (T.label x)) :
    T.IsPhylogenetic := by
  refine ⟨hinj, hleaf, ?_⟩
  intro v hv
  apply T.lowDegree_labelled v
  unfold XTree.IsLeaf at hv
  omega

/-- Saturation of the common support-size two and three ledgers forces the
first source tree to be phylogenetic (for at least three taxa). -/
theorem first_isPhylogenetic_of_common_two_three_card_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hX : 3 ≤ Fintype.card X)
    (hcard₂ : (commonDisplayedPartialQuartets T₁ T₂ 2).card =
      Nat.choose (Fintype.card X) 2)
    (hcard₃ : (commonDisplayedPartialQuartets T₁ T₂ 3).card =
      3 * Nat.choose (Fintype.card X) 3) :
    T₁.IsPhylogenetic := by
  apply isPhylogenetic_of_injective_and_labels_are_leaves T₁
    (first_label_injective_of_common_two_card_eq T₁ T₂ hcard₂)
  exact first_labels_are_leaves_of_common_three_card_eq
    T₁ T₂ hX hcard₂ hcard₃

/-- Saturation of the common support-size two and three ledgers forces the
second source tree to be phylogenetic (for at least three taxa). -/
theorem second_isPhylogenetic_of_common_two_three_card_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hX : 3 ≤ Fintype.card X)
    (hcard₂ : (commonDisplayedPartialQuartets T₁ T₂ 2).card =
      Nat.choose (Fintype.card X) 2)
    (hcard₃ : (commonDisplayedPartialQuartets T₁ T₂ 3).card =
      3 * Nat.choose (Fintype.card X) 3) :
    T₂.IsPhylogenetic := by
  apply isPhylogenetic_of_injective_and_labels_are_leaves T₂
    (second_label_injective_of_common_two_card_eq T₁ T₂ hcard₂)
  exact second_labels_are_leaves_of_common_three_card_eq
    T₁ T₂ hX hcard₂ hcard₃

/-! ## Saturation of the support-size four ledger -/

theorem commonQuartetSupports_subset_powersetCard_four
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) :
    commonQuartetSupports T₁ T₂ ⊆
      Finset.univ.powersetCard 4 := by
  classical
  intro S hS
  obtain ⟨P, hP, _hT₁, _hT₂, hPS⟩ :=
    (mem_commonQuartetSupports T₁ T₂ S).1 hS
  exact Finset.mem_powersetCard.mpr ⟨Finset.subset_univ S, by
    simpa [← hPS] using hP.support_card_four⟩

theorem commonQuartetSupports_eq_powersetCard_four_of_card_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hcard : (commonDisplayedPartialQuartets T₁ T₂ 4).card =
      Nat.choose (Fintype.card X) 4) :
    commonQuartetSupports T₁ T₂ =
      Finset.univ.powersetCard 4 := by
  apply Finset.eq_of_subset_of_card_le
    (commonQuartetSupports_subset_powersetCard_four T₁ T₂)
  rw [Finset.card_powersetCard, Finset.card_univ,
    card_commonQuartetSupports, hcard]

/-- Saturating the support-size four count gives an actual common displayed
full quartet on every prescribed four-taxon support. -/
theorem exists_common_displayed_quartet_of_card_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hcard : (commonDisplayedPartialQuartets T₁ T₂ 4).card =
      Nat.choose (Fintype.card X) 4)
    (S : Finset X) (hS : S.card = 4) :
    ∃ P : PartialSplit X,
      IsQuartet P ∧ T₁.DisplaysPartialSplit P ∧
        T₂.DisplaysPartialSplit P ∧ partialSplitSupport P = S := by
  classical
  apply (mem_commonQuartetSupports T₁ T₂ S).1
  rw [commonQuartetSupports_eq_powersetCard_four_of_card_eq T₁ T₂ hcard]
  exact Finset.mem_powersetCard.mpr ⟨Finset.subset_univ S, hS⟩

/-! ## The three resolutions on a fixed four-taxon support -/

/-- A full quartet on the prescribed four distinct taxa is exactly one of the
three pair-pair resolutions.  This is proved from the two-element cardinality
of each represented side, not taken as an informal classification principle. -/
theorem quartet_eq_one_of_three_on_fixed_support
    [DecidableEq X]
    {a b c d : X}
    (hab : a ≠ b) (hac : a ≠ c) (had : a ≠ d)
    (hbc : b ≠ c) (hbd : b ≠ d) (hcd : c ≠ d)
    {P : PartialSplit X} (hP : IsQuartet P)
    (hsupport : partialSplitSupport P = ({a, b, c, d} : Finset X)) :
    P = s(({a, b} : Finset X), ({c, d} : Finset X)) ∨
      P = s(({a, c} : Finset X), ({b, d} : Finset X)) ∨
      P = s(({a, d} : Finset X), ({b, c} : Finset X)) := by
  classical
  rcases hP with ⟨hpartial, A, B, hPAB, hAcard, hBcard⟩
  have hdisj : Disjoint A B := by
    subst P
    exact ((isPartialSplit_mk_iff A B).1 hpartial).2.2
  have hunion : A ∪ B = ({a, b, c, d} : Finset X) := by
    rw [hPAB, partialSplitSupport_mk] at hsupport
    exact hsupport
  have classify : ∀ (L R : Finset X),
      L.card = 2 → R.card = 2 → Disjoint L R →
      L ∪ R = ({a, b, c, d} : Finset X) → a ∈ L →
      s(L, R) = s(({a, b} : Finset X), ({c, d} : Finset X)) ∨
        s(L, R) = s(({a, c} : Finset X), ({b, d} : Finset X)) ∨
        s(L, R) = s(({a, d} : Finset X), ({b, c} : Finset X)) := by
    intro L R hLcard hRcard hLR hunionLR haL
    have hEraseCard : (L.erase a).card = 1 := by
      rw [Finset.card_erase_of_mem haL, hLcard]
    obtain ⟨t, htErase⟩ : (L.erase a).Nonempty :=
      Finset.card_pos.mp (by omega)
    have hta : t ≠ a := (Finset.mem_erase.mp htErase).1
    have htL : t ∈ L := Finset.mem_of_mem_erase htErase
    have htSupport : t ∈ ({a, b, c, d} : Finset X) := by
      rw [← hunionLR]
      exact Finset.mem_union_left R htL
    have htcases : t = a ∨ t = b ∨ t = c ∨ t = d := by
      simpa only [Finset.mem_insert, Finset.mem_singleton] using htSupport
    have pair_subset : ∀ {p q : X} (S : Finset X),
        p ∈ S → q ∈ S → ({p, q} : Finset X) ⊆ S := by
      intro p q S hp hq z hz
      have hz' : z = p ∨ z = q := by
        simpa only [Finset.mem_insert, Finset.mem_singleton] using hz
      exact hz'.elim (fun h => h.symm ▸ hp) (fun h => h.symm ▸ hq)
    rcases htcases with hta' | htb | htc | htd
    · exact (hta hta').elim
    · subst t
      have hpairL : ({a, b} : Finset X) = L :=
        Finset.eq_of_subset_of_card_le (pair_subset L haL htL) (by
          rw [hLcard, Finset.card_pair hab])
      have hcR : c ∈ R := by
        have hcUnion : c ∈ L ∪ R := by rw [hunionLR]; simp
        rcases Finset.mem_union.mp hcUnion with hcL | hcR
        · have : c ∈ ({a, b} : Finset X) := by simpa [hpairL] using hcL
          have hc : c = a ∨ c = b := by
            simpa only [Finset.mem_insert, Finset.mem_singleton] using this
          rcases hc with hca | hcb
          · exact (hac hca.symm).elim
          · exact (hbc hcb.symm).elim
        · exact hcR
      have hdR : d ∈ R := by
        have hdUnion : d ∈ L ∪ R := by rw [hunionLR]; simp
        rcases Finset.mem_union.mp hdUnion with hdL | hdR
        · have : d ∈ ({a, b} : Finset X) := by simpa [hpairL] using hdL
          have hd : d = a ∨ d = b := by
            simpa only [Finset.mem_insert, Finset.mem_singleton] using this
          rcases hd with hda | hdb
          · exact (had hda.symm).elim
          · exact (hbd hdb.symm).elim
        · exact hdR
      have hpairR : ({c, d} : Finset X) = R :=
        Finset.eq_of_subset_of_card_le (pair_subset R hcR hdR) (by
          rw [hRcard, Finset.card_pair hcd])
      exact Or.inl (by rw [← hpairL, ← hpairR])
    · subst t
      have hpairL : ({a, c} : Finset X) = L :=
        Finset.eq_of_subset_of_card_le (pair_subset L haL htL) (by
          rw [hLcard, Finset.card_pair hac])
      have hbR : b ∈ R := by
        have hbUnion : b ∈ L ∪ R := by rw [hunionLR]; simp
        rcases Finset.mem_union.mp hbUnion with hbL | hbR
        · have : b ∈ ({a, c} : Finset X) := by simpa [hpairL] using hbL
          have hb : b = a ∨ b = c := by
            simpa only [Finset.mem_insert, Finset.mem_singleton] using this
          rcases hb with hba | hbc'
          · exact (hab hba.symm).elim
          · exact (hbc hbc').elim
        · exact hbR
      have hdR : d ∈ R := by
        have hdUnion : d ∈ L ∪ R := by rw [hunionLR]; simp
        rcases Finset.mem_union.mp hdUnion with hdL | hdR
        · have : d ∈ ({a, c} : Finset X) := by simpa [hpairL] using hdL
          have hd : d = a ∨ d = c := by
            simpa only [Finset.mem_insert, Finset.mem_singleton] using this
          rcases hd with hda | hdc
          · exact (had hda.symm).elim
          · exact (hcd hdc.symm).elim
        · exact hdR
      have hpairR : ({b, d} : Finset X) = R :=
        Finset.eq_of_subset_of_card_le (pair_subset R hbR hdR) (by
          rw [hRcard, Finset.card_pair hbd])
      exact Or.inr (Or.inl (by rw [← hpairL, ← hpairR]))
    · subst t
      have hpairL : ({a, d} : Finset X) = L :=
        Finset.eq_of_subset_of_card_le (pair_subset L haL htL) (by
          rw [hLcard, Finset.card_pair had])
      have hbR : b ∈ R := by
        have hbUnion : b ∈ L ∪ R := by rw [hunionLR]; simp
        rcases Finset.mem_union.mp hbUnion with hbL | hbR
        · have : b ∈ ({a, d} : Finset X) := by simpa [hpairL] using hbL
          have hb : b = a ∨ b = d := by
            simpa only [Finset.mem_insert, Finset.mem_singleton] using this
          rcases hb with hba | hbd'
          · exact (hab hba.symm).elim
          · exact (hbd hbd').elim
        · exact hbR
      have hcR : c ∈ R := by
        have hcUnion : c ∈ L ∪ R := by rw [hunionLR]; simp
        rcases Finset.mem_union.mp hcUnion with hcL | hcR
        · have : c ∈ ({a, d} : Finset X) := by simpa [hpairL] using hcL
          have hc : c = a ∨ c = d := by
            simpa only [Finset.mem_insert, Finset.mem_singleton] using this
          rcases hc with hca | hcd'
          · exact (hac hca.symm).elim
          · exact (hcd hcd').elim
        · exact hcR
      have hpairR : ({b, c} : Finset X) = R :=
        Finset.eq_of_subset_of_card_le (pair_subset R hbR hcR) (by
          rw [hRcard, Finset.card_pair hbc])
      exact Or.inr (Or.inr (by rw [← hpairL, ← hpairR]))
  have haUnion : a ∈ A ∪ B := by rw [hunion]; simp
  rw [hPAB]
  rcases Finset.mem_union.mp haUnion with haA | haB
  · exact classify A B hAcard hBcard hdisj hunion haA
  · exact (Or.imp Sym2.eq_swap.trans
      (Or.imp Sym2.eq_swap.trans Sym2.eq_swap.trans))
      (classify B A hBcard hAcard hdisj.symm (by
        simpa [Finset.union_comm] using hunion) haB)

/-! ## Four-support saturation forces degree three -/

/-- A phylogenetic tree on at least four taxa which displays a full quartet on
every four-taxon support is binary.  The only nontrivial point is to rule out a
vertex of degree at least four; four distinct incident branches would force a
displaying edge to lie in two edge-disjoint cross paths. -/
theorem isBinaryPhylogenetic_of_all_four_supports_displayed
    (T : XTree X V₁) (hX : 4 ≤ Fintype.card X)
    (hphy : T.IsPhylogenetic)
    (hall : ∀ S : Finset X, S.card = 4 →
      ∃ P : PartialSplit X, IsQuartet P ∧
        T.DisplaysPartialSplit P ∧ partialSplitSupport P = S) :
    T.IsBinaryPhylogenetic := by
  classical
  letI : Nontrivial X := Fintype.one_lt_card_iff_nontrivial.mp (by omega)
  letI : Nontrivial V₁ := hphy.1.nontrivial
  refine ⟨hphy, ?_⟩
  intro centre hnotLeaf
  have hdegreePos : 0 < Nat.card (T.graph.neighborSet centre) := by
    rw [Nat.card_eq_fintype_card, T.graph.card_neighborSet_eq_degree]
    exact T.isTree.preconnected.degree_pos_of_nontrivial centre
  have hdegreeNeOne : Nat.card (T.graph.neighborSet centre) ≠ 1 := by
    simpa [XTree.IsLeaf] using hnotLeaf
  have hdegreeNeTwo : Nat.card (T.graph.neighborSet centre) ≠ 2 :=
    hphy.degree_ne_two T centre
  by_contra hdegreeNeThree
  let N : Finset V₁ := T.neighborFinset centre
  have hNlarge : 3 < N.card := by
    change 3 < (T.neighborFinset centre).card
    rw [T.card_neighborFinset]
    omega
  obtain ⟨b₁, b₂, b₃, b₄, hb₁N, hb₂N, hb₃N, hb₄N,
      hb₁₂, hb₁₃, hb₁₄, hb₂₃, hb₂₄, hb₃₄⟩ :=
    Finset.three_lt_card_iff.mp hNlarge
  have hb₁ : T.graph.Adj centre b₁ :=
    (T.mem_neighborFinset centre b₁).1 hb₁N
  have hb₂ : T.graph.Adj centre b₂ :=
    (T.mem_neighborFinset centre b₂).1 hb₂N
  have hb₃ : T.graph.Adj centre b₃ :=
    (T.mem_neighborFinset centre b₃).1 hb₃N
  have hb₄ : T.graph.Adj centre b₄ :=
    (T.mem_neighborFinset centre b₄).1 hb₄N
  obtain ⟨x₁, hx₁⟩ := T.edgeSide_nonempty_of_adj hb₁
  obtain ⟨x₂, hx₂⟩ := T.edgeSide_nonempty_of_adj hb₂
  obtain ⟨x₃, hx₃⟩ := T.edgeSide_nonempty_of_adj hb₃
  obtain ⟨x₄, hx₄⟩ := T.edgeSide_nonempty_of_adj hb₄
  have hx₁₂ : x₁ ≠ x₂ :=
    taxon_ne_of_mem_distinct_branches T hb₁ hb₂ hb₁₂ hx₁ hx₂
  have hx₁₃ : x₁ ≠ x₃ :=
    taxon_ne_of_mem_distinct_branches T hb₁ hb₃ hb₁₃ hx₁ hx₃
  have hx₁₄ : x₁ ≠ x₄ :=
    taxon_ne_of_mem_distinct_branches T hb₁ hb₄ hb₁₄ hx₁ hx₄
  have hx₂₃ : x₂ ≠ x₃ :=
    taxon_ne_of_mem_distinct_branches T hb₂ hb₃ hb₂₃ hx₂ hx₃
  have hx₂₄ : x₂ ≠ x₄ :=
    taxon_ne_of_mem_distinct_branches T hb₂ hb₄ hb₂₄ hx₂ hx₄
  have hx₃₄ : x₃ ≠ x₄ :=
    taxon_ne_of_mem_distinct_branches T hb₃ hb₄ hb₃₄ hx₃ hx₄
  let S : Finset X := {x₁, x₂, x₃, x₄}
  have hScard : S.card = 4 := by
    dsimp [S]
    simp [hx₁₂, hx₁₃, hx₁₄, hx₂₃, hx₂₄, hx₃₄]
  obtain ⟨P, hP, hdisplay, hsupport⟩ := hall S hScard
  have hcases := quartet_eq_one_of_three_on_fixed_support
    hx₁₂ hx₁₃ hx₁₄ hx₂₃ hx₂₄ hx₃₄ hP
      (by simpa [S] using hsupport)
  rcases hdisplay with ⟨u, v, huv, hdispEdge⟩
  rcases hcases with hcase₁ | hcase₂ | hcase₃
  · rw [hcase₁] at hdispEdge
    have hpaths :=
      (T.displays_edgeSplit_iff_mem_all_cross_paths huv
        ({x₁, x₂} : Finset X) ({x₃, x₄} : Finset X)
        (by simp) (by simp)).1 hdispEdge
    have h₁₃ : s(u, v) ∈ (T.taxonPath x₁ x₃).edges :=
      hpaths x₁ (by simp) x₃ (by simp)
    have h₂₄ : s(u, v) ∈ (T.taxonPath x₂ x₄).edges :=
      hpaths x₂ (by simp) x₄ (by simp)
    have hdisj := taxonPath_edges_disjoint_of_four_distinct_branches T
      hb₁ hb₂ hb₃ hb₄ hb₁₂ hb₁₃ hb₁₄ hb₂₃ hb₂₄ hb₃₄
      hx₁ hx₂ hx₃ hx₄
    exact (List.disjoint_left.mp hdisj) h₁₃ h₂₄
  · rw [hcase₂] at hdispEdge
    have hpaths :=
      (T.displays_edgeSplit_iff_mem_all_cross_paths huv
        ({x₁, x₃} : Finset X) ({x₂, x₄} : Finset X)
        (by simp) (by simp)).1 hdispEdge
    have h₁₂ : s(u, v) ∈ (T.taxonPath x₁ x₂).edges :=
      hpaths x₁ (by simp) x₂ (by simp)
    have h₃₄ : s(u, v) ∈ (T.taxonPath x₃ x₄).edges :=
      hpaths x₃ (by simp) x₄ (by simp)
    have hdisj := taxonPath_edges_disjoint_of_four_distinct_branches T
      hb₁ hb₃ hb₂ hb₄ hb₁₃ hb₁₂ hb₁₄ hb₂₃.symm hb₃₄ hb₂₄
      hx₁ hx₃ hx₂ hx₄
    exact (List.disjoint_left.mp hdisj) h₁₂ h₃₄
  · rw [hcase₃] at hdispEdge
    have hpaths :=
      (T.displays_edgeSplit_iff_mem_all_cross_paths huv
        ({x₁, x₄} : Finset X) ({x₂, x₃} : Finset X)
        (by simp) (by simp)).1 hdispEdge
    have h₁₂ : s(u, v) ∈ (T.taxonPath x₁ x₂).edges :=
      hpaths x₁ (by simp) x₂ (by simp)
    have h₄₃ : s(u, v) ∈ (T.taxonPath x₄ x₃).edges :=
      hpaths x₄ (by simp) x₃ (by simp)
    have hdisj := taxonPath_edges_disjoint_of_four_distinct_branches T
      hb₁ hb₄ hb₂ hb₃ hb₁₄ hb₁₂ hb₁₃ hb₂₄.symm hb₃₄.symm hb₂₃
      hx₁ hx₄ hx₂ hx₃
    exact (List.disjoint_left.mp hdisj) h₁₂ h₄₃

/-- Saturation of the common ledgers of support sizes two, three, and four
forces the first tree to be binary phylogenetic when there are at least four
taxa. -/
theorem first_isBinaryPhylogenetic_of_common_two_three_four_card_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hX : 4 ≤ Fintype.card X)
    (hcard₂ : (commonDisplayedPartialQuartets T₁ T₂ 2).card =
      Nat.choose (Fintype.card X) 2)
    (hcard₃ : (commonDisplayedPartialQuartets T₁ T₂ 3).card =
      3 * Nat.choose (Fintype.card X) 3)
    (hcard₄ : (commonDisplayedPartialQuartets T₁ T₂ 4).card =
      Nat.choose (Fintype.card X) 4) :
    T₁.IsBinaryPhylogenetic := by
  apply isBinaryPhylogenetic_of_all_four_supports_displayed T₁ hX
    (first_isPhylogenetic_of_common_two_three_card_eq T₁ T₂
      (by omega) hcard₂ hcard₃)
  intro S hS
  obtain ⟨P, hP, hT₁, _hT₂, hsupport⟩ :=
    exists_common_displayed_quartet_of_card_eq T₁ T₂ hcard₄ S hS
  exact ⟨P, hP, hT₁, hsupport⟩

/-- Saturation of the common ledgers of support sizes two, three, and four
forces the second tree to be binary phylogenetic when there are at least four
taxa. -/
theorem second_isBinaryPhylogenetic_of_common_two_three_four_card_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hX : 4 ≤ Fintype.card X)
    (hcard₂ : (commonDisplayedPartialQuartets T₁ T₂ 2).card =
      Nat.choose (Fintype.card X) 2)
    (hcard₃ : (commonDisplayedPartialQuartets T₁ T₂ 3).card =
      3 * Nat.choose (Fintype.card X) 3)
    (hcard₄ : (commonDisplayedPartialQuartets T₁ T₂ 4).card =
      Nat.choose (Fintype.card X) 4) :
    T₂.IsBinaryPhylogenetic := by
  apply isBinaryPhylogenetic_of_all_four_supports_displayed T₂ hX
    (second_isPhylogenetic_of_common_two_three_card_eq T₁ T₂
      (by omega) hcard₂ hcard₃)
  intro S hS
  obtain ⟨P, hP, _hT₁, hT₂, hsupport⟩ :=
    exists_common_displayed_quartet_of_card_eq T₁ T₂ hcard₄ S hS
  exact ⟨P, hP, hT₂, hsupport⟩

/-- Saturation of the common support-size four ledger makes the two displayed
full-quartet systems equal, pointwise.  The common quartet on the support of
`P` is unique in either source tree. -/
theorem displaysFullQuartet_iff_of_common_four_card_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hcard₄ : (commonDisplayedPartialQuartets T₁ T₂ 4).card =
      Nat.choose (Fintype.card X) 4)
    {P : PartialSplit X} (hP : IsQuartet P) :
    T₁.DisplaysPartialSplit P ↔ T₂.DisplaysPartialSplit P := by
  classical
  have hsupportCard : (partialSplitSupport P).card = 4 := hP.support_card_four
  obtain ⟨Q, hQ, hT₁Q, hT₂Q, hsupportQ⟩ :=
    exists_common_displayed_quartet_of_card_eq T₁ T₂ hcard₄
      (partialSplitSupport P) hsupportCard
  constructor
  · intro hT₁P
    have hPQ : P = Q := T₁.displayed_quartet_unique_on_support
      hP hQ hT₁P hT₁Q hsupportQ.symm
    simpa [hPQ] using hT₂Q
  · intro hT₂P
    have hPQ : P = Q := T₂.displayed_quartet_unique_on_support
      hP hQ hT₂P hT₂Q hsupportQ.symm
    simpa [hPQ] using hT₁Q

end QDFull
