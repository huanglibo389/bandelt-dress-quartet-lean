import QDFull.TreeReconstruction

/-!
# Rooted cluster reconstruction

This file reconstructs a finite phylogenetic tree from the hierarchy obtained
by orienting every edge away from one fixed labelled leaf.  The construction
is intrinsic to `XTree`: no version of the Buneman reconstruction theorem is
assumed.
-/

open SimpleGraph

namespace QDFull

universe uX uV uV₁ uV₂

variable {X : Type uX} {V : Type uV} {V₁ : Type uV₁} {V₂ : Type uV₂}
  [Fintype X] [Fintype V] [Fintype V₁] [Fintype V₂]
  [DecidableEq X] [DecidableEq V] [DecidableEq V₁] [DecidableEq V₂]

namespace XTree

variable (T : XTree X V)

/-- The predecessor of `v` on the unique path from the labelled root `r`.
At the root itself this harmlessly evaluates to the root. -/
noncomputable def rootParent (r : X) (v : V) : V :=
  (T.vertexPath (T.label r) v).penultimate

/-- A non-root vertex is adjacent to its predecessor on the rooted path. -/
theorem rootParent_adj (r : X) {v : V} (hv : v ≠ T.label r) :
    T.graph.Adj (T.rootParent r v) v := by
  have hnonNil : ¬(T.vertexPath (T.label r) v).Nil := by
    intro hnil
    exact hv hnil.eq.symm
  exact (T.vertexPath (T.label r) v).adj_penultimate hnonNil

/-- The root taxon lies on the root side of the incoming edge of every
non-root vertex. -/
theorem root_mem_reverse_edgeSide_rootParent
    (r : X) {v : V} (hv : v ≠ T.label r) :
    r ∈ T.edgeSide v (T.rootParent r v) := by
  classical
  let p := T.vertexPath (T.label r) v
  have hpPath : p.IsPath := T.vertexPath_isPath (T.label r) v
  have hpNonNil : ¬p.Nil := by
    intro hnil
    exact hv hnil.eq.symm
  have hparentAdj : T.graph.Adj (T.rootParent r v) v :=
    T.rootParent_adj r hv
  have hlast : s(T.rootParent r v, v) ∈ p.edges :=
    p.mk_penultimate_end_mem_edges hpNonNil
  have hnotReach :
      ¬(T.graph.deleteEdges {s(T.rootParent r v, v)}).Reachable
        (T.label r) v := by
    simpa [p] using
      (T.mem_vertexPath_edges_iff_not_reachable_delete
        (T.label r) v s(T.rootParent r v, v)).1 hlast
  have hcover :=
    T.mem_edgeSide_or_mem_edgeSide_reverse_of_adj hparentAdj r
  rcases hcover with hfar | hroot
  · exfalso
    apply hnotReach
    exact ((T.mem_edgeSide (T.rootParent r v) v r).1 hfar).symm
  · exact hroot

/-- The taxon cluster below a rooted vertex.  The root carries all taxa; a
non-root vertex carries the component beyond its incoming edge. -/
noncomputable def rootedCluster (r : X) (v : V) : Finset X :=
  by
    classical
    exact if v = T.label r then Finset.univ
      else T.edgeSide (T.rootParent r v) v

@[simp] theorem rootedCluster_root (r : X) :
    T.rootedCluster r (T.label r) = Finset.univ := by
  simp [rootedCluster]

theorem rootedCluster_eq_edgeSide_rootParent
    (r : X) {v : V} (hv : v ≠ T.label r) :
    T.rootedCluster r v = T.edgeSide (T.rootParent r v) v := by
  simp [rootedCluster, hv]

theorem rootedCluster_nonempty
    (r : X) (v : V) : (T.rootedCluster r v).Nonempty := by
  classical
  by_cases hv : v = T.label r
  · subst v
    rw [T.rootedCluster_root]
    exact ⟨r, Finset.mem_univ r⟩
  · rw [T.rootedCluster_eq_edgeSide_rootParent r hv]
    exact T.edgeSide_nonempty_of_adj (T.rootParent_adj r hv)

theorem root_not_mem_rootedCluster (r : X) {v : V}
    (hv : v ≠ T.label r) : r ∉ T.rootedCluster r v := by
  classical
  rw [T.rootedCluster_eq_edgeSide_rootParent r hv]
  exact fun hfar => (Finset.disjoint_left.mp
    (T.edgeSide_disjoint_reverse_of_adj (T.rootParent_adj r hv)))
      hfar (T.root_mem_reverse_edgeSide_rootParent r hv)

/-- If an oriented edge has the root on its near side, then its far endpoint
has that edge as its rooted incoming edge. -/
theorem rootParent_eq_of_root_mem_reverse_edgeSide
    (r : X) {p q : V} (hpq : T.graph.Adj p q)
    (hr : r ∈ T.edgeSide q p) :
    T.rootParent r q = p := by
  classical
  let w := T.vertexPath (T.label r) q
  have hbridge :
      ¬(T.graph.deleteEdges {s(p, q)}).Reachable p q :=
    (SimpleGraph.isAcyclic_iff_forall_adj_isBridge.mp
      T.isTree.isAcyclic hpq)
  have hrootP :
      (T.graph.deleteEdges {s(p, q)}).Reachable p (T.label r) := by
    rw [T.mem_edgeSide] at hr
    simpa only [Sym2.eq_swap] using hr
  have hnotRootQ :
      ¬(T.graph.deleteEdges {s(p, q)}).Reachable (T.label r) q := by
    intro hrootQ
    exact hbridge (hrootP.trans hrootQ)
  have hedge : s(p, q) ∈ w.edges := by
    simpa [w] using
      (T.mem_vertexPath_edges_iff_not_reachable_delete
        (T.label r) q s(p, q)).2 hnotRootQ
  have hp : p = w.penultimate :=
    (T.vertexPath_isPath (T.label r) q).eq_penultimate_of_mem_edges
      (by simpa only [Sym2.eq_swap] using hedge)
  simpa [rootParent, w] using hp.symm

/-- Every actual edge has exactly one orientation away from the root.  In
that orientation its taxon side is precisely the rooted cluster of the far
endpoint. -/
theorem edgeSide_eq_rootedCluster_of_root_mem_reverse
    (r : X) {p q : V} (hpq : T.graph.Adj p q)
    (hr : r ∈ T.edgeSide q p) :
    T.edgeSide p q = T.rootedCluster r q := by
  classical
  have hq : q ≠ T.label r := by
    intro hq
    subst q
    have hfar : r ∈ T.edgeSide p (T.label r) := by
      exact (T.mem_edgeSide p (T.label r) r).2 ⟨Walk.nil⟩
    exact (Finset.disjoint_left.mp
      (T.edgeSide_disjoint_reverse_of_adj hpq)) hfar hr
  rw [T.rootedCluster_eq_edgeSide_rootParent r hq,
    T.rootParent_eq_of_root_mem_reverse_edgeSide r hpq hr]

/-- Conversely, the incoming edge of a non-root vertex displays the full
split consisting of its rooted cluster and its complement. -/
theorem edgeSplit_rootParent_eq_cluster_compl
    (r : X) {v : V} (hv : v ≠ T.label r) :
    T.edgeSplit (T.rootParent r v) v =
      s(T.rootedCluster r v, Finset.univ \ T.rootedCluster r v) := by
  classical
  rw [XTree.edgeSplit, T.rootedCluster_eq_edgeSide_rootParent r hv,
    T.edgeSide_reverse_eq_sdiff_univ (T.rootParent_adj r hv)]

/-! ## Strict descent along rooted paths -/

/-- In a tree the chosen simple path is automatically a shortest path. -/
theorem vertexPath_length_eq_dist (u v : V) :
    (T.vertexPath u v).length = T.graph.dist u v := by
  obtain ⟨p, hpPath, hpLength⟩ :=
    (T.isTree.connected u v).exists_path_of_dist
  have hpEq : T.vertexPath u v = p :=
    (T.isTree.existsUnique_path u v).unique
      (T.vertexPath_isPath u v) hpPath
  simpa only [hpEq] using hpLength

/-- Cutting the unique path at one of its support vertices gives the unique
path to that vertex. -/
theorem vertexPath_eq_takeUntil {u v z : V}
    (hz : z ∈ (T.vertexPath u v).support) :
    T.vertexPath u z = (T.vertexPath u v).takeUntil z hz := by
  classical
  exact (T.isTree.existsUnique_path u z).unique
    (T.vertexPath_isPath u z)
    ((T.vertexPath_isPath u v).takeUntil hz)

/-- A proper support vertex of a rooted path is strictly closer to the root
than the endpoint. -/
theorem dist_lt_dist_of_mem_vertexPath_support
    {u v z : V} (hz : z ∈ (T.vertexPath u v).support) (hzv : z ≠ v) :
    T.graph.dist u z < T.graph.dist u v := by
  classical
  calc
    T.graph.dist u z = (T.vertexPath u z).length :=
      (T.vertexPath_length_eq_dist u z).symm
    _ = ((T.vertexPath u v).takeUntil z hz).length := by
      exact congrArg (fun q => q.length) (T.vertexPath_eq_takeUntil hz)
    _ < (T.vertexPath u v).length :=
      (T.vertexPath u v).length_takeUntil_lt_length hz hzv
    _ = T.graph.dist u v := T.vertexPath_length_eq_dist u v

/-- Two support vertices of one rooted path occurring at the same distance
from the root are the same vertex. -/
theorem eq_of_mem_vertexPath_support_of_dist_eq
    {u v z w : V}
    (hz : z ∈ (T.vertexPath u v).support)
    (hw : w ∈ (T.vertexPath u v).support)
    (hdist : T.graph.dist u z = T.graph.dist u w) : z = w := by
  classical
  let p := T.vertexPath u v
  have hzLength : (p.takeUntil z hz).length = T.graph.dist u z := by
    calc
      (p.takeUntil z hz).length = (T.vertexPath u z).length := by
        simpa only [p] using congrArg (fun q => q.length)
          (T.vertexPath_eq_takeUntil hz).symm
      _ = T.graph.dist u z := T.vertexPath_length_eq_dist u z
  have hwLength : (p.takeUntil w hw).length = T.graph.dist u w := by
    calc
      (p.takeUntil w hw).length = (T.vertexPath u w).length := by
        simpa only [p] using congrArg (fun q => q.length)
          (T.vertexPath_eq_takeUntil hw).symm
      _ = T.graph.dist u w := T.vertexPath_length_eq_dist u w
  apply (List.idxOf_inj hz).1
  rw [← p.length_takeUntil hz, ← p.length_takeUntil hw,
    hzLength, hwLength, hdist]

/-- If two vertices occur on one rooted path and the first is no deeper than
the second, then the first also occurs on the path ending at the second. -/
theorem mem_vertexPath_support_of_common_support_of_dist_le
    {u endpoint z w : V}
    (hz : z ∈ (T.vertexPath u endpoint).support)
    (hw : w ∈ (T.vertexPath u endpoint).support)
    (hle : T.graph.dist u z ≤ T.graph.dist u w) :
    z ∈ (T.vertexPath u w).support := by
  classical
  let p := T.vertexPath u endpoint
  have hzLength : (p.takeUntil z hz).length = T.graph.dist u z := by
    calc
      (p.takeUntil z hz).length = (T.vertexPath u z).length := by
        simpa only [p] using congrArg (fun q => q.length)
          (T.vertexPath_eq_takeUntil hz).symm
      _ = T.graph.dist u z := T.vertexPath_length_eq_dist u z
  have hwLength : (p.takeUntil w hw).length = T.graph.dist u w := by
    calc
      (p.takeUntil w hw).length = (T.vertexPath u w).length := by
        simpa only [p] using congrArg (fun q => q.length)
          (T.vertexPath_eq_takeUntil hw).symm
      _ = T.graph.dist u w := T.vertexPath_length_eq_dist u w
  have hidx : p.support.idxOf z ≤ p.support.idxOf w := by
    rw [← p.length_takeUntil hz, ← p.length_takeUntil hw,
      hzLength, hwLength]
    exact hle
  rw [T.vertexPath_eq_takeUntil hw, p.takeUntil_eq_take,
    Walk.support_copy, Walk.support_take]
  exact (List.mem_take_iff_idxOf_lt hz).2 (Nat.lt_succ_of_le hidx)

/-- Passing from a non-root vertex to its rooted predecessor decreases the
root distance by exactly one. -/
theorem rootParent_dist_add_one (r : X) {v : V}
    (hv : v ≠ T.label r) :
    T.graph.dist (T.label r) (T.rootParent r v) + 1 =
      T.graph.dist (T.label r) v := by
  let p := T.vertexPath (T.label r) v
  have hpNonNil : ¬p.Nil := by
    intro hpNil
    exact hv hpNil.eq.symm
  have hpDropPath : p.dropLast.IsPath :=
    (T.vertexPath_isPath (T.label r) v).dropLast
  have hprefix :
      T.vertexPath (T.label r) (T.rootParent r v) = p.dropLast :=
    (T.isTree.existsUnique_path (T.label r) (T.rootParent r v)).unique
      (T.vertexPath_isPath (T.label r) (T.rootParent r v)) hpDropPath
  calc
    T.graph.dist (T.label r) (T.rootParent r v) + 1 =
        (T.vertexPath (T.label r) (T.rootParent r v)).length + 1 := by
          rw [T.vertexPath_length_eq_dist]
    _ = p.dropLast.length + 1 :=
      congrArg (fun q => q.length + 1) hprefix
    _ = p.length := p.length_dropLast_add_one hpNonNil
    _ = T.graph.dist (T.label r) v := T.vertexPath_length_eq_dist _ _

/-- Every non-root cluster is a strict subset of its parent's cluster.  This
is the local fact that rules out invisible degree-two subdivisions. -/
theorem rootedCluster_ssubset_parent (r : X) {v : V}
    (hv : v ≠ T.label r) :
    T.rootedCluster r v ⊂ T.rootedCluster r (T.rootParent r v) := by
  classical
  by_cases hp : T.rootParent r v = T.label r
  · rw [hp, T.rootedCluster_root]
    apply (Finset.ssubset_iff_of_subset (Finset.subset_univ _)).2
    exact ⟨r, Finset.mem_univ r, T.root_not_mem_rootedCluster r hv⟩
  · have hgrandNe : T.rootParent r (T.rootParent r v) ≠ v := by
      intro hgrand
      have hparentDepth := T.rootParent_dist_add_one r hv
      have hgrandDepth := T.rootParent_dist_add_one r hp
      rw [hgrand] at hgrandDepth
      omega
    rw [T.rootedCluster_eq_edgeSide_rootParent r hv,
      T.rootedCluster_eq_edgeSide_rootParent r hp]
    exact T.edgeSide_ssubset_parentSide
      (T.rootParent_adj r hp) (T.rootParent_adj r hv) hgrandNe

/-- A taxon lying in the rooted cluster of `v` certifies that `v` lies on the
unique path from the root label to that taxon's label. -/
theorem mem_vertexPath_root_label_of_mem_rootedCluster
    (r : X) {v : V} {x : X} (hx : x ∈ T.rootedCluster r v) :
    v ∈ (T.vertexPath (T.label r) (T.label x)).support := by
  classical
  by_cases hv : v = T.label r
  · subst v
    exact Walk.start_mem_support _
  · rw [T.rootedCluster_eq_edgeSide_rootParent r hv] at hx
    have hedge : s(T.rootParent r v, v) ∈ (T.taxonPath r x).edges :=
      (T.edge_mem_taxonPath_iff_opposite_sides
        (T.rootParent_adj r hv) r x).2
        (Or.inr ⟨T.root_mem_reverse_edgeSide_rootParent r hv, hx⟩)
    simpa only [XTree.taxonPath] using
      (T.taxonPath r x).snd_mem_support_of_mem_edges hedge

/-- Along one rooted path, a proper earlier vertex has a strictly larger
taxon cluster than the endpoint. -/
theorem rootedCluster_ssubset_of_mem_vertexPath_support
    (r : X) {v w : V}
    (hv : v ∈ (T.vertexPath (T.label r) w).support)
    (hvw : v ≠ w) :
    T.rootedCluster r w ⊂ T.rootedCluster r v := by
  classical
  have hdepth : T.graph.dist (T.label r) v <
      T.graph.dist (T.label r) w :=
    T.dist_lt_dist_of_mem_vertexPath_support hv hvw
  have hwRoot : w ≠ T.label r := by
    intro hw
    subst w
    simp at hdepth
  have hchild := T.rootedCluster_ssubset_parent r hwRoot
  by_cases hvParent : v = T.rootParent r w
  · simpa only [hvParent] using hchild
  · let p := T.vertexPath (T.label r) w
    have hpNonNil : ¬p.Nil := by
      intro hpNil
      exact hwRoot hpNil.eq.symm
    have hvDropList : v ∈ p.support.dropLast := by
      apply List.mem_dropLast_of_mem_of_ne_getLast hv
      exact fun hlast => hvw (hlast.trans p.getLast_support)
    have hvDrop : v ∈ p.dropLast.support := by
      rw [p.support_dropLast hpNonNil]
      exact hvDropList
    have hprefix :
        T.vertexPath (T.label r) (T.rootParent r w) = p.dropLast :=
      (T.isTree.existsUnique_path (T.label r) (T.rootParent r w)).unique
        (T.vertexPath_isPath (T.label r) (T.rootParent r w))
        ((T.vertexPath_isPath (T.label r) w).dropLast)
    have hvParentPath :
        v ∈ (T.vertexPath (T.label r) (T.rootParent r w)).support := by
      rw [hprefix]
      exact hvDrop
    have hparentDepth := T.rootParent_dist_add_one r hwRoot
    have hrec := rootedCluster_ssubset_of_mem_vertexPath_support
      r hvParentPath hvParent
    exact lt_trans hchild hrec
termination_by T.graph.dist (T.label r) w
decreasing_by
  omega

/-- Distinct vertices have distinct rooted taxon clusters.  The proof chooses
a taxon in a common putative cluster, places both vertices on the same
root-to-taxon path, and then uses equality of depths or strict cluster descent. -/
theorem rootedCluster_injective (r : X) :
    Function.Injective (T.rootedCluster r) := by
  classical
  intro v w hcluster
  by_cases hvRoot : v = T.label r
  · subst v
    by_contra hwRoot
    have hr : r ∈ T.rootedCluster r w := by
      rw [← hcluster, T.rootedCluster_root]
      exact Finset.mem_univ r
    exact T.root_not_mem_rootedCluster r (Ne.symm hwRoot) hr
  · by_cases hwRoot : w = T.label r
    · subst w
      exfalso
      have hr : r ∈ T.rootedCluster r v := by
        rw [hcluster, T.rootedCluster_root]
        exact Finset.mem_univ r
      exact T.root_not_mem_rootedCluster r hvRoot hr
    · obtain ⟨x, hxv⟩ := T.rootedCluster_nonempty r v
      have hxw : x ∈ T.rootedCluster r w := by
        rw [← hcluster]
        exact hxv
      have hvPath := T.mem_vertexPath_root_label_of_mem_rootedCluster r hxv
      have hwPath := T.mem_vertexPath_root_label_of_mem_rootedCluster r hxw
      by_cases hdepth : T.graph.dist (T.label r) v =
          T.graph.dist (T.label r) w
      · exact T.eq_of_mem_vertexPath_support_of_dist_eq
          hvPath hwPath hdepth
      · rcases lt_or_gt_of_ne hdepth with hvwDepth | hwvDepth
        · have hvInPathW :=
            T.mem_vertexPath_support_of_common_support_of_dist_le
              hvPath hwPath (Nat.le_of_lt hvwDepth)
          have hvw : v ≠ w := by
            intro hvw
            subst w
            exact hdepth rfl
          have hstrict :=
            T.rootedCluster_ssubset_of_mem_vertexPath_support
              r hvInPathW hvw
          exfalso
          exact (ne_of_lt hstrict) hcluster.symm
        · have hwInPathV :=
            T.mem_vertexPath_support_of_common_support_of_dist_le
              hwPath hvPath (Nat.le_of_lt hwvDepth)
          have hwv : w ≠ v := by
            intro hwv
            subst w
            exact hdepth rfl
          have hstrict :=
            T.rootedCluster_ssubset_of_mem_vertexPath_support
              r hwInPathV hwv
          exfalso
          exact (ne_of_lt hstrict) hcluster

/-- Strict inclusion of rooted clusters is exactly the proper-ancestor
relation on the rooted tree. -/
theorem rootedCluster_ssubset_iff_mem_vertexPath_support
    (r : X) {v w : V} :
    T.rootedCluster r w ⊂ T.rootedCluster r v ↔
      v ∈ (T.vertexPath (T.label r) w).support ∧ v ≠ w := by
  classical
  constructor
  · intro hstrict
    obtain ⟨x, hxw⟩ := T.rootedCluster_nonempty r w
    have hxv : x ∈ T.rootedCluster r v := hstrict.1 hxw
    have hwPath := T.mem_vertexPath_root_label_of_mem_rootedCluster r hxw
    have hvPath := T.mem_vertexPath_root_label_of_mem_rootedCluster r hxv
    have hvw : v ≠ w := by
      intro hvw
      subst w
      exact (ne_of_lt hstrict) rfl
    have hdepthNe : T.graph.dist (T.label r) v ≠
        T.graph.dist (T.label r) w := by
      intro hdepth
      exact hvw (T.eq_of_mem_vertexPath_support_of_dist_eq
        hvPath hwPath hdepth)
    rcases lt_or_gt_of_ne hdepthNe with hvDepth | hwDepth
    · exact ⟨T.mem_vertexPath_support_of_common_support_of_dist_le
        hvPath hwPath (Nat.le_of_lt hvDepth), hvw⟩
    · have hwInPathV :=
        T.mem_vertexPath_support_of_common_support_of_dist_le
          hwPath hvPath (Nat.le_of_lt hwDepth)
      have hreverse := T.rootedCluster_ssubset_of_mem_vertexPath_support
        r hwInPathV (Ne.symm hvw)
      exact False.elim (lt_asymm hstrict hreverse)
  · rintro ⟨hvPath, hvw⟩
    exact T.rootedCluster_ssubset_of_mem_vertexPath_support r hvPath hvw

/-- A taxon belongs to the rooted cluster of the vertex carrying that taxon.
This remains true when labels are noninjective or lie at internal vertices. -/
theorem label_mem_rootedCluster (r x : X) :
    x ∈ T.rootedCluster r (T.label x) := by
  classical
  by_cases hxRoot : T.label x = T.label r
  · rw [hxRoot, T.rootedCluster_root]
    exact Finset.mem_univ x
  · rw [T.rootedCluster_eq_edgeSide_rootParent r hxRoot,
      T.mem_edgeSide]

/-- The rooted cluster at the vertex carrying `x` is the least rooted cluster
that contains `x`.  This is the label-recovery principle for general
vertex-labelled `X`-trees. -/
theorem rootedCluster_label_subset_of_mem
    (r x : X) {v : V} (hx : x ∈ T.rootedCluster r v) :
    T.rootedCluster r (T.label x) ⊆ T.rootedCluster r v := by
  by_cases hv : v = T.label x
  · subst v
    exact Finset.Subset.rfl
  · exact (T.rootedCluster_ssubset_of_mem_vertexPath_support r
      (T.mem_vertexPath_root_label_of_mem_rootedCluster r hx) hv).1

/-- If an adjacent vertex is one level farther from the root, then the nearer
vertex is its rooted predecessor. -/
theorem rootParent_eq_of_adj_dist_add_one
    (r : X) {p v : V} (hpv : T.graph.Adj p v)
    (hdepth : T.graph.dist (T.label r) p + 1 =
      T.graph.dist (T.label r) v) :
    T.rootParent r v = p := by
  let q := (T.vertexPath (T.label r) p).concat hpv
  have hqLength : q.length = T.graph.dist (T.label r) v := by
    rw [Walk.length_concat, T.vertexPath_length_eq_dist, hdepth]
  have hqPath : q.IsPath := q.isPath_of_length_eq_dist hqLength
  have hqEq : T.vertexPath (T.label r) v = q :=
    (T.isTree.existsUnique_path (T.label r) v).unique
      (T.vertexPath_isPath (T.label r) v) hqPath
  rw [rootParent, hqEq]
  exact Walk.penultimate_concat _ _

/-! ## Recovering adjacency from the rooted-cluster hierarchy -/

/-- `RootedClusterCovers r p c` says that the cluster of `p` covers the
cluster of `c` in the strict-inclusion hierarchy: `p` is above `c`, and no
third vertex has a cluster strictly between them. -/
def RootedClusterCovers (r : X) (p c : V) : Prop :=
  T.rootedCluster r c ⊂ T.rootedCluster r p ∧
    ¬ ∃ z : V,
      T.rootedCluster r c ⊂ T.rootedCluster r z ∧
        T.rootedCluster r z ⊂ T.rootedCluster r p

/-- The rooted predecessor of every non-root vertex covers that vertex in
the cluster hierarchy. -/
theorem rootParent_rootedClusterCovers
    (r : X) {v : V} (hv : v ≠ T.label r) :
    T.RootedClusterCovers r (T.rootParent r v) v := by
  refine ⟨T.rootedCluster_ssubset_parent r hv, ?_⟩
  rintro ⟨z, hvz, hzp⟩
  have hzPath :=
    (T.rootedCluster_ssubset_iff_mem_vertexPath_support r).1 hvz
  have hpPath :=
    (T.rootedCluster_ssubset_iff_mem_vertexPath_support r).1 hzp
  have hzDepth :=
    T.dist_lt_dist_of_mem_vertexPath_support hzPath.1 hzPath.2
  have hpDepth :=
    T.dist_lt_dist_of_mem_vertexPath_support hpPath.1 hpPath.2
  have hparentDepth := T.rootParent_dist_add_one r hv
  omega

/-- Conversely, a cluster cover has to be the actual rooted predecessor.
There is no room for a hidden graph vertex between two consecutive clusters. -/
theorem rootParent_eq_of_rootedClusterCovers
    (r : X) {p v : V} (hcover : T.RootedClusterCovers r p v) :
    T.rootParent r v = p := by
  have hvRoot : v ≠ T.label r := by
    intro hv
    subst v
    have hstrict := hcover.1
    rw [T.rootedCluster_root] at hstrict
    exact (not_lt_of_ge (Finset.subset_univ _)) hstrict
  by_contra hparent
  apply hcover.2
  refine ⟨T.rootParent r v, T.rootedCluster_ssubset_parent r hvRoot, ?_⟩
  have hpPath :=
    (T.rootedCluster_ssubset_iff_mem_vertexPath_support r).1 hcover.1
  let q := T.vertexPath (T.label r) v
  have hqNonNil : ¬q.Nil := by
    intro hnil
    exact hvRoot hnil.eq.symm
  have hparentPath : T.rootParent r v ∈ q.support := by
    exact List.mem_of_mem_dropLast
      (q.penultimate_mem_dropLast_support hqNonNil)
  have hpDepth : T.graph.dist (T.label r) p <
      T.graph.dist (T.label r) v :=
    T.dist_lt_dist_of_mem_vertexPath_support hpPath.1 hpPath.2
  have hparentDepth := T.rootParent_dist_add_one r hvRoot
  have hpLeParent : T.graph.dist (T.label r) p ≤
      T.graph.dist (T.label r) (T.rootParent r v) := by
    omega
  have hpInParentPath :
      p ∈ (T.vertexPath (T.label r) (T.rootParent r v)).support :=
    T.mem_vertexPath_support_of_common_support_of_dist_le
      hpPath.1 hparentPath hpLeParent
  exact (T.rootedCluster_ssubset_iff_mem_vertexPath_support r).2
    ⟨hpInParentPath, Ne.symm hparent⟩

/-- A cluster cover is equivalent to being the rooted predecessor. -/
theorem rootedClusterCovers_iff_rootParent_eq
    (r : X) {p v : V} :
    T.RootedClusterCovers r p v ↔
      v ≠ T.label r ∧ T.rootParent r v = p := by
  constructor
  · intro hcover
    have hparent := T.rootParent_eq_of_rootedClusterCovers r hcover
    have hvRoot : v ≠ T.label r := by
      intro hv
      subst v
      have hstrict := hcover.1
      rw [T.rootedCluster_root] at hstrict
      exact (not_lt_of_ge (Finset.subset_univ _)) hstrict
    exact ⟨hvRoot, hparent⟩
  · rintro ⟨hvRoot, hparent⟩
    rw [← hparent]
    exact T.rootParent_rootedClusterCovers r hvRoot

/-- The undirected graph adjacency relation is recovered exactly from the
two possible orientations of the cluster-cover relation. -/
theorem adj_iff_rootedClusterCovers
    (r : X) {u v : V} :
    T.graph.Adj u v ↔
      T.RootedClusterCovers r u v ∨ T.RootedClusterCovers r v u := by
  constructor
  · intro huv
    rcases T.isTree.dist_eq_dist_add_one_of_adj (T.label r) huv with
      hdepth | hdepth
    · right
      have hparent : T.rootParent r u = v :=
        T.rootParent_eq_of_adj_dist_add_one r huv.symm hdepth.symm
      have huRoot : u ≠ T.label r := by
        intro hu
        subst u
        simp at hdepth
      exact (T.rootedClusterCovers_iff_rootParent_eq r).2
        ⟨huRoot, hparent⟩
    · left
      have hparent : T.rootParent r v = u :=
        T.rootParent_eq_of_adj_dist_add_one r huv hdepth.symm
      have hvRoot : v ≠ T.label r := by
        intro hv
        subst v
        simp at hdepth
      exact (T.rootedClusterCovers_iff_rootParent_eq r).2
        ⟨hvRoot, hparent⟩
  · rintro (huv | hvu)
    · have hdata := (T.rootedClusterCovers_iff_rootParent_eq r).1 huv
      rw [← hdata.2]
      exact T.rootParent_adj r hdata.1
    · have hdata := (T.rootedClusterCovers_iff_rootParent_eq r).1 hvu
      rw [← hdata.2]
      exact (T.rootParent_adj r hdata.1).symm

end XTree

/-! ## Transporting rooted clusters across an equal split system -/

/-- Inclusion of edge-split systems transports every rooted cluster.  The
two branches below are the two possible orientations of the unordered
`Sym2` split; membership of the root taxon selects the near side. -/
theorem rootedCluster_range_subset_of_edgeSplitSet_subset
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (r : X)
    (hsplit : T₁.edgeSplitSet ⊆ T₂.edgeSplitSet) :
    Set.range (T₁.rootedCluster r) ⊆ Set.range (T₂.rootedCluster r) := by
  classical
  rintro C ⟨v, rfl⟩
  by_cases hvRoot : v = T₁.label r
  · subst v
    exact ⟨T₂.label r, by
      rw [T₁.rootedCluster_root, T₂.rootedCluster_root]⟩
  · have hmem₁ :
        T₁.edgeSplit (T₁.rootParent r v) v ∈ T₁.edgeSplitSet :=
      ⟨T₁.rootParent r v, v, T₁.rootParent_adj r hvRoot, rfl⟩
    rcases hsplit hmem₁ with ⟨p, q, hpq, heq⟩
    have hsplitEq :
        s(T₁.rootedCluster r v,
          Finset.univ \ T₁.rootedCluster r v) =
          s(T₂.edgeSide p q, T₂.edgeSide q p) := by
      calc
        s(T₁.rootedCluster r v,
            Finset.univ \ T₁.rootedCluster r v) =
            T₁.edgeSplit (T₁.rootParent r v) v :=
          (T₁.edgeSplit_rootParent_eq_cluster_compl r hvRoot).symm
        _ = T₂.edgeSplit p q := heq
        _ = s(T₂.edgeSide p q, T₂.edgeSide q p) := rfl
    rw [Sym2.eq_iff] at hsplitEq
    have hrCompl :
        r ∈ Finset.univ \ T₁.rootedCluster r v := by
      simp [T₁.root_not_mem_rootedCluster r hvRoot]
    rcases hsplitEq with ⟨hfar, hnear⟩ | ⟨hfar, hnear⟩
    · have hrNear : r ∈ T₂.edgeSide q p := by
        rw [← hnear]
        exact hrCompl
      refine ⟨q, (hfar.trans
        (T₂.edgeSide_eq_rootedCluster_of_root_mem_reverse
          r hpq hrNear)).symm⟩
    · have hrNear : r ∈ T₂.edgeSide p q := by
        rw [← hnear]
        exact hrCompl
      refine ⟨p, (hfar.trans
        (T₂.edgeSide_eq_rootedCluster_of_root_mem_reverse
          r hpq.symm hrNear)).symm⟩

/-- Equal edge-split systems have exactly the same rooted-cluster hierarchy
for every fixed root taxon. -/
theorem rootedCluster_range_eq_of_edgeSplitSet_eq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (r : X)
    (hsplit : T₁.edgeSplitSet = T₂.edgeSplitSet) :
    Set.range (T₁.rootedCluster r) = Set.range (T₂.rootedCluster r) := by
  apply Set.Subset.antisymm
  · exact rootedCluster_range_subset_of_edgeSplitSet_subset
      T₁ T₂ r (by
        intro P hP
        rw [← hsplit]
        exact hP)
  · exact rootedCluster_range_subset_of_edgeSplitSet_subset
      T₂ T₁ r (by
        intro P hP
        rw [hsplit]
        exact hP)

/-- The canonical vertex equivalence obtained by identifying two injective
rooted-cluster maps with the same range. -/
noncomputable def rootedClusterEquivOfRangeEq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (r : X)
    (hrange : Set.range (T₁.rootedCluster r) =
      Set.range (T₂.rootedCluster r)) : V₁ ≃ V₂ :=
  (Equiv.ofInjective (T₁.rootedCluster r)
      (T₁.rootedCluster_injective r)).trans
    ((Equiv.setCongr hrange).trans
      (Equiv.ofInjective (T₂.rootedCluster r)
        (T₂.rootedCluster_injective r)).symm)

/-- The canonical vertex equivalence preserves its defining rooted cluster
exactly, not merely up to cardinality. -/
theorem rootedClusterEquivOfRangeEq_cluster
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (r : X)
    (hrange : Set.range (T₁.rootedCluster r) =
      Set.range (T₂.rootedCluster r)) (v : V₁) :
    T₂.rootedCluster r (rootedClusterEquivOfRangeEq T₁ T₂ r hrange v) =
      T₁.rootedCluster r v := by
  simp [rootedClusterEquivOfRangeEq,
    Equiv.apply_ofInjective_symm]

/-- Because cluster covers are defined entirely by strict inclusion and the
absence of an intermediate cluster, the canonical vertex equivalence
preserves them in both directions. -/
theorem rootedClusterEquivOfRangeEq_covers_iff
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (r : X)
    (hrange : Set.range (T₁.rootedCluster r) =
      Set.range (T₂.rootedCluster r)) (u v : V₁) :
    T₁.RootedClusterCovers r u v ↔
      T₂.RootedClusterCovers r
        (rootedClusterEquivOfRangeEq T₁ T₂ r hrange u)
        (rootedClusterEquivOfRangeEq T₁ T₂ r hrange v) := by
  let e := rootedClusterEquivOfRangeEq T₁ T₂ r hrange
  change T₁.RootedClusterCovers r u v ↔
    T₂.RootedClusterCovers r (e u) (e v)
  have hcluster (w : V₁) :
      T₂.rootedCluster r (e w) = T₁.rootedCluster r w :=
    rootedClusterEquivOfRangeEq_cluster T₁ T₂ r hrange w
  constructor
  · rintro ⟨huv, hno⟩
    refine ⟨?_, ?_⟩
    · simpa only [hcluster] using huv
    · rintro ⟨z₂, hvz, hzu⟩
      obtain ⟨z₁, rfl⟩ := e.surjective z₂
      apply hno
      refine ⟨z₁, ?_, ?_⟩
      · simpa only [hcluster] using hvz
      · simpa only [hcluster] using hzu
  · rintro ⟨huv, hno⟩
    refine ⟨?_, ?_⟩
    · simpa only [hcluster] using huv
    · rintro ⟨z₁, hvz, hzu⟩
      apply hno
      refine ⟨e z₁, ?_, ?_⟩
      · simpa only [hcluster] using hvz
      · simpa only [hcluster] using hzu

/-- The common rooted-cluster hierarchy reconstructs an isomorphism of the
underlying finite graphs. -/
noncomputable def rootedClusterGraphIsoOfRangeEq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (r : X)
    (hrange : Set.range (T₁.rootedCluster r) =
      Set.range (T₂.rootedCluster r)) : T₁.graph ≃g T₂.graph where
  toEquiv := rootedClusterEquivOfRangeEq T₁ T₂ r hrange
  map_rel_iff' := by
    intro u v
    rw [T₁.adj_iff_rootedClusterCovers r,
      T₂.adj_iff_rootedClusterCovers r]
    constructor
    · rintro (huv | hvu)
      · exact Or.inl
          ((rootedClusterEquivOfRangeEq_covers_iff
            T₁ T₂ r hrange u v).2 huv)
      · exact Or.inr
          ((rootedClusterEquivOfRangeEq_covers_iff
            T₁ T₂ r hrange v u).2 hvu)
    · rintro (huv | hvu)
      · exact Or.inl
          ((rootedClusterEquivOfRangeEq_covers_iff
            T₁ T₂ r hrange u v).1 huv)
      · exact Or.inr
          ((rootedClusterEquivOfRangeEq_covers_iff
            T₁ T₂ r hrange v u).1 hvu)

namespace XTree

/-- In a phylogenetic tree, the rooted cluster at a labelled non-root leaf is
the singleton containing exactly that taxon. -/
theorem IsPhylogenetic.rootedCluster_label_eq_singleton
    (T : XTree X V) (hphy : T.IsPhylogenetic)
    (r x : X) (hxr : x ≠ r) :
    T.rootedCluster r (T.label x) = {x} := by
  have hlabel : T.label x ≠ T.label r := by
    intro h
    exact hxr (hphy.1 h)
  rw [T.rootedCluster_eq_edgeSide_rootParent r hlabel]
  exact hphy.edgeSide_pendant_eq_singleton T x
    (T.rootParent_adj r hlabel).symm

end XTree

/-- An isomorphism of labelled `X`-trees: the underlying graphs are
isomorphic and every taxon label is fixed by name. -/
structure LabelPreservingXTreeIso
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) where
  graphIso : T₁.graph ≃g T₂.graph
  map_label : ∀ x : X, graphIso (T₁.label x) = T₂.label x

namespace LabelPreservingXTreeIso

variable {T₁ : XTree X V₁} {T₂ : XTree X V₂}
  (F : LabelPreservingXTreeIso T₁ T₂)

/-- Deleting corresponding edges from label-preservingly isomorphic trees
again gives isomorphic graphs. -/
noncomputable def deleteEdgeGraphIso (u v : V₁) :
    T₁.graph.deleteEdges {s(u, v)} ≃g
      T₂.graph.deleteEdges {s(F.graphIso u, F.graphIso v)} where
  toEquiv := F.graphIso.toEquiv
  map_rel_iff' := by
    intro a b
    change
      (T₂.graph.deleteEdges {s(F.graphIso u, F.graphIso v)}).Adj
          (F.graphIso a) (F.graphIso b) ↔
        (T₁.graph.deleteEdges {s(u, v)}).Adj a b
    have hedge :
        s(F.graphIso a, F.graphIso b) =
            s(F.graphIso u, F.graphIso v) ↔
          s(a, b) = s(u, v) := by
      constructor
      · intro h
        rw [Sym2.eq_iff] at h ⊢
        rcases h with ⟨hau, hbv⟩ | ⟨hav, hbu⟩
        · exact Or.inl ⟨F.graphIso.injective hau,
            F.graphIso.injective hbv⟩
        · exact Or.inr ⟨F.graphIso.injective hav,
            F.graphIso.injective hbu⟩
      · intro h
        rw [Sym2.eq_iff] at h ⊢
        rcases h with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩
        · exact Or.inl ⟨rfl, rfl⟩
        · exact Or.inr ⟨rfl, rfl⟩
    rw [SimpleGraph.deleteEdges_adj, SimpleGraph.deleteEdges_adj,
      F.graphIso.map_adj_iff]
    exact and_congr Iff.rfl (not_congr hedge)

/-- Corresponding oriented edges determine exactly the same taxon side. -/
theorem edgeSide_map_eq (u v : V₁) :
    T₂.edgeSide (F.graphIso u) (F.graphIso v) = T₁.edgeSide u v := by
  classical
  ext x
  simp only [XTree.edgeSide, Finset.mem_filter, Finset.mem_univ, true_and,
    XTree.vertexSide, ← F.map_label x]
  exact (F.deleteEdgeGraphIso u v).reachable_iff

/-- Corresponding graph edges display exactly the same unordered full split. -/
theorem edgeSplit_map_eq (u v : V₁) :
    T₂.edgeSplit (F.graphIso u) (F.graphIso v) =
      T₁.edgeSplit u v := by
  rw [XTree.edgeSplit, XTree.edgeSplit,
    F.edgeSide_map_eq u v, F.edgeSide_map_eq v u]

/-- A label-preserving tree isomorphism identifies the complete edge-split
systems, including both orientations of every represented edge. -/
theorem edgeSplitSet_eq (F : LabelPreservingXTreeIso T₁ T₂) :
    T₁.edgeSplitSet = T₂.edgeSplitSet := by
  ext P
  constructor
  · rintro ⟨u, v, huv, rfl⟩
    refine ⟨F.graphIso u, F.graphIso v,
      F.graphIso.map_adj_iff.mpr huv, ?_⟩
    exact (F.edgeSplit_map_eq u v).symm
  · rintro ⟨p, q, hpq, rfl⟩
    let u := F.graphIso.symm p
    let v := F.graphIso.symm q
    have hup : F.graphIso u = p := by
      exact F.graphIso.apply_symm_apply p
    have hvq : F.graphIso v = q := by
      exact F.graphIso.apply_symm_apply q
    have huv : T₁.graph.Adj u v := by
      apply F.graphIso.map_adj_iff.mp
      simpa only [hup, hvq] using hpq
    refine ⟨u, v, huv, ?_⟩
    calc
      T₂.edgeSplit p q =
          T₂.edgeSplit (F.graphIso u) (F.graphIso v) := by
        rw [hup, hvq]
      _ = T₁.edgeSplit u v := F.edgeSplit_map_eq u v

end LabelPreservingXTreeIso

/-- The graph isomorphism reconstructed from an equal rooted-cluster range
preserves every taxon label for arbitrary vertex-labelled `X`-trees.  The
reason is intrinsic: the vertex carrying `x` has the least rooted cluster
containing `x`, and the reconstructed isomorphism preserves the whole cluster
hierarchy exactly. -/
theorem rootedClusterGraphIsoOfRangeEq_map_label_general
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (r : X)
    (hrange : Set.range (T₁.rootedCluster r) =
      Set.range (T₂.rootedCluster r)) (x : X) :
    rootedClusterGraphIsoOfRangeEq T₁ T₂ r hrange (T₁.label x) =
      T₂.label x := by
  let e := rootedClusterEquivOfRangeEq T₁ T₂ r hrange
  change e (T₁.label x) = T₂.label x
  apply T₂.rootedCluster_injective r
  have hcluster (v : V₁) :
      T₂.rootedCluster r (e v) = T₁.rootedCluster r v :=
    rootedClusterEquivOfRangeEq_cluster T₁ T₂ r hrange v
  have hx₁ : x ∈ T₁.rootedCluster r (T₁.label x) :=
    T₁.label_mem_rootedCluster r x
  have hxMapped : x ∈ T₂.rootedCluster r (e (T₁.label x)) := by
    rw [hcluster]
    exact hx₁
  have hforward :
      T₂.rootedCluster r (T₂.label x) ⊆
        T₂.rootedCluster r (e (T₁.label x)) :=
    T₂.rootedCluster_label_subset_of_mem r x hxMapped
  let w : V₁ := e.symm (T₂.label x)
  have hew : e w = T₂.label x := e.apply_symm_apply (T₂.label x)
  have hx₂ : x ∈ T₂.rootedCluster r (T₂.label x) :=
    T₂.label_mem_rootedCluster r x
  have hxPreimage : x ∈ T₁.rootedCluster r w := by
    rw [← hcluster w, hew]
    exact hx₂
  have hbackward₁ :
      T₁.rootedCluster r (T₁.label x) ⊆ T₁.rootedCluster r w :=
    T₁.rootedCluster_label_subset_of_mem r x hxPreimage
  have hbackward :
      T₂.rootedCluster r (e (T₁.label x)) ⊆
        T₂.rootedCluster r (T₂.label x) := by
    rw [hcluster, ← hew, hcluster]
    exact hbackward₁
  exact Finset.Subset.antisymm hbackward hforward

/-- Equal edge-split systems reconstruct a label-preserving isomorphism for
general `X`-trees; injective leaf labels are not required. -/
noncomputable def labelPreservingXTreeIsoOfEdgeSplitSetEqGeneral
    (T₁ : XTree X V₁) (T₂ : XTree X V₂) (r : X)
    (hsplit : T₁.edgeSplitSet = T₂.edgeSplitSet) :
    LabelPreservingXTreeIso T₁ T₂ := by
  let hrange := rootedCluster_range_eq_of_edgeSplitSet_eq T₁ T₂ r hsplit
  exact
    { graphIso := rootedClusterGraphIsoOfRangeEq T₁ T₂ r hrange
      map_label := rootedClusterGraphIsoOfRangeEq_map_label_general
        T₁ T₂ r hrange }

/-- The graph isomorphism reconstructed from equal cluster ranges preserves
all taxon labels when both trees are phylogenetic. -/
theorem rootedClusterGraphIsoOfRangeEq_map_label
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hphy₁ : T₁.IsPhylogenetic) (hphy₂ : T₂.IsPhylogenetic)
    (r : X)
    (hrange : Set.range (T₁.rootedCluster r) =
      Set.range (T₂.rootedCluster r)) (x : X) :
    rootedClusterGraphIsoOfRangeEq T₁ T₂ r hrange (T₁.label x) =
      T₂.label x := by
  change rootedClusterEquivOfRangeEq T₁ T₂ r hrange (T₁.label x) =
    T₂.label x
  apply T₂.rootedCluster_injective r
  by_cases hxr : x = r
  · subst x
    rw [rootedClusterEquivOfRangeEq_cluster,
      T₁.rootedCluster_root, T₂.rootedCluster_root]
  · rw [rootedClusterEquivOfRangeEq_cluster,
      hphy₁.rootedCluster_label_eq_singleton T₁ r x hxr,
      hphy₂.rootedCluster_label_eq_singleton T₂ r x hxr]

/-- Equal edge-split systems reconstruct a label-preserving tree
isomorphism. -/
noncomputable def labelPreservingXTreeIsoOfEdgeSplitSetEq
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hphy₁ : T₁.IsPhylogenetic) (hphy₂ : T₂.IsPhylogenetic)
    (r : X) (hsplit : T₁.edgeSplitSet = T₂.edgeSplitSet) :
    LabelPreservingXTreeIso T₁ T₂ := by
  let hrange := rootedCluster_range_eq_of_edgeSplitSet_eq T₁ T₂ r hsplit
  exact
    { graphIso := rootedClusterGraphIsoOfRangeEq T₁ T₂ r hrange
      map_label := rootedClusterGraphIsoOfRangeEq_map_label
        T₁ T₂ hphy₁ hphy₂ r hrange }

/-- Two binary phylogenetic trees displaying the same full quartet system
are identical up to the unique label-preserving graph isomorphism
reconstructed above. -/
noncomputable def labelPreservingXTreeIsoOfSameFullQuartets
    (T₁ : XTree X V₁) (T₂ : XTree X V₂)
    (hbin₁ : T₁.IsBinaryPhylogenetic)
    (hbin₂ : T₂.IsBinaryPhylogenetic)
    (hsame : ∀ P : PartialSplit X, IsQuartet P →
      (T₁.DisplaysPartialSplit P ↔ T₂.DisplaysPartialSplit P))
    (r : X) : LabelPreservingXTreeIso T₁ T₂ :=
  labelPreservingXTreeIsoOfEdgeSplitSetEq T₁ T₂ hbin₁.1 hbin₂.1 r
    (edgeSplitSet_eq_of_same_full_quartets T₁ T₂ hbin₁ hbin₂ hsame)

end QDFull
