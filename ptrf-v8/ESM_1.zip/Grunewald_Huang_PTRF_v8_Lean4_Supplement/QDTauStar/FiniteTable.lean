import QDTauStar.OrderedPathTree

/-!
# The finite ordered contingency table inside the path trees

This file identifies the path-tree quantities in Lemma 6 with the empirical
ordered table used in the proof of Corollary 3.  In particular, the local
edge coordinate is proved equal to the lower-left quadrant discrepancy
`F(i,j) - F_X(i) F_Y(j)` before any squaring or summation takes place.
-/

open scoped BigOperators

namespace QDTauStar

universe uX

variable {X : Type uX} [Fintype X] [DecidableEq X]

/-- Taxa whose ordered coordinate is exactly `k`. -/
def orderedAtomSet {m : ℕ} (coord : X → Fin (m + 1))
    (k : Fin (m + 1)) : Finset X :=
  Finset.univ.filter fun x => coord x = k

/-- Taxa at or below the cut indexed by `i`. -/
def orderedLowerSet {m : ℕ} (coord : X → Fin (m + 1))
    (i : Fin m) : Finset X :=
  Finset.univ.filter fun x => coord x ≤ i.castSucc

/-- Empirical mass at one occupied support value. -/
noncomputable def orderedAtomMass {m : ℕ}
    (coord : X → Fin (m + 1)) (k : Fin (m + 1)) : ℝ :=
  QDFull.normalizedCard (orderedAtomSet coord k)

/-- Empirical marginal CDF at one interior cut. -/
noncomputable def orderedLowerMass {m : ℕ}
    (coord : X → Fin (m + 1)) (i : Fin m) : ℝ :=
  QDFull.normalizedCard (orderedLowerSet coord i)

/-- Empirical joint CDF at a pair of interior cuts. -/
noncomputable def orderedJointLowerMass {m n : ℕ}
    (row : X → Fin (m + 1)) (col : X → Fin (n + 1))
    (i : Fin m) (j : Fin n) : ℝ :=
  QDFull.normalizedCard
    (orderedLowerSet row i ∩ orderedLowerSet col j)

/-- The finite-grid discrepancy `F(i,j) - F_X(i) F_Y(j)`. -/
noncomputable def orderedGridDelta {m n : ℕ}
    (row : X → Fin (m + 1)) (col : X → Fin (n + 1))
    (i : Fin m) (j : Fin n) : ℝ :=
  orderedJointLowerMass row col i j -
    orderedLowerMass row i * orderedLowerMass col j

@[simp] theorem mem_orderedAtomSet {m : ℕ}
    (coord : X → Fin (m + 1)) (k : Fin (m + 1)) (x : X) :
    x ∈ orderedAtomSet coord k ↔ coord x = k := by
  simp [orderedAtomSet]

@[simp] theorem mem_orderedLowerSet {m : ℕ}
    (coord : X → Fin (m + 1)) (i : Fin m) (x : X) :
    x ∈ orderedLowerSet coord i ↔ coord x ≤ i.castSucc := by
  simp [orderedLowerSet]

/-- Real-valued normalized cardinality is additive under a set/complement
partition. -/
theorem normalizedCard_inter_add_inter_compl
    (A B : Finset X) :
    QDFull.normalizedCard (A ∩ B) +
        QDFull.normalizedCard (A ∩ Bᶜ) =
      QDFull.normalizedCard A := by
  have hset : A ∩ Bᶜ = A \ B := by
    ext x
    simp
  have hcard : (A ∩ B).card + (A ∩ Bᶜ).card = A.card := by
    rw [hset]
    exact Finset.card_inter_add_card_sdiff A B
  have hcardR :
      ((A ∩ B).card : ℝ) + ((A ∩ Bᶜ).card : ℝ) =
        (A.card : ℝ) := by
    exact_mod_cast hcard
  unfold QDFull.normalizedCard
  rw [← add_div, hcardR]

/-- The normalized cardinality of the whole finite sample is one. -/
theorem normalizedCard_univ [Nonempty X] :
    QDFull.normalizedCard (Finset.univ : Finset X) = 1 := by
  unfold QDFull.normalizedCard
  rw [Finset.card_univ]
  exact div_self (by positivity)

/-- `Finset.inter` computes the same finite set for every decidable-equality
instance.  This bridge only removes an implementation-level distinction
between the classical instance inside `orientedSplitDeterminant` and the
ambient instance used by the table notation. -/
theorem normalizedCard_inter_decEq_independent
    (d₁ d₂ : DecidableEq X) (A B : Finset X) :
    QDFull.normalizedCard
        (@Inter.inter (Finset X) (@Finset.instInter X d₁) A B) =
      QDFull.normalizedCard
        (@Inter.inter (Finset X) (@Finset.instInter X d₂) A B) := by
  apply congrArg QDFull.normalizedCard
  ext x
  simp

/-- A finite set and its complement have total normalized mass one whenever
the ambient finite type is nonempty. -/
theorem normalizedCard_add_compl [Nonempty X] (A : Finset X) :
    QDFull.normalizedCard A + QDFull.normalizedCard Aᶜ = 1 := by
  calc
    QDFull.normalizedCard A + QDFull.normalizedCard Aᶜ =
        QDFull.normalizedCard (Finset.univ : Finset X) := by
      simpa using
        (normalizedCard_inter_add_inter_compl
          (A := (Finset.univ : Finset X)) (B := A))
    _ = 1 := normalizedCard_univ

/-- For complementary row and column partitions, the `2 × 2` determinant
is the centered lower-left cell mass. -/
theorem orientedSplitDeterminant_compl_eq_centered [Nonempty X]
    (P Q : Finset X) :
    QDFull.orientedSplitDeterminant Pᶜ P Qᶜ Q =
      QDFull.normalizedCard (P ∩ Q) -
        QDFull.normalizedCard P * QDFull.normalizedCard Q := by
  classical
  have hPc := normalizedCard_inter_add_inter_compl (A := Pᶜ) (B := Q)
  have hP := normalizedCard_inter_add_inter_compl (A := P) (B := Q)
  have hQ := normalizedCard_inter_add_inter_compl (A := Q) (B := P)
  have htotal := normalizedCard_add_compl P
  unfold QDFull.orientedSplitDeterminant
  simp_rw [normalizedCard_inter_decEq_independent
    (d₁ := Classical.decEq X) (d₂ := inferInstance)]
  rw [Finset.inter_comm Q P, Finset.inter_comm Q Pᶜ] at hQ
  rw [← hP, ← hQ]
  have hfour :
      QDFull.normalizedCard (P ∩ Q) +
          QDFull.normalizedCard (P ∩ Qᶜ) +
          QDFull.normalizedCard (Pᶜ ∩ Q) +
          QDFull.normalizedCard (Pᶜ ∩ Qᶜ) = 1 := by
    linarith [hP, hPc, htotal]
  calc
    QDFull.normalizedCard (Pᶜ ∩ Qᶜ) *
          QDFull.normalizedCard (P ∩ Q) -
        QDFull.normalizedCard (Pᶜ ∩ Q) *
          QDFull.normalizedCard (P ∩ Qᶜ) =
        QDFull.normalizedCard (P ∩ Q) *
            (QDFull.normalizedCard (P ∩ Q) +
              QDFull.normalizedCard (P ∩ Qᶜ) +
              QDFull.normalizedCard (Pᶜ ∩ Q) +
              QDFull.normalizedCard (Pᶜ ∩ Qᶜ)) -
          (QDFull.normalizedCard (P ∩ Q) +
              QDFull.normalizedCard (P ∩ Qᶜ)) *
            (QDFull.normalizedCard (P ∩ Q) +
              QDFull.normalizedCard (Pᶜ ∩ Q)) := by ring
    _ = QDFull.normalizedCard (P ∩ Q) -
          (QDFull.normalizedCard (P ∩ Q) +
              QDFull.normalizedCard (P ∩ Qᶜ)) *
            (QDFull.normalizedCard (P ∩ Q) +
              QDFull.normalizedCard (Pᶜ ∩ Q)) := by
      rw [hfour]
      ring

/-- The lower path component is literally the lower coordinate set. -/
theorem orderedPath_edgeSide_lower_eq {m : ℕ}
    (coord : X → Fin (m + 1)) (hsurj : Function.Surjective coord)
    (i : Fin m) :
    (orderedPathXTree coord hsurj).edgeSide i.succ i.castSucc =
      orderedLowerSet coord i := by
  ext x
  rw [mem_orderedPath_edgeSide_lower_iff, mem_orderedLowerSet]

/-- The upper path component is the complement of the lower coordinate set. -/
theorem orderedPath_edgeSide_upper_eq {m : ℕ}
    (coord : X → Fin (m + 1)) (hsurj : Function.Surjective coord)
    (i : Fin m) :
    (orderedPathXTree coord hsurj).edgeSide i.castSucc i.succ =
      (orderedLowerSet coord i)ᶜ := by
  ext x
  rw [mem_orderedPath_edgeSide_upper_iff]
  simp only [Finset.mem_compl, mem_orderedLowerSet]
  constructor
  · intro hupper hlower
    have hlt : i.castSucc < coord x :=
      lt_of_lt_of_le (Fin.castSucc_lt_succ_iff.mpr (le_refl i)) hupper
    exact (not_le_of_gt hlt) hlower
  · intro hlower
    rcases Fin.succ_le_or_le_castSucc (coord x) i with hupper | hle
    · exact hupper
    · exact False.elim (hlower hle)

/-- A path-vertex label fibre is the corresponding atom set. -/
theorem orderedPath_labelFiber_eq_atomSet {m : ℕ}
    (coord : X → Fin (m + 1)) (hsurj : Function.Surjective coord)
    (k : Fin (m + 1)) :
    (orderedPathXTree coord hsurj).labelFiber k =
      orderedAtomSet coord k := by
  ext x
  rw [mem_orderedPath_labelFiber_iff, mem_orderedAtomSet]

/-- The row endpoint coefficient in Lemma 6 is the empirical mass at that
support value. -/
theorem orderedPath_rowMass_center_eq_atomMass {m : ℕ}
    (coord : X → Fin (m + 1)) (hsurj : Function.Surjective coord)
    (t k : Fin (m + 1)) :
    (orderedPathXTree coord hsurj).rowMass t k k =
      orderedAtomMass coord k := by
  unfold QDFull.XTree.rowMass orderedAtomMass
  rw [QDFull.XTree.rowBlock_center,
    orderedPath_labelFiber_eq_atomSet]

/-- The column endpoint coefficient has the same interpretation. -/
theorem orderedPath_columnMass_center_eq_atomMass {m : ℕ}
    (coord : X → Fin (m + 1)) (hsurj : Function.Surjective coord)
    (v k : Fin (m + 1)) :
    (orderedPathXTree coord hsurj).columnMass v k k =
      orderedAtomMass coord k := by
  unfold QDFull.XTree.columnMass orderedAtomMass
  rw [QDFull.XTree.columnBlock_center,
    orderedPath_labelFiber_eq_atomSet]

/-- The local path-tree edge coordinate is exactly the empirical quadrant
discrepancy.  No square or global sum is used in this identification. -/
theorem orderedPath_xCoefficient_eq_gridDelta [Nonempty X]
    {m n : ℕ}
    (row : X → Fin (m + 1)) (col : X → Fin (n + 1))
    (hrow : Function.Surjective row) (hcol : Function.Surjective col)
    (i : Fin m) (j : Fin n) :
    QDFull.xCoefficient
        (orderedPathXTree row hrow) (orderedPathXTree col hcol)
        i.succ i.castSucc j.succ j.castSucc =
      orderedGridDelta row col i j := by
  let T₁ := orderedPathXTree row hrow
  let T₂ := orderedPathXTree col hcol
  rw [QDFull.xCoefficient_eq_edge_determinant T₁ T₂
    (pathGraph_adj_cut i).symm (pathGraph_adj_cut j).symm]
  rw [show T₁.edgeSide i.castSucc i.succ =
      (orderedLowerSet row i)ᶜ by
        exact orderedPath_edgeSide_upper_eq row hrow i]
  rw [show T₁.edgeSide i.succ i.castSucc =
      orderedLowerSet row i by
        exact orderedPath_edgeSide_lower_eq row hrow i]
  rw [show T₂.edgeSide j.castSucc j.succ =
      (orderedLowerSet col j)ᶜ by
        exact orderedPath_edgeSide_upper_eq col hcol j]
  rw [show T₂.edgeSide j.succ j.castSucc =
      orderedLowerSet col j by
        exact orderedPath_edgeSide_lower_eq col hcol j]
  rw [orientedSplitDeterminant_compl_eq_centered]
  rfl

/-- In the canonical lower-to-upper orientations, reversing both path edges
does not change the determinant, so the same coefficient is the empirical
grid discrepancy. -/
theorem orderedPath_xCoefficient_forward_eq_gridDelta [Nonempty X]
    {m n : ℕ}
    (row : X → Fin (m + 1)) (col : X → Fin (n + 1))
    (hrow : Function.Surjective row) (hcol : Function.Surjective col)
    (i : Fin m) (j : Fin n) :
    QDFull.xCoefficient
        (orderedPathXTree row hrow) (orderedPathXTree col hcol)
        i.castSucc i.succ j.castSucc j.succ =
      orderedGridDelta row col i j := by
  rw [← QDFull.xCoefficient_reverse_both
    (orderedPathXTree row hrow) (orderedPathXTree col hcol)
    i.castSucc i.succ j.castSucc j.succ]
  exact orderedPath_xCoefficient_eq_gridDelta row col hrow hcol i j

end QDTauStar
