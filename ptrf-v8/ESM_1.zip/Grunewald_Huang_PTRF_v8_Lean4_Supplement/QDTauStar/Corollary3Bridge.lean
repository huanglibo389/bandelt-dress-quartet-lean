import Mathlib
import QDTauStar.Limits

namespace QDTauStar

/-! Logical closure of Corollary 3 after the BKR discrepancy has been shown
to detect independence. -/

/-- The quantitative BKR lower bound forces strict positivity of tau-star
whenever the discrepancy is positive. -/
theorem tauStar_positive_of_bkr_positive
    (tauStar bkr : ℝ) (hLower : 2 * bkr ≤ tauStar) (hBkr : 0 < bkr) :
    0 < tauStar := by
  linarith

/-- If the BKR discrepancy is nonnegative and detects independence, then the
quantitative lower bound proves `tauStar = 0 -> independence`. -/
theorem tauStar_zero_implies_independence
    (Independent : Prop) (tauStar bkr : ℝ)
    (hBkrNonneg : 0 ≤ bkr)
    (hDetects : bkr = 0 ↔ Independent)
    (hLower : 2 * bkr ≤ tauStar)
    (hTauZero : tauStar = 0) : Independent := by
  have hBkrZero : bkr = 0 := by
    nlinarith
  exact hDetects.mp hBkrZero

/-- Contrapositive form matching the statement of Corollary 3. -/
theorem dependence_implies_tauStar_positive
    (Independent : Prop) (tauStar bkr : ℝ)
    (hBkrNonneg : 0 ≤ bkr)
    (hDetects : bkr = 0 ↔ Independent)
    (hLower : 2 * bkr ≤ tauStar)
    (hDependent : ¬ Independent) : 0 < tauStar := by
  have hBkrNe : bkr ≠ 0 := fun h => hDependent (hDetects.mp h)
  have hBkrPos : 0 < bkr := lt_of_le_of_ne hBkrNonneg (Ne.symm hBkrNe)
  exact tauStar_positive_of_bkr_positive tauStar bkr hLower hBkrPos

/-- The final logical chain of the completed Corollary 3 proof: finite
quantisation bounds pass to the two limits, and BKR detection turns dependence
into strict positivity of the limiting tau-star. -/
theorem corollary3_from_finite_quantisations
    (Independent : Prop)
    (tau bkr : ℕ → ℝ) (tauStar bkrLimit : ℝ)
    (hTauLimit : Filter.Tendsto tau Filter.atTop (nhds tauStar))
    (hBkrLimit : Filter.Tendsto bkr Filter.atTop (nhds bkrLimit))
    (hFinite : ∀ k, 2 * bkr k ≤ tau k)
    (hBkrNonneg : 0 ≤ bkrLimit)
    (hDetects : bkrLimit = 0 ↔ Independent)
    (hDependent : ¬ Independent) :
    0 < tauStar := by
  have hLower : 2 * bkrLimit ≤ tauStar :=
    lower_bound_closed_under_limits tau bkr tauStar bkrLimit
      hTauLimit hBkrLimit hFinite
  exact dependence_implies_tauStar_positive Independent tauStar bkrLimit
    hBkrNonneg hDetects hLower hDependent

end QDTauStar
