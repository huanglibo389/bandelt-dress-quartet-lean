import Mathlib.MeasureTheory.Measure.Regular
import QDTauStar.IndependentZero
import QDTauStar.Variation

/-!
# Zero characterization for the BKR discrepancy

This file closes the last measure-theoretic interface in Corollary 3 of the
manuscript.  It proves that the BKR discrepancy vanishes exactly for
independent coordinates, including atomic and singular laws, and combines
that fact with the quantitative tau-star lower bound.

The manuscript invokes a generalized-quantile representation to prove that
a narrow band immediately below a positive CDF value has positive mass.
Mathlib currently has no generalized-quantile API.  We prove the stronger
CDF sublevel estimate directly: the mass of `{x | F x <= t}` is at most `t`.
The proof uses inner regularity, a compact subset, and its greatest point.
-/

open MeasureTheory Set

namespace QDTauStar

/-- The real-valued CDF of a one-dimensional probability law, in the same
`Measure.real` convention used by the manuscript interfaces. -/
noncomputable def marginalCDF (nu : ProbabilityMeasure Real) (x : Real) : Real :=
  (nu : Measure Real).real (Iic x)

/-- A one-dimensional CDF is monotone. -/
theorem monotone_marginalCDF (nu : ProbabilityMeasure Real) :
    Monotone (marginalCDF nu) := by
  intro x y hxy
  exact measureReal_mono (Iic_subset_Iic.mpr hxy)

/-- A one-dimensional CDF is Borel measurable. -/
theorem measurable_marginalCDF (nu : ProbabilityMeasure Real) :
    Measurable (marginalCDF nu) := by
  have h := (ProbabilityTheory.monotone_cdf
    ((nu : ProbabilityMeasure Real) : Measure Real)).measurable
  change Measurable (fun x => (nu : Measure Real).real (Iic x))
  simpa only [← ProbabilityTheory.cdf_eq_real] using h

/-- The CDF sublevel set used in the generalized probability-integral
transform inequality is measurable. -/
theorem measurableSet_marginalCDF_le
    (nu : ProbabilityMeasure Real) (t : Real) :
    MeasurableSet {x : Real | marginalCDF nu x ≤ t} :=
  measurableSet_le (measurable_marginalCDF nu) measurable_const

/-- Generalized probability-integral-transform inequality, valid with atoms:
`P(F(X) <= t) <= t` for every nonnegative threshold `t`.

Rather than introducing generalized quantiles, assume the sublevel set has
mass larger than `t`, choose a compact subset of mass larger than `t`, and
take its greatest point `x`.  The whole compact set lies below `x`, whereas
membership of `x` in the sublevel set says `P(X <= x) <= t`, a contradiction.
-/
theorem measureReal_marginalCDF_le_le
    (nu : ProbabilityMeasure Real) (t : Real) (ht : 0 ≤ t) :
    (nu : Measure Real).real {x : Real | marginalCDF nu x ≤ t} ≤ t := by
  let B : Set Real := {x : Real | marginalCDF nu x ≤ t}
  have hB : MeasurableSet B := measurableSet_marginalCDF_le nu t
  by_contra hle
  have hltReal : t < (nu : Measure Real).real B := lt_of_not_ge hle
  have hltENN : ENNReal.ofReal t < (nu : Measure Real) B := by
    rw [ENNReal.ofReal_lt_iff_lt_toReal ht (measure_ne_top _ _)]
    simpa only [Measure.real] using hltReal
  obtain ⟨K, hKB, hKcompact, hKmass⟩ :=
    hB.exists_lt_isCompact_of_ne_top (measure_ne_top _ _) hltENN
  have hKnonempty : K.Nonempty := by
    by_contra hKempty
    rw [not_nonempty_iff_eq_empty.mp hKempty, measure_empty] at hKmass
    exact (not_lt_of_ge (bot_le : 0 ≤ ENNReal.ofReal t)) hKmass
  obtain ⟨x, hxK, hxGreatest⟩ := hKcompact.exists_isGreatest hKnonempty
  have hxB : x ∈ B := hKB hxK
  have hKIic : K ⊆ Iic x := by
    intro z hz
    exact hxGreatest hz
  have hmassLe : (nu : Measure Real) K ≤ (nu : Measure Real) (Iic x) :=
    measure_mono hKIic
  have hCDFLe : marginalCDF nu x ≤ t := hxB
  have hIicLe : (nu : Measure Real) (Iic x) ≤ ENNReal.ofReal t := by
    rw [← ofReal_measureReal (μ := (nu : Measure Real)) (s := Iic x)]
    exact ENNReal.ofReal_le_ofReal hCDFLe
  exact (not_lt_of_ge (hmassLe.trans hIicLe)) hKmass

/-- The manuscript's narrow CDF band immediately below the value at `a`. -/
noncomputable def cdfLowerBand
    (nu : ProbabilityMeasure Real) (a eps : Real) : Set Real :=
  {x : Real | x ≤ a ∧
    marginalCDF nu a - eps < marginalCDF nu x ∧
    marginalCDF nu x ≤ marginalCDF nu a}

/-- The lower CDF band is Borel measurable. -/
theorem measurableSet_cdfLowerBand
    (nu : ProbabilityMeasure Real) (a eps : Real) :
    MeasurableSet (cdfLowerBand nu a eps) := by
  unfold cdfLowerBand
  exact (measurableSet_le measurable_id measurable_const).inter
    ((measurableSet_lt measurable_const (measurable_marginalCDF nu)).inter
      (measurableSet_le (measurable_marginalCDF nu) measurable_const))

/-- The CDF sublevel set below `F(a) - eps` lies below `a` when `eps > 0`. -/
private theorem marginalCDF_sublevel_subset_Iic
    (nu : ProbabilityMeasure Real) (a eps : Real) (heps : 0 < eps) :
    {x : Real | marginalCDF nu x ≤ marginalCDF nu a - eps} ⊆ Iic a := by
  intro x hx
  change marginalCDF nu x ≤ marginalCDF nu a - eps at hx
  by_contra hxa
  change ¬ x ≤ a at hxa
  have hax : a ≤ x := le_of_not_ge hxa
  have hmono : marginalCDF nu a ≤ marginalCDF nu x :=
    monotone_marginalCDF nu hax
  linarith

/-- The complement of the CDF sublevel set inside `(-∞,a]` is exactly the
manuscript's lower band. -/
private theorem Iic_sdiff_marginalCDF_sublevel
    (nu : ProbabilityMeasure Real) (a eps : Real) :
    Iic a \ {x : Real | marginalCDF nu x ≤ marginalCDF nu a - eps} =
      cdfLowerBand nu a eps := by
  ext x
  constructor
  · rintro ⟨hxa, hxnot⟩
    have hlt : marginalCDF nu a - eps < marginalCDF nu x :=
      lt_of_not_ge hxnot
    have hupper : marginalCDF nu x ≤ marginalCDF nu a :=
      monotone_marginalCDF nu hxa
    exact ⟨hxa, hlt, hupper⟩
  · rintro ⟨hxa, hlt, _⟩
    exact ⟨hxa, not_le.mpr hlt⟩

/-- Positive-mass CDF-band lemma used in the atomic/singular part of the
manuscript: if `0 < eps <= F(a)`, then the band immediately below `F(a)`
has marginal mass at least `eps`. -/
theorem eps_le_measureReal_cdfLowerBand
    (nu : ProbabilityMeasure Real) (a eps : Real)
    (heps : 0 < eps) (hepsCDF : eps ≤ marginalCDF nu a) :
    eps ≤ (nu : Measure Real).real (cdfLowerBand nu a eps) := by
  let B : Set Real :=
    {x : Real | marginalCDF nu x ≤ marginalCDF nu a - eps}
  have hBmeas : MeasurableSet B :=
    measurableSet_marginalCDF_le nu (marginalCDF nu a - eps)
  have hBsub : B ⊆ Iic a :=
    marginalCDF_sublevel_subset_Iic nu a eps heps
  have hthreshold : 0 ≤ marginalCDF nu a - eps := sub_nonneg.mpr hepsCDF
  have hBmass : (nu : Measure Real).real B ≤ marginalCDF nu a - eps :=
    measureReal_marginalCDF_le_le nu (marginalCDF nu a - eps) hthreshold
  have hdiff :
      (nu : Measure Real).real (Iic a \ B) =
        marginalCDF nu a - (nu : Measure Real).real B := by
    simpa only [marginalCDF] using
      (measureReal_sdiff (μ := (nu : Measure Real)) hBsub hBmeas)
  have hband : Iic a \ B = cdfLowerBand nu a eps :=
    Iic_sdiff_marginalCDF_sublevel nu a eps
  rw [← hband, hdiff]
  linarith

/-- The joint lower-left rectangle mass is bounded by its first marginal
rectangle mass. -/
theorem jointCDF_le_marginalCDFX
    (mu : ProbabilityMeasure (Real × Real)) (x y : Real) :
    jointCDF mu x y ≤ marginalCDFX mu x := by
  calc
    jointCDF mu x y
        ≤ (mu : Measure (Real × Real)).real (Prod.fst ⁻¹' Iic x) := by
          exact measureReal_mono (by
            intro z hz
            exact hz.1)
    _ = marginalCDFX mu x := by
          symm
          exact map_measureReal_apply measurable_fst measurableSet_Iic

/-- The joint lower-left rectangle mass is bounded by its second marginal
rectangle mass. -/
theorem jointCDF_le_marginalCDFY
    (mu : ProbabilityMeasure (Real × Real)) (x y : Real) :
    jointCDF mu x y ≤ marginalCDFY mu y := by
  calc
    jointCDF mu x y
        ≤ (mu : Measure (Real × Real)).real (Prod.snd ⁻¹' Iic y) := by
          exact measureReal_mono (by
            intro z hz
            exact hz.2)
    _ = marginalCDFY mu y := by
          symm
          exact map_measureReal_apply measurable_snd measurableSet_Iic

/-- If the first marginal lower interval already has total mass, intersecting
it with a second-coordinate lower interval does not change the latter's mass. -/
theorem jointCDF_eq_marginalCDFY_of_marginalCDFX_eq_one
    (mu : ProbabilityMeasure (Real × Real)) (x y : Real)
    (hx : marginalCDFX mu x = 1) :
    jointCDF mu x y = marginalCDFY mu y := by
  let A : Set (Real × Real) := Prod.fst ⁻¹' Iic x
  let C : Set (Real × Real) := Prod.snd ⁻¹' Iic y
  have hAmeas : MeasurableSet A := measurable_fst measurableSet_Iic
  have hCmeas : MeasurableSet C := measurable_snd measurableSet_Iic
  have hAreal : (mu : Measure (Real × Real)).real A = 1 := by
    calc
      (mu : Measure (Real × Real)).real A = marginalCDFX mu x := by
        symm
        exact map_measureReal_apply measurable_fst measurableSet_Iic
      _ = 1 := hx
  have hUreal : (mu : Measure (Real × Real)).real univ = 1 := by simp
  have hAmass : (mu : Measure (Real × Real)) A =
      (mu : Measure (Real × Real)) univ :=
    (measureReal_eq_measureReal_iff
      (μ := (mu : Measure (Real × Real)))
      (ν := (mu : Measure (Real × Real)))
      (s := A) (t := univ)).mp (hAreal.trans hUreal.symm)
  have hinter : (mu : Measure (Real × Real)) (A ∩ C) =
      (mu : Measure (Real × Real)) C := by
    simpa only [univ_inter] using
      (Measure.measure_inter_eq_of_measure_eq hCmeas hAmass
        (subset_univ A) (measure_ne_top _ _))
  apply (measureReal_eq_measureReal_iff
    (μ := (mu : Measure (Real × Real)))
    (ν := (marginalY mu : Measure Real))
    (s := {z : Real × Real | z.1 ≤ x ∧ z.2 ≤ y})
    (t := Iic y)).mpr
  calc
    (mu : Measure (Real × Real)) {z : Real × Real | z.1 ≤ x ∧ z.2 ≤ y}
        = (mu : Measure (Real × Real)) (A ∩ C) := by
            rfl
    _ = (mu : Measure (Real × Real)) C := hinter
    _ = (marginalY mu : Measure Real) (Iic y) := by
          unfold marginalY
          simp only [ProbabilityMeasure.toMeasure_map]
          rw [Measure.map_apply_of_aemeasurable measurable_snd.aemeasurable]
          exact measurableSet_Iic

/-- Symmetric full-marginal identity. -/
theorem jointCDF_eq_marginalCDFX_of_marginalCDFY_eq_one
    (mu : ProbabilityMeasure (Real × Real)) (x y : Real)
    (hy : marginalCDFY mu y = 1) :
    jointCDF mu x y = marginalCDFX mu x := by
  let A : Set (Real × Real) := Prod.snd ⁻¹' Iic y
  let C : Set (Real × Real) := Prod.fst ⁻¹' Iic x
  have hAmeas : MeasurableSet A := measurable_snd measurableSet_Iic
  have hCmeas : MeasurableSet C := measurable_fst measurableSet_Iic
  have hAreal : (mu : Measure (Real × Real)).real A = 1 := by
    calc
      (mu : Measure (Real × Real)).real A = marginalCDFY mu y := by
        symm
        exact map_measureReal_apply measurable_snd measurableSet_Iic
      _ = 1 := hy
  have hUreal : (mu : Measure (Real × Real)).real univ = 1 := by simp
  have hAmass : (mu : Measure (Real × Real)) A =
      (mu : Measure (Real × Real)) univ :=
    (measureReal_eq_measureReal_iff
      (μ := (mu : Measure (Real × Real)))
      (ν := (mu : Measure (Real × Real)))
      (s := A) (t := univ)).mp (hAreal.trans hUreal.symm)
  have hinter : (mu : Measure (Real × Real)) (A ∩ C) =
      (mu : Measure (Real × Real)) C := by
    simpa only [univ_inter] using
      (Measure.measure_inter_eq_of_measure_eq hCmeas hAmass
        (subset_univ A) (measure_ne_top _ _))
  apply (measureReal_eq_measureReal_iff
    (μ := (mu : Measure (Real × Real)))
    (ν := (marginalX mu : Measure Real))
    (s := {z : Real × Real | z.1 ≤ x ∧ z.2 ≤ y})
    (t := Iic x)).mpr
  calc
    (mu : Measure (Real × Real)) {z : Real × Real | z.1 ≤ x ∧ z.2 ≤ y}
        = (mu : Measure (Real × Real)) (A ∩ C) := by
            congr 1
            ext z
            simp only [A, C, mem_inter_iff, mem_preimage, mem_Iic]
            exact and_comm
    _ = (mu : Measure (Real × Real)) C := hinter
    _ = (marginalX mu : Measure Real) (Iic x) := by
          unfold marginalX
          simp only [ProbabilityMeasure.toMeasure_map]
          rw [Measure.map_apply_of_aemeasurable measurable_fst.aemeasurable]
          exact measurableSet_Iic

/-- A nonzero CDF discrepancy can occur only at an interior value of the
first marginal CDF. -/
theorem marginalCDFX_mem_Ioo_of_cdfDiscrepancy_ne_zero
    (mu : ProbabilityMeasure (Real × Real)) (x y : Real)
    (hD : cdfDiscrepancy mu x y ≠ 0) :
    marginalCDFX mu x ∈ Ioo (0 : Real) 1 := by
  have hx0 : 0 ≤ marginalCDFX mu x := measureReal_nonneg
  have hx1 : marginalCDFX mu x ≤ 1 := measureReal_le_one
  constructor
  · apply lt_of_le_of_ne hx0
    intro hx
    have hj0 : jointCDF mu x y = 0 :=
      le_antisymm ((jointCDF_le_marginalCDFX mu x y).trans (le_of_eq hx.symm))
        measureReal_nonneg
    apply hD
    unfold cdfDiscrepancy
    rw [hj0, hx.symm]
    ring
  · apply lt_of_le_of_ne hx1
    intro hx
    have hxeq : marginalCDFX mu x = 1 := hx
    have hj := jointCDF_eq_marginalCDFY_of_marginalCDFX_eq_one mu x y hxeq
    apply hD
    unfold cdfDiscrepancy
    rw [hj, hxeq]
    ring

/-- A nonzero CDF discrepancy can occur only at an interior value of the
second marginal CDF. -/
theorem marginalCDFY_mem_Ioo_of_cdfDiscrepancy_ne_zero
    (mu : ProbabilityMeasure (Real × Real)) (x y : Real)
    (hD : cdfDiscrepancy mu x y ≠ 0) :
    marginalCDFY mu y ∈ Ioo (0 : Real) 1 := by
  have hy0 : 0 ≤ marginalCDFY mu y := measureReal_nonneg
  have hy1 : marginalCDFY mu y ≤ 1 := measureReal_le_one
  constructor
  · apply lt_of_le_of_ne hy0
    intro hy
    have hj0 : jointCDF mu x y = 0 :=
      le_antisymm ((jointCDF_le_marginalCDFY mu x y).trans (le_of_eq hy.symm))
        measureReal_nonneg
    apply hD
    unfold cdfDiscrepancy
    rw [hj0, hy.symm]
    ring
  · apply lt_of_le_of_ne hy1
    intro hy
    have hyeq : marginalCDFY mu y = 1 := hy
    have hj := jointCDF_eq_marginalCDFX_of_marginalCDFY_eq_one mu x y hyeq
    apply hD
    unfold cdfDiscrepancy
    rw [hj, hyeq]
    ring

@[simp] theorem marginalCDF_marginalX
    (mu : ProbabilityMeasure (Real × Real)) (x : Real) :
    marginalCDF (marginalX mu) x = marginalCDFX mu x := rfl

@[simp] theorem marginalCDF_marginalY
    (mu : ProbabilityMeasure (Real × Real)) (y : Real) :
    marginalCDF (marginalY mu) y = marginalCDFY mu y := rfl

/-- A pointwise nonzero CDF discrepancy forces the BKR integral to be
strictly positive.  The proof uses positive-mass lower CDF bands and is
therefore valid for continuous, atomic, and singular laws alike. -/
theorem bkrDiscrepancy_pos_of_cdfDiscrepancy_ne_zero
    (mu : ProbabilityMeasure (Real × Real)) (x₀ y₀ : Real)
    (hD : cdfDiscrepancy mu x₀ y₀ ≠ 0) :
    0 < bkrDiscrepancy mu := by
  let d : Real := cdfDiscrepancy mu x₀ y₀
  let eps : Real := min (|d| / 8)
    (min (marginalCDFX mu x₀) (marginalCDFY mu y₀))
  let AX : Set Real := cdfLowerBand (marginalX mu) x₀ eps
  let AY : Set Real := cdfLowerBand (marginalY mu) y₀ eps
  let nuX : Measure Real := (marginalX mu : ProbabilityMeasure Real)
  let nuY : Measure Real := (marginalY mu : ProbabilityMeasure Real)
  let nu : Measure (Real × Real) :=
    (((marginalX mu).prod (marginalY mu) : ProbabilityMeasure (Real × Real)) :
      Measure (Real × Real))
  have hdpos : 0 < |d| := by
    exact abs_pos.mpr hD
  have hxpos : 0 < marginalCDFX mu x₀ :=
    (marginalCDFX_mem_Ioo_of_cdfDiscrepancy_ne_zero mu x₀ y₀ hD).1
  have hypos : 0 < marginalCDFY mu y₀ :=
    (marginalCDFY_mem_Ioo_of_cdfDiscrepancy_ne_zero mu x₀ y₀ hD).1
  have heps : 0 < eps := by
    dsimp only [eps]
    exact lt_min (by positivity) (lt_min hxpos hypos)
  have hepsD : eps ≤ |d| / 8 := by
    dsimp only [eps]
    exact min_le_left _ _
  have hepsX : eps ≤ marginalCDFX mu x₀ := by
    dsimp only [eps]
    exact (min_le_right _ _).trans (min_le_left _ _)
  have hepsY : eps ≤ marginalCDFY mu y₀ := by
    dsimp only [eps]
    exact (min_le_right _ _).trans (min_le_right _ _)
  have hAXmass : eps ≤ nuX.real AX := by
    dsimp only [nuX, AX]
    simpa only [marginalCDF_marginalX] using
      eps_le_measureReal_cdfLowerBand (marginalX mu) x₀ eps heps hepsX
  have hAYmass : eps ≤ nuY.real AY := by
    dsimp only [nuY, AY]
    simpa only [marginalCDF_marginalY] using
      eps_le_measureReal_cdfLowerBand (marginalY mu) y₀ eps heps hepsY
  have hAXpos : 0 < nuX AX := by
    apply pos_iff_ne_zero.mpr
    apply (measureReal_ne_zero_iff (μ := nuX) (s := AX)).mp
    exact (lt_of_lt_of_le heps hAXmass).ne'
  have hAYpos : 0 < nuY AY := by
    apply pos_iff_ne_zero.mpr
    apply (measureReal_ne_zero_iff (μ := nuY) (s := AY)).mp
    exact (lt_of_lt_of_le heps hAYmass).ne'
  have hbandSupport : AX ×ˢ AY ⊆ Function.support
      (fun p : Real × Real => cdfDiscrepancy mu p.1 p.2 ^ 2) := by
    intro p hp
    rcases hp with ⟨hpX, hpY⟩
    rcases hpX with ⟨_, hpXlow, hpXhigh⟩
    rcases hpY with ⟨_, hpYlow, hpYhigh⟩
    simp only [marginalCDF_marginalX] at hpXlow hpXhigh
    simp only [marginalCDF_marginalY] at hpYlow hpYhigh
    have hXabs :
        |marginalCDFX mu p.1 - marginalCDFX mu x₀| < eps := by
      rw [abs_of_nonpos (sub_nonpos.mpr hpXhigh)]
      linarith
    have hYabs :
        |marginalCDFY mu p.2 - marginalCDFY mu y₀| < eps := by
      rw [abs_of_nonpos (sub_nonpos.mpr hpYhigh)]
      linarith
    have hvar := cdfDiscrepancy_variation mu p.1 x₀ p.2 y₀
    have hvarlt :
        |cdfDiscrepancy mu p.1 p.2 - d| < 4 * eps := by
      dsimp only [d]
      linarith
    have hfour : 4 * eps < |d| := by
      nlinarith
    have hpoint : cdfDiscrepancy mu p.1 p.2 ≠ 0 := by
      intro hpzero
      have hirr : |d| < |d| := by
        calc
          |d| = |cdfDiscrepancy mu p.1 p.2 - d| := by
            rw [hpzero, zero_sub, abs_neg]
          _ < 4 * eps := hvarlt
          _ < |d| := hfour
      exact (lt_irrefl _ hirr)
    exact pow_ne_zero 2 hpoint
  have hbandPos : 0 < nu (AX ×ˢ AY) := by
    dsimp only [nu, nuX, nuY]
    rw [ProbabilityMeasure.toMeasure_prod]
    rw [Measure.prod_prod]
    exact ENNReal.mul_pos hAXpos.ne' hAYpos.ne'
  have hsupportPos : 0 < nu (Function.support
      (fun p : Real × Real => cdfDiscrepancy mu p.1 p.2 ^ 2)) :=
    lt_of_lt_of_le hbandPos (measure_mono hbandSupport)
  unfold bkrDiscrepancy
  apply (integral_pos_iff_support_of_nonneg
    (fun p : Real × Real => sq_nonneg (cdfDiscrepancy mu p.1 p.2))
    (integrable_bkrIntegrand mu)).mpr
  exact hsupportPos

/-- If the BKR discrepancy is zero, every lower-left rectangle discrepancy
vanishes pointwise. -/
theorem cdfDiscrepancy_eq_zero_of_bkrDiscrepancy_eq_zero
    (mu : ProbabilityMeasure (Real × Real))
    (hBKR : bkrDiscrepancy mu = 0) (x y : Real) :
    cdfDiscrepancy mu x y = 0 := by
  by_contra hD
  have hpos := bkrDiscrepancy_pos_of_cdfDiscrepancy_ne_zero mu x y hD
  rw [hBKR] at hpos
  exact (lt_irrefl 0 hpos)

/-- The half-lines `(-∞,n]`, `n : ℕ`, form finite spanning sets inside
the half-line generator of the real Borel sigma algebra. -/
private noncomputable def finiteSpanningSetsIn_Iic
    (nu : ProbabilityMeasure Real) :
    (nu : Measure Real).FiniteSpanningSetsIn
      (Set.range (fun x : Real => Iic x)) where
  set n := Iic (n : Real)
  set_mem n := ⟨(n : Real), rfl⟩
  finite n := measure_lt_top _ _
  spanning := by
    ext x
    simp only [mem_iUnion, mem_Iic, mem_univ, iff_true]
    exact exists_nat_ge x

/-- Pointwise factorisation of all lower-left rectangle probabilities implies
that the coordinate projections are independent.  The proof invokes measure
uniqueness on the `Iic` pi-system rather than assuming a density or continuity
of either marginal. -/
theorem coordinatesIndependent_of_cdfDiscrepancy_eq_zero
    (mu : ProbabilityMeasure (Real × Real))
    (hD : ∀ x y : Real, cdfDiscrepancy mu x y = 0) :
    CoordinatesIndependent mu := by
  have hprod :
      ((marginalX mu : ProbabilityMeasure Real) : Measure Real).prod
          ((marginalY mu : ProbabilityMeasure Real) : Measure Real) =
        (mu : Measure (Real × Real)) := by
    apply Measure.prod_eq_generateFrom
    · exact (borel_eq_generateFrom_Iic Real).symm
    · exact (borel_eq_generateFrom_Iic Real).symm
    · exact isPiSystem_Iic
    · exact isPiSystem_Iic
    · exact finiteSpanningSetsIn_Iic (marginalX mu)
    · exact finiteSpanningSetsIn_Iic (marginalY mu)
    · intro s hs t ht
      obtain ⟨x, rfl⟩ := hs
      obtain ⟨y, rfl⟩ := ht
      have hreal :
          (mu : Measure (Real × Real)).real (Iic x ×ˢ Iic y) =
            (((marginalX mu : ProbabilityMeasure Real) : Measure Real).prod
              ((marginalY mu : ProbabilityMeasure Real) : Measure Real)).real
                (Iic x ×ˢ Iic y) := by
        rw [measureReal_prod_prod]
        simpa only [jointCDF, marginalCDFX, marginalCDFY] using
          (sub_eq_zero.mp (hD x y))
      have hmeasure := (measureReal_eq_measureReal_iff
          (μ := (mu : Measure (Real × Real)))
          (ν := ((marginalX mu : ProbabilityMeasure Real) : Measure Real).prod
            ((marginalY mu : ProbabilityMeasure Real) : Measure Real))
          (s := Iic x ×ˢ Iic y) (t := Iic x ×ˢ Iic y)).mp hreal
      simpa only [Measure.prod_prod] using hmeasure
  unfold CoordinatesIndependent
  apply ProbabilityMeasure.toMeasure_injective
  simpa only [ProbabilityMeasure.toMeasure_prod] using hprod.symm

/-- Exact zero characterization of the BKR discrepancy for arbitrary Borel
probability laws on `ℝ × ℝ`. -/
theorem bkrDiscrepancy_eq_zero_iff_coordinatesIndependent
    (mu : ProbabilityMeasure (Real × Real)) :
    bkrDiscrepancy mu = 0 ↔ CoordinatesIndependent mu := by
  constructor
  · intro hBKR
    apply coordinatesIndependent_of_cdfDiscrepancy_eq_zero
    intro x y
    exact cdfDiscrepancy_eq_zero_of_bkrDiscrepancy_eq_zero mu hBKR x y
  · exact bkrDiscrepancy_eq_zero_of_independent

/-- Equivalently, the BKR discrepancy is strictly positive exactly for a
dependent pair of coordinates. -/
theorem bkrDiscrepancy_pos_iff_not_coordinatesIndependent
    (mu : ProbabilityMeasure (Real × Real)) :
    0 < bkrDiscrepancy mu ↔ ¬ CoordinatesIndependent mu := by
  constructor
  · intro hpos hind
    have hzero := bkrDiscrepancy_eq_zero_of_independent hind
    rw [hzero] at hpos
    exact (lt_irrefl 0 hpos)
  · intro hdep
    have hne : bkrDiscrepancy mu ≠ 0 := by
      intro hzero
      exact hdep
        ((bkrDiscrepancy_eq_zero_iff_coordinatesIndependent mu).mp hzero)
    exact lt_of_le_of_ne (bkrDiscrepancy_nonneg mu) hne.symm

/-- Tau-star is nonnegative for every Borel probability law. -/
theorem populationTauStar_nonneg
    (mu : ProbabilityMeasure (Real × Real)) :
    0 ≤ populationTauStar mu := by
  have hBKR := bkrDiscrepancy_nonneg mu
  have hmain := two_bkrDiscrepancy_le_populationTauStar mu
  linarith

/-- Vanishing tau-star forces independence. -/
theorem coordinatesIndependent_of_populationTauStar_eq_zero
    (mu : ProbabilityMeasure (Real × Real))
    (hTau : populationTauStar mu = 0) :
    CoordinatesIndependent mu := by
  have hmain := two_bkrDiscrepancy_le_populationTauStar mu
  have hBKRnonneg := bkrDiscrepancy_nonneg mu
  have hBKRzero : bkrDiscrepancy mu = 0 := by
    rw [hTau] at hmain
    linarith
  exact (bkrDiscrepancy_eq_zero_iff_coordinatesIndependent mu).mp hBKRzero

/-- Exact zero characterization of Bergsma--Dassios tau-star for arbitrary
Borel probability laws on `ℝ × ℝ`. -/
theorem populationTauStar_eq_zero_iff_coordinatesIndependent
    (mu : ProbabilityMeasure (Real × Real)) :
    populationTauStar mu = 0 ↔ CoordinatesIndependent mu := by
  constructor
  · exact coordinatesIndependent_of_populationTauStar_eq_zero mu
  · exact populationTauStar_eq_zero_of_coordinatesIndependent mu

/-- Corollary 3 of the manuscript: every dependent bivariate Borel
probability law has strictly positive Bergsma--Dassios tau-star. -/
theorem populationTauStar_pos_of_not_coordinatesIndependent
    (mu : ProbabilityMeasure (Real × Real))
    (hdep : ¬ CoordinatesIndependent mu) :
    0 < populationTauStar mu := by
  have hBKR : 0 < bkrDiscrepancy mu :=
    (bkrDiscrepancy_pos_iff_not_coordinatesIndependent mu).mpr hdep
  calc
    0 < 2 * bkrDiscrepancy mu := by positivity
    _ ≤ populationTauStar mu :=
      two_bkrDiscrepancy_le_populationTauStar mu

end QDTauStar
