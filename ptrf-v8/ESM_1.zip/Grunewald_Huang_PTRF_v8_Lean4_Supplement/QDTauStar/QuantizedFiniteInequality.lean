import QDTauStar.FiniteLawBridge
import QDTauStar.CDFQuantizationLimit

/-!
# From the finite table inequality to arbitrary probability laws

At a fixed dyadic level, the two coordinate ranks have a finite joint law.
This file identifies that law's mass-table tau-star and BKR polynomials with
the two quantized population quantities from the manuscript.  The finite-table
inequality can therefore be applied without any positivity assumption on the
individual cells or marginals.  Passing to the two already-proved dominated
convergence limits gives the population inequality for every Borel probability
law on `ℝ × ℝ`.

The proof keeps every push-forward explicit.  In particular, it proves that
the row and column marginals of the finite joint rank law are the separately
defined rank laws, and that applying the rank pair to four independent draws
produces four independent copies of the finite joint rank law.
-/

open scoped Topology
open Filter MeasureTheory Set

namespace QDTauStar

section RankPushforwards

/-- The coordinatewise ordered dyadic-rank map on one bivariate observation. -/
noncomputable def dyadicRankPairMap (k : ℕ) (z : ℝ × ℝ) :
    DyadicRank k × DyadicRank k :=
  (dyadicRank k z.1, dyadicRank k z.2)

/-- The coordinatewise rank-pair map applied to each of four observations. -/
noncomputable def dyadicRankFourMap (k : ℕ) (draw : Four → (ℝ × ℝ)) :
    Four → (DyadicRank k × DyadicRank k) :=
  fun i => dyadicRankPairMap k (draw i)

theorem measurable_dyadicRankPairMap (k : ℕ) :
    Measurable (dyadicRankPairMap k) := by
  exact ((measurable_dyadicRank k).comp measurable_fst).prodMk
    ((measurable_dyadicRank k).comp measurable_snd)

theorem measurable_dyadicRankFourMap (k : ℕ) :
    Measurable (dyadicRankFourMap k) := by
  apply measurable_pi_lambda
  intro i
  exact (measurable_dyadicRankPairMap k).comp (measurable_pi_apply i)

/-- The row marginal of the finite joint rank law is exactly the first
coordinate rank law. -/
theorem finiteLawRow_dyadicRankJointLaw
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :
    finiteLawRow (dyadicRankJointLaw mu k) = dyadicRankXLaw mu k := by
  apply ProbabilityMeasure.toMeasure_injective
  unfold finiteLawRow dyadicRankJointLaw dyadicRankXLaw marginalX
  simp only [ProbabilityMeasure.toMeasure_map]
  rw [Measure.map_map measurable_fst
      (((measurable_dyadicRank k).comp measurable_fst).prodMk
        ((measurable_dyadicRank k).comp measurable_snd)),
    Measure.map_map (measurable_dyadicRank k) measurable_fst]
  rfl

/-- The column marginal of the finite joint rank law is exactly the second
coordinate rank law. -/
theorem finiteLawCol_dyadicRankJointLaw
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :
    finiteLawCol (dyadicRankJointLaw mu k) = dyadicRankYLaw mu k := by
  apply ProbabilityMeasure.toMeasure_injective
  unfold finiteLawCol dyadicRankJointLaw dyadicRankYLaw marginalY
  simp only [ProbabilityMeasure.toMeasure_map]
  rw [Measure.map_map measurable_snd
      (((measurable_dyadicRank k).comp measurable_fst).prodMk
        ((measurable_dyadicRank k).comp measurable_snd)),
    Measure.map_map (measurable_dyadicRank k) measurable_snd]
  rfl

/-- Ranking four independent bivariate observations gives four independent
copies of the joint rank law. -/
theorem fourfoldLaw_map_dyadicRankFourMap
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :
    (fourfoldLaw mu).map (measurable_dyadicRankFourMap k).aemeasurable =
      ProbabilityMeasure.pi (fun _ : Four => dyadicRankJointLaw mu k) := by
  apply ProbabilityMeasure.toMeasure_injective
  unfold fourfoldLaw dyadicRankJointLaw
  simp only [ProbabilityMeasure.toMeasure_map, ProbabilityMeasure.toMeasure_pi]
  exact Measure.pi_map_pi
    (fun _ : Four => (measurable_dyadicRankPairMap k).aemeasurable)

end RankPushforwards

section ExactFiniteCorrespondence

/-- The finite mass-table tau-star is exactly the population tau-star after
level-`k` dyadic rank quantization. -/
theorem finiteTableTauStar_dyadicRankLaw
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :
    finiteTableTauStar (finiteLawMass (dyadicRankJointLaw mu k)) =
      quantizedPopulationTauStar mu k := by
  rw [finiteTableTauStar_finiteLawMass_eq_integral]
  rw [← fourfoldLaw_map_dyadicRankFourMap mu k]
  simp only [ProbabilityMeasure.toMeasure_map]
  rw [integral_map (measurable_dyadicRankFourMap k).aemeasurable
    (Measurable.of_discrete.aestronglyMeasurable)]
  rfl

/-- The finite mass-table BKR polynomial is exactly the finite-rank BKR
integral.  The terminal CDF row and column are removed only through the
proved zero-boundary theorem. -/
theorem finiteTableBKR_dyadicRankLaw
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :
    finiteTableBKR (finiteLawMass (dyadicRankJointLaw mu k)) =
      dyadicRankBKR mu k := by
  rw [← finiteTableBKRAll_eq_finiteTableBKR
      (finiteLawMass (dyadicRankJointLaw mu k))
      (sum_finiteLawMass (dyadicRankJointLaw mu k)),
    finiteTableBKRAll_finiteLawMass_eq_integral,
    finiteLawRow_dyadicRankJointLaw,
    finiteLawCol_dyadicRankJointLaw]
  rfl

/-- The manuscript's finite-support inequality at every dyadic rank level,
including levels with zero-mass cells, rows, or columns. -/
theorem two_dyadicRankBKR_le_quantizedPopulationTauStar
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :
    2 * dyadicRankBKR mu k ≤ quantizedPopulationTauStar mu k := by
  have h := finiteTable_tauStar_ge_two_bkr_of_nonneg
    (finiteLawMass (dyadicRankJointLaw mu k))
    (finiteLawMass_nonneg (dyadicRankJointLaw mu k))
    (sum_finiteLawMass (dyadicRankJointLaw mu k))
  rw [finiteTableBKR_dyadicRankLaw,
    finiteTableTauStar_dyadicRankLaw] at h
  exact h

end ExactFiniteCorrespondence

section PopulationLimit

/-- Population form of the central inequality: twice the BKR discrepancy is
bounded above by the unnormalised Bergsma--Dassios tau-star for every Borel
probability law on `ℝ × ℝ`. -/
theorem two_bkrDiscrepancy_le_populationTauStar
    (mu : ProbabilityMeasure (ℝ × ℝ)) :
    2 * bkrDiscrepancy mu ≤ populationTauStar mu := by
  have hPair : Tendsto
      (fun k => (2 * dyadicRankBKR mu k, quantizedPopulationTauStar mu k))
      atTop (𝓝 (2 * bkrDiscrepancy mu, populationTauStar mu)) :=
    (tendsto_const_nhds.mul (tendsto_dyadicRankBKR mu)).prodMk_nhds
      (tendsto_quantizedPopulationTauStar mu)
  exact (isClosed_le continuous_fst continuous_snd).mem_of_tendsto hPair
    (Filter.Eventually.of_forall
      (two_dyadicRankBKR_le_quantizedPopulationTauStar mu))

end PopulationLimit

end QDTauStar
