import QDTauStar.Population

open MeasureTheory Set
open scoped symmDiff

namespace QDTauStar

private theorem measureReal_symmDiff_Iic_eq_abs_sub
    (nu : ProbabilityMeasure Real) (a b : Real) :
    (nu : Measure Real).real (Iic a ∆ Iic b) =
      |(nu : Measure Real).real (Iic a) -
        (nu : Measure Real).real (Iic b)| := by
  rw [measureReal_symmDiff_eq measurableSet_Iic measurableSet_Iic]
  by_cases hab : a ≤ b
  · have hsub : Iic a \ Iic b = ∅ :=
      sdiff_eq_empty.mpr (Iic_subset_Iic.mpr hab)
    have hmono : (nu : Measure Real).real (Iic a) ≤
        (nu : Measure Real).real (Iic b) :=
      measureReal_mono (Iic_subset_Iic.mpr hab)
    rw [hsub, measureReal_empty, zero_add,
      measureReal_sdiff (Iic_subset_Iic.mpr hab) measurableSet_Iic,
      abs_of_nonpos (sub_nonpos.mpr hmono)]
    ring
  · have hba : b ≤ a := le_of_not_ge hab
    have hsub : Iic b \ Iic a = ∅ :=
      sdiff_eq_empty.mpr (Iic_subset_Iic.mpr hba)
    have hmono : (nu : Measure Real).real (Iic b) ≤
        (nu : Measure Real).real (Iic a) :=
      measureReal_mono (Iic_subset_Iic.mpr hba)
    rw [hsub, measureReal_empty, add_zero,
      measureReal_sdiff (Iic_subset_Iic.mpr hba) measurableSet_Iic,
      abs_of_nonneg (sub_nonneg.mpr hmono)]

private theorem lowerRect_symmDiff_subset_fst
    (x x' y : Real) :
    (Iic x ×ˢ Iic y) ∆ (Iic x' ×ˢ Iic y) ⊆
      Prod.fst ⁻¹' (Iic x ∆ Iic x') := by
  intro z hz
  rw [mem_symmDiff] at hz
  change z.1 ∈ Iic x ∆ Iic x'
  rw [mem_symmDiff]
  rcases hz with ⟨hA, hnB⟩ | ⟨hB, hnA⟩
  · left
    exact ⟨hA.1, fun hx' => hnB ⟨hx', hA.2⟩⟩
  · right
    exact ⟨hB.1, fun hx => hnA ⟨hx, hB.2⟩⟩

private theorem lowerRect_symmDiff_subset_snd
    (x y y' : Real) :
    (Iic x ×ˢ Iic y) ∆ (Iic x ×ˢ Iic y') ⊆
      Prod.snd ⁻¹' (Iic y ∆ Iic y') := by
  intro z hz
  rw [mem_symmDiff] at hz
  change z.2 ∈ Iic y ∆ Iic y'
  rw [mem_symmDiff]
  rcases hz with ⟨hA, hnB⟩ | ⟨hB, hnA⟩
  · left
    exact ⟨hA.2, fun hy' => hnB ⟨hA.1, hy'⟩⟩
  · right
    exact ⟨hB.2, fun hy => hnA ⟨hB.1, hy⟩⟩

theorem abs_jointCDF_sub_same_y_le
    (mu : ProbabilityMeasure (Real × Real)) (x x' y : Real) :
    |jointCDF mu x y - jointCDF mu x' y| ≤
      |marginalCDFX mu x - marginalCDFX mu x'| := by
  let A : Set (Real × Real) := Iic x ×ˢ Iic y
  let B : Set (Real × Real) := Iic x' ×ˢ Iic y
  calc
    |jointCDF mu x y - jointCDF mu x' y|
        ≤ (mu : Measure (Real × Real)).real (A ∆ B) := by
          exact abs_measureReal_sub_le_measureReal_symmDiff
            (measurableSet_Iic.prod measurableSet_Iic).nullMeasurableSet
            (measurableSet_Iic.prod measurableSet_Iic).nullMeasurableSet
    _ ≤ (mu : Measure (Real × Real)).real
          (Prod.fst ⁻¹' (Iic x ∆ Iic x')) := by
          exact measureReal_mono (lowerRect_symmDiff_subset_fst x x' y)
    _ = ((marginalX mu : ProbabilityMeasure Real) : Measure Real).real
          (Iic x ∆ Iic x') := by
          symm
          exact map_measureReal_apply measurable_fst
            (measurableSet_Iic.symmDiff measurableSet_Iic)
    _ = |marginalCDFX mu x - marginalCDFX mu x'| := by
          exact measureReal_symmDiff_Iic_eq_abs_sub (marginalX mu) x x'

theorem abs_jointCDF_sub_same_x_le
    (mu : ProbabilityMeasure (Real × Real)) (x y y' : Real) :
    |jointCDF mu x y - jointCDF mu x y'| ≤
      |marginalCDFY mu y - marginalCDFY mu y'| := by
  let A : Set (Real × Real) := Iic x ×ˢ Iic y
  let B : Set (Real × Real) := Iic x ×ˢ Iic y'
  calc
    |jointCDF mu x y - jointCDF mu x y'|
        ≤ (mu : Measure (Real × Real)).real (A ∆ B) := by
          exact abs_measureReal_sub_le_measureReal_symmDiff
            (measurableSet_Iic.prod measurableSet_Iic).nullMeasurableSet
            (measurableSet_Iic.prod measurableSet_Iic).nullMeasurableSet
    _ ≤ (mu : Measure (Real × Real)).real
          (Prod.snd ⁻¹' (Iic y ∆ Iic y')) := by
          exact measureReal_mono (lowerRect_symmDiff_subset_snd x y y')
    _ = ((marginalY mu : ProbabilityMeasure Real) : Measure Real).real
          (Iic y ∆ Iic y') := by
          symm
          exact map_measureReal_apply measurable_snd
            (measurableSet_Iic.symmDiff measurableSet_Iic)
    _ = |marginalCDFY mu y - marginalCDFY mu y'| := by
          exact measureReal_symmDiff_Iic_eq_abs_sub (marginalY mu) y y'

theorem abs_jointCDF_sub_le
    (mu : ProbabilityMeasure (Real × Real)) (x x' y y' : Real) :
    |jointCDF mu x y - jointCDF mu x' y'| ≤
      |marginalCDFX mu x - marginalCDFX mu x'| +
        |marginalCDFY mu y - marginalCDFY mu y'| := by
  calc
    |jointCDF mu x y - jointCDF mu x' y'|
        ≤ |jointCDF mu x y - jointCDF mu x' y| +
            |jointCDF mu x' y - jointCDF mu x' y'| := by
          exact abs_sub_le _ _ _
    _ ≤ |marginalCDFX mu x - marginalCDFX mu x'| +
          |marginalCDFY mu y - marginalCDFY mu y'| :=
      add_le_add (abs_jointCDF_sub_same_y_le mu x x' y)
        (abs_jointCDF_sub_same_x_le mu x' y y')

private theorem abs_mul_sub_mul_le
    {a a' b b' : Real}
    (ha'0 : 0 ≤ a') (ha'1 : a' ≤ 1)
    (hb0 : 0 ≤ b) (hb1 : b ≤ 1) :
    |a * b - a' * b'| ≤ |a - a'| + |b - b'| := by
  calc
    |a * b - a' * b'| = |(a - a') * b + a' * (b - b')| := by
      congr 1
      ring
    _ ≤ |(a - a') * b| + |a' * (b - b')| := abs_add_le _ _
    _ = |a - a'| * b + a' * |b - b'| := by
      rw [abs_mul, abs_mul, abs_of_nonneg hb0, abs_of_nonneg ha'0]
    _ ≤ |a - a'| * 1 + 1 * |b - b'| := by
      gcongr
    _ = |a - a'| + |b - b'| := by ring

theorem cdfDiscrepancy_variation
    (mu : ProbabilityMeasure (Real × Real)) (x x' y y' : Real) :
    |cdfDiscrepancy mu x y - cdfDiscrepancy mu x' y'| ≤
      2 * |marginalCDFX mu x - marginalCDFX mu x'| +
        2 * |marginalCDFY mu y - marginalCDFY mu y'| := by
  have hprod :
      |marginalCDFX mu x * marginalCDFY mu y -
          marginalCDFX mu x' * marginalCDFY mu y'| ≤
        |marginalCDFX mu x - marginalCDFX mu x'| +
          |marginalCDFY mu y - marginalCDFY mu y'| :=
    abs_mul_sub_mul_le measureReal_nonneg measureReal_le_one
      measureReal_nonneg measureReal_le_one
  have hjoint := abs_jointCDF_sub_le mu x x' y y'
  unfold cdfDiscrepancy
  calc
    |(jointCDF mu x y - marginalCDFX mu x * marginalCDFY mu y) -
        (jointCDF mu x' y' - marginalCDFX mu x' * marginalCDFY mu y')|
      ≤ |jointCDF mu x y - jointCDF mu x' y'| +
          |marginalCDFX mu x * marginalCDFY mu y -
            marginalCDFX mu x' * marginalCDFY mu y'| := by
        calc
          |(jointCDF mu x y - marginalCDFX mu x * marginalCDFY mu y) -
              (jointCDF mu x' y' - marginalCDFX mu x' * marginalCDFY mu y')|
            = |(jointCDF mu x y - jointCDF mu x' y') -
                (marginalCDFX mu x * marginalCDFY mu y -
                  marginalCDFX mu x' * marginalCDFY mu y')| := by
                congr 1
                ring
          _ ≤ |jointCDF mu x y - jointCDF mu x' y'| +
              |marginalCDFX mu x * marginalCDFY mu y -
                marginalCDFX mu x' * marginalCDFY mu y'| := abs_sub _ _
    _ ≤ (|marginalCDFX mu x - marginalCDFX mu x'| +
          |marginalCDFY mu y - marginalCDFY mu y'|) +
        (|marginalCDFX mu x - marginalCDFX mu x'| +
          |marginalCDFY mu y - marginalCDFY mu y'|) :=
      add_le_add hjoint hprod
    _ = 2 * |marginalCDFX mu x - marginalCDFX mu x'| +
        2 * |marginalCDFY mu y - marginalCDFY mu y'| := by ring

end QDTauStar

