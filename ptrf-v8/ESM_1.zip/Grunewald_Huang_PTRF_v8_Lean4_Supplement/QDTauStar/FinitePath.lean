import Mathlib
import QDTauStar.Algebra

open scoped BigOperators

namespace QDTauStar

/-! Finite ordered-support inequalities used after applying Lemma 6 to the
two path trees. -/

/-- The adjacent endpoint weight used by Lemma 6 dominates the atomic BKR
weight at the lower-left endpoint of the same grid cell. -/
theorem adjacent_weights_dominate_atomic
    {m n : ℕ}
    (p : Fin (m + 1) → ℝ) (q : Fin (n + 1) → ℝ)
    (delta : Fin m → Fin n → ℝ)
    (hp : ∀ i, 0 ≤ p i) (hq : ∀ j, 0 ≤ q j) :
    (∑ i, ∑ j, p i.castSucc * q j.castSucc * (delta i j) ^ 2) ≤
      ∑ i, ∑ j,
        (p i.castSucc + p i.succ) * (q j.castSucc + q j.succ) *
          (delta i j) ^ 2 := by
  refine Finset.sum_le_sum fun i _ => ?_
  refine Finset.sum_le_sum fun j _ => ?_
  have hpStep : p i.castSucc ≤ p i.castSucc + p i.succ := by
    linarith [hp i.succ]
  have hqStep : q j.castSucc ≤ q j.castSucc + q j.succ := by
    linarith [hq j.succ]
  have hpSum : 0 ≤ p i.castSucc + p i.succ :=
    add_nonneg (hp i.castSucc) (hp i.succ)
  have hProduct :
      p i.castSucc * q j.castSucc ≤
        (p i.castSucc + p i.succ) * (q j.castSucc + q j.succ) :=
    mul_le_mul hpStep hqStep (hq j.castSucc) hpSum
  exact mul_le_mul_of_nonneg_right hProduct (sq_nonneg (delta i j))

/-- This checks the numerical factors linking Lemma 6 to tau-star:
`Q >= 3 S` and `Q = (3/2) tauStar` imply `tauStar >= 2 S`. -/
theorem path_quartet_lower_to_tauStar_lower
    (quartetCovariance tauStar adjacentSum : ℝ)
    (hNormalisation : quartetCovariance = (3 / 2 : ℝ) * tauStar)
    (hQuartetLower : 3 * adjacentSum ≤ quartetCovariance) :
    2 * adjacentSum ≤ tauStar := by
  nlinarith

/-- The finite atomic BKR sum is nonnegative. -/
theorem finite_bkr_nonnegative
    {m n : ℕ}
    (p : Fin (m + 1) → ℝ) (q : Fin (n + 1) → ℝ)
    (delta : Fin m → Fin n → ℝ)
    (hp : ∀ i, 0 ≤ p i) (hq : ∀ j, 0 ≤ q j) :
    0 ≤ ∑ i, ∑ j, p i.castSucc * q j.castSucc * (delta i j) ^ 2 := by
  apply Finset.sum_nonneg
  intro i _
  apply Finset.sum_nonneg
  intro j _
  exact mul_nonneg (mul_nonneg (hp i.castSucc) (hq j.castSucc))
    (sq_nonneg (delta i j))

/-- Once Lemma 6 supplies the adjacent-weight path bound, deleting the
nonnegative adjacent terms leaves the atomic BKR lower bound. -/
theorem finite_tauStar_ge_two_bkr
    {m n : ℕ}
    (p : Fin (m + 1) → ℝ) (q : Fin (n + 1) → ℝ)
    (delta : Fin m → Fin n → ℝ) (tauStar : ℝ)
    (hp : ∀ i, 0 ≤ p i) (hq : ∀ j, 0 ≤ q j)
    (hPath :
      2 * (∑ i, ∑ j,
        (p i.castSucc + p i.succ) * (q j.castSucc + q j.succ) *
          (delta i j) ^ 2) ≤ tauStar) :
    2 * (∑ i, ∑ j, p i.castSucc * q j.castSucc * (delta i j) ^ 2) ≤
      tauStar := by
  have hDom := adjacent_weights_dominate_atomic p q delta hp hq
  nlinarith

/-- Direct paper-shaped version of the finite path argument, including both
the quartet-covariance normalization and Lemma 6's factor. -/
theorem finite_tauStar_ge_two_bkr_from_quartet
    {m n : ℕ}
    (p : Fin (m + 1) → ℝ) (q : Fin (n + 1) → ℝ)
    (delta : Fin m → Fin n → ℝ)
    (quartetCovariance tauStar : ℝ)
    (hp : ∀ i, 0 ≤ p i) (hq : ∀ j, 0 ≤ q j)
    (hNormalisation : quartetCovariance = (3 / 2 : ℝ) * tauStar)
    (hQuartetLower :
      3 * (∑ i, ∑ j,
        (p i.castSucc + p i.succ) * (q j.castSucc + q j.succ) *
          (delta i j) ^ 2) ≤ quartetCovariance) :
    2 * (∑ i, ∑ j, p i.castSucc * q j.castSucc * (delta i j) ^ 2) ≤
      tauStar := by
  have hPath := path_quartet_lower_to_tauStar_lower
    quartetCovariance tauStar
      (∑ i, ∑ j,
        (p i.castSucc + p i.succ) * (q j.castSucc + q j.succ) *
          (delta i j) ^ 2)
    hNormalisation hQuartetLower
  exact finite_tauStar_ge_two_bkr p q delta tauStar hp hq hPath

/-- The finite BKR sum includes no extra boundary contribution once the last
row and last column discrepancies vanish.  This theorem packages that exact
bookkeeping without imposing a particular representation of the grid. -/
theorem finite_bkr_boundary_terms_vanish
    (interior lastRow lastColumn corner : ℝ)
    (hRow : lastRow = 0) (hColumn : lastColumn = 0) (hCorner : corner = 0) :
    interior + lastRow + lastColumn + corner = interior := by
  rw [hRow, hColumn, hCorner]
  ring

end QDTauStar
