import QDTauStar.FiniteMassInequality

/-!
# Strictness of the finite-support tau-star/BKR inequality

This file retains the adjacent-marginal expression occurring before the final
termwise comparison in the finite path-tree proof.  Passing that stronger
bound from rational tables to real tables makes the strictness statement
transparent: if one interior CDF discrepancy is nonzero and every listed
marginal atom has positive mass, then the adjacent expression is strictly
larger than the atomic BKR expression.
-/

open scoped BigOperators Topology

namespace QDTauStar

section AdjacentPolynomial

variable {m n : ℕ}

/-- The stronger finite-table expression furnished directly by the path-tree
form of Lemma 6, before deleting the positive adjacent marginal masses. -/
noncomputable def finiteTableAdjacentBKR
    (p : OrderedCell m n → ℝ) : ℝ :=
  ∑ i : Fin m, ∑ j : Fin n,
    (finiteTableRowMass p i.castSucc + finiteTableRowMass p i.succ) *
      (finiteTableColMass p j.castSucc + finiteTableColMass p j.succ) *
        finiteTableDelta p i j ^ 2

/-- A table row mass is the sum of the cells in that row. -/
theorem finiteTableRowMass_eq_sum
    (p : OrderedCell m n → ℝ) (r : Fin (m + 1)) :
    finiteTableRowMass p r = ∑ c, p (r, c) := by
  classical
  unfold finiteTableRowMass finiteWeightedEventMass indicator
  rw [Fintype.sum_prod_type]
  simp

/-- A table column mass is the sum of the cells in that column. -/
theorem finiteTableColMass_eq_sum
    (p : OrderedCell m n → ℝ) (c : Fin (n + 1)) :
    finiteTableColMass p c = ∑ r, p (r, c) := by
  classical
  unfold finiteTableColMass finiteWeightedEventMass indicator
  rw [Fintype.sum_prod_type]
  simp

/-- For a rational probability table, the path-tree form of Lemma 6 gives
the stronger adjacent-marginal lower bound. -/
theorem rationalTable_tauStar_ge_two_adjacentBKR
    (p : OrderedCell m n → ℚ≥0)
    (hsum : ∑ rc, p rc = 1)
    (hrow : ∀ r, 0 < ∑ c, p (r, c))
    (hcol : ∀ c, 0 < ∑ r, p (r, c)) :
    2 * finiteTableAdjacentBKR (fun rc => (p rc : ℝ)) ≤
      finiteTableTauStar (fun rc => (p rc : ℝ)) := by
  have hrowSurj : Function.Surjective (rationalTableRow p) :=
    rationalTableRow_surjective p hrow
  have hcolSurj : Function.Surjective (rationalTableCol p) :=
    rationalTableCol_surjective p hcol
  letI : Nonempty (RationalTableLabel p) :=
    ⟨(hrowSurj 0).choose⟩
  have hQuartet := orderedPath_three_adjacentSum_le_treeQuartetCovariance
    (rationalTableRow p) (rationalTableCol p) hrowSurj hcolSurj
  have hNormalisation := orderedPath_treeQuartetCovariance_eq_threeHalves_tauStar
    (rationalTableRow p) (rationalTableCol p) hrowSurj hcolSurj
  have hPath := path_quartet_lower_to_tauStar_lower
    (QDFull.treeQuartetCovariance
      (orderedPathXTree (rationalTableRow p) hrowSurj)
      (orderedPathXTree (rationalTableCol p) hcolSurj))
    (finiteTauStar (rationalTableRow p) (rationalTableCol p)
      (uniformWeight (RationalTableLabel p)))
    (∑ i : Fin m, ∑ j : Fin n,
      (orderedAtomMass (rationalTableRow p) i.castSucc +
          orderedAtomMass (rationalTableRow p) i.succ) *
        (orderedAtomMass (rationalTableCol p) j.castSucc +
          orderedAtomMass (rationalTableCol p) j.succ) *
        orderedGridDelta (rationalTableRow p) (rationalTableCol p) i j ^ 2)
    hNormalisation hQuartet
  simp_rw [rationalTable_orderedAtomMass_row_eq p hsum,
    rationalTable_orderedAtomMass_col_eq p hsum,
    rationalTable_orderedGridDelta_eq p hsum] at hPath
  rw [rationalTable_finiteTauStar_eq p hsum] at hPath
  simpa only [finiteTableAdjacentBKR] using hPath

end AdjacentPolynomial

section AdjacentContinuity

variable {A : Type*} {l : Filter A} {m n : ℕ}

/-- The adjacent-marginal expression is a continuous polynomial in the fixed
finite table entries. -/
theorem tendsto_finiteTableAdjacentBKR
    (pA : A → OrderedCell m n → ℝ) (p : OrderedCell m n → ℝ)
    (hp : ∀ rc, Filter.Tendsto (fun a => pA a rc) l (nhds (p rc))) :
    Filter.Tendsto (fun a => finiteTableAdjacentBKR (pA a)) l
      (nhds (finiteTableAdjacentBKR p)) := by
  unfold finiteTableAdjacentBKR
  apply tendsto_finsetSum Finset.univ
  intro i _
  apply tendsto_finsetSum Finset.univ
  intro j _
  exact (((tendsto_finiteTableRowMass pA p hp i.castSucc).add
      (tendsto_finiteTableRowMass pA p hp i.succ)).mul
    ((tendsto_finiteTableColMass pA p hp j.castSucc).add
      (tendsto_finiteTableColMass pA p hp j.succ))).mul
    ((tendsto_finiteTableDelta pA p hp i j).pow 2)

end AdjacentContinuity

section FiniteSupportStrictness

variable {m n : ℕ}

/-- The stronger adjacent-marginal bound extends from rational probability
tables to arbitrary real probability tables with the same finite support. -/
theorem finiteTable_tauStar_ge_two_adjacentBKR
    (p : OrderedCell m n → ℝ) (s0 : PositiveMassSupport p)
    (hp : ∀ rc, 0 ≤ p rc) (hsum : ∑ rc, p rc = 1)
    (hrow : ∀ r, 0 < ∑ c, p (r, c))
    (hcol : ∀ c, 0 < ∑ r, p (r, c)) :
    2 * finiteTableAdjacentBKR p ≤ finiteTableTauStar p := by
  let q : ℕ → OrderedCell m n → ℚ≥0 :=
    fun N rc => fullSupportMassApproxNNRat p s0 N rc
  let pA : ℕ → OrderedCell m n → ℝ :=
    fun N rc => (q N rc : ℝ)
  have hpA : ∀ rc, Filter.Tendsto (fun N => pA N rc) Filter.atTop
      (nhds (p rc)) := by
    intro rc
    exact tendsto_fullSupportMassApproxNNRat p s0 hp hsum rc
  have hMarginals :
      ∀ᶠ N : ℕ in Filter.atTop,
        (∀ r, 0 < ∑ c, q N (r, c)) ∧
        (∀ c, 0 < ∑ r, q N (r, c)) := by
    filter_upwards [eventually_fullSupportMassApproxNNRat_marginals_pos
      p s0 hp hsum] with N hN
    exact ⟨fun r => hN.1 r (hrow r), fun c => hN.2 c (hcol c)⟩
  have hIneq :
      ∀ᶠ N : ℕ in Filter.atTop,
        2 * finiteTableAdjacentBKR (pA N) ≤ finiteTableTauStar (pA N) := by
    filter_upwards [hMarginals] with N hN
    exact rationalTable_tauStar_ge_two_adjacentBKR (q N)
      (sum_fullSupportMassApproxNNRat p s0 hp hsum N) hN.1 hN.2
  have hAdjacent : Filter.Tendsto
      (fun N => finiteTableAdjacentBKR (pA N)) Filter.atTop
      (nhds (finiteTableAdjacentBKR p)) :=
    tendsto_finiteTableAdjacentBKR pA p hpA
  have hTau : Filter.Tendsto (fun N => finiteTableTauStar (pA N))
      Filter.atTop (nhds (finiteTableTauStar p)) :=
    tendsto_finiteTableTauStar pA p hpA
  have hPair : Filter.Tendsto
      (fun N => (2 * finiteTableAdjacentBKR (pA N),
        finiteTableTauStar (pA N)))
      Filter.atTop
      (nhds (2 * finiteTableAdjacentBKR p, finiteTableTauStar p)) :=
    (tendsto_const_nhds.mul hAdjacent).prodMk_nhds hTau
  exact (isClosed_le continuous_fst continuous_snd).mem_of_tendsto hPair hIneq

/-- If at least one interior CDF discrepancy is nonzero, positivity of every
listed marginal atom makes the adjacent expression strictly larger than the
atomic BKR expression. -/
theorem finiteTableBKR_lt_adjacentBKR_of_delta_ne_zero
    (p : OrderedCell m n → ℝ)
    (hrow : ∀ r, 0 < ∑ c, p (r, c))
    (hcol : ∀ c, 0 < ∑ r, p (r, c))
    (hdep : ∃ i j, finiteTableDelta p i j ≠ 0) :
    finiteTableBKR p < finiteTableAdjacentBKR p := by
  have hrowMass (r : Fin (m + 1)) : 0 < finiteTableRowMass p r := by
    rw [finiteTableRowMass_eq_sum]
    exact hrow r
  have hcolMass (c : Fin (n + 1)) : 0 < finiteTableColMass p c := by
    rw [finiteTableColMass_eq_sum]
    exact hcol c
  have hterm_le (i : Fin m) (j : Fin n) :
      finiteTableRowMass p i.castSucc *
          finiteTableColMass p j.castSucc * finiteTableDelta p i j ^ 2 ≤
        (finiteTableRowMass p i.castSucc + finiteTableRowMass p i.succ) *
          (finiteTableColMass p j.castSucc + finiteTableColMass p j.succ) *
            finiteTableDelta p i j ^ 2 := by
    have hCoeff :
        finiteTableRowMass p i.castSucc * finiteTableColMass p j.castSucc ≤
          (finiteTableRowMass p i.castSucc + finiteTableRowMass p i.succ) *
            (finiteTableColMass p j.castSucc + finiteTableColMass p j.succ) :=
      mul_le_mul
        (le_add_of_nonneg_right (hrowMass i.succ).le)
        (le_add_of_nonneg_right (hcolMass j.succ).le)
        (hcolMass j.castSucc).le
        (add_nonneg (hrowMass i.castSucc).le (hrowMass i.succ).le)
    exact mul_le_mul_of_nonneg_right hCoeff (sq_nonneg _)
  rcases hdep with ⟨i, j, hdelta⟩
  unfold finiteTableBKR finiteTableAdjacentBKR
  apply Finset.sum_lt_sum
  · intro i' _
    exact Finset.sum_le_sum fun j' _ => hterm_le i' j'
  · refine ⟨i, Finset.mem_univ i, ?_⟩
    apply Finset.sum_lt_sum
    · intro j' _
      exact hterm_le i j'
    · refine ⟨j, Finset.mem_univ j, ?_⟩
      have hCoeff :
          finiteTableRowMass p i.castSucc * finiteTableColMass p j.castSucc <
            (finiteTableRowMass p i.castSucc + finiteTableRowMass p i.succ) *
              (finiteTableColMass p j.castSucc + finiteTableColMass p j.succ) :=
        mul_lt_mul
          (lt_add_of_pos_right _ (hrowMass i.succ))
          (le_add_of_nonneg_right (hcolMass j.succ).le)
          (hcolMass j.castSucc)
          (add_nonneg (hrowMass i.castSucc).le (hrowMass i.succ).le)
      exact mul_lt_mul_of_pos_right hCoeff (sq_pos_of_ne_zero hdelta)

/-- Finite-support strictness: dependence, expressed by a nonzero interior CDF
discrepancy, forces `tau-star > 2 * BKR`. -/
theorem finiteTable_tauStar_gt_two_bkr_of_delta_ne_zero
    (p : OrderedCell m n → ℝ) (s0 : PositiveMassSupport p)
    (hp : ∀ rc, 0 ≤ p rc) (hsum : ∑ rc, p rc = 1)
    (hrow : ∀ r, 0 < ∑ c, p (r, c))
    (hcol : ∀ c, 0 < ∑ r, p (r, c))
    (hdep : ∃ i j, finiteTableDelta p i j ≠ 0) :
    2 * finiteTableBKR p < finiteTableTauStar p := by
  have hAdjacent := finiteTable_tauStar_ge_two_adjacentBKR
    p s0 hp hsum hrow hcol
  have hStrict := finiteTableBKR_lt_adjacentBKR_of_delta_ne_zero
    p hrow hcol hdep
  linarith

/-- Hence equality in the finite-support lower bound can occur only when all
interior CDF discrepancies vanish, i.e. only for a factorising finite law. -/
theorem finiteTable_tauStar_eq_two_bkr_implies_delta_eq_zero
    (p : OrderedCell m n → ℝ) (s0 : PositiveMassSupport p)
    (hp : ∀ rc, 0 ≤ p rc) (hsum : ∑ rc, p rc = 1)
    (hrow : ∀ r, 0 < ∑ c, p (r, c))
    (hcol : ∀ c, 0 < ∑ r, p (r, c))
    (heq : finiteTableTauStar p = 2 * finiteTableBKR p) :
    ∀ i j, finiteTableDelta p i j = 0 := by
  intro i j
  by_contra hne
  have hStrict := finiteTable_tauStar_gt_two_bkr_of_delta_ne_zero
    p s0 hp hsum hrow hcol ⟨i, j, hne⟩
  linarith

end FiniteSupportStrictness

end QDTauStar
