import QDTauStar.FinitePathTree
import QDTauStar.FiniteSymmetrization

/-!
# Exact finite path-tree normalisation for tau-star

This module identifies strict two--two order separation with display by an
actual cut of the ordered path `X`-tree, classifies the same and different
tree-quartet events including ties, proves that uniform product weights equal
the paper's four-draw probabilities, and combines that normalisation with the
actual path-tree form of Lemma 6.  The terminal theorem therefore proves the
finite inequality `2 * BKR <= tau-star` without a scalar bridge assumption.
-/

namespace QDTauStar

theorem pairBelow_iff_exists_pathCut {m : ℕ}
    (z : Four → Fin (m + 1)) (r s t u : Four) :
    PairBelow z r s t u ↔
      ∃ i : Fin m,
        z r ≤ i.castSucc ∧ z s ≤ i.castSucc ∧
          i.succ ≤ z t ∧ i.succ ≤ z u := by
  constructor
  · rintro ⟨hrt, hru, hst, hsu⟩
    let M : Fin (m + 1) := max (z r) (z s)
    have hMt : M < z t := by
      exact max_lt hrt hst
    have hMu : M < z u := by
      exact max_lt hru hsu
    let i : Fin m := ⟨M.val, by omega⟩
    refine ⟨i, ?_, ?_, ?_, ?_⟩
    · change z r ≤ M
      exact le_max_left _ _
    · change z s ≤ M
      exact le_max_right _ _
    · change M.val + 1 ≤ (z t).val
      omega
    · change M.val + 1 ≤ (z u).val
      omega
  · rintro ⟨i, hr, hs, ht, hu⟩
    have hcut : i.castSucc < i.succ :=
      Fin.castSucc_lt_succ_iff.mpr (le_refl i)
    exact ⟨hr.trans_lt (hcut.trans_le ht),
      hr.trans_lt (hcut.trans_le hu),
      hs.trans_lt (hcut.trans_le ht),
      hs.trans_lt (hcut.trans_le hu)⟩

theorem strictlySeparates_iff_exists_pathCut {m : ℕ}
    (z : Four → Fin (m + 1)) (r s t u : Four) :
    StrictlySeparates z r s t u ↔
      ∃ i : Fin m,
        ((z r ≤ i.castSucc ∧ z s ≤ i.castSucc ∧
            i.succ ≤ z t ∧ i.succ ≤ z u) ∨
          (z t ≤ i.castSucc ∧ z u ≤ i.castSucc ∧
            i.succ ≤ z r ∧ i.succ ≤ z s)) := by
  rw [StrictlySeparates]
  constructor
  · rintro (h | h)
    · obtain ⟨i, hi⟩ := (pairBelow_iff_exists_pathCut z r s t u).mp h
      exact ⟨i, Or.inl hi⟩
    · obtain ⟨i, hi⟩ := (pairBelow_iff_exists_pathCut z t u r s).mp h
      exact ⟨i, Or.inr hi⟩
  · rintro ⟨i, hi | hi⟩
    · exact Or.inl ((pairBelow_iff_exists_pathCut z r s t u).mpr ⟨i, hi⟩)
    · exact Or.inr ((pairBelow_iff_exists_pathCut z t u r s).mpr ⟨i, hi⟩)

universe uX

variable {X : Type uX} [Fintype X] [DecidableEq X]

theorem orderedPath_cut_displays_drawPairSplit_iff {m : ℕ}
    (coord : X → Fin (m + 1)) (hsurj : Function.Surjective coord)
    (draw : Four → X) (i : Fin m) (r s t u : Four) :
    QDFull.Displays
        ((orderedPathXTree coord hsurj).edgeSplit i.castSucc i.succ)
        (QDFull.drawPairSplit draw r s t u) ↔
      ((coord (draw r) ≤ i.castSucc ∧ coord (draw s) ≤ i.castSucc ∧
          i.succ ≤ coord (draw t) ∧ i.succ ≤ coord (draw u)) ∨
        (coord (draw t) ≤ i.castSucc ∧ coord (draw u) ≤ i.castSucc ∧
          i.succ ≤ coord (draw r) ∧ i.succ ≤ coord (draw s))) := by
  classical
  rw [QDFull.XTree.edgeSplit, QDFull.drawPairSplit,
    QDFull.displays_comm_representative]
  rw [orderedPath_edgeSide_upper_eq, orderedPath_edgeSide_lower_eq]
  simp only [Finset.insert_subset_iff,
    Finset.singleton_subset_iff, Finset.mem_compl, mem_orderedLowerSet]
  have hcut (x : Fin (m + 1)) : ¬ x ≤ i.castSucc ↔ i.succ ≤ x := by
    simpa only [not_le] using
      (Fin.castSucc_lt_iff_succ_le (i := i) (j := x))
  constructor
  · rintro (⟨hrt, hsu⟩ | ⟨hrs, htu⟩)
    · right
      exact ⟨hsu.1, hsu.2,
        (hcut _).mp hrt.1,
        (hcut _).mp hrt.2⟩
    · left
      exact ⟨hrs.1, hrs.2,
        (hcut _).mp htu.1,
        (hcut _).mp htu.2⟩
  · rintro (h | h)
    · right
      exact ⟨⟨h.1, h.2.1⟩,
        ⟨(hcut _).mpr h.2.2.1,
          (hcut _).mpr h.2.2.2⟩⟩
    · left
      exact ⟨⟨(hcut _).mpr h.2.2.1,
          (hcut _).mpr h.2.2.2⟩,
        ⟨h.1, h.2.1⟩⟩

theorem orderedPath_displaysPartialSplit_iff_exists_cut {m : ℕ}
    (coord : X → Fin (m + 1)) (hsurj : Function.Surjective coord)
    (P : QDFull.PartialSplit X) :
    (orderedPathXTree coord hsurj).DisplaysPartialSplit P ↔
      ∃ i : Fin m,
        QDFull.Displays
          ((orderedPathXTree coord hsurj).edgeSplit i.castSucc i.succ) P := by
  constructor
  · rintro ⟨u, v, huv, hdisplay⟩
    change (SimpleGraph.pathGraph (m + 1)).Adj u v at huv
    rw [SimpleGraph.pathGraph_adj] at huv
    rcases huv with huv | hvu
    · let i : Fin m := ⟨u.val, by omega⟩
      refine ⟨i, ?_⟩
      have hu : i.castSucc = u := Fin.ext (by simp [i])
      have hv : i.succ = v := Fin.ext (by simp [i, huv])
      simpa [hu, hv] using hdisplay
    · let i : Fin m := ⟨v.val, by omega⟩
      refine ⟨i, ?_⟩
      have hv : i.castSucc = v := Fin.ext (by simp [i])
      have hu : i.succ = u := Fin.ext (by simp [i, hvu])
      rw [hu, hv]
      rw [(orderedPathXTree coord hsurj).edgeSplit_comm]
      exact hdisplay
  · rintro ⟨i, hdisplay⟩
    exact ⟨i.castSucc, i.succ, pathGraph_adj_cut i, hdisplay⟩

theorem orderedPath_displays_drawPairSplit_iff_strictlySeparates {m : ℕ}
    (coord : X → Fin (m + 1)) (hsurj : Function.Surjective coord)
    (draw : Four → X) (r s t u : Four) :
    (orderedPathXTree coord hsurj).DisplaysPartialSplit
        (QDFull.drawPairSplit draw r s t u) ↔
      StrictlySeparates (coord ∘ draw) r s t u := by
  rw [orderedPath_displaysPartialSplit_iff_exists_cut,
    strictlySeparates_iff_exists_pathCut]
  constructor
  · rintro ⟨i, hdisplay⟩
    refine ⟨i, ?_⟩
    simpa only [Function.comp_apply] using
      (orderedPath_cut_displays_drawPairSplit_iff
        coord hsurj draw i r s t u).mp hdisplay
  · rintro ⟨i, hcut⟩
    refine ⟨i, ?_⟩
    apply (orderedPath_cut_displays_drawPairSplit_iff
      coord hsurj draw i r s t u).mpr
    simpa only [Function.comp_apply] using hcut

private theorem drawPairSplit_isPartialSplit_of_treeDisplay
    {V : Type*} [Fintype V]
    (T : QDFull.XTree X V) (draw : Four → X) (r s t u : Four)
    (hdisplay : T.DisplaysPartialSplit
      (QDFull.drawPairSplit draw r s t u)) :
    QDFull.IsPartialSplit (QDFull.drawPairSplit draw r s t u) := by
  rcases hdisplay with ⟨a, b, hab, h⟩
  exact QDFull.drawPairSplit_isPartialSplit_of_displays
    draw (T.edgeSide a b) (T.edgeSide b a) r s t u
      (T.edgeSide_disjoint_reverse_of_adj hab) h

theorem orderedPath_sameTreeQuartetEvent_iff_commonStrict
    {m n : ℕ}
    (row : X → Fin (m + 1)) (col : X → Fin (n + 1))
    (hrow : Function.Surjective row) (hcol : Function.Surjective col)
    (draw : Four → X) :
    QDFull.SameTreeQuartetEvent
        (orderedPathXTree row hrow) (orderedPathXTree col hcol) draw ↔
      E12_12 row col draw ∨ E13_13 row col draw ∨
        E14_14 row col draw := by
  constructor
  · rintro ⟨R, hind, hRrow, hRcol⟩
    rcases (QDFull.induces_iff_canonical draw R).mp hind with
      ⟨-, hR | hR | hR⟩
    · left
      constructor <;>
        rw [Pairing12, ← orderedPath_displays_drawPairSplit_iff_strictlySeparates]
      · simpa [hR] using hRrow
      · simpa [hR] using hRcol
    · right; left
      constructor <;>
        rw [Pairing13, ← orderedPath_displays_drawPairSplit_iff_strictlySeparates]
      · simpa [hR] using hRrow
      · simpa [hR] using hRcol
    · right; right
      constructor <;>
        rw [Pairing14, ← orderedPath_displays_drawPairSplit_iff_strictlySeparates]
      · simpa [hR] using hRrow
      · simpa [hR] using hRcol
  · rintro (h | h | h)
    · let P := QDFull.drawPairSplit draw 0 1 2 3
      have hProw : (orderedPathXTree row hrow).DisplaysPartialSplit P := by
        rw [orderedPath_displays_drawPairSplit_iff_strictlySeparates]
        exact h.1
      have hPcol : (orderedPathXTree col hcol).DisplaysPartialSplit P := by
        rw [orderedPath_displays_drawPairSplit_iff_strictlySeparates]
        exact h.2
      have hPpartial := drawPairSplit_isPartialSplit_of_treeDisplay
        (orderedPathXTree row hrow) draw 0 1 2 3 hProw
      refine ⟨P, (QDFull.induces_iff_canonical draw P).mpr ?_, hProw, hPcol⟩
      exact ⟨hPpartial, Or.inl rfl⟩
    · let P := QDFull.drawPairSplit draw 0 2 1 3
      have hProw : (orderedPathXTree row hrow).DisplaysPartialSplit P := by
        rw [orderedPath_displays_drawPairSplit_iff_strictlySeparates]
        exact h.1
      have hPcol : (orderedPathXTree col hcol).DisplaysPartialSplit P := by
        rw [orderedPath_displays_drawPairSplit_iff_strictlySeparates]
        exact h.2
      have hPpartial := drawPairSplit_isPartialSplit_of_treeDisplay
        (orderedPathXTree row hrow) draw 0 2 1 3 hProw
      refine ⟨P, (QDFull.induces_iff_canonical draw P).mpr ?_, hProw, hPcol⟩
      exact ⟨hPpartial, Or.inr (Or.inl rfl)⟩
    · let P := QDFull.drawPairSplit draw 0 3 1 2
      have hProw : (orderedPathXTree row hrow).DisplaysPartialSplit P := by
        rw [orderedPath_displays_drawPairSplit_iff_strictlySeparates]
        exact h.1
      have hPcol : (orderedPathXTree col hcol).DisplaysPartialSplit P := by
        rw [orderedPath_displays_drawPairSplit_iff_strictlySeparates]
        exact h.2
      have hPpartial := drawPairSplit_isPartialSplit_of_treeDisplay
        (orderedPathXTree row hrow) draw 0 3 1 2 hProw
      refine ⟨P, (QDFull.induces_iff_canonical draw P).mpr ?_, hProw, hPcol⟩
      exact ⟨hPpartial, Or.inr (Or.inr rfl)⟩

private theorem differentTreeQuartetEvent_of_canonical_display_pair
    {V₁ V₂ : Type*} [Fintype V₁] [Fintype V₂]
    (T₁ : QDFull.XTree X V₁) (T₂ : QDFull.XTree X V₂)
    (draw : Four → X) (P Q : QDFull.PartialSplit X)
    (hP : T₁.DisplaysPartialSplit P)
    (hQ : T₂.DisplaysPartialSplit Q)
    (hSplit : ∀ A B C D : Finset X,
      Disjoint A B → Disjoint C D →
      QDFull.Displays s(A, B) P → QDFull.Displays s(C, D) Q →
        QDFull.DifferentSplitQuartetEvent s(A, B) s(C, D) draw) :
    QDFull.DifferentTreeQuartetEvent T₁ T₂ draw := by
  rcases hP with ⟨a, b, hab, hSP⟩
  rcases hQ with ⟨c, d, hcd, hTQ⟩
  apply QDFull.differentSplitQuartetEvent_imp_differentTreeQuartetEvent
    T₁ T₂ (T₁.displays_edgeSplit hab) (T₂.displays_edgeSplit hcd)
  simpa only [QDFull.XTree.edgeSplit] using
    hSplit (T₁.edgeSide a b) (T₁.edgeSide b a)
      (T₂.edgeSide c d) (T₂.edgeSide d c)
      (T₁.edgeSide_disjoint_reverse_of_adj hab)
      (T₂.edgeSide_disjoint_reverse_of_adj hcd) hSP hTQ

theorem orderedPath_differentTreeQuartetEvent_iff_conflictingStrict
    {m n : ℕ}
    (row : X → Fin (m + 1)) (col : X → Fin (n + 1))
    (hrow : Function.Surjective row) (hcol : Function.Surjective col)
    (draw : Four → X) :
    QDFull.DifferentTreeQuartetEvent
        (orderedPathXTree row hrow) (orderedPathXTree col hcol) draw ↔
      E12_13 row col draw ∨ E13_12 row col draw ∨
      E12_14 row col draw ∨ E14_12 row col draw ∨
      E13_14 row col draw ∨ E14_13 row col draw := by
  constructor
  · rintro ⟨R, S, hindR, hindS, hRrow, hScol, hne⟩
    rcases (QDFull.induces_iff_canonical draw R).mp hindR with
      ⟨-, hR | hR | hR⟩ <;>
      rcases (QDFull.induces_iff_canonical draw S).mp hindS with
        ⟨-, hS | hS | hS⟩
    · exact (hne (hR.trans hS.symm)).elim
    · left
      constructor
      · rw [Pairing12, ← orderedPath_displays_drawPairSplit_iff_strictlySeparates]
        simpa [hR] using hRrow
      · rw [Pairing13, ← orderedPath_displays_drawPairSplit_iff_strictlySeparates]
        simpa [hS] using hScol
    · right; right; left
      constructor
      · rw [Pairing12, ← orderedPath_displays_drawPairSplit_iff_strictlySeparates]
        simpa [hR] using hRrow
      · rw [Pairing14, ← orderedPath_displays_drawPairSplit_iff_strictlySeparates]
        simpa [hS] using hScol
    · right; left
      constructor
      · rw [Pairing13, ← orderedPath_displays_drawPairSplit_iff_strictlySeparates]
        simpa [hR] using hRrow
      · rw [Pairing12, ← orderedPath_displays_drawPairSplit_iff_strictlySeparates]
        simpa [hS] using hScol
    · exact (hne (hR.trans hS.symm)).elim
    · right; right; right; right; left
      constructor
      · rw [Pairing13, ← orderedPath_displays_drawPairSplit_iff_strictlySeparates]
        simpa [hR] using hRrow
      · rw [Pairing14, ← orderedPath_displays_drawPairSplit_iff_strictlySeparates]
        simpa [hS] using hScol
    · right; right; right; left
      constructor
      · rw [Pairing14, ← orderedPath_displays_drawPairSplit_iff_strictlySeparates]
        simpa [hR] using hRrow
      · rw [Pairing12, ← orderedPath_displays_drawPairSplit_iff_strictlySeparates]
        simpa [hS] using hScol
    · right; right; right; right; right
      constructor
      · rw [Pairing14, ← orderedPath_displays_drawPairSplit_iff_strictlySeparates]
        simpa [hR] using hRrow
      · rw [Pairing13, ← orderedPath_displays_drawPairSplit_iff_strictlySeparates]
        simpa [hS] using hScol
    · exact (hne (hR.trans hS.symm)).elim
  · rintro (h | h | h | h | h | h)
    · apply differentTreeQuartetEvent_of_canonical_display_pair
        (orderedPathXTree row hrow) (orderedPathXTree col hcol) draw
        (QDFull.drawPairSplit draw 0 1 2 3)
        (QDFull.drawPairSplit draw 0 2 1 3)
      · exact (orderedPath_displays_drawPairSplit_iff_strictlySeparates
          row hrow draw 0 1 2 3).mpr h.1
      · exact (orderedPath_displays_drawPairSplit_iff_strictlySeparates
          col hcol draw 0 2 1 3).mpr h.2
      · intro A B C D hAB hCD hAP hCQ
        exact (QDFull.differentSplitQuartetEvent_iff_canonical
          draw A B C D hAB hCD).mpr (Or.inl ⟨hAP, hCQ⟩)
    · apply differentTreeQuartetEvent_of_canonical_display_pair
        (orderedPathXTree row hrow) (orderedPathXTree col hcol) draw
        (QDFull.drawPairSplit draw 0 2 1 3)
        (QDFull.drawPairSplit draw 0 1 2 3)
      · exact (orderedPath_displays_drawPairSplit_iff_strictlySeparates
          row hrow draw 0 2 1 3).mpr h.1
      · exact (orderedPath_displays_drawPairSplit_iff_strictlySeparates
          col hcol draw 0 1 2 3).mpr h.2
      · intro A B C D hAB hCD hAP hCQ
        exact (QDFull.differentSplitQuartetEvent_iff_canonical
          draw A B C D hAB hCD).mpr (Or.inr (Or.inr (Or.inl ⟨hAP, hCQ⟩)))
    · apply differentTreeQuartetEvent_of_canonical_display_pair
        (orderedPathXTree row hrow) (orderedPathXTree col hcol) draw
        (QDFull.drawPairSplit draw 0 1 2 3)
        (QDFull.drawPairSplit draw 0 3 1 2)
      · exact (orderedPath_displays_drawPairSplit_iff_strictlySeparates
          row hrow draw 0 1 2 3).mpr h.1
      · exact (orderedPath_displays_drawPairSplit_iff_strictlySeparates
          col hcol draw 0 3 1 2).mpr h.2
      · intro A B C D hAB hCD hAP hCQ
        exact (QDFull.differentSplitQuartetEvent_iff_canonical
          draw A B C D hAB hCD).mpr (Or.inr (Or.inl ⟨hAP, hCQ⟩))
    · apply differentTreeQuartetEvent_of_canonical_display_pair
        (orderedPathXTree row hrow) (orderedPathXTree col hcol) draw
        (QDFull.drawPairSplit draw 0 3 1 2)
        (QDFull.drawPairSplit draw 0 1 2 3)
      · exact (orderedPath_displays_drawPairSplit_iff_strictlySeparates
          row hrow draw 0 3 1 2).mpr h.1
      · exact (orderedPath_displays_drawPairSplit_iff_strictlySeparates
          col hcol draw 0 1 2 3).mpr h.2
      · intro A B C D hAB hCD hAP hCQ
        exact (QDFull.differentSplitQuartetEvent_iff_canonical
          draw A B C D hAB hCD).mpr
            (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl ⟨hAP, hCQ⟩)))))
    · apply differentTreeQuartetEvent_of_canonical_display_pair
        (orderedPathXTree row hrow) (orderedPathXTree col hcol) draw
        (QDFull.drawPairSplit draw 0 2 1 3)
        (QDFull.drawPairSplit draw 0 3 1 2)
      · exact (orderedPath_displays_drawPairSplit_iff_strictlySeparates
          row hrow draw 0 2 1 3).mpr h.1
      · exact (orderedPath_displays_drawPairSplit_iff_strictlySeparates
          col hcol draw 0 3 1 2).mpr h.2
      · intro A B C D hAB hCD hAP hCQ
        exact (QDFull.differentSplitQuartetEvent_iff_canonical
          draw A B C D hAB hCD).mpr
            (Or.inr (Or.inr (Or.inr (Or.inl ⟨hAP, hCQ⟩))))
    · apply differentTreeQuartetEvent_of_canonical_display_pair
        (orderedPathXTree row hrow) (orderedPathXTree col hcol) draw
        (QDFull.drawPairSplit draw 0 3 1 2)
        (QDFull.drawPairSplit draw 0 2 1 3)
      · exact (orderedPath_displays_drawPairSplit_iff_strictlySeparates
          row hrow draw 0 3 1 2).mpr h.1
      · exact (orderedPath_displays_drawPairSplit_iff_strictlySeparates
          col hcol draw 0 2 1 3).mpr h.2
      · intro A B C D hAB hCD hAP hCQ
        exact (QDFull.differentSplitQuartetEvent_iff_canonical
          draw A B C D hAB hCD).mpr
            (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr ⟨hAP, hCQ⟩)))))

noncomputable def uniformWeight (X : Type*) [Fintype X] : X → ℝ :=
  fun _ ↦ 1 / (Fintype.card X : ℝ)

theorem fourDrawWeight_uniform (draw : Four → X) :
    fourDrawWeight (uniformWeight X) draw =
      1 / (Fintype.card X : ℝ) ^ 4 := by
  simp [fourDrawWeight, uniformWeight]

theorem weightedEventMass_uniform_eq_fourDrawProbability
    [Nonempty X] (E : (Four → X) → Prop) :
    weightedEventMass (uniformWeight X) E =
      QDFull.fourDrawProbability E := by
  classical
  rw [QDFull.fourDrawProbability_eq]
  unfold weightedEventMass weightedFourSum
  simp_rw [fourDrawWeight_uniform]
  rw [← Finset.mul_sum]
  have hindicator :
      (∑ draw : Four → X, indicator (E draw)) =
        (QDFull.fourDrawEventSet E).card := by
    unfold QDFull.fourDrawEventSet
    simp [indicator]
  rw [hindicator]
  have hcard : (Fintype.card X : ℝ) ≠ 0 := by
    exact_mod_cast Fintype.card_ne_zero
  field_simp

private theorem indicator_commonStrict_union
    {A B Ω : Type*} [LinearOrder A] [LinearOrder B]
    (x : Ω → A) (y : Ω → B) (draw : Four → Ω) :
    indicator (E12_12 x y draw ∨ E13_13 x y draw ∨ E14_14 x y draw) =
      indicator (E12_12 x y draw) + indicator (E13_13 x y draw) +
        indicator (E14_14 x y draw) := by
  have h12_13 : ¬(E12_12 x y draw ∧ E13_13 x y draw) := by
    rintro ⟨⟨hx12, -⟩, ⟨hx13, -⟩⟩
    exact not_pairing13_of_pairing12 hx12 hx13
  have h12_14 : ¬(E12_12 x y draw ∧ E14_14 x y draw) := by
    rintro ⟨⟨hx12, -⟩, ⟨hx14, -⟩⟩
    exact not_pairing14_of_pairing12 hx12 hx14
  have h13_14 : ¬(E13_13 x y draw ∧ E14_14 x y draw) := by
    rintro ⟨⟨hx13, -⟩, ⟨hx14, -⟩⟩
    exact not_pairing14_of_pairing13 hx13 hx14
  by_cases h12 : E12_12 x y draw <;>
    by_cases h13 : E13_13 x y draw <;>
    by_cases h14 : E14_14 x y draw <;>
    simp [indicator, h12, h13, h14] at h12_13 h12_14 h13_14 ⊢

theorem commonStrictMass_eq_unionMass
    {A B Ω : Type*} [LinearOrder A] [LinearOrder B] [Fintype Ω]
    (x : Ω → A) (y : Ω → B) (weight : Ω → ℝ) :
    commonStrictMass x y weight =
      weightedEventMass weight
        (fun draw ↦ E12_12 x y draw ∨ E13_13 x y draw ∨
          E14_14 x y draw) := by
  classical
  unfold commonStrictMass weightedEventMass weightedFourSum
  rw [← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro draw _
  simp only
  rw [indicator_commonStrict_union]
  ring

private theorem indicator_conflictingStrict_union
    {A B Ω : Type*} [LinearOrder A] [LinearOrder B]
    (x : Ω → A) (y : Ω → B) (draw : Four → Ω) :
    indicator (E12_13 x y draw ∨ E13_12 x y draw ∨
      E12_14 x y draw ∨ E14_12 x y draw ∨
      E13_14 x y draw ∨ E14_13 x y draw) =
      indicator (E12_13 x y draw) + indicator (E13_12 x y draw) +
      indicator (E12_14 x y draw) + indicator (E14_12 x y draw) +
      indicator (E13_14 x y draw) + indicator (E14_13 x y draw) := by
  have hAB : ¬(E12_13 x y draw ∧ E13_12 x y draw) := by
    rintro ⟨⟨hx12, -⟩, ⟨hx13, -⟩⟩
    exact not_pairing13_of_pairing12 hx12 hx13
  have hAC : ¬(E12_13 x y draw ∧ E12_14 x y draw) := by
    rintro ⟨⟨-, hy13⟩, ⟨-, hy14⟩⟩
    exact not_pairing14_of_pairing13 hy13 hy14
  have hAD : ¬(E12_13 x y draw ∧ E14_12 x y draw) := by
    rintro ⟨⟨hx12, -⟩, ⟨hx14, -⟩⟩
    exact not_pairing14_of_pairing12 hx12 hx14
  have hAE : ¬(E12_13 x y draw ∧ E13_14 x y draw) := by
    rintro ⟨⟨hx12, -⟩, ⟨hx13, -⟩⟩
    exact not_pairing13_of_pairing12 hx12 hx13
  have hAF : ¬(E12_13 x y draw ∧ E14_13 x y draw) := by
    rintro ⟨⟨hx12, -⟩, ⟨hx14, -⟩⟩
    exact not_pairing14_of_pairing12 hx12 hx14
  have hBC : ¬(E13_12 x y draw ∧ E12_14 x y draw) := by
    rintro ⟨⟨hx13, -⟩, ⟨hx12, -⟩⟩
    exact not_pairing12_of_pairing13 hx13 hx12
  have hBD : ¬(E13_12 x y draw ∧ E14_12 x y draw) := by
    rintro ⟨⟨hx13, -⟩, ⟨hx14, -⟩⟩
    exact not_pairing14_of_pairing13 hx13 hx14
  have hBE : ¬(E13_12 x y draw ∧ E13_14 x y draw) := by
    rintro ⟨⟨-, hy12⟩, ⟨-, hy14⟩⟩
    exact not_pairing14_of_pairing12 hy12 hy14
  have hBF : ¬(E13_12 x y draw ∧ E14_13 x y draw) := by
    rintro ⟨⟨hx13, -⟩, ⟨hx14, -⟩⟩
    exact not_pairing14_of_pairing13 hx13 hx14
  have hCD : ¬(E12_14 x y draw ∧ E14_12 x y draw) := by
    rintro ⟨⟨hx12, -⟩, ⟨hx14, -⟩⟩
    exact not_pairing14_of_pairing12 hx12 hx14
  have hCE : ¬(E12_14 x y draw ∧ E13_14 x y draw) := by
    rintro ⟨⟨hx12, -⟩, ⟨hx13, -⟩⟩
    exact not_pairing13_of_pairing12 hx12 hx13
  have hCF : ¬(E12_14 x y draw ∧ E14_13 x y draw) := by
    rintro ⟨⟨hx12, -⟩, ⟨hx14, -⟩⟩
    exact not_pairing14_of_pairing12 hx12 hx14
  have hDE : ¬(E14_12 x y draw ∧ E13_14 x y draw) := by
    rintro ⟨⟨hx14, -⟩, ⟨hx13, -⟩⟩
    exact not_pairing13_of_pairing14 hx14 hx13
  have hDF : ¬(E14_12 x y draw ∧ E14_13 x y draw) := by
    rintro ⟨⟨-, hy12⟩, ⟨-, hy13⟩⟩
    exact not_pairing13_of_pairing12 hy12 hy13
  have hEF : ¬(E13_14 x y draw ∧ E14_13 x y draw) := by
    rintro ⟨⟨hx13, -⟩, ⟨hx14, -⟩⟩
    exact not_pairing14_of_pairing13 hx13 hx14
  by_cases hA : E12_13 x y draw <;>
    by_cases hB : E13_12 x y draw <;>
    by_cases hC : E12_14 x y draw <;>
    by_cases hD : E14_12 x y draw <;>
    by_cases hE : E13_14 x y draw <;>
    by_cases hF : E14_13 x y draw <;>
    simp [indicator, hA, hB, hC, hD, hE, hF] at *

theorem conflictingStrictMass_eq_unionMass
    {A B Ω : Type*} [LinearOrder A] [LinearOrder B] [Fintype Ω]
    (x : Ω → A) (y : Ω → B) (weight : Ω → ℝ) :
    conflictingStrictMass x y weight =
      weightedEventMass weight (fun draw ↦
        E12_13 x y draw ∨ E13_12 x y draw ∨
        E12_14 x y draw ∨ E14_12 x y draw ∨
        E13_14 x y draw ∨ E14_13 x y draw) := by
  classical
  unfold conflictingStrictMass weightedEventMass weightedFourSum
  repeat' rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro draw _
  simp only
  rw [indicator_conflictingStrict_union]
  ring

theorem weightedEventMass_congr_iff
    {Ω : Type*} [Fintype Ω] (weight : Ω → ℝ)
    {E F : (Four → Ω) → Prop} (h : ∀ draw, E draw ↔ F draw) :
    weightedEventMass weight E = weightedEventMass weight F := by
  unfold weightedEventMass weightedFourSum
  apply Finset.sum_congr rfl
  intro draw _
  apply congrArg (fun t : ℝ ↦ fourDrawWeight weight draw * t)
  exact congrArg indicator (propext (h draw))

theorem commonStrictMass_uniform_eq_pathSameProbability
    {m n : ℕ}
    (row : X → Fin (m + 1)) (col : X → Fin (n + 1))
    (hrow : Function.Surjective row) (hcol : Function.Surjective col) :
    commonStrictMass row col (uniformWeight X) =
      QDFull.fourDrawProbability
        (QDFull.SameTreeQuartetEvent
          (orderedPathXTree row hrow) (orderedPathXTree col hcol)) := by
  letI : Nonempty X := ⟨(hrow 0).choose⟩
  calc
    commonStrictMass row col (uniformWeight X) =
        weightedEventMass (uniformWeight X)
          (fun draw ↦ E12_12 row col draw ∨ E13_13 row col draw ∨
            E14_14 row col draw) :=
      commonStrictMass_eq_unionMass row col (uniformWeight X)
    _ = weightedEventMass (uniformWeight X)
        (QDFull.SameTreeQuartetEvent
          (orderedPathXTree row hrow) (orderedPathXTree col hcol)) := by
      apply weightedEventMass_congr_iff
      intro draw
      exact (orderedPath_sameTreeQuartetEvent_iff_commonStrict
        row col hrow hcol draw).symm
    _ = QDFull.fourDrawProbability
        (QDFull.SameTreeQuartetEvent
          (orderedPathXTree row hrow) (orderedPathXTree col hcol)) :=
      weightedEventMass_uniform_eq_fourDrawProbability _

theorem conflictingStrictMass_uniform_eq_pathDifferentProbability
    {m n : ℕ}
    (row : X → Fin (m + 1)) (col : X → Fin (n + 1))
    (hrow : Function.Surjective row) (hcol : Function.Surjective col) :
    conflictingStrictMass row col (uniformWeight X) =
      QDFull.fourDrawProbability
        (QDFull.DifferentTreeQuartetEvent
          (orderedPathXTree row hrow) (orderedPathXTree col hcol)) := by
  letI : Nonempty X := ⟨(hrow 0).choose⟩
  calc
    conflictingStrictMass row col (uniformWeight X) =
        weightedEventMass (uniformWeight X) (fun draw ↦
          E12_13 row col draw ∨ E13_12 row col draw ∨
          E12_14 row col draw ∨ E14_12 row col draw ∨
          E13_14 row col draw ∨ E14_13 row col draw) :=
      conflictingStrictMass_eq_unionMass row col (uniformWeight X)
    _ = weightedEventMass (uniformWeight X)
        (QDFull.DifferentTreeQuartetEvent
          (orderedPathXTree row hrow) (orderedPathXTree col hcol)) := by
      apply weightedEventMass_congr_iff
      intro draw
      exact (orderedPath_differentTreeQuartetEvent_iff_conflictingStrict
        row col hrow hcol draw).symm
    _ = QDFull.fourDrawProbability
        (QDFull.DifferentTreeQuartetEvent
          (orderedPathXTree row hrow) (orderedPathXTree col hcol)) :=
      weightedEventMass_uniform_eq_fourDrawProbability _

theorem orderedPath_treeQuartetCovariance_eq_threeHalves_tauStar
    {m n : ℕ}
    (row : X → Fin (m + 1)) (col : X → Fin (n + 1))
    (hrow : Function.Surjective row) (hcol : Function.Surjective col) :
    QDFull.treeQuartetCovariance
        (orderedPathXTree row hrow) (orderedPathXTree col hcol) =
      (3 / 2 : ℝ) * finiteTauStar row col (uniformWeight X) := by
  rw [QDFull.treeQuartetCovariance,
    ← commonStrictMass_uniform_eq_pathSameProbability row col hrow hcol,
    ← conflictingStrictMass_uniform_eq_pathDifferentProbability
      row col hrow hcol]
  exact finiteQuartetCovariance_eq_threeHalves_tauStar
    row col (uniformWeight X)

theorem orderedPath_finiteTauStar_ge_two_bkr
    {m n : ℕ}
    (row : X → Fin (m + 1)) (col : X → Fin (n + 1))
    (hrow : Function.Surjective row) (hcol : Function.Surjective col) :
    2 * (∑ i : Fin m, ∑ j : Fin n,
        orderedAtomMass row i.castSucc *
          orderedAtomMass col j.castSucc *
          orderedGridDelta row col i j ^ 2) ≤
      finiteTauStar row col (uniformWeight X) := by
  letI : Nonempty X := ⟨(hrow 0).choose⟩
  apply finite_tauStar_ge_two_bkr_from_quartet
    (orderedAtomMass row) (orderedAtomMass col)
    (orderedGridDelta row col)
    (QDFull.treeQuartetCovariance
      (orderedPathXTree row hrow) (orderedPathXTree col hcol))
    (finiteTauStar row col (uniformWeight X))
  · intro i
    exact QDFull.normalizedCard_nonneg _
  · intro j
    exact QDFull.normalizedCard_nonneg _
  · exact orderedPath_treeQuartetCovariance_eq_threeHalves_tauStar
      row col hrow hcol
  · exact orderedPath_three_adjacentSum_le_treeQuartetCovariance
      row col hrow hcol

end QDTauStar

