import Mathlib.Probability.CDF
import Mathlib.MeasureTheory.Measure.FiniteMeasurePi
import Mathlib.MeasureTheory.Measure.FiniteMeasureProd
import QDTauStar.Kernel

/-!
# Population definitions for tau-star and the BKR discrepancy

This file formalizes the measure-theoretic objects at the start and end of
Corollary 3 in the manuscript.  A joint law is represented by a
`ProbabilityMeasure (ℝ × ℝ)`.  Its two marginals are push-forwards by the
coordinate projections, four independent copies are the finite product
measure, and the population statistic is the integral of the exact strict
four-sample kernel from `QDTauStar.Kernel`.

The joint cumulative distribution function is the mass of a lower-left
rectangle.  The BKR discrepancy is its squared difference from the product
of the marginal cumulative distribution functions, integrated against the
product of the marginals.  All measurability, integrability, boundedness, and
nonnegativity assertions used later are proved here rather than hidden in
definitions.
-/

open MeasureTheory Set

namespace QDTauStar

/-- The first marginal of a real bivariate probability law. -/
noncomputable def marginalX (mu : ProbabilityMeasure (Real × Real)) :
    ProbabilityMeasure Real :=
  mu.map measurable_fst.aemeasurable

/-- The second marginal of a real bivariate probability law. -/
noncomputable def marginalY (mu : ProbabilityMeasure (Real × Real)) :
    ProbabilityMeasure Real :=
  mu.map measurable_snd.aemeasurable

/-- The law of four independent copies of a bivariate observation. -/
noncomputable def fourfoldLaw (mu : ProbabilityMeasure (Real × Real)) :
    ProbabilityMeasure (Four → (Real × Real)) :=
  ProbabilityMeasure.pi (fun _ : Four => mu)

private theorem measurable_pairBelow
    (r s t u : Four) :
    MeasurableSet {z : Four → Real | PairBelow z r s t u} := by
  have hmeas (i : Four) : Measurable (fun z : Four → Real => z i) :=
    measurable_pi_apply i
  simp only [PairBelow]
  exact (measurableSet_lt (hmeas r) (hmeas t)).inter
    ((measurableSet_lt (hmeas r) (hmeas u)).inter
      ((measurableSet_lt (hmeas s) (hmeas t)).inter
        (measurableSet_lt (hmeas s) (hmeas u))))

private theorem measurable_strictlySeparates
    (r s t u : Four) :
    MeasurableSet {z : Four → Real | StrictlySeparates z r s t u} := by
  change MeasurableSet
    ({z : Four → Real | PairBelow z r s t u} ∪
      {z : Four → Real | PairBelow z t u r s})
  exact (measurable_pairBelow r s t u).union
    (measurable_pairBelow t u r s)

/-- The strict `12|34` pairing event is Borel measurable. -/
theorem measurable_pairing12 :
    MeasurableSet {z : Four → Real | Pairing12 z} :=
  measurable_strictlySeparates 0 1 2 3

/-- The strict `13|24` pairing event is Borel measurable. -/
theorem measurable_pairing13 :
    MeasurableSet {z : Four → Real | Pairing13 z} :=
  measurable_strictlySeparates 0 2 1 3

/-- The one-coordinate Bergsma--Dassios sign kernel is measurable. -/
theorem measurable_signKernel :
    Measurable (fun z : Four → Real => signKernel z) := by
  unfold signKernel indicator
  apply Measurable.sub
  · exact Measurable.ite measurable_pairing13 measurable_const measurable_const
  · exact Measurable.ite measurable_pairing12 measurable_const measurable_const

/-- The bivariate four-sample product kernel is measurable. -/
theorem measurable_tauProductKernel :
    Measurable (fun draw : Four → (Real × Real) =>
      tauProductKernel Prod.fst Prod.snd draw) := by
  unfold tauProductKernel
  apply Measurable.mul
  · apply measurable_signKernel.comp
    fun_prop
  · apply measurable_signKernel.comp
    fun_prop

/-- The bivariate four-sample product kernel is integrable under four
independent copies of every probability law. -/
theorem integrable_tauProductKernel
    (mu : ProbabilityMeasure (Real × Real)) :
    Integrable (fun draw : Four → (Real × Real) =>
      tauProductKernel Prod.fst Prod.snd draw) (fourfoldLaw mu) := by
  apply Integrable.mono' (integrable_const (1 : Real))
    measurable_tauProductKernel.aestronglyMeasurable
  filter_upwards [] with draw
  simpa only [Real.norm_eq_abs, norm_one] using
    abs_tauProductKernel_le_one Prod.fst Prod.snd draw

/-- Population tau-star in the unnormalised convention of the manuscript. -/
noncomputable def populationTauStar
    (mu : ProbabilityMeasure (Real × Real)) : Real :=
  ∫ draw : Four → (Real × Real),
    tauProductKernel Prod.fst Prod.snd draw ∂(fourfoldLaw mu : Measure _)

/-- The joint lower-left cumulative distribution function. -/
noncomputable def jointCDF
    (mu : ProbabilityMeasure (Real × Real)) (x y : Real) : Real :=
  (mu : Measure (Real × Real)).real (Iic x ×ˢ Iic y)

/-- The cumulative distribution function of the first marginal. -/
noncomputable def marginalCDFX
    (mu : ProbabilityMeasure (Real × Real)) (x : Real) : Real :=
  ((marginalX mu : ProbabilityMeasure Real) : Measure Real).real (Iic x)

/-- The cumulative distribution function of the second marginal. -/
noncomputable def marginalCDFY
    (mu : ProbabilityMeasure (Real × Real)) (y : Real) : Real :=
  ((marginalY mu : ProbabilityMeasure Real) : Measure Real).real (Iic y)

/-- The manuscript's discrepancy `D(x,y) = F(x,y) - F_X(x) F_Y(y)`. -/
noncomputable def cdfDiscrepancy
    (mu : ProbabilityMeasure (Real × Real)) (x y : Real) : Real :=
  jointCDF mu x y - marginalCDFX mu x * marginalCDFY mu y

/-- The unnormalised Blum--Kiefer--Rosenblatt discrepancy. -/
noncomputable def bkrDiscrepancy
    (mu : ProbabilityMeasure (Real × Real)) : Real :=
  ∫ p : Real × Real, cdfDiscrepancy mu p.1 p.2 ^ 2
    ∂(((marginalX mu).prod (marginalY mu)) : Measure _)

/-- Indicator, as an extended nonnegative real, of membership in the
lower-left rectangle with upper endpoint `p`. -/
noncomputable def lowerRectangleIndicator
    (p z : Real × Real) : ENNReal :=
  if z.1 ≤ p.1 ∧ z.2 ≤ p.2 then 1 else 0

/-- Joint measurability of the parameterised lower-rectangle indicator. -/
theorem measurable_lowerRectangleIndicator :
    Measurable (Function.uncurry lowerRectangleIndicator) := by
  unfold lowerRectangleIndicator Function.uncurry
  apply Measurable.ite
  · exact (measurableSet_le
      (measurable_fst.comp measurable_snd)
      (measurable_fst.comp measurable_fst)).inter
      (measurableSet_le
        (measurable_snd.comp measurable_snd)
        (measurable_snd.comp measurable_fst))
  · exact measurable_const
  · exact measurable_const

/-- Integrating the lower-rectangle indicator gives exactly the joint CDF
rectangle mass. -/
theorem lowerRectangleIndicator_lintegral
    (mu : ProbabilityMeasure (Real × Real)) (p : Real × Real) :
    (∫⁻ z, lowerRectangleIndicator p z ∂(mu : Measure _)) =
      (mu : Measure (Real × Real)) (Iic p.1 ×ˢ Iic p.2) := by
  rw [← lintegral_indicator_one]
  · apply lintegral_congr
    intro z
    simp [lowerRectangleIndicator, Set.indicator, Prod.le_def]
  · exact measurableSet_Iic.prod measurableSet_Iic

/-- The joint CDF is jointly Borel measurable in its two endpoints. -/
theorem measurable_jointCDF_uncurry (mu : ProbabilityMeasure (Real × Real)) :
    Measurable (Function.uncurry (jointCDF mu)) := by
  have hLint : Measurable (fun p : Real × Real =>
      ∫⁻ z, lowerRectangleIndicator p z ∂(mu : Measure _)) :=
    Measurable.lintegral_prod_right measurable_lowerRectangleIndicator
  have hToReal := hLint.ennreal_toReal
  change Measurable (fun p : Real × Real => jointCDF mu p.1 p.2)
  simpa only [jointCDF, measureReal_def,
    lowerRectangleIndicator_lintegral] using hToReal

/-- The first marginal CDF is Borel measurable. -/
theorem measurable_marginalCDFX (mu : ProbabilityMeasure (Real × Real)) :
    Measurable (marginalCDFX mu) := by
  have h := (ProbabilityTheory.monotone_cdf
    (((marginalX mu : ProbabilityMeasure Real) : Measure Real))).measurable
  change Measurable (fun x =>
    ((marginalX mu : ProbabilityMeasure Real) : Measure Real).real (Iic x))
  simp_rw [← ProbabilityTheory.cdf_eq_real]
  exact h

/-- The second marginal CDF is Borel measurable. -/
theorem measurable_marginalCDFY (mu : ProbabilityMeasure (Real × Real)) :
    Measurable (marginalCDFY mu) := by
  have h := (ProbabilityTheory.monotone_cdf
    (((marginalY mu : ProbabilityMeasure Real) : Measure Real))).measurable
  change Measurable (fun y =>
    ((marginalY mu : ProbabilityMeasure Real) : Measure Real).real (Iic y))
  simp_rw [← ProbabilityTheory.cdf_eq_real]
  exact h

/-- The CDF discrepancy is jointly Borel measurable. -/
theorem measurable_cdfDiscrepancy_uncurry
    (mu : ProbabilityMeasure (Real × Real)) :
    Measurable (Function.uncurry (cdfDiscrepancy mu)) := by
  unfold cdfDiscrepancy Function.uncurry
  exact (measurable_jointCDF_uncurry mu).sub
    ((measurable_marginalCDFX mu).comp measurable_fst |>.mul
      ((measurable_marginalCDFY mu).comp measurable_snd))

/-- Every CDF discrepancy lies in `[-1,1]`. -/
theorem cdfDiscrepancy_abs_le_one
    (mu : ProbabilityMeasure (Real × Real)) (x y : Real) :
    |cdfDiscrepancy mu x y| ≤ 1 := by
  have hj0 : 0 ≤ jointCDF mu x y := measureReal_nonneg
  have hj1 : jointCDF mu x y ≤ 1 := measureReal_le_one
  have hx0 : 0 ≤ marginalCDFX mu x := measureReal_nonneg
  have hx1 : marginalCDFX mu x ≤ 1 := measureReal_le_one
  have hy0 : 0 ≤ marginalCDFY mu y := measureReal_nonneg
  have hy1 : marginalCDFY mu y ≤ 1 := measureReal_le_one
  rw [abs_le]
  constructor <;> unfold cdfDiscrepancy <;> nlinarith

/-- The squared discrepancy is integrable against the product of the
marginals. -/
theorem integrable_bkrIntegrand
    (mu : ProbabilityMeasure (Real × Real)) :
    Integrable (fun p : Real × Real => cdfDiscrepancy mu p.1 p.2 ^ 2)
      (((marginalX mu).prod (marginalY mu)) : Measure _) := by
  apply Integrable.mono' (integrable_const (1 : Real))
  · exact ((measurable_cdfDiscrepancy_uncurry mu).pow_const 2).aestronglyMeasurable
  · filter_upwards [] with p
    rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
    have hAbs : |cdfDiscrepancy mu p.1 p.2| ≤ |(1 : Real)| := by
      simpa using cdfDiscrepancy_abs_le_one mu p.1 p.2
    simpa using (sq_le_sq.mpr hAbs)

/-- The BKR discrepancy is nonnegative. -/
theorem bkrDiscrepancy_nonneg
    (mu : ProbabilityMeasure (Real × Real)) :
    0 ≤ bkrDiscrepancy mu := by
  apply integral_nonneg
  intro p
  exact sq_nonneg _

/-- The two coordinate projections are independent exactly when the joint
law equals the product of its marginals. -/
def CoordinatesIndependent (mu : ProbabilityMeasure (Real × Real)) : Prop :=
  mu = (marginalX mu).prod (marginalY mu)

/-- The joint CDF of a product law is the product of the two marginal CDFs. -/
theorem jointCDF_product
    (muX muY : ProbabilityMeasure Real) (x y : Real) :
    jointCDF (muX.prod muY) x y =
      (muX : Measure Real).real (Iic x) *
        (muY : Measure Real).real (Iic y) := by
  change (muX.toMeasure.prod muY.toMeasure).real
      (Iic x ×ˢ Iic y) = _
  exact measureReal_prod_prod (Iic x) (Iic y)

/-- Independence makes every CDF discrepancy vanish pointwise. -/
theorem cdfDiscrepancy_eq_zero_of_independent
    {mu : ProbabilityMeasure (Real × Real)}
    (h : CoordinatesIndependent mu) (x y : Real) :
    cdfDiscrepancy mu x y = 0 := by
  rw [CoordinatesIndependent] at h
  rw [h]
  simp [cdfDiscrepancy, jointCDF_product, marginalCDFX,
    marginalCDFY, marginalX, marginalY]

/-- Independence implies zero BKR discrepancy. -/
theorem bkrDiscrepancy_eq_zero_of_independent
    {mu : ProbabilityMeasure (Real × Real)}
    (h : CoordinatesIndependent mu) :
    bkrDiscrepancy mu = 0 := by
  unfold bkrDiscrepancy
  apply integral_eq_zero_of_ae
  filter_upwards [] with p
  rw [cdfDiscrepancy_eq_zero_of_independent h]
  norm_num

end QDTauStar
