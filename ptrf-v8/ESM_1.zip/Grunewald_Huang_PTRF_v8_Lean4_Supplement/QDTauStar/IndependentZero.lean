import QDTauStar.QuantizedFiniteInequality

/-!
# Vanishing of tau-star under coordinate independence

This file supplies the direction of the population zero characterization
which is not obtained from the BKR lower bound: independent coordinates have
zero Bergsma--Dassios tau-star.  The proof first factors the finite four-draw
sum under a product mass table and then passes through the already formalized
dyadic-rank approximation.
-/

open scoped BigOperators Topology
open Filter MeasureTheory

namespace QDTauStar

section FiniteCancellation

variable {A : Type*} [LinearOrder A]

/-- Swapping positions `1` and `2` reverses the one-coordinate sign kernel. -/
theorem signKernel_permute_swap12 (z : Four → A) :
    signKernel (permuteDraw swap12 z) = -signKernel z := by
  by_cases h12 : Pairing12 z <;> by_cases h13 : Pairing13 z <;>
    simp [signKernel, indicator, h12, h13]

variable {Omega : Type*} [Fintype Omega]

/-- The weighted one-coordinate sign kernel has mean zero under four i.i.d.
finite draws. -/
theorem weightedFourSum_signKernel_eq_zero
    (weight : Omega → ℝ) (x : Omega → A) :
    weightedFourSum weight (fun draw => signKernel (x ∘ draw)) = 0 := by
  have hperm := weightedFourSum_permute weight swap12
    (fun draw => signKernel (x ∘ draw))
  have hneg :
      weightedFourSum weight
          (fun draw => signKernel (x ∘ permuteDraw swap12 draw)) =
        -weightedFourSum weight (fun draw => signKernel (x ∘ draw)) := by
    unfold weightedFourSum
    calc
      (∑ draw, fourDrawWeight weight draw *
          signKernel (x ∘ permuteDraw swap12 draw)) =
          ∑ draw, -(fourDrawWeight weight draw * signKernel (x ∘ draw)) := by
            apply Finset.sum_congr rfl
            intro draw _
            rw [show x ∘ permuteDraw swap12 draw =
                permuteDraw swap12 (x ∘ draw) by rfl]
            rw [signKernel_permute_swap12]
            ring
      _ = -∑ draw, fourDrawWeight weight draw * signKernel (x ∘ draw) := by
        rw [Finset.sum_neg_distrib]
  rw [hneg] at hperm
  linarith

end FiniteCancellation

section ProductTable

variable {R C : Type*} [Fintype R] [Fintype C]
  [LinearOrder R] [LinearOrder C]

/-- A four-draw from a product type is equivalently a pair of coordinatewise
four-draws. -/
def splitProductDrawEquiv :
    (Four → R × C) ≃ (Four → R) × (Four → C) where
  toFun draw := (Prod.fst ∘ draw, Prod.snd ∘ draw)
  invFun draws := fun i => (draws.1 i, draws.2 i)
  left_inv draw := by
    funext i
    exact Prod.eta (draw i)
  right_inv draws := by
    ext i <;> rfl

/-- Under product cell weights, the finite tau-star sum factors into the two
one-coordinate sign-kernel sums. -/
theorem finiteTauStar_productWeight_factor
    (rowWeight : R → ℝ) (colWeight : C → ℝ) :
    finiteTauStar Prod.fst Prod.snd
        (fun rc : R × C => rowWeight rc.1 * colWeight rc.2) =
      weightedFourSum rowWeight signKernel *
        weightedFourSum colWeight signKernel := by
  classical
  unfold finiteTauStar weightedFourSum
  calc
    (∑ draw : Four → R × C,
        fourDrawWeight (fun rc : R × C => rowWeight rc.1 * colWeight rc.2) draw *
          tauProductKernel Prod.fst Prod.snd draw) =
        ∑ draws : (Four → R) × (Four → C),
          (fourDrawWeight rowWeight draws.1 * fourDrawWeight colWeight draws.2) *
            (signKernel draws.1 * signKernel draws.2) := by
              rw [← Equiv.sum_comp splitProductDrawEquiv.symm]
              apply Finset.sum_congr rfl
              intro draws _
              change
                ((∏ i, rowWeight (draws.1 i) * colWeight (draws.2 i)) *
                    (signKernel draws.1 * signKernel draws.2)) = _
              rw [Finset.prod_mul_distrib]
              rfl
    _ = ∑ rowDraw : Four → R, ∑ colDraw : Four → C,
          (fourDrawWeight rowWeight rowDraw * signKernel rowDraw) *
            (fourDrawWeight colWeight colDraw * signKernel colDraw) := by
              rw [Fintype.sum_prod_type]
              apply Finset.sum_congr rfl
              intro rowDraw _
              apply Finset.sum_congr rfl
              intro colDraw _
              ring
    _ = ∑ rowDraw : Four → R,
          (fourDrawWeight rowWeight rowDraw * signKernel rowDraw) *
            (∑ colDraw : Four → C,
              fourDrawWeight colWeight colDraw * signKernel colDraw) := by
                apply Finset.sum_congr rfl
                intro rowDraw _
                rw [Finset.mul_sum]
    _ = (∑ rowDraw : Four → R,
          fourDrawWeight rowWeight rowDraw * signKernel rowDraw) *
          (∑ colDraw : Four → C,
            fourDrawWeight colWeight colDraw * signKernel colDraw) := by
              rw [Finset.sum_mul]

/-- Every finite product mass table has zero tau-star. -/
theorem finiteTauStar_productWeight_eq_zero
    (rowWeight : R → ℝ) (colWeight : C → ℝ) :
    finiteTauStar Prod.fst Prod.snd
        (fun rc : R × C => rowWeight rc.1 * colWeight rc.2) = 0 := by
  rw [finiteTauStar_productWeight_factor]
  have hrow : weightedFourSum rowWeight signKernel = 0 := by
    simpa [Function.comp_def] using
      (weightedFourSum_signKernel_eq_zero rowWeight (fun r : R => r))
  rw [hrow]
  simp

end ProductTable

section FiniteProductLaw

variable {m n : ℕ}

/-- Singleton masses of a product probability law factor into the two
singleton marginal masses. -/
theorem finiteLawMass_prod
    (rowLaw : ProbabilityMeasure (Fin (m + 1)))
    (colLaw : ProbabilityMeasure (Fin (n + 1)))
    (rc : OrderedCell m n) :
    finiteLawMass (rowLaw.prod colLaw) rc =
      (rowLaw : Measure (Fin (m + 1))).real {rc.1} *
        (colLaw : Measure (Fin (n + 1))).real {rc.2} := by
  unfold finiteLawMass
  rw [show ({rc} : Set (OrderedCell m n)) =
      ({rc.1} : Set (Fin (m + 1))) ×ˢ ({rc.2} : Set (Fin (n + 1))) by
    ext x
    simp]
  simp only [ProbabilityMeasure.toMeasure_prod]
  rw [measureReal_prod_prod]

/-- The finite-table tau-star polynomial of a product law is zero. -/
theorem finiteTableTauStar_prod_eq_zero
    (rowLaw : ProbabilityMeasure (Fin (m + 1)))
    (colLaw : ProbabilityMeasure (Fin (n + 1))) :
    finiteTableTauStar (finiteLawMass (rowLaw.prod colLaw)) = 0 := by
  unfold finiteTableTauStar
  rw [show finiteLawMass (rowLaw.prod colLaw) =
      fun rc : OrderedCell m n =>
        (rowLaw : Measure (Fin (m + 1))).real {rc.1} *
          (colLaw : Measure (Fin (n + 1))).real {rc.2} by
    funext rc
    exact finiteLawMass_prod rowLaw colLaw rc]
  exact finiteTauStar_productWeight_eq_zero
    (fun r => (rowLaw : Measure (Fin (m + 1))).real {r})
    (fun c => (colLaw : Measure (Fin (n + 1))).real {c})

end FiniteProductLaw

section IndependentQuantization

/-- Coordinate independence is preserved by the two dyadic rank maps. -/
theorem dyadicRankJointLaw_eq_prod_of_coordinatesIndependent
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ)
    (hInd : CoordinatesIndependent mu) :
    dyadicRankJointLaw mu k =
      (dyadicRankXLaw mu k).prod (dyadicRankYLaw mu k) := by
  calc
    dyadicRankJointLaw mu k =
        dyadicRankJointLaw
          ((marginalX mu).prod (marginalY mu)) k := by
            exact congrArg (fun nu => dyadicRankJointLaw nu k) hInd
    _ = (dyadicRankXLaw mu k).prod (dyadicRankYLaw mu k) := by
      unfold dyadicRankJointLaw dyadicRankXLaw dyadicRankYLaw
      exact (ProbabilityMeasure.map_prod_map
        (marginalX mu) (marginalY mu)
        (measurable_dyadicRank k) (measurable_dyadicRank k)).symm

/-- Every dyadic-rank approximation of an independent law has zero tau-star. -/
theorem quantizedPopulationTauStar_eq_zero_of_coordinatesIndependent
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ)
    (hInd : CoordinatesIndependent mu) :
    quantizedPopulationTauStar mu k = 0 := by
  rw [← finiteTableTauStar_dyadicRankLaw]
  rw [dyadicRankJointLaw_eq_prod_of_coordinatesIndependent mu k hInd]
  exact finiteTableTauStar_prod_eq_zero
    (dyadicRankXLaw mu k) (dyadicRankYLaw mu k)

/-- Coordinate independence forces the population tau-star to vanish. -/
theorem populationTauStar_eq_zero_of_coordinatesIndependent
    (mu : ProbabilityMeasure (ℝ × ℝ))
    (hInd : CoordinatesIndependent mu) :
    populationTauStar mu = 0 := by
  have hlim : Tendsto (quantizedPopulationTauStar mu) atTop
      (nhds (populationTauStar mu)) := tendsto_quantizedPopulationTauStar mu
  have hzero : Tendsto (quantizedPopulationTauStar mu) atTop (nhds 0) := by
    have hfun : quantizedPopulationTauStar mu = fun _ : ℕ => (0 : ℝ) := by
      funext k
      exact quantizedPopulationTauStar_eq_zero_of_coordinatesIndependent
        mu k hInd
    rw [hfun]
    exact tendsto_const_nhds
  exact tendsto_nhds_unique hlim hzero

end IndependentQuantization

end QDTauStar
