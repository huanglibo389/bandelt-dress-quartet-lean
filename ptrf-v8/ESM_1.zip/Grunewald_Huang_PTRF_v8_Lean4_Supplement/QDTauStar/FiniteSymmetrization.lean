import QDTauStar.Kernel

/-!
# Finite i.i.d. symmetrisation of the tau-star kernel

The manuscript's factors `2/3` and `-1/3` are consequences of
exchangeability of the four occurrence positions.  Here exchangeability is
proved by an explicit equivalence of the finite sample space; no conditional
probability or informal appeal to a uniform permutation is left implicit.
-/

open scoped BigOperators

namespace QDTauStar

/-- Reindex the four positions of one draw by a permutation. -/
def permuteDraw {Ω : Type*} (π : Equiv.Perm Four)
    (draw : Four → Ω) : Four → Ω :=
  draw ∘ π

/-- Position reindexing is an equivalence of the ordered four-draw sample
space. -/
def permuteDrawEquiv {Ω : Type*} (π : Equiv.Perm Four) :
    (Four → Ω) ≃ (Four → Ω) where
  toFun := permuteDraw π
  invFun := permuteDraw π.symm
  left_inv draw := by
    funext i
    simp [permuteDraw]
  right_inv draw := by
    funext i
    simp [permuteDraw]

/-- Product weight of four i.i.d. finite observations. -/
noncomputable def fourDrawWeight {Ω : Type*}
    (weight : Ω → ℝ) (draw : Four → Ω) : ℝ :=
  ∏ i, weight (draw i)

/-- Unnormalised expectation under the fourfold product weights. -/
noncomputable def weightedFourSum {Ω : Type*} [Fintype Ω]
    (weight : Ω → ℝ) (f : (Four → Ω) → ℝ) : ℝ :=
  ∑ draw, fourDrawWeight weight draw * f draw

/-- Product weights are invariant under every position permutation. -/
theorem fourDrawWeight_permute {Ω : Type*}
    (weight : Ω → ℝ) (π : Equiv.Perm Four) (draw : Four → Ω) :
    fourDrawWeight weight (permuteDraw π draw) =
      fourDrawWeight weight draw := by
  unfold fourDrawWeight permuteDraw
  exact Equiv.prod_comp π (fun i => weight (draw i))

/-- Exact finite exchangeability of four i.i.d. draws. -/
theorem weightedFourSum_permute {Ω : Type*} [Fintype Ω]
    (weight : Ω → ℝ) (π : Equiv.Perm Four)
    (f : (Four → Ω) → ℝ) :
    weightedFourSum weight (fun draw => f (permuteDraw π draw)) =
      weightedFourSum weight f := by
  classical
  unfold weightedFourSum
  calc
    (∑ draw, fourDrawWeight weight draw * f (permuteDraw π draw)) =
        ∑ draw, fourDrawWeight weight (permuteDraw π draw) *
          f (permuteDraw π draw) := by
            apply Finset.sum_congr rfl
            intro draw _
            rw [fourDrawWeight_permute]
    _ = ∑ draw, fourDrawWeight weight draw * f draw :=
      Equiv.sum_comp (permuteDrawEquiv π)
        (fun draw => fourDrawWeight weight draw * f draw)

/-- Weighted mass of an event in the fourfold product sample space. -/
noncomputable def weightedEventMass {Ω : Type*} [Fintype Ω]
    (weight : Ω → ℝ) (E : (Four → Ω) → Prop) : ℝ :=
  weightedFourSum weight (fun draw => indicator (E draw))

theorem weightedEventMass_permute {Ω : Type*} [Fintype Ω]
    (weight : Ω → ℝ) (π : Equiv.Perm Four)
    (E : (Four → Ω) → Prop) :
    weightedEventMass weight (fun draw => E (permuteDraw π draw)) =
      weightedEventMass weight E := by
  unfold weightedEventMass
  simpa only using
    (weightedFourSum_permute weight π (fun draw => indicator (E draw)))

theorem indicator_and (P Q : Prop) :
    indicator (P ∧ Q) = indicator P * indicator Q := by
  classical
  by_cases hP : P <;> by_cases hQ : Q <;>
    simp [indicator, hP, hQ]

/-- The three position permutations used to generate all three pairings and
all six ordered pairs of distinct pairings. -/
def swap12 : Equiv.Perm Four := Equiv.swap 1 2
def swap23 : Equiv.Perm Four := Equiv.swap 2 3
def swap13 : Equiv.Perm Four := Equiv.swap 1 3

section PairingAction

variable {A : Type*} [LinearOrder A]

@[simp] theorem pairing12_swap12 (z : Four → A) :
    Pairing12 (permuteDraw swap12 z) ↔ Pairing13 z := by
  simp [Pairing12, Pairing13, StrictlySeparates, PairBelow,
    permuteDraw, swap12, Function.comp_apply]
  tauto

@[simp] theorem pairing13_swap12 (z : Four → A) :
    Pairing13 (permuteDraw swap12 z) ↔ Pairing12 z := by
  simp [Pairing12, Pairing13, StrictlySeparates, PairBelow,
    permuteDraw, swap12, Function.comp_apply]
  tauto

@[simp] theorem pairing14_swap12 (z : Four → A) :
    Pairing14 (permuteDraw swap12 z) ↔ Pairing14 z := by
  simp [Pairing14, StrictlySeparates, PairBelow,
    permuteDraw, swap12, Function.comp_apply]
  tauto

@[simp] theorem pairing12_swap23 (z : Four → A) :
    Pairing12 (permuteDraw swap23 z) ↔ Pairing12 z := by
  simp [Pairing12, StrictlySeparates, PairBelow,
    permuteDraw, swap23, Function.comp_apply]
  tauto

@[simp] theorem pairing13_swap23 (z : Four → A) :
    Pairing13 (permuteDraw swap23 z) ↔ Pairing14 z := by
  simp [Pairing13, Pairing14, StrictlySeparates, PairBelow,
    permuteDraw, swap23, Function.comp_apply]
  tauto

@[simp] theorem pairing14_swap23 (z : Four → A) :
    Pairing14 (permuteDraw swap23 z) ↔ Pairing13 z := by
  simp [Pairing13, Pairing14, StrictlySeparates, PairBelow,
    permuteDraw, swap23, Function.comp_apply]
  tauto

@[simp] theorem pairing12_swap13 (z : Four → A) :
    Pairing12 (permuteDraw swap13 z) ↔ Pairing14 z := by
  simp [Pairing12, Pairing14, StrictlySeparates, PairBelow,
    permuteDraw, swap13, Function.comp_apply]
  tauto

@[simp] theorem pairing13_swap13 (z : Four → A) :
    Pairing13 (permuteDraw swap13 z) ↔ Pairing13 z := by
  simp [Pairing13, StrictlySeparates, PairBelow,
    permuteDraw, swap13, Function.comp_apply]
  tauto

@[simp] theorem pairing14_swap13 (z : Four → A) :
    Pairing14 (permuteDraw swap13 z) ↔ Pairing12 z := by
  simp [Pairing12, Pairing14, StrictlySeparates, PairBelow,
    permuteDraw, swap13, Function.comp_apply]
  tauto

end PairingAction

section FiniteLaw

variable {A B Ω : Type*} [LinearOrder A] [LinearOrder B] [Fintype Ω]

variable (x : Ω → A) (y : Ω → B)

def E12_12 (draw : Four → Ω) : Prop :=
  Pairing12 (x ∘ draw) ∧ Pairing12 (y ∘ draw)
def E13_13 (draw : Four → Ω) : Prop :=
  Pairing13 (x ∘ draw) ∧ Pairing13 (y ∘ draw)
def E14_14 (draw : Four → Ω) : Prop :=
  Pairing14 (x ∘ draw) ∧ Pairing14 (y ∘ draw)

def E12_13 (draw : Four → Ω) : Prop :=
  Pairing12 (x ∘ draw) ∧ Pairing13 (y ∘ draw)
def E13_12 (draw : Four → Ω) : Prop :=
  Pairing13 (x ∘ draw) ∧ Pairing12 (y ∘ draw)
def E12_14 (draw : Four → Ω) : Prop :=
  Pairing12 (x ∘ draw) ∧ Pairing14 (y ∘ draw)
def E14_12 (draw : Four → Ω) : Prop :=
  Pairing14 (x ∘ draw) ∧ Pairing12 (y ∘ draw)
def E13_14 (draw : Four → Ω) : Prop :=
  Pairing13 (x ∘ draw) ∧ Pairing14 (y ∘ draw)
def E14_13 (draw : Four → Ω) : Prop :=
  Pairing14 (x ∘ draw) ∧ Pairing13 (y ∘ draw)

/-- Finite weighted version of the paper's tau-star expectation. -/
noncomputable def finiteTauStar (weight : Ω → ℝ) : ℝ :=
  weightedFourSum weight (tauProductKernel x y)

/-- Weighted common-strict-partition event mass.  Mutual exclusivity of the
three pairing events makes this sum the mass of their disjoint union. -/
noncomputable def commonStrictMass (weight : Ω → ℝ) : ℝ :=
  weightedEventMass weight (E12_12 x y) +
    weightedEventMass weight (E13_13 x y) +
    weightedEventMass weight (E14_14 x y)

/-- Weighted conflicting-strict-partition event mass. -/
noncomputable def conflictingStrictMass (weight : Ω → ℝ) : ℝ :=
  weightedEventMass weight (E12_13 x y) +
    weightedEventMass weight (E13_12 x y) +
    weightedEventMass weight (E12_14 x y) +
    weightedEventMass weight (E14_12 x y) +
    weightedEventMass weight (E13_14 x y) +
    weightedEventMass weight (E14_13 x y)

private theorem eventMass_congr (weight : Ω → ℝ)
    {E F : (Four → Ω) → Prop} (h : ∀ draw, E draw ↔ F draw) :
    weightedEventMass weight E = weightedEventMass weight F := by
  unfold weightedEventMass weightedFourSum
  apply Finset.sum_congr rfl
  intro draw _
  apply congrArg (fun t : ℝ => fourDrawWeight weight draw * t)
  exact congrArg indicator (propext (h draw))

private theorem mass12_12_eq_mass13_13 (weight : Ω → ℝ) :
    weightedEventMass weight (E12_12 x y) =
      weightedEventMass weight (E13_13 x y) := by
  symm
  calc
    weightedEventMass weight (E13_13 x y) =
        weightedEventMass weight
          (fun draw => E12_12 x y (permuteDraw swap12 draw)) := by
            apply eventMass_congr
            intro draw
            simpa [E12_12, E13_13, permuteDraw, Function.comp_def] using
              and_congr
                (pairing12_swap12 (x ∘ draw)).symm
                (pairing12_swap12 (y ∘ draw)).symm
    _ = weightedEventMass weight (E12_12 x y) :=
      weightedEventMass_permute weight swap12 (E12_12 x y)

private theorem mass12_12_eq_mass14_14 (weight : Ω → ℝ) :
    weightedEventMass weight (E12_12 x y) =
      weightedEventMass weight (E14_14 x y) := by
  symm
  calc
    weightedEventMass weight (E14_14 x y) =
        weightedEventMass weight
          (fun draw => E12_12 x y (permuteDraw swap13 draw)) := by
            apply eventMass_congr
            intro draw
            simpa [E12_12, E14_14, permuteDraw, Function.comp_def] using
              and_congr
                (pairing12_swap13 (x ∘ draw)).symm
                (pairing12_swap13 (y ∘ draw)).symm
    _ = weightedEventMass weight (E12_12 x y) :=
      weightedEventMass_permute weight swap13 (E12_12 x y)

private theorem mass12_13_eq_mass13_12 (weight : Ω → ℝ) :
    weightedEventMass weight (E12_13 x y) =
      weightedEventMass weight (E13_12 x y) := by
  symm
  calc
    weightedEventMass weight (E13_12 x y) =
        weightedEventMass weight
          (fun draw => E12_13 x y (permuteDraw swap12 draw)) := by
            apply eventMass_congr
            intro draw
            simpa [E12_13, E13_12, permuteDraw, Function.comp_def] using
              and_congr
                (pairing12_swap12 (x ∘ draw)).symm
                (pairing13_swap12 (y ∘ draw)).symm
    _ = weightedEventMass weight (E12_13 x y) :=
      weightedEventMass_permute weight swap12 (E12_13 x y)

private theorem mass12_13_eq_mass12_14 (weight : Ω → ℝ) :
    weightedEventMass weight (E12_13 x y) =
      weightedEventMass weight (E12_14 x y) := by
  symm
  calc
    weightedEventMass weight (E12_14 x y) =
        weightedEventMass weight
          (fun draw => E12_13 x y (permuteDraw swap23 draw)) := by
            apply eventMass_congr
            intro draw
            simpa [E12_13, E12_14, permuteDraw, Function.comp_def] using
              and_congr
                (pairing12_swap23 (x ∘ draw)).symm
                (pairing13_swap23 (y ∘ draw)).symm
    _ = weightedEventMass weight (E12_13 x y) :=
      weightedEventMass_permute weight swap23 (E12_13 x y)

private theorem mass12_14_eq_mass14_12 (weight : Ω → ℝ) :
    weightedEventMass weight (E12_14 x y) =
      weightedEventMass weight (E14_12 x y) := by
  symm
  calc
    weightedEventMass weight (E14_12 x y) =
        weightedEventMass weight
          (fun draw => E12_14 x y (permuteDraw swap13 draw)) := by
            apply eventMass_congr
            intro draw
            simpa [E12_14, E14_12, permuteDraw, Function.comp_def] using
              and_congr
                (pairing12_swap13 (x ∘ draw)).symm
                (pairing14_swap13 (y ∘ draw)).symm
    _ = weightedEventMass weight (E12_14 x y) :=
      weightedEventMass_permute weight swap13 (E12_14 x y)

private theorem mass13_12_eq_mass13_14 (weight : Ω → ℝ) :
    weightedEventMass weight (E13_12 x y) =
      weightedEventMass weight (E13_14 x y) := by
  symm
  calc
    weightedEventMass weight (E13_14 x y) =
        weightedEventMass weight
          (fun draw => E13_12 x y (permuteDraw swap13 draw)) := by
            apply eventMass_congr
            intro draw
            simpa [E13_12, E13_14, permuteDraw, Function.comp_def] using
              and_congr
                (pairing13_swap13 (x ∘ draw)).symm
                (pairing12_swap13 (y ∘ draw)).symm
    _ = weightedEventMass weight (E13_12 x y) :=
      weightedEventMass_permute weight swap13 (E13_12 x y)

private theorem mass13_14_eq_mass14_13 (weight : Ω → ℝ) :
    weightedEventMass weight (E13_14 x y) =
      weightedEventMass weight (E14_13 x y) := by
  symm
  calc
    weightedEventMass weight (E14_13 x y) =
        weightedEventMass weight
          (fun draw => E13_14 x y (permuteDraw swap23 draw)) := by
            apply eventMass_congr
            intro draw
            simpa [E13_14, E14_13, permuteDraw, Function.comp_def] using
              and_congr
                (pairing13_swap23 (x ∘ draw)).symm
                (pairing14_swap23 (y ∘ draw)).symm
    _ = weightedEventMass weight (E13_14 x y) :=
      weightedEventMass_permute weight swap23 (E13_14 x y)

/-- Pointwise expansion of the product kernel into the two positive and two
negative pairing events that occur in the printed definition of `a`. -/
theorem tauProductKernel_event_expansion (draw : Four → Ω) :
    tauProductKernel x y draw =
      indicator (E13_13 x y draw) + indicator (E12_12 x y draw) -
        indicator (E13_12 x y draw) - indicator (E12_13 x y draw) := by
  rw [tauProductKernel]
  simp only [signKernel, E13_13, E12_12, E13_12, E12_13,
    indicator_and]
  ring

/-- Exact finite 24-permutation normalisation, proved by sample-space
reindexing: `tauStar = (2/3) P(C_4) - (1/3) P(D_4)`.  The event masses may be
unnormalised; when `weight` is a probability mass function they are the
corresponding probabilities. -/
theorem finiteTauStar_eq_twoThirds_common_sub_oneThird_conflicting
    (weight : Ω → ℝ) :
    finiteTauStar x y weight =
      (2 / 3 : ℝ) * commonStrictMass x y weight -
        (1 / 3 : ℝ) * conflictingStrictMass x y weight := by
  have hSame13 := mass12_12_eq_mass13_13 x y weight
  have hSame14 := mass12_12_eq_mass14_14 x y weight
  have hDiff21 := mass12_13_eq_mass13_12 x y weight
  have hDiff14 := mass12_13_eq_mass12_14 x y weight
  have hDiff41 := mass12_14_eq_mass14_12 x y weight
  have hDiff34 := mass13_12_eq_mass13_14 x y weight
  have hDiff43 := mass13_14_eq_mass14_13 x y weight
  have hExpand :
      finiteTauStar x y weight =
        weightedEventMass weight (E13_13 x y) +
          weightedEventMass weight (E12_12 x y) -
          weightedEventMass weight (E13_12 x y) -
          weightedEventMass weight (E12_13 x y) := by
    unfold finiteTauStar weightedEventMass weightedFourSum
    simp_rw [tauProductKernel_event_expansion x y]
    simp only [mul_add, mul_sub, Finset.sum_add_distrib,
      Finset.sum_sub_distrib]
  rw [hExpand]
  unfold commonStrictMass conflictingStrictMass
  rw [← hSame13, ← hSame14,
    ← hDiff43, ← hDiff34, ← hDiff21,
    ← hDiff41, ← hDiff14]
  ring

/-- The paper's quartet normalisation follows algebraically from the exact
finite symmetrisation. -/
theorem finiteQuartetCovariance_eq_threeHalves_tauStar
    (weight : Ω → ℝ) :
    commonStrictMass x y weight -
        (1 / 2 : ℝ) * conflictingStrictMass x y weight =
      (3 / 2 : ℝ) * finiteTauStar x y weight := by
  rw [finiteTauStar_eq_twoThirds_common_sub_oneThird_conflicting]
  ring

end FiniteLaw

end QDTauStar
