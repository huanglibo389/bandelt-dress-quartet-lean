import QDFull.LemmaThree
import QuartetV060.PathLineGraph

/-!
# Ordered finite supports as path `X`-trees

The finite part of Corollary 3 replaces each ordered marginal support by a
path.  This file constructs that path as an actual `QDFull.XTree` and proves
the component description that the paper uses implicitly: deleting the edge
between consecutive support values cuts the taxa exactly according to the
corresponding weak order inequality.
-/

open scoped BigOperators
open SimpleGraph

namespace QDTauStar

universe uX

variable {X : Type uX} [Fintype X]

/-- The path `X`-tree carried by a surjective ordered coordinate.  Surjectivity
is precisely what is needed to ensure that every path vertex is labelled. -/
noncomputable def orderedPathXTree {m : ℕ}
    (coord : X → Fin (m + 1)) (hsurj : Function.Surjective coord) :
    QDFull.XTree X (Fin (m + 1)) where
  graph := SimpleGraph.pathGraph (m + 1)
  isTree := QuartetV060.PathLineGraph.pathGraph_succ_isTree m
  label := coord
  lowDegree_labelled := by
    intro v _
    obtain ⟨x, hx⟩ := hsurj v
    exact ⟨x, hx⟩

@[simp] theorem orderedPathXTree_graph {m : ℕ}
    (coord : X → Fin (m + 1)) (hsurj : Function.Surjective coord) :
    (orderedPathXTree coord hsurj).graph =
      SimpleGraph.pathGraph (m + 1) := rfl

@[simp] theorem orderedPathXTree_label {m : ℕ}
    (coord : X → Fin (m + 1)) (hsurj : Function.Surjective coord)
    (x : X) :
    (orderedPathXTree coord hsurj).label x = coord x := rfl

/-- Consecutive support vertices form an edge of the ordered path. -/
theorem pathGraph_adj_cut {m : ℕ} (i : Fin m) :
    (SimpleGraph.pathGraph (m + 1)).Adj i.castSucc i.succ := by
  rw [SimpleGraph.pathGraph_adj]
  left
  rfl

/-- An edge that survives deletion of the cut edge cannot cross that cut. -/
private theorem deletedPath_adj_preserves_lowerSide {m : ℕ} (i : Fin m)
    {u v : Fin (m + 1)}
    (huv : ((SimpleGraph.pathGraph (m + 1)).deleteEdges
      {s(i.castSucc, i.succ)}).Adj u v) :
    (u ≤ i.castSucc ↔ v ≤ i.castSucc) := by
  rw [SimpleGraph.deleteEdges_adj] at huv
  rcases huv with ⟨hadj, hne⟩
  rw [SimpleGraph.pathGraph_adj] at hadj
  simp only [Set.mem_singleton_iff] at hne
  constructor
  · intro hu
    by_contra hv
    have hv' : i.castSucc < v := lt_of_not_ge hv
    change u.val ≤ i.val at hu
    change i.val < v.val at hv'
    rcases hadj with huv | hvu
    · have hui : u = i.castSucc := by
        apply Fin.ext
        change u.val = i.val
        omega
      have hvi : v = i.succ := by
        apply Fin.ext
        change v.val = i.val + 1
        omega
      exact hne (by simp [hui, hvi])
    · omega
  · intro hv
    by_contra hu
    have hu' : i.castSucc < u := lt_of_not_ge hu
    change v.val ≤ i.val at hv
    change i.val < u.val at hu'
    rcases hadj with huv | hvu
    · omega
    · have hvi : v = i.castSucc := by
        apply Fin.ext
        change v.val = i.val
        omega
      have hui : u = i.succ := by
        apply Fin.ext
        change u.val = i.val + 1
        omega
      exact hne (by simp [hui, hvi])

/-- The walk-level invariant underlying the reachability statement below. -/
private theorem deletedPath_walk_preserves_lowerSide {m : ℕ} (i : Fin m)
    {u v : Fin (m + 1)}
    (p : ((SimpleGraph.pathGraph (m + 1)).deleteEdges
      {s(i.castSucc, i.succ)}).Walk u v) :
    (u ≤ i.castSucc ↔ v ≤ i.castSucc) := by
  induction p with
  | nil => exact Iff.rfl
  | cons h p ih =>
      exact (deletedPath_adj_preserves_lowerSide i h).trans ih

/-- Reachability in the cut path preserves membership in the lower interval. -/
theorem deletedPath_reachable_preserves_lowerSide {m : ℕ} (i : Fin m)
    {u v : Fin (m + 1)}
    (huv : ((SimpleGraph.pathGraph (m + 1)).deleteEdges
      {s(i.castSucc, i.succ)}).Reachable u v) :
    (u ≤ i.castSucc ↔ v ≤ i.castSucc) := by
  exact huv.elim (deletedPath_walk_preserves_lowerSide i)

/-- The component containing the lower endpoint of a cut consists exactly of
the taxa whose ordered coordinate is at most that endpoint. -/
theorem mem_orderedPath_edgeSide_lower_iff {m : ℕ}
    (coord : X → Fin (m + 1)) (hsurj : Function.Surjective coord)
    (i : Fin m) (x : X) :
    x ∈ (orderedPathXTree coord hsurj).edgeSide i.succ i.castSucc ↔
      coord x ≤ i.castSucc := by
  let T := orderedPathXTree coord hsurj
  have hadj : T.graph.Adj i.succ i.castSucc :=
    (pathGraph_adj_cut i).symm
  constructor
  · intro hx
    have hr := ((T.mem_edgeSide i.succ i.castSucc x).1 hx)
    have hr' : ((SimpleGraph.pathGraph (m + 1)).deleteEdges
        {s(i.castSucc, i.succ)}).Reachable i.castSucc (coord x) := by
      simpa only [T, orderedPathXTree, Sym2.eq_swap] using hr
    have hpres := deletedPath_reachable_preserves_lowerSide i hr'
    exact hpres.mp (le_refl i.castSucc)
  · intro hx
    rcases T.mem_vertexSide_or_mem_vertexSide_reverse_of_adj hadj (coord x) with
      hlower | hupper
    · exact (T.mem_edgeSide i.succ i.castSucc x).2 hlower
    · have hupper' : ((SimpleGraph.pathGraph (m + 1)).deleteEdges
          {s(i.castSucc, i.succ)}).Reachable i.succ (coord x) := by
        change (T.graph.deleteEdges
          {s(i.castSucc, i.succ)}).Reachable i.succ (T.label x) at hupper
        simpa only [T, orderedPathXTree] using hupper
      have hpres := deletedPath_reachable_preserves_lowerSide i hupper'
      have hnot : ¬i.succ ≤ i.castSucc :=
        not_le_of_gt (Fin.castSucc_lt_succ_iff.mpr (le_refl i))
      exact False.elim (hnot (hpres.mpr hx))

/-- The reverse component of the same cut is the strict upper interval. -/
theorem mem_orderedPath_edgeSide_upper_iff {m : ℕ}
    (coord : X → Fin (m + 1)) (hsurj : Function.Surjective coord)
    (i : Fin m) (x : X) :
    x ∈ (orderedPathXTree coord hsurj).edgeSide i.castSucc i.succ ↔
      i.succ ≤ coord x := by
  let T := orderedPathXTree coord hsurj
  have hadj : T.graph.Adj i.castSucc i.succ := pathGraph_adj_cut i
  constructor
  · intro hx
    have hr := ((T.mem_edgeSide i.castSucc i.succ x).1 hx)
    have hr' : ((SimpleGraph.pathGraph (m + 1)).deleteEdges
        {s(i.castSucc, i.succ)}).Reachable i.succ (coord x) := by
      simpa only [T, orderedPathXTree] using hr
    have hpres := deletedPath_reachable_preserves_lowerSide i hr'
    have hnot : ¬i.succ ≤ i.castSucc :=
      not_le_of_gt (Fin.castSucc_lt_succ_iff.mpr (le_refl i))
    have hcoord : ¬coord x ≤ i.castSucc := by
      intro hle
      exact hnot (hpres.mpr hle)
    rcases Fin.succ_le_or_le_castSucc (coord x) i with hupper | hlower
    · exact hupper
    · exact False.elim (hcoord hlower)
  · intro hx
    rcases T.mem_vertexSide_or_mem_vertexSide_reverse_of_adj hadj (coord x) with
      hupper | hlower
    · exact (T.mem_edgeSide i.castSucc i.succ x).2 hupper
    · have hlower' : ((SimpleGraph.pathGraph (m + 1)).deleteEdges
          {s(i.castSucc, i.succ)}).Reachable i.castSucc (coord x) := by
        change (T.graph.deleteEdges
          {s(i.succ, i.castSucc)}).Reachable i.castSucc (T.label x) at hlower
        simpa only [T, orderedPathXTree, Sym2.eq_swap] using hlower
      have hpres := deletedPath_reachable_preserves_lowerSide i hlower'
      have hle : coord x ≤ i.castSucc := hpres.mp (le_refl i.castSucc)
      have hlt : i.castSucc < coord x :=
        lt_of_lt_of_le (Fin.castSucc_lt_succ_iff.mpr (le_refl i)) hx
      exact False.elim ((not_le_of_gt hlt) hle)

/-- The fibre at a path vertex is exactly the corresponding coordinate fibre. -/
theorem mem_orderedPath_labelFiber_iff {m : ℕ}
    (coord : X → Fin (m + 1)) (hsurj : Function.Surjective coord)
    (k : Fin (m + 1)) (x : X) :
    x ∈ (orderedPathXTree coord hsurj).labelFiber k ↔ coord x = k := by
  rw [QDFull.XTree.mem_labelFiber]
  rfl

/-- The canonical orientation of the path cut indexed by `i`: from the lower
support vertex to the next support vertex. -/
def pathCutDirectedEdge {m : ℕ} (i : Fin m) :
    Fin (m + 1) × Fin (m + 1) :=
  (i.castSucc, i.succ)

theorem pathCutDirectedEdge_injective {m : ℕ} :
    Function.Injective (pathCutDirectedEdge (m := m)) := by
  intro i j hij
  apply Fin.castSucc_inj.mp
  exact congrArg Prod.fst hij

/-- Every canonically oriented edge of the ordered path occurs at exactly one
cut index.  This is the no-double-counting statement used when the directed
edge sum in Lemma 6 is reindexed by adjacent support values. -/
theorem orderedPath_canonicalEdgeFinset_eq_image {m : ℕ}
    (coord : X → Fin (m + 1)) (hsurj : Function.Surjective coord) :
    (orderedPathXTree coord hsurj).canonicalEdgeFinset =
      Finset.univ.image (pathCutDirectedEdge (m := m)) := by
  classical
  ext e
  rcases e with ⟨u, v⟩
  rw [QDFull.XTree.mem_canonicalEdgeFinset, Finset.mem_image]
  constructor
  · rintro ⟨hadj, huv⟩
    change (SimpleGraph.pathGraph (m + 1)).Adj u v at hadj
    rw [SimpleGraph.pathGraph_adj] at hadj
    rcases hadj with huvSucc | hvuSucc
    · let i : Fin m := ⟨u.val, by omega⟩
      refine ⟨i, Finset.mem_univ i, ?_⟩
      apply Prod.ext
      · exact Fin.ext (by simp [pathCutDirectedEdge, i])
      · exact Fin.ext (by simp [pathCutDirectedEdge, i, huvSucc])
    · exfalso
      omega
  · rintro ⟨i, -, h⟩
    cases h
    exact ⟨pathGraph_adj_cut i,
      Fin.castSucc_lt_succ_iff.mpr (le_refl i)⟩

/-- Sum over canonical path edges by their unique cut indices. -/
theorem orderedPath_sum_canonicalEdge_eq_sum_cuts {m : ℕ}
    (coord : X → Fin (m + 1)) (hsurj : Function.Surjective coord)
    (f : (Fin (m + 1) × Fin (m + 1)) → ℝ) :
    (∑ e ∈ (orderedPathXTree coord hsurj).canonicalEdgeFinset, f e) =
      ∑ i : Fin m, f (pathCutDirectedEdge i) := by
  rw [orderedPath_canonicalEdgeFinset_eq_image]
  rw [Finset.sum_image pathCutDirectedEdge_injective.injOn]

end QDTauStar
