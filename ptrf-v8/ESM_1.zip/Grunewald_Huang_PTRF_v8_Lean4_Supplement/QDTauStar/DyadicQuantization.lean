import QDTauStar.Population
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.MeasureTheory.MeasurableSpace.Constructions

/-!
# Concrete nested dyadic quantisation of the real line

This file formalizes the partitions used to pass from finite laws to arbitrary
real-valued laws in Corollary 3.  At level `k`, the finite endpoint set is

`{j / 2^k : -k * 2^k <= j <= k * 2^k}`.

The associated cells are right-closed: the code of `x` records, for every
endpoint `r`, whether `x <= r`.  This finite Boolean code distinguishes the two
tails and every interval `(j / 2^k, (j+1) / 2^k]`, without making an arbitrary
choice of numerical cell labels.  Multiplication of an old integer endpoint
index by two embeds every level-`k` endpoint into level `k+1`; hence equality of
fine codes implies equality of coarse codes.  Finally, the Archimedean
argument below proves that two distinct real numbers are separated at all
sufficiently fine levels.
-/

open scoped BigOperators Topology
open Filter MeasureTheory Set

namespace QDTauStar

/-- The integer radius of the finite endpoint set at level `k`. -/
def dyadicEndpointBound (k : ℕ) : ℤ := (k : ℤ) * (2 : ℤ) ^ k

/-- Integer indices of the endpoints retained at level `k`. -/
noncomputable def dyadicEndpointIndices (k : ℕ) : Finset ℤ :=
  Finset.Icc (-dyadicEndpointBound k) (dyadicEndpointBound k)

/-- A retained endpoint at level `k`, represented by its integer numerator. -/
abbrev DyadicEndpoint (k : ℕ) :=
  {j : ℤ // j ∈ dyadicEndpointIndices k}

noncomputable instance dyadicEndpointFintype (k : ℕ) :
    Fintype (DyadicEndpoint k) :=
  Fintype.ofFinset (dyadicEndpointIndices k) (fun _ => Iff.rfl)

/-- The positive real scale `2^k`. -/
noncomputable def dyadicScale (k : ℕ) : ℝ := (2 : ℝ) ^ k

/-- The real value `j / 2^k` of a retained endpoint. -/
noncomputable def dyadicEndpointValue (k : ℕ) (e : DyadicEndpoint k) : ℝ :=
  (e.1 : ℝ) / dyadicScale k

theorem dyadicScale_pos (k : ℕ) : 0 < dyadicScale k := by
  exact pow_pos (by norm_num) k

theorem dyadicEndpointBound_succ (k : ℕ) :
    dyadicEndpointBound (k + 1) =
      2 * dyadicEndpointBound k + 2 * (2 : ℤ) ^ k := by
  simp [dyadicEndpointBound, pow_succ]
  ring

/-- The same real endpoint at the next level has doubled numerator. -/
def dyadicEndpointLift (k : ℕ) (e : DyadicEndpoint k) :
    DyadicEndpoint (k + 1) := by
  refine ⟨2 * e.1, ?_⟩
  have he : -dyadicEndpointBound k ≤ e.1 ∧
      e.1 ≤ dyadicEndpointBound k := by
    apply Finset.mem_Icc.mp
    change e.1 ∈ Finset.Icc (-dyadicEndpointBound k) (dyadicEndpointBound k)
    exact e.property
  have hp : 0 ≤ (2 : ℤ) ^ k := by positivity
  have hnew : -dyadicEndpointBound (k + 1) ≤ 2 * e.1 ∧
      2 * e.1 ≤ dyadicEndpointBound (k + 1) := by
    rw [dyadicEndpointBound_succ]
    constructor <;> nlinarith [he.1, he.2]
  change 2 * e.1 ∈
    Finset.Icc (-dyadicEndpointBound (k + 1)) (dyadicEndpointBound (k + 1))
  exact Finset.mem_Icc.mpr hnew

theorem dyadicEndpointValue_lift (k : ℕ) (e : DyadicEndpoint k) :
    dyadicEndpointValue (k + 1) (dyadicEndpointLift k e) =
      dyadicEndpointValue k e := by
  simp [dyadicEndpointValue, dyadicEndpointLift, dyadicScale, pow_succ]
  ring

/-- The finite right-closed-cell code at level `k`.  Its coordinate at an
endpoint `r` is true exactly when `x <= r`. -/
abbrev DyadicCellCode (k : ℕ) := DyadicEndpoint k → Bool

noncomputable def dyadicQuantizer (k : ℕ) (x : ℝ) : DyadicCellCode k :=
  fun e => decide (x ≤ dyadicEndpointValue k e)

@[simp]
theorem dyadicQuantizer_apply_eq_true_iff
    (k : ℕ) (x : ℝ) (e : DyadicEndpoint k) :
    dyadicQuantizer k x e = true ↔ x ≤ dyadicEndpointValue k e := by
  simp [dyadicQuantizer]

@[simp]
theorem dyadicQuantizer_apply_eq_false_iff
    (k : ℕ) (x : ℝ) (e : DyadicEndpoint k) :
    dyadicQuantizer k x e = false ↔ dyadicEndpointValue k e < x := by
  simp [dyadicQuantizer, not_le]

/-- Every endpoint of level `k` is literally an endpoint of level `k+1`.
Consequently the finer code determines the coarser code. -/
theorem dyadicQuantizer_refines (k : ℕ) {x y : ℝ}
    (hxy : dyadicQuantizer (k + 1) x = dyadicQuantizer (k + 1) y) :
    dyadicQuantizer k x = dyadicQuantizer k y := by
  funext e
  have hcoord := congrFun hxy (dyadicEndpointLift k e)
  simpa [dyadicQuantizer, dyadicEndpointValue_lift] using hcoord

/-- Equality of codes persists when one passes from a fine level to any
coarser level. -/
theorem dyadicQuantizer_eq_of_le {k l : ℕ} (hkl : k ≤ l) {x y : ℝ}
    (hxy : dyadicQuantizer l x = dyadicQuantizer l y) :
    dyadicQuantizer k x = dyadicQuantizer k y := by
  induction l, hkl using Nat.le_induction with
  | base => exact hxy
  | succ l hkl ih =>
      exact ih (dyadicQuantizer_refines l hxy)

/-- Once two points have been separated, every finer code keeps them
separated. -/
theorem dyadicQuantizer_ne_of_le {k l : ℕ} (hkl : k ≤ l) {x y : ℝ}
    (hxy : dyadicQuantizer k x ≠ dyadicQuantizer k y) :
    dyadicQuantizer l x ≠ dyadicQuantizer l y := by
  intro heq
  exact hxy (dyadicQuantizer_eq_of_le hkl heq)

/-! ## Eventual separation of distinct real numbers -/

private theorem exists_large_level_with_small_mesh_and_large_window
    {x y : ℝ} (hxy : x < y) :
    ∃ k : ℕ,
      (1 / 2 : ℝ) ^ k < y - x ∧ |x| < k ∧ |y| < k := by
  obtain ⟨n, hn⟩ :=
    exists_pow_lt_of_lt_one (sub_pos.mpr hxy)
      (by norm_num : (1 / 2 : ℝ) < 1)
  obtain ⟨m, hm⟩ := exists_nat_gt (max |x| |y|)
  let k := max n m
  refine ⟨k, ?_, ?_, ?_⟩
  · have hle : (1 / 2 : ℝ) ^ k ≤ (1 / 2 : ℝ) ^ n := by
      simpa [k, one_div_pow] using
        (one_div_pow_le_one_div_pow_of_le
          (by norm_num : (1 : ℝ) ≤ 2) (Nat.le_max_left n m))
    exact hle.trans_lt hn
  · have hmle : (m : ℝ) ≤ (k : ℝ) := by
      exact_mod_cast (Nat.le_max_right n m)
    exact (le_max_left |x| |y|).trans_lt (hm.trans_le hmle)
  · have hmle : (m : ℝ) ≤ (k : ℝ) := by
      exact_mod_cast (Nat.le_max_right n m)
    exact (le_max_right |x| |y|).trans_lt (hm.trans_le hmle)

/-- Between two distinct ordered reals lies a retained dyadic endpoint at
some level.  The left inequality is weak because cells are right-closed. -/
theorem exists_dyadicEndpoint_between {x y : ℝ} (hxy : x < y) :
    ∃ k : ℕ, ∃ e : DyadicEndpoint k,
      x ≤ dyadicEndpointValue k e ∧ dyadicEndpointValue k e < y := by
  obtain ⟨k, hmesh, hxk, hyk⟩ :=
    exists_large_level_with_small_mesh_and_large_window hxy
  let A : ℝ := dyadicScale k
  let j : ℤ := ⌈x * A⌉
  have hApos : 0 < A := by
    simpa [A] using dyadicScale_pos k
  have hmesh' : 1 / A < y - x := by
    simpa [A, dyadicScale, one_div, div_pow] using hmesh
  have hxj : x ≤ (j : ℝ) / A := by
    rw [le_div_iff₀ hApos]
    exact Int.le_ceil (x * A)
  have hjy : (j : ℝ) / A < y := by
    have hjlt : (j : ℝ) < x * A + 1 := by
      simpa [j] using Int.ceil_lt_add_one (x * A)
    have hjdiv : (j : ℝ) / A < x + 1 / A := by
      rw [div_lt_iff₀ hApos]
      calc
        (j : ℝ) < x * A + 1 := hjlt
        _ = (x + 1 / A) * A := by field_simp
    linarith
  have hjmem : j ∈ dyadicEndpointIndices k := by
    rw [dyadicEndpointIndices, Finset.mem_Icc]
    have hxabs : |x| < (k : ℝ) := by simpa using hxk
    have hxlower : -(k : ℝ) < x := (abs_lt.mp hxabs).1
    have hxupper : x < (k : ℝ) := (abs_lt.mp hxabs).2
    have hbound_cast : (dyadicEndpointBound k : ℝ) = (k : ℝ) * A := by
      simp [dyadicEndpointBound, A, dyadicScale]
    have hlowreal : ((-dyadicEndpointBound k : ℤ) : ℝ) < x * A := by
      rw [Int.cast_neg, hbound_cast]
      nlinarith
    have huppreal : x * A ≤ (dyadicEndpointBound k : ℝ) := by
      rw [hbound_cast]
      nlinarith
    constructor
    · exact (Int.lt_ceil.mpr hlowreal).le
    · exact Int.ceil_le.mpr huppreal
  refine ⟨k, ⟨j, hjmem⟩, ?_, ?_⟩
  · simpa [dyadicEndpointValue, A] using hxj
  · simpa [dyadicEndpointValue, A] using hjy

/-- Strictly ordered points have different codes at some level. -/
theorem exists_dyadicQuantizer_ne_of_lt {x y : ℝ} (hxy : x < y) :
    ∃ k : ℕ, dyadicQuantizer k x ≠ dyadicQuantizer k y := by
  obtain ⟨k, e, hxe, hey⟩ := exists_dyadicEndpoint_between hxy
  refine ⟨k, fun h => ?_⟩
  have hcoord := congrFun h e
  have hxtrue : dyadicQuantizer k x e = true :=
    (dyadicQuantizer_apply_eq_true_iff k x e).2 hxe
  have hyfalse : dyadicQuantizer k y e = false :=
    (dyadicQuantizer_apply_eq_false_iff k y e).2 hey
  rw [hxtrue, hyfalse] at hcoord
  contradiction

/-- Distinct real numbers are separated at some level. -/
theorem exists_dyadicQuantizer_ne_of_ne {x y : ℝ} (hxy : x ≠ y) :
    ∃ k : ℕ, dyadicQuantizer k x ≠ dyadicQuantizer k y := by
  rcases lt_or_gt_of_ne hxy with hlt | hgt
  · exact exists_dyadicQuantizer_ne_of_lt hlt
  · obtain ⟨k, hk⟩ := exists_dyadicQuantizer_ne_of_lt hgt
    exact ⟨k, fun h => hk h.symm⟩

/-- Distinct points remain separated at every sufficiently fine level. -/
theorem eventually_dyadicQuantizer_ne_of_ne {x y : ℝ} (hxy : x ≠ y) :
    ∀ᶠ k : ℕ in atTop, dyadicQuantizer k x ≠ dyadicQuantizer k y := by
  obtain ⟨k, hk⟩ := exists_dyadicQuantizer_ne_of_ne hxy
  filter_upwards [eventually_ge_atTop k] with l hl
  exact dyadicQuantizer_ne_of_le hl hk

/-- Equal real values have equal codes at every level. -/
theorem dyadicQuantizer_eq_of_eq {x y : ℝ} (hxy : x = y) (k : ℕ) :
    dyadicQuantizer k x = dyadicQuantizer k y := by
  simpa [hxy]

/-! ## Measurable finite cells and deletion of zero-mass cells -/

/-- The concrete dyadic code is Borel measurable. -/
theorem measurable_dyadicQuantizer (k : ℕ) :
    Measurable (dyadicQuantizer k) := by
  apply measurable_pi_lambda
  intro e
  apply measurable_to_bool
  change MeasurableSet
    ((fun x : ℝ => decide (x ≤ dyadicEndpointValue k e)) ⁻¹' {true})
  rw [show
      (fun x : ℝ => decide (x ≤ dyadicEndpointValue k e)) ⁻¹' {true} =
        Iic (dyadicEndpointValue k e) by
    ext x
    simp]
  exact measurableSet_Iic

/-- Mass of one cell of an arbitrary measurable finite quantizer. -/
noncomputable def quantizedCellMass
    {α β : Type*} [MeasurableSpace α]
    (mu : ProbabilityMeasure α) (q : α → β) (c : β) : ℝ :=
  (mu : Measure α).real (q ⁻¹' {c})

theorem quantizedCellMass_nonneg
    {α β : Type*} [MeasurableSpace α]
    (mu : ProbabilityMeasure α) (q : α → β) (c : β) :
    0 ≤ quantizedCellMass mu q c :=
  measureReal_nonneg

/-- The masses of all cells of a measurable finite quantizer sum to one. -/
theorem sum_quantizedCellMass
    {α β : Type*} [MeasurableSpace α] [MeasurableSpace β]
    [Fintype β] [MeasurableSingletonClass β]
    (mu : ProbabilityMeasure α) (q : α → β) (hq : Measurable q) :
    ∑ c, quantizedCellMass mu q c = 1 := by
  have h := sum_measureReal_preimage_singleton
    (μ := (mu : Measure α)) (Finset.univ : Finset β)
    (fun c _ => (measurableSet_singleton c).preimage hq)
    (by finiteness)
  simpa [quantizedCellMass] using h

/-- A cell not having positive real mass has exactly zero mass. -/
theorem quantizedCellMass_eq_zero_of_not_pos
    {α β : Type*} [MeasurableSpace α]
    (mu : ProbabilityMeasure α) (q : α → β) {c : β}
    (hc : ¬ 0 < quantizedCellMass mu q c) :
    quantizedCellMass mu q c = 0 := by
  exact le_antisymm (le_of_not_gt hc) (quantizedCellMass_nonneg mu q c)

/-- The finite type obtained by deleting precisely the zero-mass cells. -/
abbrev OccupiedQuantizedCell
    {α β : Type*} [MeasurableSpace α]
    (mu : ProbabilityMeasure α) (q : α → β) :=
  {c : β // 0 < quantizedCellMass mu q c}

/-- Deleting the zero-mass cells loses no mass. -/
theorem sum_occupiedQuantizedCellMass
    {α β : Type*} [MeasurableSpace α] [MeasurableSpace β]
    [Fintype β] [MeasurableSingletonClass β]
    (mu : ProbabilityMeasure α) (q : α → β) (hq : Measurable q) :
    ∑ c : OccupiedQuantizedCell mu q, quantizedCellMass mu q c = 1 := by
  classical
  let s : Finset β :=
    Finset.univ.filter (fun c => 0 < quantizedCellMass mu q c)
  calc
    ∑ c : OccupiedQuantizedCell mu q, quantizedCellMass mu q c =
        ∑ c ∈ s, quantizedCellMass mu q c := by
      symm
      apply Finset.sum_subtype
      intro c
      simp [s]
    _ = ∑ c, quantizedCellMass mu q c := by
      apply Finset.sum_subset (by simp [s])
      intro c _ hc
      exact quantizedCellMass_eq_zero_of_not_pos mu q (by simpa [s] using hc)
    _ = 1 := sum_quantizedCellMass mu q hq

/-- A draw from the original law lands in a retained positive-mass cell
almost surely.  This is the precise probabilistic meaning of deleting the
zero cells. -/
theorem ae_quantizer_cellMass_pos
    {α β : Type*} [MeasurableSpace α] [MeasurableSpace β]
    [Fintype β] [MeasurableSingletonClass β]
    (mu : ProbabilityMeasure α) (q : α → β) (hq : Measurable q) :
    ∀ᵐ x ∂(mu : Measure α), 0 < quantizedCellMass mu q (q x) := by
  have hcell : ∀ c : β,
      ∀ᵐ x ∂(mu : Measure α),
        ¬ 0 < quantizedCellMass mu q c → q x ≠ c := by
    intro c
    by_cases hc : 0 < quantizedCellMass mu q c
    · exact Filter.Eventually.of_forall fun _ hnot => (hnot hc).elim
    · have hreal : quantizedCellMass mu q c = 0 :=
        quantizedCellMass_eq_zero_of_not_pos mu q hc
      have hmeasure : (mu : Measure α) (q ⁻¹' {c}) = 0 := by
        apply (measureReal_eq_zero_iff
          (μ := (mu : Measure α)) (s := q ⁻¹' {c})).mp
        exact hreal
      have hae : ∀ᵐ x ∂(mu : Measure α), x ∉ q ⁻¹' {c} :=
        measure_eq_zero_iff_ae_notMem.mp hmeasure
      filter_upwards [hae] with x hx
      intro _ heq
      exact hx (by simpa [heq])
  have hall : ∀ᵐ x ∂(mu : Measure α), ∀ c : β,
      ¬ 0 < quantizedCellMass mu q c → q x ≠ c :=
    ae_all_iff.mpr hcell
  filter_upwards [hall] with x hx
  by_contra hnot
  exact hx (q x) hnot rfl

/-- The one-dimensional dyadic cell mass under a real probability law. -/
noncomputable def dyadicCellMass
    (mu : ProbabilityMeasure ℝ) (k : ℕ) (c : DyadicCellCode k) : ℝ :=
  quantizedCellMass mu (dyadicQuantizer k) c

/-- The positive dyadic cells of a real probability law. -/
abbrev OccupiedDyadicCell (mu : ProbabilityMeasure ℝ) (k : ℕ) :=
  OccupiedQuantizedCell mu (dyadicQuantizer k)

theorem sum_occupiedDyadicCellMass
    (mu : ProbabilityMeasure ℝ) (k : ℕ) :
    ∑ c : OccupiedDyadicCell mu k, dyadicCellMass mu k c = 1 := by
  simpa [dyadicCellMass] using
    sum_occupiedQuantizedCellMass mu (dyadicQuantizer k)
      (measurable_dyadicQuantizer k)

theorem ae_dyadicCellMass_pos
    (mu : ProbabilityMeasure ℝ) (k : ℕ) :
    ∀ᵐ x ∂(mu : Measure ℝ), 0 < dyadicCellMass mu k (dyadicQuantizer k x) := by
  simpa [dyadicCellMass] using
    ae_quantizer_cellMass_pos mu (dyadicQuantizer k)
      (measurable_dyadicQuantizer k)

/-! ### Joint cells and occupied marginal rows and columns -/

abbrev DyadicPairCode (k : ℕ) := DyadicCellCode k × DyadicCellCode k

noncomputable def dyadicPairQuantizer (k : ℕ) (z : ℝ × ℝ) :
    DyadicPairCode k :=
  (dyadicQuantizer k z.1, dyadicQuantizer k z.2)

noncomputable def dyadicRowQuantizer (k : ℕ) (z : ℝ × ℝ) :
    DyadicCellCode k := dyadicQuantizer k z.1

noncomputable def dyadicColumnQuantizer (k : ℕ) (z : ℝ × ℝ) :
    DyadicCellCode k := dyadicQuantizer k z.2

theorem measurable_dyadicPairQuantizer (k : ℕ) :
    Measurable (dyadicPairQuantizer k) := by
  exact ((measurable_dyadicQuantizer k).comp measurable_fst).prodMk
    ((measurable_dyadicQuantizer k).comp measurable_snd)

theorem measurable_dyadicRowQuantizer (k : ℕ) :
    Measurable (dyadicRowQuantizer k) :=
  (measurable_dyadicQuantizer k).comp measurable_fst

theorem measurable_dyadicColumnQuantizer (k : ℕ) :
    Measurable (dyadicColumnQuantizer k) :=
  (measurable_dyadicQuantizer k).comp measurable_snd

noncomputable def dyadicPairCellMass
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) (c : DyadicPairCode k) : ℝ :=
  quantizedCellMass mu (dyadicPairQuantizer k) c

noncomputable def dyadicRowCellMass
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) (c : DyadicCellCode k) : ℝ :=
  quantizedCellMass mu (dyadicRowQuantizer k) c

noncomputable def dyadicColumnCellMass
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) (c : DyadicCellCode k) : ℝ :=
  quantizedCellMass mu (dyadicColumnQuantizer k) c

/-- The directly computed row mass is exactly the mass of the same cell under
the first marginal probability measure. -/
theorem dyadicRowCellMass_eq_marginalX
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) (c : DyadicCellCode k) :
    dyadicRowCellMass mu k c = dyadicCellMass (marginalX mu) k c := by
  unfold dyadicRowCellMass dyadicCellMass quantizedCellMass marginalX
  simp only [ProbabilityMeasure.toMeasure_map]
  rw [measureReal_def, measureReal_def]
  congr 1
  rw [Measure.map_apply_of_aemeasurable measurable_fst.aemeasurable]
  · rfl
  · exact (measurableSet_singleton c).preimage (measurable_dyadicQuantizer k)

/-- The directly computed column mass is exactly the mass under the second
marginal probability measure. -/
theorem dyadicColumnCellMass_eq_marginalY
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) (c : DyadicCellCode k) :
    dyadicColumnCellMass mu k c = dyadicCellMass (marginalY mu) k c := by
  unfold dyadicColumnCellMass dyadicCellMass quantizedCellMass marginalY
  simp only [ProbabilityMeasure.toMeasure_map]
  rw [measureReal_def, measureReal_def]
  congr 1
  rw [Measure.map_apply_of_aemeasurable measurable_snd.aemeasurable]
  · rfl
  · exact (measurableSet_singleton c).preimage (measurable_dyadicQuantizer k)

abbrev OccupiedDyadicPairCell
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :=
  OccupiedQuantizedCell mu (dyadicPairQuantizer k)

abbrev OccupiedDyadicRow
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :=
  OccupiedQuantizedCell mu (dyadicRowQuantizer k)

abbrev OccupiedDyadicColumn
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :=
  OccupiedQuantizedCell mu (dyadicColumnQuantizer k)

/-- Every positive joint cell lies in a positive marginal row. -/
theorem dyadicPairCellMass_le_rowCellMass
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ)
    (r c : DyadicCellCode k) :
    dyadicPairCellMass mu k (r, c) ≤ dyadicRowCellMass mu k r := by
  refine measureReal_mono ?_ (by finiteness)
  intro z hz
  change dyadicPairQuantizer k z = (r, c) at hz
  change dyadicRowQuantizer k z = r
  exact congrArg Prod.fst hz

/-- Every positive joint cell lies in a positive marginal column. -/
theorem dyadicPairCellMass_le_columnCellMass
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ)
    (r c : DyadicCellCode k) :
    dyadicPairCellMass mu k (r, c) ≤ dyadicColumnCellMass mu k c := by
  refine measureReal_mono ?_ (by finiteness)
  intro z hz
  change dyadicPairQuantizer k z = (r, c) at hz
  change dyadicColumnQuantizer k z = c
  exact congrArg Prod.snd hz

/-- Projecting an occupied joint cell to its row is well-defined after zero
marginal rows have been deleted. -/
noncomputable def occupiedDyadicPairRow
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ)
    (p : OccupiedDyadicPairCell mu k) : OccupiedDyadicRow mu k :=
  ⟨p.1.1, lt_of_lt_of_le p.2
    (dyadicPairCellMass_le_rowCellMass mu k p.1.1 p.1.2)⟩

/-- Projecting an occupied joint cell to its column is likewise well-defined. -/
noncomputable def occupiedDyadicPairColumn
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ)
    (p : OccupiedDyadicPairCell mu k) : OccupiedDyadicColumn mu k :=
  ⟨p.1.2, lt_of_lt_of_le p.2
    (dyadicPairCellMass_le_columnCellMass mu k p.1.1 p.1.2)⟩

/-- The occupied rows retain total marginal mass one. -/
theorem sum_occupiedDyadicRowCellMass
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :
    ∑ r : OccupiedDyadicRow mu k, dyadicRowCellMass mu k r = 1 := by
  simpa [dyadicRowCellMass] using
    sum_occupiedQuantizedCellMass mu (dyadicRowQuantizer k)
      (measurable_dyadicRowQuantizer k)

/-- The occupied columns retain total marginal mass one. -/
theorem sum_occupiedDyadicColumnCellMass
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :
    ∑ c : OccupiedDyadicColumn mu k, dyadicColumnCellMass mu k c = 1 := by
  simpa [dyadicColumnCellMass] using
    sum_occupiedQuantizedCellMass mu (dyadicColumnQuantizer k)
      (measurable_dyadicColumnQuantizer k)

/-- The occupied joint cells retain total joint mass one. -/
theorem sum_occupiedDyadicPairCellMass
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :
    ∑ c : OccupiedDyadicPairCell mu k, dyadicPairCellMass mu k c = 1 := by
  simpa [dyadicPairCellMass] using
    sum_occupiedQuantizedCellMass mu (dyadicPairQuantizer k)
      (measurable_dyadicPairQuantizer k)

end QDTauStar
