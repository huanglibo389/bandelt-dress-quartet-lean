import QDTauStar.DyadicQuantization

/-!
# Eventual stabilization of weak-order patterns

The finite Boolean code in `DyadicQuantization` identifies the right-closed
partition cell.  Here the same cell is assigned its canonical ordered rank:
the number of retained endpoints strictly below the point.  This rank lies in
`Fin (number of endpoints + 1)`, is monotone, and is strictly increasing
whenever a retained endpoint separates two real numbers.

Consequently every pairwise `<` and `=` relation in a fixed finite tuple is
eventually identical before and after quantization.  In particular, all ties
are retained and every distinct pair is eventually separated.  The last
theorems apply this to each four-sample pairing event, the one-coordinate sign
kernel, and the bivariate tau-star product kernel.
-/

open scoped BigOperators Topology
open Filter

namespace QDTauStar

/-- The finite ordered set of dyadic cells at level `k`. -/
abbrev DyadicRank (k : ℕ) := Fin (Fintype.card (DyadicEndpoint k) + 1)

/-- Canonical ordered cell index: the number of retained endpoints strictly
below `x`.  Because cells are right-closed, an endpoint itself remains in the
cell on its left. -/
noncomputable def dyadicRank (k : ℕ) (x : ℝ) : DyadicRank k :=
  ⟨(Finset.univ.filter (fun e : DyadicEndpoint k =>
      dyadicEndpointValue k e < x)).card,
    by
      apply Nat.lt_succ_of_le
      simpa using Finset.card_le_card
        (Finset.filter_subset
          (fun e : DyadicEndpoint k => dyadicEndpointValue k e < x)
          Finset.univ)⟩

@[simp]
theorem dyadicRank_val (k : ℕ) (x : ℝ) :
    (dyadicRank k x).val =
      (Finset.univ.filter (fun e : DyadicEndpoint k =>
        dyadicEndpointValue k e < x)).card := rfl

/-- Ordered dyadic cell indices are monotone in the underlying real value. -/
theorem dyadicRank_mono (k : ℕ) : Monotone (dyadicRank k) := by
  intro x y hxy
  rw [Fin.le_iff_val_le_val]
  change
    (Finset.univ.filter (fun e : DyadicEndpoint k =>
      dyadicEndpointValue k e < x)).card ≤
    (Finset.univ.filter (fun e : DyadicEndpoint k =>
      dyadicEndpointValue k e < y)).card
  apply Finset.card_le_card
  intro e he
  rw [Finset.mem_filter] at he ⊢
  exact ⟨he.1, he.2.trans_le hxy⟩

/-- The ordered dyadic quantizer is Borel measurable. -/
theorem measurable_dyadicRank (k : ℕ) : Measurable (dyadicRank k) :=
  (dyadicRank_mono k).measurable

/-- A retained endpoint separates `x` and `y` in the right-closed convention. -/
def DyadicSeparates (k : ℕ) (x y : ℝ) : Prop :=
  ∃ e : DyadicEndpoint k,
    x ≤ dyadicEndpointValue k e ∧ dyadicEndpointValue k e < y

theorem dyadicSeparates_imp_lt {k : ℕ} {x y : ℝ}
    (h : DyadicSeparates k x y) : x < y := by
  obtain ⟨e, hxe, hey⟩ := h
  exact hxe.trans_lt hey

/-- Endpoint nesting makes separation persist at the next level. -/
theorem dyadicSeparates_succ {k : ℕ} {x y : ℝ}
    (h : DyadicSeparates k x y) : DyadicSeparates (k + 1) x y := by
  obtain ⟨e, hxe, hey⟩ := h
  refine ⟨dyadicEndpointLift k e, ?_, ?_⟩
  · simpa [dyadicEndpointValue_lift] using hxe
  · simpa [dyadicEndpointValue_lift] using hey

/-- Separation persists from level `k` to every finer level `l`. -/
theorem dyadicSeparates_of_le {k l : ℕ} (hkl : k ≤ l) {x y : ℝ}
    (h : DyadicSeparates k x y) : DyadicSeparates l x y := by
  induction l, hkl using Nat.le_induction with
  | base => exact h
  | succ l _ ih => exact dyadicSeparates_succ ih

/-- Every strict pair is separated at some level. -/
theorem exists_dyadicSeparates_of_lt {x y : ℝ} (hxy : x < y) :
    ∃ k : ℕ, DyadicSeparates k x y := by
  obtain ⟨k, e, hxe, hey⟩ := exists_dyadicEndpoint_between hxy
  exact ⟨k, e, hxe, hey⟩

/-- Every strict pair is separated at all sufficiently fine levels. -/
theorem eventually_dyadicSeparates_of_lt {x y : ℝ} (hxy : x < y) :
    ∀ᶠ k : ℕ in atTop, DyadicSeparates k x y := by
  obtain ⟨k, hk⟩ := exists_dyadicSeparates_of_lt hxy
  filter_upwards [eventually_ge_atTop k] with l hl
  exact dyadicSeparates_of_le hl hk

/-- A separating endpoint makes the ordered cell rank strictly increase. -/
theorem dyadicRank_lt_of_separates {k : ℕ} {x y : ℝ}
    (h : DyadicSeparates k x y) : dyadicRank k x < dyadicRank k y := by
  obtain ⟨e, hxe, hey⟩ := h
  have hxy : x < y := hxe.trans_lt hey
  let sx : Finset (DyadicEndpoint k) :=
    Finset.univ.filter (fun a => dyadicEndpointValue k a < x)
  let sy : Finset (DyadicEndpoint k) :=
    Finset.univ.filter (fun a => dyadicEndpointValue k a < y)
  have hsub : sx ⊆ sy := by
    intro a ha
    simp only [sx, sy, Finset.mem_filter, Finset.mem_univ, true_and] at ha ⊢
    exact ha.trans hxy
  have hey_mem : e ∈ sy := by
    simp [sy, hey]
  have hxe_not_mem : e ∉ sx := by
    simp [sx, not_lt.mpr hxe]
  have hne : sx ≠ sy := by
    intro heq
    exact hxe_not_mem (by rw [heq]; exact hey_mem)
  rw [Fin.lt_iff_val_lt_val]
  change sx.card < sy.card
  exact Finset.card_lt_card
    (Finset.ssubset_iff_subset_ne.mpr ⟨hsub, hne⟩)

/-- A strict rank comparison cannot reverse the underlying real order. -/
theorem dyadicRank_lt_imp_lt {k : ℕ} {x y : ℝ}
    (h : dyadicRank k x < dyadicRank k y) : x < y := by
  by_contra hnot
  have hyx : y ≤ x := le_of_not_gt hnot
  exact (not_lt_of_ge (dyadicRank_mono k hyx)) h

/-- For each ordered pair of real values, the quantized strict comparison is
eventually exactly the original strict comparison. -/
theorem eventually_dyadicRank_lt_iff (x y : ℝ) :
    ∀ᶠ k : ℕ in atTop, (dyadicRank k x < dyadicRank k y ↔ x < y) := by
  by_cases hxy : x < y
  · filter_upwards [eventually_dyadicSeparates_of_lt hxy] with k hk
    exact ⟨dyadicRank_lt_imp_lt, fun _ => dyadicRank_lt_of_separates hk⟩
  · exact Filter.Eventually.of_forall fun k => by
      constructor
      · exact dyadicRank_lt_imp_lt
      · exact fun h => (hxy h).elim

/-- Equality, including every tie, also stabilizes exactly. -/
theorem eventually_dyadicRank_eq_iff (x y : ℝ) :
    ∀ᶠ k : ℕ in atTop, (dyadicRank k x = dyadicRank k y ↔ x = y) := by
  filter_upwards [eventually_dyadicRank_lt_iff x y,
    eventually_dyadicRank_lt_iff y x] with k hxy hyx
  constructor
  · intro heq
    by_contra hne
    rcases lt_or_gt_of_ne hne with hlt | hgt
    · have := hxy.mpr hlt
      simpa [heq] using this
    · have := hyx.mpr hgt
      simpa [heq] using this
  · intro heq
    subst y
    rfl

/-- The entire weak-order matrix of a fixed four-tuple stabilizes. -/
theorem eventually_dyadicRank_weakOrder (z : Four → ℝ) :
    ∀ᶠ k : ℕ in atTop, ∀ i j : Four,
      (dyadicRank k (z i) < dyadicRank k (z j) ↔ z i < z j) ∧
      (dyadicRank k (z i) = dyadicRank k (z j) ↔ z i = z j) := by
  rw [Filter.eventually_all]
  intro i
  rw [Filter.eventually_all]
  intro j
  filter_upwards [eventually_dyadicRank_lt_iff (z i) (z j),
    eventually_dyadicRank_eq_iff (z i) (z j)] with k hlt heq
  exact ⟨hlt, heq⟩

/-- Every specified strict two-versus-two separation event stabilizes. -/
theorem eventually_strictlySeparates_dyadicRank_iff
    (z : Four → ℝ) (r s t u : Four) :
    ∀ᶠ k : ℕ in atTop,
      (StrictlySeparates (fun i => dyadicRank k (z i)) r s t u ↔
        StrictlySeparates z r s t u) := by
  filter_upwards [eventually_dyadicRank_weakOrder z] with k hk
  simp only [StrictlySeparates, PairBelow,
    (hk r t).1, (hk r u).1, (hk s t).1, (hk s u).1,
    (hk t r).1, (hk t s).1, (hk u r).1, (hk u s).1]

/-- The exact one-coordinate Bergsma--Dassios sign kernel stabilizes, with
ties handled by the same zero-valued cases on both sides. -/
theorem eventually_signKernel_dyadicRank_eq (z : Four → ℝ) :
    ∀ᶠ k : ℕ in atTop,
      signKernel (fun i => dyadicRank k (z i)) = signKernel z := by
  filter_upwards [eventually_strictlySeparates_dyadicRank_iff z 0 1 2 3,
    eventually_strictlySeparates_dyadicRank_iff z 0 2 1 3] with k h12 h13
  simp only [signKernel, Pairing12, Pairing13, h12, h13]

/-- The complete bivariate four-sample product kernel stabilizes pointwise. -/
theorem eventually_tauProductKernel_dyadicRank_eq
    (draw : Four → (ℝ × ℝ)) :
    ∀ᶠ k : ℕ in atTop,
      tauProductKernel
          (fun z : ℝ × ℝ => dyadicRank k z.1)
          (fun z : ℝ × ℝ => dyadicRank k z.2) draw =
        tauProductKernel Prod.fst Prod.snd draw := by
  let zx : Four → ℝ := fun i => (draw i).1
  let zy : Four → ℝ := fun i => (draw i).2
  filter_upwards [eventually_signKernel_dyadicRank_eq zx,
    eventually_signKernel_dyadicRank_eq zy] with k hx hy
  unfold tauProductKernel
  change signKernel (fun i => dyadicRank k (zx i)) *
      signKernel (fun i => dyadicRank k (zy i)) =
    signKernel zx * signKernel zy
  rw [hx, hy]

end QDTauStar
