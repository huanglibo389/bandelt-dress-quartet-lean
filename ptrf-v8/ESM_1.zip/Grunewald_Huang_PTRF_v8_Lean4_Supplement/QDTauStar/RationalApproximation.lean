import QDTauStar.RationalEncoding
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Order.Filter.Finite

/-!
# Support-preserving rational approximation

This file formalizes the rational approximation used after the finite-table
argument in Corollary 3.  On a finite positive support, every cell except one
distinguished cell is rounded down to a multiple of `1 / (n + 1)`.  The
distinguished cell receives the remaining mass.  Thus the approximants are
genuine `NNRat` probability tables, have the same positive support for all
sufficiently large `n`, and converge pointwise to the original real table.
-/

open scoped BigOperators Topology
open Filter

namespace QDTauStar

variable {S : Type*} [Fintype S] [DecidableEq S]

/-- The rational lower approximation
`floor (a * (n + 1)) / (n + 1)`, stored as a nonnegative rational. -/
noncomputable def floorMassApproxNNRat (a : ℝ) (n : ℕ) : ℚ≥0 :=
  ⟨(⌊a * (n + 1)⌋₊ : ℚ) / (n + 1), by positivity⟩

@[simp]
theorem coe_floorMassApproxNNRat (a : ℝ) (n : ℕ) :
    (floorMassApproxNNRat a n : ℝ) =
      (⌊a * (n + 1)⌋₊ : ℝ) / (n + 1) := by
  simp [floorMassApproxNNRat, NNRat.cast_mk]

theorem floorMassApproxNNRat_nonneg (a : ℝ) (n : ℕ) :
    0 ≤ (floorMassApproxNNRat a n : ℝ) := by
  positivity

/-- Rounding down never increases a nonnegative mass. -/
theorem floorMassApproxNNRat_le (a : ℝ) (n : ℕ) (ha : 0 ≤ a) :
    (floorMassApproxNNRat a n : ℝ) ≤ a := by
  rw [coe_floorMassApproxNNRat]
  have hden : (0 : ℝ) < n + 1 := by positivity
  rw [div_le_iff₀ hden]
  simpa using Nat.floor_le (mul_nonneg ha hden.le)

/-- The rounded mass converges to the original mass. -/
theorem tendsto_floorMassApproxNNRat (a : ℝ) (ha : 0 ≤ a) :
    Tendsto (fun n : ℕ ↦ (floorMassApproxNNRat a n : ℝ)) atTop (𝓝 a) := by
  have hden : Tendsto (fun n : ℕ ↦ (n : ℝ) + 1) atTop atTop :=
    tendsto_atTop_add_const_right _ _ tendsto_natCast_atTop_atTop
  rw [show (fun n : ℕ ↦ (floorMassApproxNNRat a n : ℝ)) =
      (fun n : ℕ ↦ (⌊a * ((n : ℝ) + 1)⌋₊ : ℝ) / ((n : ℝ) + 1)) by
    funext n
    simp]
  convert ((tendsto_nat_floor_mul_div_atTop (R := ℝ) ha).comp hden) using 1
  funext n
  rfl

/-- The total rounded mass away from the distinguished cell is at most one. -/
theorem sum_floorMassApproxNNRat_erase_le_one
    (p : S → ℝ) (s0 : S)
    (hp : ∀ s, 0 ≤ p s) (hsum : ∑ s, p s = 1) (n : ℕ) :
    ∑ s ∈ (Finset.univ.erase s0),
        (floorMassApproxNNRat (p s) n : ℝ) ≤ 1 := by
  have hrounded :
      ∑ s ∈ (Finset.univ.erase s0),
          (floorMassApproxNNRat (p s) n : ℝ) ≤
        ∑ s ∈ (Finset.univ.erase s0), p s := by
    exact Finset.sum_le_sum fun s _ ↦ floorMassApproxNNRat_le (p s) n (hp s)
  have hdecomp :
      (∑ s ∈ (Finset.univ.erase s0), p s) + p s0 = 1 := by
    calc
      (∑ s ∈ (Finset.univ.erase s0), p s) + p s0 = ∑ s, p s :=
        Finset.sum_erase_add _ _ (Finset.mem_univ s0)
      _ = 1 := hsum
  linarith [hp s0]

theorem sum_floorMassApproxNNRat_erase_le_one_nnrat
    (p : S → ℝ) (s0 : S)
    (hp : ∀ s, 0 ≤ p s) (hsum : ∑ s, p s = 1) (n : ℕ) :
    ∑ s ∈ (Finset.univ.erase s0), floorMassApproxNNRat (p s) n ≤ 1 := by
  exact_mod_cast
    (sum_floorMassApproxNNRat_erase_le_one p s0 hp hsum n)

/-- The support-preserving rational probability approximation.  All cells
other than `s0` are rounded down; `s0` receives the exact residual mass. -/
noncomputable def supportMassApproxNNRat
    (p : S → ℝ) (s0 : S) (n : ℕ) (s : S) : ℚ≥0 :=
  if s = s0 then
    1 - ∑ t ∈ (Finset.univ.erase s0), floorMassApproxNNRat (p t) n
  else
    floorMassApproxNNRat (p s) n

/-- Every approximating table has total mass exactly one. -/
theorem sum_supportMassApproxNNRat
    (p : S → ℝ) (s0 : S)
    (hp : ∀ s, 0 ≤ p s) (hsum : ∑ s, p s = 1) (n : ℕ) :
    ∑ s, supportMassApproxNNRat p s0 n s = 1 := by
  classical
  let A : ℚ≥0 :=
    ∑ s ∈ (Finset.univ.erase s0), floorMassApproxNNRat (p s) n
  have hA : A ≤ 1 := by
    simpa [A] using
      sum_floorMassApproxNNRat_erase_le_one_nnrat p s0 hp hsum n
  calc
    ∑ s, supportMassApproxNNRat p s0 n s =
        (∑ s ∈ (Finset.univ.erase s0),
            supportMassApproxNNRat p s0 n s) +
          supportMassApproxNNRat p s0 n s0 := by
      symm
      exact Finset.sum_erase_add _ _ (Finset.mem_univ s0)
    _ = A + (1 - A) := by
      congr 1
      · apply Finset.sum_congr rfl
        intro s hs
        have hne : s ≠ s0 := (Finset.mem_erase.mp hs).1
        simp [supportMassApproxNNRat, hne]
      · simp [supportMassApproxNNRat, A]
    _ = 1 := add_tsub_cancel_of_le hA

/-- Real coercion of the distinguished residual cell. -/
theorem coe_supportMassApproxNNRat_at_distinguished
    (p : S → ℝ) (s0 : S)
    (hp : ∀ s, 0 ≤ p s) (hsum : ∑ s, p s = 1) (n : ℕ) :
    (supportMassApproxNNRat p s0 n s0 : ℝ) =
      1 - ∑ s ∈ (Finset.univ.erase s0),
        (floorMassApproxNNRat (p s) n : ℝ) := by
  have hA := sum_floorMassApproxNNRat_erase_le_one_nnrat p s0 hp hsum n
  simp only [supportMassApproxNNRat, if_pos]
  let A : ℚ≥0 :=
    ∑ s ∈ (Finset.univ.erase s0), floorMassApproxNNRat (p s) n
  have hcast :
      (A : ℝ) = ∑ s ∈ (Finset.univ.erase s0),
        (floorMassApproxNNRat (p s) n : ℝ) := by
    change (NNRat.castHom ℝ)
        (∑ s ∈ (Finset.univ.erase s0), floorMassApproxNNRat (p s) n) = _
    simp only [map_sum]
    rfl
  change ((1 - A : ℚ≥0) : ℝ) = _
  calc
    ((1 - A : ℚ≥0) : ℝ) = (((1 - A : ℚ≥0) : ℚ) : ℝ) := by
      rw [Rat.cast_nnratCast]
    _ = (((1 : ℚ≥0) : ℚ) - (A : ℚ) : ℚ) := by
      rw [NNRat.coe_sub hA]
    _ = (1 : ℝ) - (A : ℝ) := by
      rw [Rat.cast_sub, Rat.cast_nnratCast, Rat.cast_nnratCast]
      norm_num
    _ = 1 - ∑ s ∈ (Finset.univ.erase s0),
        (floorMassApproxNNRat (p s) n : ℝ) := by rw [hcast]

/-- Away from the distinguished cell, the approximation is just the lower
rational approximation. -/
theorem supportMassApproxNNRat_of_ne
    (p : S → ℝ) (s0 : S) (n : ℕ) {s : S} (hs : s ≠ s0) :
    supportMassApproxNNRat p s0 n s = floorMassApproxNNRat (p s) n := by
  simp [supportMassApproxNNRat, hs]

/-- Pointwise convergence of the support-preserving rational tables. -/
theorem tendsto_supportMassApproxNNRat
    (p : S → ℝ) (s0 : S)
    (hp : ∀ s, 0 ≤ p s) (hsum : ∑ s, p s = 1) (s : S) :
    Tendsto (fun n : ℕ ↦ (supportMassApproxNNRat p s0 n s : ℝ))
      atTop (𝓝 (p s)) := by
  classical
  by_cases hs : s = s0
  · subst s
    have hsum_lim :
        Tendsto
          (fun n : ℕ ↦
            ∑ t ∈ (Finset.univ.erase s0),
              (floorMassApproxNNRat (p t) n : ℝ))
          atTop
          (𝓝 (∑ t ∈ (Finset.univ.erase s0), p t)) := by
      exact tendsto_finsetSum (Finset.univ.erase s0) fun t _ ↦
        tendsto_floorMassApproxNNRat (p t) (hp t)
    have hres :
        Tendsto
          (fun n : ℕ ↦
            (1 : ℝ) - ∑ t ∈ (Finset.univ.erase s0),
              (floorMassApproxNNRat (p t) n : ℝ))
          atTop
          (𝓝 ((1 : ℝ) - ∑ t ∈ (Finset.univ.erase s0), p t)) :=
      tendsto_const_nhds.sub hsum_lim
    have hdecomp : 1 - ∑ t ∈ (Finset.univ.erase s0), p t = p s0 := by
      have h :
          (∑ t ∈ (Finset.univ.erase s0), p t) + p s0 = 1 := by
        calc
          (∑ t ∈ (Finset.univ.erase s0), p t) + p s0 = ∑ t, p t :=
            Finset.sum_erase_add _ _ (Finset.mem_univ s0)
          _ = 1 := hsum
      linarith
    rw [show (fun n : ℕ ↦ (supportMassApproxNNRat p s0 n s0 : ℝ)) =
        (fun n : ℕ ↦
          (1 : ℝ) - ∑ t ∈ (Finset.univ.erase s0),
            (floorMassApproxNNRat (p t) n : ℝ)) by
      funext n
      exact coe_supportMassApproxNNRat_at_distinguished p s0 hp hsum n]
    simpa only [hdecomp] using hres
  · simpa [supportMassApproxNNRat, hs] using
      tendsto_floorMassApproxNNRat (p s) (hp s)

/-- Every originally positive support cell is positive in all sufficiently
large rational approximants. -/
theorem eventually_supportMassApproxNNRat_pos
    (p : S → ℝ) (s0 : S)
    (hp : ∀ s, 0 < p s) (hsum : ∑ s, p s = 1) :
    ∀ᶠ n : ℕ in atTop, ∀ s, 0 < supportMassApproxNNRat p s0 n s := by
  rw [Filter.eventually_all]
  intro s
  have hlim := tendsto_supportMassApproxNNRat p s0
    (fun t ↦ (hp t).le) hsum s
  have hev :
      ∀ᶠ n : ℕ in atTop,
        (0 : ℝ) < (supportMassApproxNNRat p s0 n s : ℝ) :=
    hlim.eventually (Ioi_mem_nhds (hp s))
  exact hev.mono fun n hn ↦ by exact_mod_cast hn

/-- Consequently, for all sufficiently large denominators the rational table
has exactly the prescribed finite positive support and is ready for the exact
equal-weight encoding in `RationalEncoding`. -/
theorem eventually_supportMassApproxNNRat_probability_table
    (p : S → ℝ) (s0 : S)
    (hp : ∀ s, 0 < p s) (hsum : ∑ s, p s = 1) :
    ∀ᶠ n : ℕ in atTop,
      (∑ s, supportMassApproxNNRat p s0 n s = 1) ∧
      (∀ s, 0 < supportMassApproxNNRat p s0 n s) := by
  filter_upwards [eventually_supportMassApproxNNRat_pos p s0 hp hsum] with n hn
  exact ⟨sum_supportMassApproxNNRat p s0 (fun s ↦ (hp s).le) hsum n, hn⟩

/-! ## Extension from the positive support to the whole finite table -/

/-- The finite set of cells carrying positive mass. -/
abbrev PositiveMassSupport (p : S → ℝ) := {s : S // 0 < p s}

/-- Extend the positive-support approximation by exactly zero on every
originally zero cell. -/
noncomputable def fullSupportMassApproxNNRat
    (p : S → ℝ) (s0 : PositiveMassSupport p) (n : ℕ) (s : S) : ℚ≥0 :=
  if hs : 0 < p s then
    supportMassApproxNNRat (fun t : PositiveMassSupport p ↦ p t) s0 n ⟨s, hs⟩
  else
    0

theorem fullSupportMassApproxNNRat_of_pos
    (p : S → ℝ) (s0 : PositiveMassSupport p) (n : ℕ)
    {s : S} (hs : 0 < p s) :
    fullSupportMassApproxNNRat p s0 n s =
      supportMassApproxNNRat (fun t : PositiveMassSupport p ↦ p t)
        s0 n ⟨s, hs⟩ := by
  simp [fullSupportMassApproxNNRat, hs]

/-- Zero cells are not merely small: they remain identically zero. -/
theorem fullSupportMassApproxNNRat_eq_zero_of_nonpos
    (p : S → ℝ) (s0 : PositiveMassSupport p) (n : ℕ)
    {s : S} (hs : ¬ 0 < p s) :
    fullSupportMassApproxNNRat p s0 n s = 0 := by
  simp [fullSupportMassApproxNNRat, hs]

/-- Under nonnegativity, the positive-support masses still sum to one. -/
theorem sum_positiveMassSupport
    (p : S → ℝ) (hp : ∀ s, 0 ≤ p s) (hsum : ∑ s, p s = 1) :
    ∑ s : PositiveMassSupport p, p s = 1 := by
  classical
  calc
    ∑ s : PositiveMassSupport p, p s =
        ∑ s ∈ (Finset.univ.filter fun s : S ↦ 0 < p s), p s := by
      simpa using
        (Finset.sum_subtype_eq_sum_filter
          (s := (Finset.univ : Finset S)) p
          (p := fun s : S ↦ 0 < p s))
    _ = ∑ s, p s := by
      rw [Finset.sum_filter]
      apply Finset.sum_congr rfl
      intro s _
      by_cases hs : 0 < p s
      · simp [hs]
      · have hz : p s = 0 := le_antisymm (le_of_not_gt hs) (hp s)
        simp [hs, hz]
    _ = 1 := hsum

/-- Summing the zero-extended table is the same as summing over its positive
support. -/
theorem sum_fullSupportMassApproxNNRat_eq_support
    (p : S → ℝ) (s0 : PositiveMassSupport p) (n : ℕ) :
    ∑ s, fullSupportMassApproxNNRat p s0 n s =
      ∑ t : PositiveMassSupport p,
        supportMassApproxNNRat (fun u : PositiveMassSupport p ↦ p u) s0 n t := by
  classical
  calc
    ∑ s, fullSupportMassApproxNNRat p s0 n s =
        ∑ s ∈ (Finset.univ.filter fun s : S ↦ 0 < p s),
          fullSupportMassApproxNNRat p s0 n s := by
      rw [Finset.sum_filter]
      apply Finset.sum_congr rfl
      intro s _
      by_cases hs : 0 < p s
      · simp [hs]
      · simp [hs, fullSupportMassApproxNNRat_eq_zero_of_nonpos p s0 n hs]
    _ = ∑ t : PositiveMassSupport p,
          fullSupportMassApproxNNRat p s0 n t := by
      symm
      simpa using
        (Finset.sum_subtype_eq_sum_filter
          (s := (Finset.univ : Finset S))
          (fun s ↦ fullSupportMassApproxNNRat p s0 n s)
          (p := fun s : S ↦ 0 < p s))
    _ = ∑ t : PositiveMassSupport p,
          supportMassApproxNNRat
            (fun u : PositiveMassSupport p ↦ p u) s0 n t := by
      apply Finset.sum_congr rfl
      intro t _
      simpa using
        fullSupportMassApproxNNRat_of_pos p s0 n t.property

/-- The zero-extended approximation is a probability table for every `n`. -/
theorem sum_fullSupportMassApproxNNRat
    (p : S → ℝ) (s0 : PositiveMassSupport p)
    (hp : ∀ s, 0 ≤ p s) (hsum : ∑ s, p s = 1) (n : ℕ) :
    ∑ s, fullSupportMassApproxNNRat p s0 n s = 1 := by
  rw [sum_fullSupportMassApproxNNRat_eq_support]
  exact sum_supportMassApproxNNRat
    (fun t : PositiveMassSupport p ↦ p t) s0
    (fun t ↦ (t.property).le) (sum_positiveMassSupport p hp hsum) n

/-- The full rational tables converge cell by cell, including the zero cells. -/
theorem tendsto_fullSupportMassApproxNNRat
    (p : S → ℝ) (s0 : PositiveMassSupport p)
    (hp : ∀ s, 0 ≤ p s) (hsum : ∑ s, p s = 1) (s : S) :
    Tendsto (fun n : ℕ ↦ (fullSupportMassApproxNNRat p s0 n s : ℝ))
      atTop (𝓝 (p s)) := by
  by_cases hs : 0 < p s
  · rw [show (fun n : ℕ ↦ (fullSupportMassApproxNNRat p s0 n s : ℝ)) =
        (fun n : ℕ ↦
          (supportMassApproxNNRat
            (fun t : PositiveMassSupport p ↦ p t) s0 n ⟨s, hs⟩ : ℝ)) by
      funext n
      rw [fullSupportMassApproxNNRat_of_pos p s0 n hs]]
    exact tendsto_supportMassApproxNNRat
      (fun t : PositiveMassSupport p ↦ p t) s0
      (fun t ↦ (t.property).le) (sum_positiveMassSupport p hp hsum) ⟨s, hs⟩
  · have hz : p s = 0 := le_antisymm (le_of_not_gt hs) (hp s)
    simpa [fullSupportMassApproxNNRat_eq_zero_of_nonpos p s0, hs, hz] using
      (tendsto_const_nhds : Tendsto (fun _ : ℕ ↦ (0 : ℝ)) atTop (𝓝 0))

/-- Eventually the approximating table has exactly the same support as the
original table. -/
theorem eventually_fullSupportMassApproxNNRat_support_iff
    (p : S → ℝ) (s0 : PositiveMassSupport p)
    (hp : ∀ s, 0 ≤ p s) (hsum : ∑ s, p s = 1) :
    ∀ᶠ n : ℕ in atTop, ∀ s,
      (0 < fullSupportMassApproxNNRat p s0 n s ↔ 0 < p s) := by
  rw [Filter.eventually_all]
  intro s
  by_cases hs : 0 < p s
  · have hlim := tendsto_fullSupportMassApproxNNRat p s0 hp hsum s
    have hev :
        ∀ᶠ n : ℕ in atTop,
          (0 : ℝ) < (fullSupportMassApproxNNRat p s0 n s : ℝ) :=
      hlim.eventually (Ioi_mem_nhds hs)
    exact hev.mono fun n hn ↦ by
      constructor
      · intro _
        exact hs
      · intro _
        exact_mod_cast hn
  · exact Filter.Eventually.of_forall fun n ↦ by
      simp [hs, fullSupportMassApproxNNRat_eq_zero_of_nonpos p s0 n hs]

section MarginalSupport

variable {R C : Type*} [Fintype R] [DecidableEq R]
  [Fintype C] [DecidableEq C]

/-- Once cell support is preserved, every originally occupied row remains
occupied. -/
theorem row_mass_pos_of_fullSupportMassApproxNNRat
    (p : R × C → ℝ) (s0 : PositiveMassSupport p)
    (hp : ∀ rc, 0 ≤ p rc) (n : ℕ) (hsupport : ∀ rc,
      0 < fullSupportMassApproxNNRat p s0 n rc ↔ 0 < p rc)
    (r : R) (hrow : 0 < ∑ c, p (r, c)) :
    0 < ∑ c, fullSupportMassApproxNNRat p s0 n (r, c) := by
  have hp_exists : ∃ c ∈ (Finset.univ : Finset C), 0 < p (r, c) :=
    (Finset.sum_pos_iff_of_nonneg (fun c _ ↦ hp (r, c))).mp hrow
  obtain ⟨c, _, hpc⟩ := hp_exists
  exact (Finset.sum_pos_iff).2 ⟨c, Finset.mem_univ c, (hsupport (r, c)).2 hpc⟩

/-- Once cell support is preserved, every originally occupied column remains
occupied. -/
theorem col_mass_pos_of_fullSupportMassApproxNNRat
    (p : R × C → ℝ) (s0 : PositiveMassSupport p)
    (hp : ∀ rc, 0 ≤ p rc) (n : ℕ) (hsupport : ∀ rc,
      0 < fullSupportMassApproxNNRat p s0 n rc ↔ 0 < p rc)
    (c : C) (hcol : 0 < ∑ r, p (r, c)) :
    0 < ∑ r, fullSupportMassApproxNNRat p s0 n (r, c) := by
  have hp_exists : ∃ r ∈ (Finset.univ : Finset R), 0 < p (r, c) :=
    (Finset.sum_pos_iff_of_nonneg (fun r _ ↦ hp (r, c))).mp hcol
  obtain ⟨r, _, hpr⟩ := hp_exists
  exact (Finset.sum_pos_iff).2 ⟨r, Finset.mem_univ r, (hsupport (r, c)).2 hpr⟩

/-- For all sufficiently large denominators, every occupied marginal row and
column of a finite real table remains occupied in the rational table. -/
theorem eventually_fullSupportMassApproxNNRat_marginals_pos
    (p : R × C → ℝ) (s0 : PositiveMassSupport p)
    (hp : ∀ rc, 0 ≤ p rc) (hsum : ∑ rc, p rc = 1) :
    ∀ᶠ n : ℕ in atTop,
      (∀ r, 0 < ∑ c, p (r, c) →
        0 < ∑ c, fullSupportMassApproxNNRat p s0 n (r, c)) ∧
      (∀ c, 0 < ∑ r, p (r, c) →
        0 < ∑ r, fullSupportMassApproxNNRat p s0 n (r, c)) := by
  filter_upwards [eventually_fullSupportMassApproxNNRat_support_iff
    p s0 hp hsum] with n hsupport
  constructor
  · intro r hrow
    exact row_mass_pos_of_fullSupportMassApproxNNRat
      p s0 hp n hsupport r hrow
  · intro c hcol
    exact col_mass_pos_of_fullSupportMassApproxNNRat
      p s0 hp n hsupport c hcol

end MarginalSupport

end QDTauStar
