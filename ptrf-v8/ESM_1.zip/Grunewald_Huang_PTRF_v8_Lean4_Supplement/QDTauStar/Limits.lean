import Mathlib

namespace QDTauStar

/-- A lower bound valid for every finite quantisation survives simultaneous
limits of the statistic and the discrepancy. -/
theorem lower_bound_closed_under_limits
    (tau b : ℕ → ℝ) (tauLimit bLimit : ℝ)
    (hTau : Filter.Tendsto tau Filter.atTop (nhds tauLimit))
    (hB : Filter.Tendsto b Filter.atTop (nhds bLimit))
    (hFinite : ∀ k, 2 * b k ≤ tau k) :
    2 * bLimit ≤ tauLimit := by
  have hTwoB :
      Filter.Tendsto (fun k => 2 * b k) Filter.atTop (nhds (2 * bLimit)) :=
    tendsto_const_nhds.mul hB
  exact le_of_tendsto_of_tendsto' hTwoB hTau hFinite

end QDTauStar
