import Mathlib

open scoped BigOperators

namespace QDTauStar

/-! The scalar inequality at the core of the completed proof of Lemma 6. -/

/-- If every retained weight dominates the endpoint weight, then the retained
first part dominates the endpoint weight times the unaccounted row mass. -/
theorem weighted_rest_lower_bound
    {ι : Type*} [Fintype ι]
    (a s : ι → ℝ) (cw r auv : ℝ)
    (ha : ∀ i, 0 ≤ a i)
    (hs : ∀ i, cw ≤ s i)
    (hSum : ∑ i, a i = r - auv) :
    cw * (r - auv) ≤ ∑ i, s i * a i := by
  have hTerm : ∀ i, cw * a i ≤ s i * a i := fun i =>
    mul_le_mul_of_nonneg_right (hs i) (ha i)
  calc
    cw * (r - auv) = ∑ i, cw * a i := by rw [← hSum, Finset.mul_sum]
    _ ≤ ∑ i, s i * a i := Finset.sum_le_sum fun i _ => hTerm i

/-- For `0 < cv <= 1`, division by `cv` cannot reduce a nonnegative mass. -/
theorem mass_le_mass_div
    (auv cv : ℝ) (hauv : 0 ≤ auv) (hcv : 0 < cv) (hcv_le : cv ≤ 1) :
    auv ≤ auv / cv := by
  apply (le_div_iff₀ hcv).2
  exact mul_le_of_le_one_right hauv hcv_le

/-- A distinguished retained term supplies the second part of the local
coefficient bound in Lemma 6. -/
theorem distinguished_term_lower_bound
    {ι : Type*} [Fintype ι] [DecidableEq ι]
    (c s : ι → ℝ) (w0 : ι) (cw cv auv : ℝ)
    (hc : ∀ i, 0 ≤ c i) (hs_nonneg : ∀ i, 0 ≤ s i)
    (hw0s : s w0 = 1) (hw0c : c w0 = cw)
    (hcw : 0 ≤ cw) (hauv : 0 ≤ auv)
    (hcv : 0 < cv) (hcv_le : cv ≤ 1) :
    cw * auv ≤ ∑ i, s i * c i * (auv / cv) := by
  have hdiv : 0 ≤ auv / cv := div_nonneg hauv hcv.le
  have hTermNonneg : ∀ i, 0 ≤ s i * c i * (auv / cv) := fun i =>
    mul_nonneg (mul_nonneg (hs_nonneg i) (hc i)) hdiv
  have hSingle :
      s w0 * c w0 * (auv / cv) ≤ ∑ i, s i * c i * (auv / cv) := by
    exact Finset.single_le_sum (fun i _ => hTermNonneg i) (Finset.mem_univ w0)
  have hDiv := mass_le_mass_div auv cv hauv hcv hcv_le
  have hScaled : cw * auv ≤ cw * (auv / cv) :=
    mul_le_mul_of_nonneg_left hDiv hcw
  rw [hw0s, hw0c, one_mul] at hSingle
  exact hScaled.trans hSingle

/-- The complete local scalar estimate behind the first assertion of Lemma 6.
The hypotheses are exactly the two partition inequalities established in the
paper before the final addition. -/
theorem lemma3_local_coefficient_bound
    {ι : Type*} [Fintype ι]
    (a c s : ι → ℝ) (cw cv auv r : ℝ)
    (hFirst : cw * (r - auv) ≤ ∑ i, s i * a i)
    (hSecond : cw * auv ≤ ∑ i, s i * c i * (auv / cv)) :
    (1 / 2 : ℝ) * cw * r ≤
      (1 / 2 : ℝ) * ∑ i, s i * (a i + c i * (auv / cv)) := by
  have hSplit :
      ∑ i, s i * (a i + c i * (auv / cv)) =
        (∑ i, s i * a i) + (∑ i, s i * c i * (auv / cv)) := by
    simp only [mul_add, Finset.sum_add_distrib, mul_assoc]
  rw [hSplit]
  linarith

/-- The global lower bound follows by retaining a nonnegative square family
and applying the local coefficient estimate term by term. -/
theorem nonnegative_square_family_lower_bound
    {ι : Type*} [Fintype ι]
    (coefficient lower square : ι → ℝ)
    (hCoeff : ∀ i, lower i ≤ coefficient i)
    (hSquare : ∀ i, 0 ≤ square i) :
    ∑ i, lower i * square i ≤ ∑ i, coefficient i * square i := by
  exact Finset.sum_le_sum fun i _ =>
    mul_le_mul_of_nonneg_right (hCoeff i) (hSquare i)

end QDTauStar
