import QDTauStar.TauQuantizationLimit
import Mathlib.MeasureTheory.Integral.Indicator

/-!
# Right-closed quantized CDFs and their limits

The manuscript describes the cumulative cell containing `x` by its upper
endpoint `r_k(x)`, allowing `+∞` for the top tail.  In Lean it is cleaner to
use the equivalent lower set directly: a point `z` belongs when it lies below
every retained endpoint that is weakly above `x`.  This is exactly
`(-∞, r_k(x)]` for a finite upper endpoint and the whole line in the top-tail
case.  It avoids mixing real and extended-real endpoint types while retaining
the exact right-closed convention.

We prove that this set is also the pullback of the finite rank interval
`Iic (dyadicRank k x)`, that the sets decrease under refinement, and that
their intersection is `Iic x`.  Consequently the joint and marginal CDFs of
the quantized variables are precisely the corresponding lower-set masses and
converge by continuity from above.
-/

open scoped Topology
open Filter MeasureTheory Set

namespace QDTauStar

/-- The union of the right-closed dyadic cell containing `x` and all cells to
its left.  If `x` is in the top tail, the condition is vacuous and the set is
the whole real line. -/
def dyadicUpperCellLowerSet (k : ℕ) (x : ℝ) : Set ℝ :=
  {z | ∀ e : DyadicEndpoint k,
    x ≤ dyadicEndpointValue k e → z ≤ dyadicEndpointValue k e}

@[simp]
theorem mem_dyadicUpperCellLowerSet_iff (k : ℕ) (x z : ℝ) :
    z ∈ dyadicUpperCellLowerSet k x ↔
      ∀ e : DyadicEndpoint k,
        x ≤ dyadicEndpointValue k e → z ≤ dyadicEndpointValue k e :=
  Iff.rfl

/-- The endpoint description is exactly the cumulative ordered-rank
description.  This is the formal right-closed-cell identity in one
coordinate, including the two tail cells. -/
theorem mem_dyadicUpperCellLowerSet_iff_rank_le
    (k : ℕ) (x z : ℝ) :
    z ∈ dyadicUpperCellLowerSet k x ↔
      dyadicRank k z ≤ dyadicRank k x := by
  constructor
  · intro hz
    rw [Fin.le_iff_val_le_val]
    by_contra hnot
    have hcard :
        (Finset.univ.filter (fun e : DyadicEndpoint k =>
          dyadicEndpointValue k e < x)).card <
        (Finset.univ.filter (fun e : DyadicEndpoint k =>
          dyadicEndpointValue k e < z)).card := by
      simpa [dyadicRank] using (Nat.lt_of_not_ge hnot)
    obtain ⟨e, hez, hex⟩ :=
      Finset.exists_mem_notMem_of_card_lt_card hcard
    have hez' : dyadicEndpointValue k e < z := by
      simpa using hez
    have hxe : x ≤ dyadicEndpointValue k e := by
      have : ¬dyadicEndpointValue k e < x := by simpa using hex
      exact le_of_not_gt this
    exact (not_le_of_gt hez') (hz e hxe)
  · intro hr e hxe
    by_contra hnot
    have hez : dyadicEndpointValue k e < z := lt_of_not_ge hnot
    have hsep : DyadicSeparates k x z := ⟨e, hxe, hez⟩
    exact (not_lt_of_ge hr) (dyadicRank_lt_of_separates hsep)

/-- Every cumulative dyadic cell set is Borel measurable. -/
theorem measurableSet_dyadicUpperCellLowerSet (k : ℕ) (x : ℝ) :
    MeasurableSet (dyadicUpperCellLowerSet k x) := by
  rw [show dyadicUpperCellLowerSet k x =
      dyadicRank k ⁻¹' Iic (dyadicRank k x) by
    ext z
    change
      (z ∈ dyadicUpperCellLowerSet k x) ↔
        dyadicRank k z ≤ dyadicRank k x
    exact mem_dyadicUpperCellLowerSet_iff_rank_le k x z]
  exact measurableSet_Iic.preimage (measurable_dyadicRank k)

/-- Refining once can only shrink the cumulative cell set. -/
theorem dyadicUpperCellLowerSet_succ_subset (k : ℕ) (x : ℝ) :
    dyadicUpperCellLowerSet (k + 1) x ⊆
      dyadicUpperCellLowerSet k x := by
  intro z hz e hxe
  have h := hz (dyadicEndpointLift k e)
  rw [dyadicEndpointValue_lift] at h
  exact h hxe

/-- The cumulative right-closed cell sets form an antitone sequence. -/
theorem antitone_dyadicUpperCellLowerSet (x : ℝ) :
    Antitone (fun k : ℕ => dyadicUpperCellLowerSet k x) :=
  antitone_nat_of_succ_le fun k => dyadicUpperCellLowerSet_succ_subset k x

/-- Every actual lower ray is contained in every cumulative dyadic cell set. -/
theorem Iic_subset_dyadicUpperCellLowerSet (k : ℕ) (x : ℝ) :
    Iic x ⊆ dyadicUpperCellLowerSet k x := by
  intro z hzx e hxe
  exact hzx.trans hxe

/-- The intersection of all cumulative right-closed dyadic cell sets is the
original closed lower ray.  A point strictly above `x` is excluded once a
retained endpoint appears between the two points. -/
theorem iInter_dyadicUpperCellLowerSet (x : ℝ) :
    (⋂ k : ℕ, dyadicUpperCellLowerSet k x) = Iic x := by
  ext z
  constructor
  · intro hz
    simp only [mem_iInter] at hz
    by_contra hnot
    have hxz : x < z := lt_of_not_ge hnot
    obtain ⟨k, e, hxe, hez⟩ := exists_dyadicEndpoint_between hxz
    exact (not_le_of_gt hez) (hz k e hxe)
  · intro hzx
    simp only [mem_iInter]
    intro k
    exact Iic_subset_dyadicUpperCellLowerSet k x hzx

/-- The two-dimensional cumulative cell rectangle. -/
def dyadicUpperCellLowerRectangle (k : ℕ) (x y : ℝ) : Set (ℝ × ℝ) :=
  dyadicUpperCellLowerSet k x ×ˢ dyadicUpperCellLowerSet k y

theorem measurableSet_dyadicUpperCellLowerRectangle
    (k : ℕ) (x y : ℝ) :
    MeasurableSet (dyadicUpperCellLowerRectangle k x y) :=
  (measurableSet_dyadicUpperCellLowerSet k x).prod
    (measurableSet_dyadicUpperCellLowerSet k y)

theorem antitone_dyadicUpperCellLowerRectangle (x y : ℝ) :
    Antitone (fun k : ℕ => dyadicUpperCellLowerRectangle k x y) := by
  intro k l hkl z hz
  exact ⟨antitone_dyadicUpperCellLowerSet x hkl hz.1,
    antitone_dyadicUpperCellLowerSet y hkl hz.2⟩

theorem iInter_dyadicUpperCellLowerRectangle (x y : ℝ) :
    (⋂ k : ℕ, dyadicUpperCellLowerRectangle k x y) =
      Iic x ×ˢ Iic y := by
  ext z
  constructor
  · intro hz
    simp only [mem_iInter] at hz
    constructor
    · rw [← iInter_dyadicUpperCellLowerSet x]
      simp only [mem_iInter]
      exact fun k => (hz k).1
    · rw [← iInter_dyadicUpperCellLowerSet y]
      simp only [mem_iInter]
      exact fun k => (hz k).2
  · intro hz
    simp only [mem_iInter]
    intro k
    exact ⟨Iic_subset_dyadicUpperCellLowerSet k x hz.1,
      Iic_subset_dyadicUpperCellLowerSet k y hz.2⟩

/-! ## Finite rank laws and the exact CDF pullback identity -/

/-- The joint law of the two ordered dyadic ranks. -/
noncomputable def dyadicRankJointLaw
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :
    ProbabilityMeasure (DyadicRank k × DyadicRank k) :=
  mu.map (((measurable_dyadicRank k).comp measurable_fst).prodMk
    ((measurable_dyadicRank k).comp measurable_snd)).aemeasurable

/-- The first marginal rank law. -/
noncomputable def dyadicRankXLaw
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :
    ProbabilityMeasure (DyadicRank k) :=
  (marginalX mu).map (measurable_dyadicRank k).aemeasurable

/-- The second marginal rank law. -/
noncomputable def dyadicRankYLaw
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :
    ProbabilityMeasure (DyadicRank k) :=
  (marginalY mu).map (measurable_dyadicRank k).aemeasurable

/-- Joint CDF of the finite ordered rank law. -/
noncomputable def dyadicRankJointCDF
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ)
    (r c : DyadicRank k) : ℝ :=
  ((dyadicRankJointLaw mu k : ProbabilityMeasure _) : Measure _).real
    (Iic r ×ˢ Iic c)

/-- First marginal CDF of the finite ordered rank law. -/
noncomputable def dyadicRankCDFX
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ)
    (r : DyadicRank k) : ℝ :=
  ((dyadicRankXLaw mu k : ProbabilityMeasure _) : Measure _).real (Iic r)

/-- Second marginal CDF of the finite ordered rank law. -/
noncomputable def dyadicRankCDFY
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ)
    (c : DyadicRank k) : ℝ :=
  ((dyadicRankYLaw mu k : ProbabilityMeasure _) : Measure _).real (Iic c)

/-- Evaluating the finite joint CDF at the cells of `x,y` gives exactly the
mass of the cumulative right-closed rectangle. -/
theorem dyadicRankJointCDF_at_quantized_eq
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) (x y : ℝ) :
    dyadicRankJointCDF mu k (dyadicRank k x) (dyadicRank k y) =
      (mu : Measure (ℝ × ℝ)).real
        (dyadicUpperCellLowerRectangle k x y) := by
  unfold dyadicRankJointCDF dyadicRankJointLaw
  simp only [ProbabilityMeasure.toMeasure_map]
  rw [measureReal_def, measureReal_def]
  congr 1
  rw [Measure.map_apply_of_aemeasurable
    ((((measurable_dyadicRank k).comp measurable_fst).prodMk
      ((measurable_dyadicRank k).comp measurable_snd)).aemeasurable)
    ((measurableSet_Iic : MeasurableSet (Iic (dyadicRank k x))).prod
      (measurableSet_Iic : MeasurableSet (Iic (dyadicRank k y))))]
  apply congrArg (mu : Measure (ℝ × ℝ))
  ext z
  simp only [mem_preimage, mem_prod, mem_Iic]
  exact and_congr
    (mem_dyadicUpperCellLowerSet_iff_rank_le k x z.1).symm
    (mem_dyadicUpperCellLowerSet_iff_rank_le k y z.2).symm

theorem dyadicRankCDFX_at_quantized_eq
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) (x : ℝ) :
    dyadicRankCDFX mu k (dyadicRank k x) =
      ((marginalX mu : ProbabilityMeasure ℝ) : Measure ℝ).real
        (dyadicUpperCellLowerSet k x) := by
  unfold dyadicRankCDFX dyadicRankXLaw
  simp only [ProbabilityMeasure.toMeasure_map]
  rw [measureReal_def, measureReal_def]
  congr 1
  rw [Measure.map_apply_of_aemeasurable
    (measurable_dyadicRank k).aemeasurable
    (measurableSet_Iic : MeasurableSet (Iic (dyadicRank k x)))]
  apply congrArg ((marginalX mu : ProbabilityMeasure ℝ) : Measure ℝ)
  ext z
  simp only [mem_preimage, mem_Iic]
  exact (mem_dyadicUpperCellLowerSet_iff_rank_le k x z).symm

theorem dyadicRankCDFY_at_quantized_eq
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) (y : ℝ) :
    dyadicRankCDFY mu k (dyadicRank k y) =
      ((marginalY mu : ProbabilityMeasure ℝ) : Measure ℝ).real
        (dyadicUpperCellLowerSet k y) := by
  unfold dyadicRankCDFY dyadicRankYLaw
  simp only [ProbabilityMeasure.toMeasure_map]
  rw [measureReal_def, measureReal_def]
  congr 1
  rw [Measure.map_apply_of_aemeasurable
    (measurable_dyadicRank k).aemeasurable
    (measurableSet_Iic : MeasurableSet (Iic (dyadicRank k y)))]
  apply congrArg ((marginalY mu : ProbabilityMeasure ℝ) : Measure ℝ)
  ext z
  simp only [mem_preimage, mem_Iic]
  exact (mem_dyadicUpperCellLowerSet_iff_rank_le k y z).symm

/-- Finite-rank CDF discrepancy. -/
noncomputable def dyadicRankDiscrepancy
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ)
    (r c : DyadicRank k) : ℝ :=
  dyadicRankJointCDF mu k r c -
    dyadicRankCDFX mu k r * dyadicRankCDFY mu k c

/-- The finite-rank discrepancy pulled back to the original real coordinates.
This is the manuscript's extended `D̄(r_k(x),s_k(y))`. -/
noncomputable def pulledDyadicDiscrepancy
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) (x y : ℝ) : ℝ :=
  dyadicRankDiscrepancy mu k (dyadicRank k x) (dyadicRank k y)

/-- Exact right-closed-cell discrepancy identity, including the top-tail
zero convention through the whole-space cumulative set. -/
theorem pulledDyadicDiscrepancy_eq_lowerSet_masses
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) (x y : ℝ) :
    pulledDyadicDiscrepancy mu k x y =
      (mu : Measure (ℝ × ℝ)).real
          (dyadicUpperCellLowerRectangle k x y) -
        ((marginalX mu : ProbabilityMeasure ℝ) : Measure ℝ).real
            (dyadicUpperCellLowerSet k x) *
          ((marginalY mu : ProbabilityMeasure ℝ) : Measure ℝ).real
            (dyadicUpperCellLowerSet k y) := by
  unfold pulledDyadicDiscrepancy dyadicRankDiscrepancy
  rw [dyadicRankJointCDF_at_quantized_eq,
    dyadicRankCDFX_at_quantized_eq, dyadicRankCDFY_at_quantized_eq]

/-! ## Continuity from above -/

/-- Real-valued continuity from above for the one-dimensional cumulative
cell sets. -/
theorem tendsto_measureReal_dyadicUpperCellLowerSet
    (nu : ProbabilityMeasure ℝ) (x : ℝ) :
    Tendsto
      (fun k : ℕ => (nu : Measure ℝ).real
        (dyadicUpperCellLowerSet k x))
      atTop (𝓝 ((nu : Measure ℝ).real (Iic x))) := by
  have hMeasure := tendsto_measure_iInter_atTop
    (μ := (nu : Measure ℝ))
    (s := fun k : ℕ => dyadicUpperCellLowerSet k x)
    (fun k => (measurableSet_dyadicUpperCellLowerSet k x).nullMeasurableSet)
    (antitone_dyadicUpperCellLowerSet x)
    ⟨0, by finiteness⟩
  rw [iInter_dyadicUpperCellLowerSet x] at hMeasure
  simpa only [measureReal_def, Function.comp_def] using
    (ENNReal.tendsto_toReal (measure_ne_top (nu : Measure ℝ) (Iic x))).comp
      hMeasure

/-- Real-valued continuity from above for the joint cumulative rectangles. -/
theorem tendsto_measureReal_dyadicUpperCellLowerRectangle
    (mu : ProbabilityMeasure (ℝ × ℝ)) (x y : ℝ) :
    Tendsto
      (fun k : ℕ => (mu : Measure (ℝ × ℝ)).real
        (dyadicUpperCellLowerRectangle k x y))
      atTop (𝓝 ((mu : Measure (ℝ × ℝ)).real (Iic x ×ˢ Iic y))) := by
  have hMeasure := tendsto_measure_iInter_atTop
    (μ := (mu : Measure (ℝ × ℝ)))
    (s := fun k : ℕ => dyadicUpperCellLowerRectangle k x y)
    (fun k =>
      (measurableSet_dyadicUpperCellLowerRectangle k x y).nullMeasurableSet)
    (antitone_dyadicUpperCellLowerRectangle x y)
    ⟨0, by finiteness⟩
  rw [iInter_dyadicUpperCellLowerRectangle x y] at hMeasure
  simpa only [measureReal_def, Function.comp_def] using
    (ENNReal.tendsto_toReal
      (measure_ne_top (mu : Measure (ℝ × ℝ)) (Iic x ×ˢ Iic y))).comp
      hMeasure

/-- The pulled finite-rank discrepancy converges pointwise to the original
joint-versus-product CDF discrepancy. -/
theorem tendsto_pulledDyadicDiscrepancy
    (mu : ProbabilityMeasure (ℝ × ℝ)) (x y : ℝ) :
    Tendsto (fun k : ℕ => pulledDyadicDiscrepancy mu k x y) atTop
      (𝓝 (cdfDiscrepancy mu x y)) := by
  rw [show (fun k : ℕ => pulledDyadicDiscrepancy mu k x y) =
      (fun k : ℕ =>
        (mu : Measure (ℝ × ℝ)).real
            (dyadicUpperCellLowerRectangle k x y) -
          ((marginalX mu : ProbabilityMeasure ℝ) : Measure ℝ).real
              (dyadicUpperCellLowerSet k x) *
            ((marginalY mu : ProbabilityMeasure ℝ) : Measure ℝ).real
              (dyadicUpperCellLowerSet k y)) by
    funext k
    exact pulledDyadicDiscrepancy_eq_lowerSet_masses mu k x y]
  unfold cdfDiscrepancy jointCDF marginalCDFX marginalCDFY
  exact (tendsto_measureReal_dyadicUpperCellLowerRectangle mu x y).sub
    ((tendsto_measureReal_dyadicUpperCellLowerSet (marginalX mu) x).mul
      (tendsto_measureReal_dyadicUpperCellLowerSet (marginalY mu) y))

/-! ## The quantized BKR discrepancy and dominated convergence -/

/-- The pulled finite-rank discrepancy is jointly Borel measurable in the
original real coordinates. -/
theorem measurable_pulledDyadicDiscrepancy_uncurry
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :
    Measurable (fun p : ℝ × ℝ =>
      pulledDyadicDiscrepancy mu k p.1 p.2) := by
  let f : DyadicRank k × DyadicRank k → ℝ :=
    fun rc => dyadicRankDiscrepancy mu k rc.1 rc.2
  have hFinite : Measurable f := Measurable.of_discrete
  have hRankPair : Measurable (fun p : ℝ × ℝ =>
      (dyadicRank k p.1, dyadicRank k p.2)) :=
    ((measurable_dyadicRank k).comp measurable_fst).prodMk
      ((measurable_dyadicRank k).comp measurable_snd)
  change Measurable (f ∘ fun p : ℝ × ℝ =>
    (dyadicRank k p.1, dyadicRank k p.2))
  exact hFinite.comp hRankPair

/-- Every finite-rank discrepancy lies in `[-1,1]`. -/
theorem dyadicRankDiscrepancy_abs_le_one
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ)
    (r c : DyadicRank k) :
    |dyadicRankDiscrepancy mu k r c| ≤ 1 := by
  have hj0 : 0 ≤ dyadicRankJointCDF mu k r c := measureReal_nonneg
  have hj1 : dyadicRankJointCDF mu k r c ≤ 1 := measureReal_le_one
  have hx0 : 0 ≤ dyadicRankCDFX mu k r := measureReal_nonneg
  have hx1 : dyadicRankCDFX mu k r ≤ 1 := measureReal_le_one
  have hy0 : 0 ≤ dyadicRankCDFY mu k c := measureReal_nonneg
  have hy1 : dyadicRankCDFY mu k c ≤ 1 := measureReal_le_one
  rw [abs_le]
  constructor <;> unfold dyadicRankDiscrepancy <;> nlinarith

theorem pulledDyadicDiscrepancy_abs_le_one
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) (x y : ℝ) :
    |pulledDyadicDiscrepancy mu k x y| ≤ 1 :=
  dyadicRankDiscrepancy_abs_le_one mu k (dyadicRank k x) (dyadicRank k y)

/-- BKR discrepancy of the finite ordered-rank law. -/
noncomputable def dyadicRankBKR
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) : ℝ :=
  ∫ rc : DyadicRank k × DyadicRank k,
      dyadicRankDiscrepancy mu k rc.1 rc.2 ^ 2
    ∂(((dyadicRankXLaw mu k).prod (dyadicRankYLaw mu k)) : Measure _)

/-- The same finite BKR discrepancy pulled back to two independent draws
from the original marginal laws.  This is the expectation displayed in the
manuscript immediately after the right-closed-cell identity. -/
noncomputable def pulledDyadicBKR
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) : ℝ :=
  ∫ p : ℝ × ℝ, pulledDyadicDiscrepancy mu k p.1 p.2 ^ 2
    ∂(((marginalX mu).prod (marginalY mu)) : Measure _)

/-- Change of variables under the product of the two marginal rank maps:
the finite-rank BKR is exactly its pulled-back real-coordinate expectation. -/
theorem dyadicRankBKR_eq_pulledDyadicBKR
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :
    dyadicRankBKR mu k = pulledDyadicBKR mu k := by
  let q : ℝ × ℝ → DyadicRank k × DyadicRank k :=
    Prod.map (dyadicRank k) (dyadicRank k)
  have hq : Measurable q :=
    (measurable_dyadicRank k).prodMap (measurable_dyadicRank k)
  have hLaw :
      (dyadicRankXLaw mu k).prod (dyadicRankYLaw mu k) =
        ((marginalX mu).prod (marginalY mu)).map hq.aemeasurable := by
    unfold dyadicRankXLaw dyadicRankYLaw
    exact ProbabilityMeasure.map_prod_map
      (marginalX mu) (marginalY mu)
      (measurable_dyadicRank k) (measurable_dyadicRank k)
  unfold dyadicRankBKR pulledDyadicBKR
  rw [hLaw]
  simp only [ProbabilityMeasure.toMeasure_map]
  have hIntegrand : Measurable
      (fun rc : DyadicRank k × DyadicRank k =>
        dyadicRankDiscrepancy mu k rc.1 rc.2 ^ 2) :=
    Measurable.of_discrete
  rw [integral_map hq.aemeasurable hIntegrand.aestronglyMeasurable]
  apply integral_congr_ae
  filter_upwards [] with p
  simp [q, pulledDyadicDiscrepancy]

/-- Each pulled finite-rank BKR integrand is integrable and uniformly
dominated by one. -/
theorem integrable_pulledDyadicBKRIntegrand
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :
    Integrable (fun p : ℝ × ℝ =>
      pulledDyadicDiscrepancy mu k p.1 p.2 ^ 2)
      (((marginalX mu).prod (marginalY mu)) : Measure _) := by
  apply Integrable.mono' (integrable_const (1 : ℝ))
  · exact ((measurable_pulledDyadicDiscrepancy_uncurry mu k).pow_const 2).aestronglyMeasurable
  · filter_upwards [] with p
    rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
    have hAbs : |pulledDyadicDiscrepancy mu k p.1 p.2| ≤ |(1 : ℝ)| := by
      simpa using pulledDyadicDiscrepancy_abs_le_one mu k p.1 p.2
    simpa using (sq_le_sq.mpr hAbs)

/-- Dominated convergence of the pulled finite-rank BKR discrepancies. -/
theorem tendsto_pulledDyadicBKR
    (mu : ProbabilityMeasure (ℝ × ℝ)) :
    Tendsto (pulledDyadicBKR mu) atTop (𝓝 (bkrDiscrepancy mu)) := by
  unfold pulledDyadicBKR bkrDiscrepancy
  apply MeasureTheory.tendsto_integral_of_dominated_convergence
      (bound := fun _ : ℝ × ℝ => (1 : ℝ))
  · intro k
    exact ((measurable_pulledDyadicDiscrepancy_uncurry mu k).pow_const 2).aestronglyMeasurable
  · exact integrable_const (1 : ℝ)
  · intro k
    filter_upwards [] with p
    rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
    have hAbs : |pulledDyadicDiscrepancy mu k p.1 p.2| ≤ |(1 : ℝ)| := by
      simpa using pulledDyadicDiscrepancy_abs_le_one mu k p.1 p.2
    simpa using (sq_le_sq.mpr hAbs)
  · filter_upwards [] with p
    exact (tendsto_pulledDyadicDiscrepancy mu p.1 p.2).pow 2

/-- Therefore the actual finite-rank BKR discrepancies converge to the BKR
discrepancy of the original bivariate law. -/
theorem tendsto_dyadicRankBKR
    (mu : ProbabilityMeasure (ℝ × ℝ)) :
    Tendsto (dyadicRankBKR mu) atTop (𝓝 (bkrDiscrepancy mu)) := by
  apply Filter.Tendsto.congr'
    (Filter.EventuallyEq.symm (Filter.Eventually.of_forall fun k =>
      dyadicRankBKR_eq_pulledDyadicBKR mu k))
  exact tendsto_pulledDyadicBKR mu

end QDTauStar
