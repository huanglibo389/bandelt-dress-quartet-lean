import QDTauStar.FiniteTable
import QDTauStar.FinitePath

/-!
# Lemma 6 on the actual finite ordered path trees

This file removes the abstract scalar hypotheses from the finite part of the
tau-star argument.  It reindexes every directed edge of the two ordered path
trees, settles the four orientation copies in each grid cell, and identifies
the resulting coefficient with the empirical BKR discrepancy.
-/

open scoped BigOperators

namespace QDTauStar

universe uX

variable {X : Type uX} [Fintype X] [DecidableEq X] [Nonempty X]

/-- One directed-edge-pair summand in `lemma3GlobalLowerBound`. -/
noncomputable def pathLemma3EdgePairTerm
    {V₁ V₂ : Type*} [Fintype V₁] [Fintype V₂]
    (T₁ : QDFull.XTree X V₁) (T₂ : QDFull.XTree X V₂)
    (e₁ : V₁ × V₁) (e₂ : V₂ × V₂) : ℝ :=
  (1 / 2 : ℝ) * T₂.columnMass e₂.1 e₂.2 e₂.2 *
    T₁.rowMass e₁.1 e₁.2 e₁.2 *
    QDFull.splitQuartetCovariance
      (T₁.edgeSplit e₁.1 e₁.2) (T₂.edgeSplit e₂.1 e₂.2)

/-- At one pair of adjacent support cuts, the four edge orientations occur
once each.  Their endpoint masses add to the two adjacent marginal masses,
and their common split covariance is `6 * Delta^2`; the factor `1/2` in
Lemma 6 therefore leaves the coefficient `3`. -/
theorem pathLemma3_four_orientations_eq
    {m n : ℕ}
    (row : X → Fin (m + 1)) (col : X → Fin (n + 1))
    (hrow : Function.Surjective row) (hcol : Function.Surjective col)
    (i : Fin m) (j : Fin n) :
    let T₁ := orderedPathXTree row hrow
    let T₂ := orderedPathXTree col hcol
    let e₁ := pathCutDirectedEdge i
    let e₂ := pathCutDirectedEdge j
    pathLemma3EdgePairTerm T₁ T₂ e₁ e₂ +
        pathLemma3EdgePairTerm T₁ T₂ e₁ (QDFull.XTree.reverseEdge e₂) +
        pathLemma3EdgePairTerm T₁ T₂ (QDFull.XTree.reverseEdge e₁) e₂ +
        pathLemma3EdgePairTerm T₁ T₂ (QDFull.XTree.reverseEdge e₁)
          (QDFull.XTree.reverseEdge e₂) =
      3 *
        (orderedAtomMass row i.castSucc + orderedAtomMass row i.succ) *
        (orderedAtomMass col j.castSucc + orderedAtomMass col j.succ) *
        orderedGridDelta row col i j ^ 2 := by
  dsimp only
  unfold pathLemma3EdgePairTerm
  simp only [pathCutDirectedEdge, QDFull.XTree.reverseEdge]
  rw [orderedPath_rowMass_center_eq_atomMass]
  rw [orderedPath_rowMass_center_eq_atomMass]
  rw [orderedPath_columnMass_center_eq_atomMass]
  rw [orderedPath_columnMass_center_eq_atomMass]
  rw [(orderedPathXTree row hrow).edgeSplit_comm i.succ i.castSucc]
  rw [(orderedPathXTree col hcol).edgeSplit_comm j.succ j.castSucc]
  have hQ :
      QDFull.splitQuartetCovariance
          ((orderedPathXTree row hrow).edgeSplit i.castSucc i.succ)
          ((orderedPathXTree col hcol).edgeSplit j.castSucc j.succ) =
        6 * orderedGridDelta row col i j ^ 2 := by
    rw [QDFull.edgeSplit_quartetCovariance_eq
      (orderedPathXTree row hrow) (orderedPathXTree col hcol)
      (pathGraph_adj_cut i) (pathGraph_adj_cut j)]
    rw [orderedPath_xCoefficient_forward_eq_gridDelta]
  rw [hQ]
  ring

/-- The complete directed-edge sum in Lemma 6 is exactly three times the
adjacent-weight discrepancy sum for the two ordered path trees. -/
theorem orderedPath_lemma3GlobalLowerBound_eq
    {m n : ℕ}
    (row : X → Fin (m + 1)) (col : X → Fin (n + 1))
    (hrow : Function.Surjective row) (hcol : Function.Surjective col) :
    QDFull.lemma3GlobalLowerBound
        (orderedPathXTree row hrow) (orderedPathXTree col hcol) =
      3 * ∑ i : Fin m, ∑ j : Fin n,
        (orderedAtomMass row i.castSucc + orderedAtomMass row i.succ) *
        (orderedAtomMass col j.castSucc + orderedAtomMass col j.succ) *
        orderedGridDelta row col i j ^ 2 := by
  change
    (∑ e₁ ∈ (orderedPathXTree row hrow).directedEdgeFinset,
      ∑ e₂ ∈ (orderedPathXTree col hcol).directedEdgeFinset,
        pathLemma3EdgePairTerm (orderedPathXTree row hrow)
          (orderedPathXTree col hcol) e₁ e₂) = _
  rw [(orderedPathXTree row hrow).sum_directedEdge_eq_sum_canonical_with_reverse]
  rw [orderedPath_sum_canonicalEdge_eq_sum_cuts]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i hi
  rw [(orderedPathXTree col hcol).sum_directedEdge_eq_sum_canonical_with_reverse]
  rw [orderedPath_sum_canonicalEdge_eq_sum_cuts]
  rw [(orderedPathXTree col hcol).sum_directedEdge_eq_sum_canonical_with_reverse]
  rw [orderedPath_sum_canonicalEdge_eq_sum_cuts]
  rw [← Finset.sum_add_distrib]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro j hj
  simpa only [add_assoc, mul_assoc] using
    pathLemma3_four_orientations_eq row col hrow hcol i j

/-- Lemma 6 applied to the actual path trees, with no assumed scalar bridge. -/
theorem orderedPath_three_adjacentSum_le_treeQuartetCovariance
    {m n : ℕ}
    (row : X → Fin (m + 1)) (col : X → Fin (n + 1))
    (hrow : Function.Surjective row) (hcol : Function.Surjective col) :
    3 * ∑ i : Fin m, ∑ j : Fin n,
        (orderedAtomMass row i.castSucc + orderedAtomMass row i.succ) *
        (orderedAtomMass col j.castSucc + orderedAtomMass col j.succ) *
        orderedGridDelta row col i j ^ 2 ≤
      QDFull.treeQuartetCovariance
        (orderedPathXTree row hrow) (orderedPathXTree col hcol) := by
  rw [← orderedPath_lemma3GlobalLowerBound_eq row col hrow hcol]
  exact QDFull.lemma3_global_split_covariance_lower_bound
    (orderedPathXTree row hrow) (orderedPathXTree col hcol)

end QDTauStar
