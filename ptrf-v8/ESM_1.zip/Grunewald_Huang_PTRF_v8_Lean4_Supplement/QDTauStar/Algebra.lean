import Mathlib

namespace QDTauStar

/-! Algebraic identities used in Lemma 2 and in the finite-path
normalisation of Corollary 3. -/

/-- The determinant identity of Lemma 2, written entrywise. -/
theorem matrix_identity
    (a11 a12 a13 a21 a22 a23 α r1 r2 : ℝ)
    (hr1 : r1 = a11 + a12 + a13)
    (hr2 : r2 = a21 + a22 + a23)
    (hr1_ne : r1 ≠ 0) (hr2_ne : r2 ≠ 0) :
    a11 * a23 - a21 * a13 =
      (α * (a13 / r1) + (1 - α) * (a23 / r2)) *
          (a11 * (a22 + a23) - a21 * (a12 + a13)) -
      (α * (a11 / r1) + (1 - α) * (a21 / r2)) *
          (a13 * (a21 + a22) - a23 * (a11 + a12)) := by
  subst r1
  subst r2
  field_simp [hr1_ne, hr2_ne]
  ring

/-- The two event normalisations used in the supplement imply
`Q = (3/2) tauStar`. -/
theorem quartetCovariance_eq_threeHalves_tauStar
    (pConcordant pDiscordant quartetCovariance tauStar : ℝ)
    (hTau :
      tauStar = (2 / 3 : ℝ) * pConcordant - (1 / 3 : ℝ) * pDiscordant)
    (hQ :
      quartetCovariance = pConcordant - (1 / 2 : ℝ) * pDiscordant) :
    quartetCovariance = (3 / 2 : ℝ) * tauStar := by
  rw [hQ, hTau]
  ring

/-- The determinant of a `2 x 2` probability table is the lower-left
distribution discrepancy. -/
theorem quadrant_determinant_eq_discrepancy
    (p11 p12 p21 p22 : ℝ)
    (hTotal : p11 + p12 + p21 + p22 = 1) :
    p11 * p22 - p12 * p21 =
      p11 - (p11 + p12) * (p11 + p21) := by
  calc
    p11 * p22 - p12 * p21 =
        p11 - (p11 + p12) * (p11 + p21) +
          p11 * (p11 + p12 + p21 + p22 - 1) := by ring
    _ = p11 - (p11 + p12) * (p11 + p21) := by rw [hTotal]; ring

/-- The last row of a finite ordered table contributes zero to the BKR
discrepancy because its cumulative marginal equals one. -/
theorem bkr_last_row_zero (joint marginal : ℝ)
    (hJoint : joint = marginal) :
    joint - 1 * marginal = 0 := by
  rw [hJoint]
  ring

/-- The last column of a finite ordered table contributes zero for the same
reason.  This separate statement mirrors the two boundary checks in the paper. -/
theorem bkr_last_column_zero (joint marginal : ℝ)
    (hJoint : joint = marginal) :
    joint - marginal * 1 = 0 := by
  rw [hJoint]
  ring

end QDTauStar
