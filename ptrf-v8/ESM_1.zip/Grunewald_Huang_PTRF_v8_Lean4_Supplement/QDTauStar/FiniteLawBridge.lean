import QDTauStar.FiniteMassInequality
import Mathlib.MeasureTheory.Integral.Bochner.SumMeasure

/-!
# Exact bridge between a finite probability law and its mass table

For a probability measure on an ordered finite grid, this file proves that
integration is literally finite summation against the singleton masses.  It
identifies the four-draw tau-star integral and the product-marginal BKR
integral with the two finite-table polynomials used in the finite-support
proof.  Terminal CDF rows and columns are included first and then shown to
vanish, so the omission of the last row and column in `finiteTableBKR` is an
explicit theorem rather than an indexing convention.
-/

open scoped BigOperators
open MeasureTheory Set

namespace QDTauStar

section FiniteLaw

variable {m n : ℕ}

/-- Singleton masses of a probability law on a finite ordered grid. -/
noncomputable def finiteLawMass
    (nu : ProbabilityMeasure (OrderedCell m n))
    (rc : OrderedCell m n) : ℝ :=
  (nu : Measure (OrderedCell m n)).real {rc}

/-- The row marginal of a finite ordered grid law. -/
noncomputable def finiteLawRow
    (nu : ProbabilityMeasure (OrderedCell m n)) :
    ProbabilityMeasure (Fin (m + 1)) :=
  nu.map measurable_fst.aemeasurable

/-- The column marginal of a finite ordered grid law. -/
noncomputable def finiteLawCol
    (nu : ProbabilityMeasure (OrderedCell m n)) :
    ProbabilityMeasure (Fin (n + 1)) :=
  nu.map measurable_snd.aemeasurable

theorem finiteLawMass_nonneg
    (nu : ProbabilityMeasure (OrderedCell m n)) (rc : OrderedCell m n) :
    0 ≤ finiteLawMass nu rc :=
  measureReal_nonneg

theorem sum_finiteLawMass
    (nu : ProbabilityMeasure (OrderedCell m n)) :
    ∑ rc, finiteLawMass nu rc = 1 := by
  unfold finiteLawMass
  simpa using
    (sum_measureReal_singleton
      (μ := (nu : Measure (OrderedCell m n)))
      (Finset.univ : Finset (OrderedCell m n)))

/-- Summing singleton masses over an event gives exactly the mass of that
event. -/
theorem finiteWeightedEventMass_finiteLawMass
    (nu : ProbabilityMeasure (OrderedCell m n))
    (E : OrderedCell m n → Prop) :
    finiteWeightedEventMass (finiteLawMass nu) E =
      (nu : Measure (OrderedCell m n)).real {rc | E rc} := by
  classical
  unfold finiteWeightedEventMass finiteLawMass
  calc
    (∑ rc, (nu : Measure (OrderedCell m n)).real {rc} * indicator (E rc)) =
        ∑ rc ∈ (Finset.univ.filter E),
          (nu : Measure (OrderedCell m n)).real {rc} := by
      rw [Finset.sum_filter]
      apply Finset.sum_congr rfl
      intro rc _
      by_cases hrc : E rc <;> simp [indicator, hrc]
    _ = (nu : Measure (OrderedCell m n)).real
          (Finset.univ.filter E : Set (OrderedCell m n)) := by
      exact sum_measureReal_singleton
        (μ := (nu : Measure (OrderedCell m n)))
        (Finset.univ.filter E)
    _ = (nu : Measure (OrderedCell m n)).real {rc | E rc} := by
      congr 1
      ext rc
      simp

theorem finiteLawRow_apply
    (nu : ProbabilityMeasure (OrderedCell m n)) (A : Set (Fin (m + 1))) :
    (finiteLawRow nu : Measure (Fin (m + 1))).real A =
      (nu : Measure (OrderedCell m n)).real (Prod.fst ⁻¹' A) := by
  unfold finiteLawRow
  simp only [ProbabilityMeasure.toMeasure_map]
  rw [measureReal_def, measureReal_def]
  congr 1
  rw [Measure.map_apply_of_aemeasurable measurable_fst.aemeasurable]
  exact MeasurableSet.of_discrete

theorem finiteLawCol_apply
    (nu : ProbabilityMeasure (OrderedCell m n)) (A : Set (Fin (n + 1))) :
    (finiteLawCol nu : Measure (Fin (n + 1))).real A =
      (nu : Measure (OrderedCell m n)).real (Prod.snd ⁻¹' A) := by
  unfold finiteLawCol
  simp only [ProbabilityMeasure.toMeasure_map]
  rw [measureReal_def, measureReal_def]
  congr 1
  rw [Measure.map_apply_of_aemeasurable measurable_snd.aemeasurable]
  exact MeasurableSet.of_discrete

theorem finiteTableRowMass_finiteLawMass
    (nu : ProbabilityMeasure (OrderedCell m n)) (r : Fin (m + 1)) :
    finiteTableRowMass (finiteLawMass nu) r =
      (finiteLawRow nu : Measure (Fin (m + 1))).real {r} := by
  rw [finiteLawRow_apply]
  unfold finiteTableRowMass
  rw [finiteWeightedEventMass_finiteLawMass]
  congr 1

theorem finiteTableColMass_finiteLawMass
    (nu : ProbabilityMeasure (OrderedCell m n)) (c : Fin (n + 1)) :
    finiteTableColMass (finiteLawMass nu) c =
      (finiteLawCol nu : Measure (Fin (n + 1))).real {c} := by
  rw [finiteLawCol_apply]
  unfold finiteTableColMass
  rw [finiteWeightedEventMass_finiteLawMass]
  congr 1

/-- Cumulative discrepancy at an arbitrary grid point, including the
terminal row and terminal column. -/
noncomputable def finiteTableDeltaAt
    (p : OrderedCell m n → ℝ) (r : Fin (m + 1)) (c : Fin (n + 1)) : ℝ :=
  finiteWeightedEventMass p (fun rc => rc.1 ≤ r ∧ rc.2 ≤ c) -
    finiteWeightedEventMass p (fun rc => rc.1 ≤ r) *
      finiteWeightedEventMass p (fun rc => rc.2 ≤ c)

theorem finiteTableDeltaAt_castSucc
    (p : OrderedCell m n → ℝ) (i : Fin m) (j : Fin n) :
    finiteTableDeltaAt p i.castSucc j.castSucc = finiteTableDelta p i j := by
  rfl

theorem finiteTableDeltaAt_finiteLawMass
    (nu : ProbabilityMeasure (OrderedCell m n))
    (r : Fin (m + 1)) (c : Fin (n + 1)) :
    finiteTableDeltaAt (finiteLawMass nu) r c =
      (nu : Measure (OrderedCell m n)).real (Iic r ×ˢ Iic c) -
        (finiteLawRow nu : Measure (Fin (m + 1))).real (Iic r) *
          (finiteLawCol nu : Measure (Fin (n + 1))).real (Iic c) := by
  unfold finiteTableDeltaAt
  rw [finiteWeightedEventMass_finiteLawMass,
    finiteWeightedEventMass_finiteLawMass,
    finiteWeightedEventMass_finiteLawMass,
    finiteLawRow_apply, finiteLawCol_apply]
  congr 1

theorem finiteTableDeltaAt_last_row
    (p : OrderedCell m n → ℝ) (hsum : ∑ rc, p rc = 1)
    (c : Fin (n + 1)) :
    finiteTableDeltaAt p (Fin.last m) c = 0 := by
  classical
  unfold finiteTableDeltaAt finiteWeightedEventMass
  have hAllRow (rc : OrderedCell m n) : rc.1 ≤ Fin.last m := Fin.le_last _
  simp only [hAllRow, true_and, indicator_of_true, mul_one]
  rw [hsum]
  ring

theorem finiteTableDeltaAt_last_col
    (p : OrderedCell m n → ℝ) (hsum : ∑ rc, p rc = 1)
    (r : Fin (m + 1)) :
    finiteTableDeltaAt p r (Fin.last n) = 0 := by
  classical
  unfold finiteTableDeltaAt finiteWeightedEventMass
  have hAllCol (rc : OrderedCell m n) : rc.2 ≤ Fin.last n := Fin.le_last _
  simp only [hAllCol, and_true, indicator_of_true, mul_one]
  rw [hsum]
  ring

/-- The BKR expression before deleting its terminal zero row and column. -/
noncomputable def finiteTableBKRAll
    (p : OrderedCell m n → ℝ) : ℝ :=
  ∑ r : Fin (m + 1), ∑ c : Fin (n + 1),
    finiteTableRowMass p r * finiteTableColMass p c *
      finiteTableDeltaAt p r c ^ 2

/-- The terminal row and column of a CDF discrepancy are zero, so the full
finite BKR sum is exactly the manuscript's sum over interior cuts. -/
theorem finiteTableBKRAll_eq_finiteTableBKR
    (p : OrderedCell m n → ℝ) (hsum : ∑ rc, p rc = 1) :
    finiteTableBKRAll p = finiteTableBKR p := by
  unfold finiteTableBKRAll finiteTableBKR
  rw [Fin.sum_univ_castSucc]
  simp_rw [Fin.sum_univ_castSucc]
  simp [finiteTableDeltaAt_castSucc, finiteTableDeltaAt_last_row,
    finiteTableDeltaAt_last_col, hsum]

/-- The mass of one ordered four-draw atom under four independent copies of
a finite law is the product of its four singleton masses. -/
theorem finiteLaw_fourfold_singletonMass
    (nu : ProbabilityMeasure (OrderedCell m n))
    (draw : Four → OrderedCell m n) :
    ((ProbabilityMeasure.pi (fun _ : Four => nu) :
        ProbabilityMeasure (Four → OrderedCell m n)) : Measure _).real {draw} =
      fourDrawWeight (finiteLawMass nu) draw := by
  rw [measureReal_def]
  change
    (Measure.pi (fun _ : Four => (nu : Measure (OrderedCell m n))) {draw}).toReal =
      fourDrawWeight (finiteLawMass nu) draw
  rw [Measure.pi_singleton]
  simp only [ENNReal.toReal_prod]
  rfl

/-- The finite-table tau-star polynomial is exactly the tau-star integral of
four independent draws from the corresponding finite law. -/
theorem finiteTableTauStar_finiteLawMass_eq_integral
    (nu : ProbabilityMeasure (OrderedCell m n)) :
    finiteTableTauStar (finiteLawMass nu) =
      ∫ draw : Four → OrderedCell m n,
        tauProductKernel Prod.fst Prod.snd draw
        ∂((ProbabilityMeasure.pi (fun _ : Four => nu)) : Measure _) := by
  rw [integral_fintype Integrable.of_finite]
  unfold finiteTableTauStar finiteTauStar weightedFourSum
  apply Finset.sum_congr rfl
  intro draw _
  rw [finiteLaw_fourfold_singletonMass]
  simp

/-- The full finite-table BKR polynomial is exactly the BKR integral of the
finite law against the product of its two marginals. -/
theorem finiteTableBKRAll_finiteLawMass_eq_integral
    (nu : ProbabilityMeasure (OrderedCell m n)) :
    finiteTableBKRAll (finiteLawMass nu) =
      ∫ rc : Fin (m + 1) × Fin (n + 1),
        ((nu : Measure (OrderedCell m n)).real
              (Iic rc.1 ×ˢ Iic rc.2) -
            (finiteLawRow nu : Measure (Fin (m + 1))).real (Iic rc.1) *
              (finiteLawCol nu : Measure (Fin (n + 1))).real (Iic rc.2)) ^ 2
        ∂(((finiteLawRow nu).prod (finiteLawCol nu)) : Measure _) := by
  rw [integral_fintype Integrable.of_finite]
  unfold finiteTableBKRAll
  rw [Fintype.sum_prod_type]
  apply Finset.sum_congr rfl
  intro r _
  apply Finset.sum_congr rfl
  intro c _
  rw [finiteTableRowMass_finiteLawMass,
    finiteTableColMass_finiteLawMass,
    finiteTableDeltaAt_finiteLawMass]
  rw [show ({(r, c)} : Set (Fin (m + 1) × Fin (n + 1))) =
      ({r} : Set (Fin (m + 1))) ×ˢ ({c} : Set (Fin (n + 1))) by
    ext x
    simp]
  simp only [ProbabilityMeasure.toMeasure_prod]
  rw [measureReal_prod_prod]
  simp [smul_eq_mul]

end FiniteLaw

end QDTauStar
