import QDTauStar.FiniteTable

open scoped BigOperators

namespace QDTauStar

variable {R C : Type*} [Fintype R] [DecidableEq R]
  [Fintype C] [DecidableEq C]

noncomputable def rationalTableDenom (p : R × C → ℚ≥0) : ℕ :=
  ∏ rc : R × C, (p rc).den

noncomputable def rationalCellCount (p : R × C → ℚ≥0)
    (rc : R × C) : ℕ :=
  (p rc).num * ∏ st ∈ (Finset.univ.erase rc), (p st).den

omit [DecidableEq R] [DecidableEq C] in
theorem rationalTableDenom_pos (p : R × C → ℚ≥0) :
    0 < rationalTableDenom p := by
  classical
  unfold rationalTableDenom
  exact Finset.prod_pos fun _ _ ↦ NNRat.den_pos _

theorem rationalCellCount_div_denom (p : R × C → ℚ≥0)
    (rc : R × C) :
    (rationalCellCount p rc : ℚ≥0) / rationalTableDenom p = p rc := by
  classical
  have hprod := Finset.mul_prod_erase Finset.univ
    (fun st : R × C ↦ (p st).den) (Finset.mem_univ rc)
  rw [rationalCellCount, rationalTableDenom, ← hprod]
  push_cast
  rw [mul_div_mul_right _ _ (by positivity)]
  exact NNRat.num_div_den (p rc)

theorem sum_rationalCellCount_eq_denom
    (p : R × C → ℚ≥0) (hsum : ∑ rc, p rc = 1) :
    ∑ rc, rationalCellCount p rc = rationalTableDenom p := by
  classical
  have hden : (rationalTableDenom p : ℚ≥0) ≠ 0 := by
    exact_mod_cast (ne_of_gt (rationalTableDenom_pos p))
  have hdiv : (∑ rc, (rationalCellCount p rc : ℚ≥0)) /
      rationalTableDenom p = 1 := by
    rw [Finset.sum_div]
    simp_rw [rationalCellCount_div_denom]
    exact hsum
  have hcast : (∑ rc, (rationalCellCount p rc : ℚ≥0)) =
      rationalTableDenom p := (div_eq_one_iff_eq hden).mp hdiv
  exact_mod_cast hcast

abbrev RationalTableLabel (p : R × C → ℚ≥0) :=
  Σ rc : R × C, Fin (rationalCellCount p rc)

noncomputable def rationalTableRow (p : R × C → ℚ≥0) :
    RationalTableLabel p → R := fun x ↦ x.1.1

noncomputable def rationalTableCol (p : R × C → ℚ≥0) :
    RationalTableLabel p → C := fun x ↦ x.1.2

noncomputable def rationalCellFiberEquiv (p : R × C → ℚ≥0)
    (rc : R × C) :
    {x : RationalTableLabel p // x.1 = rc} ≃ Fin (rationalCellCount p rc) where
  toFun x := by
    rcases x with ⟨⟨st, k⟩, h⟩
    change st = rc at h
    subst st
    exact k
  invFun k := ⟨⟨rc, k⟩, rfl⟩
  left_inv x := by
    rcases x with ⟨⟨st, k⟩, h⟩
    change st = rc at h
    subst st
    rfl
  right_inv k := rfl

theorem card_rationalTableLabel
    (p : R × C → ℚ≥0) (hsum : ∑ rc, p rc = 1) :
    Fintype.card (RationalTableLabel p) = rationalTableDenom p := by
  unfold RationalTableLabel
  rw [Fintype.card_sigma]
  simp_rw [Fintype.card_fin]
  exact sum_rationalCellCount_eq_denom p hsum

theorem card_rationalTable_cell (p : R × C → ℚ≥0)
    (rc : R × C) :
    Fintype.card {x : RationalTableLabel p // x.1 = rc} =
      rationalCellCount p rc := by
  simpa using Fintype.card_congr (rationalCellFiberEquiv p rc)

theorem rationalTable_empirical_cell_mass
    (p : R × C → ℚ≥0) (hsum : ∑ rc, p rc = 1)
    (rc : R × C) :
    (Fintype.card {x : RationalTableLabel p // x.1 = rc} : ℚ≥0) /
        Fintype.card (RationalTableLabel p) = p rc := by
  rw [card_rationalTable_cell, card_rationalTableLabel p hsum]
  exact rationalCellCount_div_denom p rc

theorem rationalCellCount_pos_of_pos
    (p : R × C → ℚ≥0) (rc : R × C) (hp : 0 < p rc) :
    0 < rationalCellCount p rc := by
  by_contra hcount
  have hzero : rationalCellCount p rc = 0 := Nat.eq_zero_of_not_pos hcount
  have heq := rationalCellCount_div_denom p rc
  rw [hzero] at heq
  simp only [Nat.cast_zero, zero_div] at heq
  exact (ne_of_gt hp) heq.symm

theorem rationalTableRow_surjective
    (p : R × C → ℚ≥0) (hrow : ∀ r, 0 < ∑ c, p (r, c)) :
    Function.Surjective (rationalTableRow p) := by
  classical
  intro r
  obtain ⟨c, -, hpc⟩ := (Finset.sum_pos_iff).mp (hrow r)
  have hcount := rationalCellCount_pos_of_pos p (r, c) hpc
  exact ⟨⟨(r, c), ⟨0, hcount⟩⟩, rfl⟩

theorem rationalTableCol_surjective
    (p : R × C → ℚ≥0) (hcol : ∀ c, 0 < ∑ r, p (r, c)) :
    Function.Surjective (rationalTableCol p) := by
  classical
  intro c
  obtain ⟨r, -, hpr⟩ := (Finset.sum_pos_iff).mp (hcol c)
  have hcount := rationalCellCount_pos_of_pos p (r, c) hpr
  exact ⟨⟨(r, c), ⟨0, hcount⟩⟩, rfl⟩

theorem rationalTable_normalizedCard_cell
    (p : R × C → ℚ≥0) (hsum : ∑ rc, p rc = 1)
    (r : R) (c : C) :
    QDFull.normalizedCard
        (Finset.univ.filter fun x : RationalTableLabel p ↦
          rationalTableRow p x = r ∧ rationalTableCol p x = c) =
      (p (r, c) : ℝ) := by
  classical
  unfold QDFull.normalizedCard
  have hfilter :
      (Finset.univ.filter fun x : RationalTableLabel p ↦
          rationalTableRow p x = r ∧ rationalTableCol p x = c).card =
        rationalCellCount p (r, c) := by
    rw [← Fintype.card_subtype]
    let e :
        {x : RationalTableLabel p //
          rationalTableRow p x = r ∧ rationalTableCol p x = c} ≃
          {x : RationalTableLabel p // x.1 = (r, c)} := {
      toFun x := ⟨x.1, by
        apply Prod.ext
        · simpa [rationalTableRow] using x.2.1
        · simpa [rationalTableCol] using x.2.2⟩
      invFun x := ⟨x.1, by
        constructor
        · simpa [rationalTableRow] using congrArg Prod.fst x.2
        · simpa [rationalTableCol] using congrArg Prod.snd x.2⟩
      left_inv x := Subtype.ext rfl
      right_inv x := Subtype.ext rfl
    }
    calc
      Fintype.card {x : RationalTableLabel p //
          rationalTableRow p x = r ∧ rationalTableCol p x = c} =
          Fintype.card {x : RationalTableLabel p // x.1 = (r, c)} :=
        Fintype.card_congr e
      _ = rationalCellCount p (r, c) := card_rationalTable_cell p (r, c)
  rw [hfilter, card_rationalTableLabel p hsum]
  have h := congrArg (fun q : ℚ≥0 ↦ (q : ℝ))
    (rationalCellCount_div_denom p (r, c))
  simpa using h

end QDTauStar

