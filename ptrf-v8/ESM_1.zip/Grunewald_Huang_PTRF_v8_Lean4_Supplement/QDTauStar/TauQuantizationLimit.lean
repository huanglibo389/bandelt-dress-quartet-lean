import QDTauStar.WeakOrderQuantization
import QDTauStar.Population

/-!
# Dominated convergence for the dyadically quantized tau-star kernel

The weak-order stabilization theorem in `WeakOrderQuantization` is pointwise:
for every fixed four-sample draw, the two coordinate sign kernels, and hence
their product, are eventually unchanged by sufficiently fine dyadic
quantization.  This file supplies the measure-theoretic interface needed in
the manuscript.  The quantized kernels are measurable, uniformly bounded in
absolute value by one, and therefore converge under the fourfold product law
by dominated convergence.
-/

open scoped Topology
open Filter MeasureTheory

namespace QDTauStar

/-- The tau-star product kernel after applying the level-`k` ordered dyadic
cell rank to both coordinates. -/
noncomputable def quantizedTauProductKernel (k : ℕ)
    (draw : Four → (ℝ × ℝ)) : ℝ :=
  tauProductKernel
    (fun z : ℝ × ℝ => dyadicRank k z.1)
    (fun z : ℝ × ℝ => dyadicRank k z.2)
    draw

/-- The population tau-star obtained from the level-`k` dyadic ranks. -/
noncomputable def quantizedPopulationTauStar
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) : ℝ :=
  ∫ draw : Four → (ℝ × ℝ), quantizedTauProductKernel k draw
    ∂(fourfoldLaw mu : Measure _)

/-- For a finite ordered codomain, the one-coordinate sign kernel is a
measurable function on four-tuples. -/
private theorem measurable_finite_signKernel {A : Type*}
    [Fintype A] [LinearOrder A] [MeasurableSpace A]
    [MeasurableSingletonClass A] :
    Measurable (fun z : Four → A => signKernel z) :=
  measurable_of_finite _

/-- Each dyadically quantized bivariate tau-star kernel is measurable. -/
theorem measurable_quantizedTauProductKernel (k : ℕ) :
    Measurable (quantizedTauProductKernel k) := by
  have hx : Measurable (fun draw : Four → (ℝ × ℝ) =>
      fun i : Four => dyadicRank k (draw i).1) := by
    apply measurable_pi_lambda
    intro i
    exact (measurable_dyadicRank k).comp
      (measurable_fst.comp (measurable_pi_apply i))
  have hy : Measurable (fun draw : Four → (ℝ × ℝ) =>
      fun i : Four => dyadicRank k (draw i).2) := by
    apply measurable_pi_lambda
    intro i
    exact (measurable_dyadicRank k).comp
      (measurable_snd.comp (measurable_pi_apply i))
  unfold quantizedTauProductKernel tauProductKernel
  exact ((measurable_finite_signKernel (A := DyadicRank k)).comp hx).mul
    ((measurable_finite_signKernel (A := DyadicRank k)).comp hy)

/-- The quantized kernel inherits the exact uniform bound of the underlying
strict four-sample kernel. -/
theorem abs_quantizedTauProductKernel_le_one (k : ℕ)
    (draw : Four → (ℝ × ℝ)) :
    |quantizedTauProductKernel k draw| ≤ 1 := by
  exact abs_tauProductKernel_le_one
    (fun z : ℝ × ℝ => dyadicRank k z.1)
    (fun z : ℝ × ℝ => dyadicRank k z.2)
    draw

/-- Every quantized kernel is integrable under four independent copies of an
arbitrary bivariate probability law. -/
theorem integrable_quantizedTauProductKernel
    (mu : ProbabilityMeasure (ℝ × ℝ)) (k : ℕ) :
    Integrable (quantizedTauProductKernel k) (fourfoldLaw mu) := by
  apply Integrable.mono' (integrable_const (1 : ℝ))
    (measurable_quantizedTauProductKernel k).aestronglyMeasurable
  filter_upwards [] with draw
  simpa only [Real.norm_eq_abs, norm_one] using
    abs_quantizedTauProductKernel_le_one k draw

/-- For each fixed four-sample draw, the quantized product kernel converges to
the original product kernel.  In fact the sequence is eventually equal to its
limit, including all tie cases. -/
theorem tendsto_quantizedTauProductKernel
    (draw : Four → (ℝ × ℝ)) :
    Tendsto (fun k : ℕ => quantizedTauProductKernel k draw) atTop
      (𝓝 (tauProductKernel Prod.fst Prod.snd draw)) := by
  apply Filter.Tendsto.congr'
    (Filter.EventuallyEq.symm
      (eventually_tauProductKernel_dyadicRank_eq draw))
  exact tendsto_const_nhds

/-- Dominated convergence for the dyadically quantized tau-star integrals. -/
theorem tendsto_integral_quantizedTauProductKernel
    (mu : ProbabilityMeasure (ℝ × ℝ)) :
    Tendsto
      (fun k : ℕ => ∫ draw : Four → (ℝ × ℝ),
        quantizedTauProductKernel k draw ∂(fourfoldLaw mu : Measure _))
      atTop
      (𝓝 (∫ draw : Four → (ℝ × ℝ),
        tauProductKernel Prod.fst Prod.snd draw
          ∂(fourfoldLaw mu : Measure _))) := by
  apply MeasureTheory.tendsto_integral_of_dominated_convergence
      (bound := fun _ : Four → (ℝ × ℝ) => (1 : ℝ))
  · intro k
    exact (measurable_quantizedTauProductKernel k).aestronglyMeasurable
  · exact integrable_const (1 : ℝ)
  · intro k
    filter_upwards [] with draw
    simpa only [Real.norm_eq_abs, norm_one] using
      abs_quantizedTauProductKernel_le_one k draw
  · filter_upwards [] with draw
    exact tendsto_quantizedTauProductKernel draw

/-- The quantized population tau-star converges to the manuscript's
population tau-star for every real bivariate probability law. -/
theorem tendsto_quantizedPopulationTauStar
    (mu : ProbabilityMeasure (ℝ × ℝ)) :
    Tendsto (quantizedPopulationTauStar mu) atTop
      (𝓝 (populationTauStar mu)) := by
  change Tendsto
    (fun k : ℕ => ∫ draw : Four → (ℝ × ℝ),
      quantizedTauProductKernel k draw ∂(fourfoldLaw mu : Measure _))
    atTop
    (𝓝 (∫ draw : Four → (ℝ × ℝ),
      tauProductKernel Prod.fst Prod.snd draw
        ∂(fourfoldLaw mu : Measure _)))
  exact tendsto_integral_quantizedTauProductKernel mu

end QDTauStar
