import Mathlib

/-!
# The Bergsma--Dassios four-sample kernel

This file formalizes the strict-separation indicator and the unnormalised
kernel used in Corollary 3 of the manuscript.  The arguments are kept
as an ordered `Fin 4` tuple, so ties and repeated observations remain in the
domain rather than being discarded tacitly.
-/

namespace QDTauStar

abbrev Four := Fin 4

/-- Every entry in the first ordered pair is strictly below every entry in
the second ordered pair. -/
def PairBelow {A : Type*} [LinearOrder A]
    (z : Four → A) (r s t u : Four) : Prop :=
  z r < z t ∧ z r < z u ∧ z s < z t ∧ z s < z u

/-- The two occurrences at positions `r,s` lie strictly on one side of the
two occurrences at positions `t,u`, in either order. -/
def StrictlySeparates {A : Type*} [LinearOrder A]
    (z : Four → A) (r s t u : Four) : Prop :=
  PairBelow z r s t u ∨ PairBelow z t u r s

/-- The expanded definition is exactly the max--min formula printed in the
paper. -/
theorem strictlySeparates_iff_max_lt_min {A : Type*} [LinearOrder A]
    (z : Four → A) (r s t u : Four) :
    StrictlySeparates z r s t u ↔
      max (z r) (z s) < min (z t) (z u) ∨
        max (z t) (z u) < min (z r) (z s) := by
  simp [StrictlySeparates, PairBelow, and_assoc, and_left_comm]

/-- `I_{12|34}` in zero-based position notation. -/
def Pairing12 {A : Type*} [LinearOrder A] (z : Four → A) : Prop :=
  StrictlySeparates z 0 1 2 3

/-- `I_{13|24}` in zero-based position notation. -/
def Pairing13 {A : Type*} [LinearOrder A] (z : Four → A) : Prop :=
  StrictlySeparates z 0 2 1 3

/-- The third possible strict two--two partition, `I_{14|23}`. -/
def Pairing14 {A : Type*} [LinearOrder A] (z : Four → A) : Prop :=
  StrictlySeparates z 0 3 1 2

/-- Real-valued indicator of a proposition. -/
noncomputable def indicator (P : Prop) : ℝ := by
  classical
  exact if P then 1 else 0

@[simp] theorem indicator_of_true {P : Prop} (h : P) : indicator P = 1 := by
  simp [indicator, h]

@[simp] theorem indicator_of_false {P : Prop} (h : ¬ P) : indicator P = 0 := by
  simp [indicator, h]

/-- The paper's unnormalised one-coordinate sign kernel
`a(z)=I_{13|24}(z)-I_{12|34}(z)`. -/
noncomputable def signKernel {A : Type*} [LinearOrder A]
    (z : Four → A) : ℝ :=
  indicator (Pairing13 z) - indicator (Pairing12 z)

/-- Product kernel evaluated on the two coordinate vectors of four joint
observations. -/
noncomputable def tauProductKernel {A B Ω : Type*}
    [LinearOrder A] [LinearOrder B]
    (x : Ω → A) (y : Ω → B) (draw : Four → Ω) : ℝ :=
  signKernel (x ∘ draw) * signKernel (y ∘ draw)

private theorem pairing12_pairing13_disjoint
    {A : Type*} [LinearOrder A] (z : Four → A) :
    ¬(Pairing12 z ∧ Pairing13 z) := by
  rintro ⟨h12, h13⟩
  rcases h12 with h12 | h12 <;> rcases h13 with h13 | h13
  · rcases h12 with ⟨_, _, h12, _⟩
    rcases h13 with ⟨_, _, h21, _⟩
    exact lt_asymm h12 h21
  · rcases h12 with ⟨_, h03, _, _⟩
    rcases h13 with ⟨_, _, h30, _⟩
    exact lt_asymm h03 h30
  · rcases h12 with ⟨_, _, h30, _⟩
    rcases h13 with ⟨_, h03, _, _⟩
    exact lt_asymm h30 h03
  · rcases h12 with ⟨_, h21, _, _⟩
    rcases h13 with ⟨_, h12, _, _⟩
    exact lt_asymm h21 h12

private theorem pairing12_pairing14_disjoint
    {A : Type*} [LinearOrder A] (z : Four → A) :
    ¬(Pairing12 z ∧ Pairing14 z) := by
  rintro ⟨h12, h14⟩
  rcases h12 with h12 | h12 <;> rcases h14 with h14 | h14
  · rcases h12 with ⟨_, _, _, h13⟩
    rcases h14 with ⟨_, _, h31, _⟩
    exact lt_asymm h13 h31
  · rcases h12 with ⟨h02, _, _, _⟩
    rcases h14 with ⟨_, _, h20, _⟩
    exact lt_asymm h02 h20
  · rcases h12 with ⟨h20, _, _, _⟩
    rcases h14 with ⟨_, h02, _, _⟩
    exact lt_asymm h20 h02
  · rcases h12 with ⟨_, _, _, h31⟩
    rcases h14 with ⟨_, h13, _, _⟩
    exact lt_asymm h31 h13

private theorem pairing13_pairing14_disjoint
    {A : Type*} [LinearOrder A] (z : Four → A) :
    ¬(Pairing13 z ∧ Pairing14 z) := by
  rintro ⟨h13, h14⟩
  rcases h13 with h13 | h13 <;> rcases h14 with h14 | h14
  · rcases h13 with ⟨_, _, _, h23⟩
    rcases h14 with ⟨_, _, _, h32⟩
    exact lt_asymm h23 h32
  · rcases h13 with ⟨h01, _, _, _⟩
    rcases h14 with ⟨h10, _, _, _⟩
    exact lt_asymm h01 h10
  · rcases h13 with ⟨h10, _, _, _⟩
    rcases h14 with ⟨h01, _, _, _⟩
    exact lt_asymm h10 h01
  · rcases h13 with ⟨_, _, _, h32⟩
    rcases h14 with ⟨_, _, _, h23⟩
    exact lt_asymm h32 h23

theorem not_pairing13_of_pairing12 {A : Type*} [LinearOrder A]
    {z : Four → A} (h : Pairing12 z) : ¬Pairing13 z :=
  fun h' => pairing12_pairing13_disjoint z ⟨h, h'⟩

theorem not_pairing14_of_pairing12 {A : Type*} [LinearOrder A]
    {z : Four → A} (h : Pairing12 z) : ¬Pairing14 z :=
  fun h' => pairing12_pairing14_disjoint z ⟨h, h'⟩

theorem not_pairing12_of_pairing13 {A : Type*} [LinearOrder A]
    {z : Four → A} (h : Pairing13 z) : ¬Pairing12 z :=
  fun h' => pairing12_pairing13_disjoint z ⟨h', h⟩

theorem not_pairing14_of_pairing13 {A : Type*} [LinearOrder A]
    {z : Four → A} (h : Pairing13 z) : ¬Pairing14 z :=
  fun h' => pairing13_pairing14_disjoint z ⟨h, h'⟩

theorem not_pairing12_of_pairing14 {A : Type*} [LinearOrder A]
    {z : Four → A} (h : Pairing14 z) : ¬Pairing12 z :=
  fun h' => pairing12_pairing14_disjoint z ⟨h', h⟩

theorem not_pairing13_of_pairing14 {A : Type*} [LinearOrder A]
    {z : Four → A} (h : Pairing14 z) : ¬Pairing13 z :=
  fun h' => pairing13_pairing14_disjoint z ⟨h', h⟩

theorem signKernel_eq_neg_one_of_pairing12
    {A : Type*} [LinearOrder A] {z : Four → A} (h : Pairing12 z) :
    signKernel z = -1 := by
  simp [signKernel, indicator_of_true h,
    indicator_of_false (not_pairing13_of_pairing12 h)]

theorem signKernel_eq_one_of_pairing13
    {A : Type*} [LinearOrder A] {z : Four → A} (h : Pairing13 z) :
    signKernel z = 1 := by
  simp [signKernel, indicator_of_true h,
    indicator_of_false (not_pairing12_of_pairing13 h)]

theorem signKernel_eq_zero_of_pairing14
    {A : Type*} [LinearOrder A] {z : Four → A} (h : Pairing14 z) :
    signKernel z = 0 := by
  simp [signKernel, indicator_of_false (not_pairing12_of_pairing14 h),
    indicator_of_false (not_pairing13_of_pairing14 h)]

theorem signKernel_eq_zero_of_no_strict_pairing
    {A : Type*} [LinearOrder A] {z : Four → A}
    (h12 : ¬Pairing12 z) (h13 : ¬Pairing13 z) :
    signKernel z = 0 := by
  simp [signKernel, indicator_of_false h12, indicator_of_false h13]

theorem signKernel_eq_neg_one_or_zero_or_one
    {A : Type*} [LinearOrder A] (z : Four → A) :
    signKernel z = -1 ∨ signKernel z = 0 ∨ signKernel z = 1 := by
  by_cases h12 : Pairing12 z
  · exact Or.inl (signKernel_eq_neg_one_of_pairing12 h12)
  · by_cases h13 : Pairing13 z
    · exact Or.inr (Or.inr (signKernel_eq_one_of_pairing13 h13))
    · exact Or.inr (Or.inl (signKernel_eq_zero_of_no_strict_pairing h12 h13))

theorem abs_signKernel_le_one
    {A : Type*} [LinearOrder A] (z : Four → A) :
    |signKernel z| ≤ 1 := by
  rcases signKernel_eq_neg_one_or_zero_or_one z with h | h | h <;>
    rw [h] <;> norm_num

theorem abs_tauProductKernel_le_one
    {A B Ω : Type*} [LinearOrder A] [LinearOrder B]
    (x : Ω → A) (y : Ω → B) (draw : Four → Ω) :
    |tauProductKernel x y draw| ≤ 1 := by
  rw [tauProductKernel, abs_mul]
  nlinarith [abs_signKernel_le_one (x ∘ draw),
    abs_signKernel_le_one (y ∘ draw),
    abs_nonneg (signKernel (x ∘ draw)),
    abs_nonneg (signKernel (y ∘ draw))]

end QDTauStar
