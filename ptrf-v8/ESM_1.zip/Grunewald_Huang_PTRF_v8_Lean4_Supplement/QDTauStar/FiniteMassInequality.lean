import QDTauStar.RationalApproximation
import QDTauStar.FinitePathTau

/-!
# Finite probability tables and the rational-to-real passage

This module closes the continuity step in the finite-support part of
Corollary 3.  It first proves a general finite pushforward identity for four
independent weighted draws.  It then applies that identity to the equally
weighted label encoding of a rational contingency table, identifies every
atomic and cumulative coefficient with the corresponding table polynomial,
and finally passes the inequality to arbitrary real cell masses by the
support-preserving rational approximants.
-/

open scoped BigOperators Topology
open Filter

namespace QDTauStar

section FinitePushforward

variable {Ω S : Type*} [Fintype Ω] [Fintype S] [DecidableEq S]

/-- The total source weight in one fibre of a finite map. -/
noncomputable def finitePushforwardWeight
    (π : Ω → S) (w : Ω → ℝ) (s : S) : ℝ :=
  ∑ x : {x : Ω // π x = s}, w x

/-- The pointwise map on an ordered four-draw sample. -/
def mapFourDraw (π : Ω → S) (draw : Four → Ω) : Four → S :=
  π ∘ draw

/-- A draw lying over `d` is the same thing as an independent choice from
the fibre over `d i` at each of the four occurrence positions. -/
def fourDrawFiberEquiv (π : Ω → S) (d : Four → S) :
    {draw : Four → Ω // mapFourDraw π draw = d} ≃
      ((i : Four) → {x : Ω // π x = d i}) where
  toFun draw i := ⟨draw.1 i, by
    have h := congrFun draw.2 i
    simpa [mapFourDraw, Function.comp_apply] using h⟩
  invFun z := ⟨fun i => (z i).1, by
    funext i
    exact (z i).2⟩
  left_inv draw := by
    apply Subtype.ext
    funext i
    rfl
  right_inv z := by
    funext i
    apply Subtype.ext
    rfl

/-- The sum of source product weights over one four-draw fibre factors into
the product of its four one-coordinate fibre masses. -/
theorem sum_fourDrawWeight_fiber
    (π : Ω → S) (w : Ω → ℝ) (d : Four → S) :
    ∑ draw ∈ (Finset.univ.filter fun draw : Four → Ω =>
        mapFourDraw π draw = d), fourDrawWeight w draw =
      fourDrawWeight (finitePushforwardWeight π w) d := by
  classical
  calc
    (∑ draw ∈ (Finset.univ.filter fun draw : Four → Ω =>
        mapFourDraw π draw = d), fourDrawWeight w draw) =
        ∑ draw : {draw : Four → Ω // mapFourDraw π draw = d},
          fourDrawWeight w draw.1 := by
      symm
      simpa using
        (Finset.sum_subtype_eq_sum_filter
          (s := (Finset.univ : Finset (Four → Ω)))
          (fun draw => fourDrawWeight w draw)
          (p := fun draw => mapFourDraw π draw = d))
    _ = ∑ z : (i : Four) → {x : Ω // π x = d i},
          ∏ i, w (z i).1 := by
      apply Fintype.sum_equiv (fourDrawFiberEquiv π d)
      intro draw
      rfl
    _ = ∏ i, ∑ x : {x : Ω // π x = d i}, w x.1 := by
      symm
      exact Fintype.prod_sum (fun i (x : {x : Ω // π x = d i}) => w x.1)
    _ = fourDrawWeight (finitePushforwardWeight π w) d := by
      rfl

/-- Exact change of variables for every function of four independently
weighted observations under a finite pushforward. -/
theorem weightedFourSum_mapFourDraw
    (π : Ω → S) (w : Ω → ℝ) (f : (Four → S) → ℝ) :
    weightedFourSum w (fun draw => f (mapFourDraw π draw)) =
      weightedFourSum (finitePushforwardWeight π w) f := by
  classical
  unfold weightedFourSum
  rw [← Finset.sum_fiberwise (Finset.univ : Finset (Four → Ω))
    (mapFourDraw π)
    (fun draw => fourDrawWeight w draw * f (mapFourDraw π draw))]
  apply Finset.sum_congr rfl
  intro d _
  calc
    (∑ draw ∈ (Finset.univ.filter fun draw : Four → Ω =>
        mapFourDraw π draw = d),
        fourDrawWeight w draw * f (mapFourDraw π draw)) =
        ∑ draw ∈ (Finset.univ.filter fun draw : Four → Ω =>
          mapFourDraw π draw = d), fourDrawWeight w draw * f d := by
      apply Finset.sum_congr rfl
      intro draw hdraw
      have hd : mapFourDraw π draw = d := (Finset.mem_filter.mp hdraw).2
      rw [hd]
    _ = (∑ draw ∈ (Finset.univ.filter fun draw : Four → Ω =>
          mapFourDraw π draw = d), fourDrawWeight w draw) * f d := by
      rw [Finset.sum_mul]
    _ = fourDrawWeight (finitePushforwardWeight π w) d * f d := by
      rw [sum_fourDrawWeight_fiber]

/-- A one-draw weighted event mass. -/
noncomputable def finiteWeightedEventMass
    (w : Ω → ℝ) (E : Ω → Prop) : ℝ :=
  ∑ x, w x * indicator (E x)

/-- The fibre-mass definition is the weighted mass of the corresponding
singleton event. -/
theorem finitePushforwardWeight_eq_sum_filter
    (π : Ω → S) (w : Ω → ℝ) (s : S) :
    finitePushforwardWeight π w s =
      ∑ x ∈ (Finset.univ.filter fun x : Ω => π x = s), w x := by
  classical
  unfold finitePushforwardWeight
  simpa using
    (Finset.sum_subtype_eq_sum_filter
      (s := (Finset.univ : Finset Ω)) w
      (p := fun x => π x = s))

theorem finitePushforwardWeight_eq_eventMass
    (π : Ω → S) (w : Ω → ℝ) (s : S) :
    finitePushforwardWeight π w s =
      finiteWeightedEventMass w (fun x => π x = s) := by
  classical
  rw [finitePushforwardWeight_eq_sum_filter]
  unfold finiteWeightedEventMass
  rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro x _
  by_cases hx : π x = s <;> simp [indicator, hx]

/-- Exact one-draw pushforward identity. -/
theorem finiteWeightedEventMass_map
    (π : Ω → S) (w : Ω → ℝ) (E : S → Prop) :
    finiteWeightedEventMass w (fun x => E (π x)) =
      finiteWeightedEventMass (finitePushforwardWeight π w) E := by
  classical
  unfold finiteWeightedEventMass
  rw [← Finset.sum_fiberwise (Finset.univ : Finset Ω) π
    (fun x => w x * indicator (E (π x)))]
  apply Finset.sum_congr rfl
  intro s _
  calc
    (∑ x ∈ (Finset.univ.filter fun x : Ω => π x = s),
        w x * indicator (E (π x))) =
        ∑ x ∈ (Finset.univ.filter fun x : Ω => π x = s),
          w x * indicator (E s) := by
      apply Finset.sum_congr rfl
      intro x hx
      have hxs : π x = s := (Finset.mem_filter.mp hx).2
      rw [hxs]
    _ = (∑ x ∈ (Finset.univ.filter fun x : Ω => π x = s), w x) *
          indicator (E s) := by rw [Finset.sum_mul]
    _ = finitePushforwardWeight π w s * indicator (E s) := by
      rw [finitePushforwardWeight_eq_sum_filter]

/-- Pushforward weights compose exactly. -/
theorem finitePushforwardWeight_comp
    {T : Type*} [Fintype T] [DecidableEq T]
    (π : Ω → S) (σ : S → T) (w : Ω → ℝ) (t : T) :
    finitePushforwardWeight (σ ∘ π) w t =
      finitePushforwardWeight σ (finitePushforwardWeight π w) t := by
  rw [finitePushforwardWeight_eq_eventMass,
    finitePushforwardWeight_eq_eventMass]
  simpa [Function.comp_apply] using
    finiteWeightedEventMass_map π w (fun s => σ s = t)

/-- Under uniform weights, a finite event mass is its normalized cardinality. -/
theorem finiteWeightedEventMass_uniform_eq_normalizedCard
    [Nonempty Ω] (E : Ω → Prop) [DecidablePred E] :
    finiteWeightedEventMass (uniformWeight Ω) E =
      QDFull.normalizedCard (Finset.univ.filter E) := by
  classical
  unfold finiteWeightedEventMass uniformWeight QDFull.normalizedCard
  rw [show (∑ x : Ω, (1 / (Fintype.card Ω : ℝ)) * indicator (E x)) =
      ∑ x ∈ (Finset.univ.filter E), (1 / (Fintype.card Ω : ℝ)) by
    calc
      (∑ x : Ω, (1 / (Fintype.card Ω : ℝ)) * indicator (E x)) =
          ∑ x ∈ (Finset.univ.filter E),
            (1 / (Fintype.card Ω : ℝ)) * indicator (E x) := by
        rw [Finset.sum_filter]
        apply Finset.sum_congr rfl
        intro x _
        by_cases hx : E x <;> simp [indicator, hx]
      _ = ∑ x ∈ (Finset.univ.filter E),
          (1 / (Fintype.card Ω : ℝ)) := by
        apply Finset.sum_congr rfl
        intro x hx
        simp [indicator, (Finset.mem_filter.mp hx).2]
      ]
  simp only [Finset.sum_const_zero, Finset.sum_const, nsmul_eq_mul]
  field_simp

end FinitePushforward

/-! ## Polynomial functionals of a fixed ordered finite table -/

section FiniteTablePolynomial

variable {m n : ℕ}

abbrev OrderedCell (m n : ℕ) := Fin (m + 1) × Fin (n + 1)

/-- Atomic mass of one row of an ordered finite table. -/
noncomputable def finiteTableRowMass
    (p : OrderedCell m n → ℝ) (r : Fin (m + 1)) : ℝ :=
  finiteWeightedEventMass p (fun rc => rc.1 = r)

/-- Atomic mass of one column of an ordered finite table. -/
noncomputable def finiteTableColMass
    (p : OrderedCell m n → ℝ) (c : Fin (n + 1)) : ℝ :=
  finiteWeightedEventMass p (fun rc => rc.2 = c)

/-- Mass at or below one interior row cut. -/
noncomputable def finiteTableLowerRowMass
    (p : OrderedCell m n → ℝ) (i : Fin m) : ℝ :=
  finiteWeightedEventMass p (fun rc => rc.1 ≤ i.castSucc)

/-- Mass at or below one interior column cut. -/
noncomputable def finiteTableLowerColMass
    (p : OrderedCell m n → ℝ) (j : Fin n) : ℝ :=
  finiteWeightedEventMass p (fun rc => rc.2 ≤ j.castSucc)

/-- Joint mass in one lower-left cumulative rectangle. -/
noncomputable def finiteTableJointLowerMass
    (p : OrderedCell m n → ℝ) (i : Fin m) (j : Fin n) : ℝ :=
  finiteWeightedEventMass p
    (fun rc => rc.1 ≤ i.castSucc ∧ rc.2 ≤ j.castSucc)

/-- The finite-table CDF discrepancy. -/
noncomputable def finiteTableDelta
    (p : OrderedCell m n → ℝ) (i : Fin m) (j : Fin n) : ℝ :=
  finiteTableJointLowerMass p i j -
    finiteTableLowerRowMass p i * finiteTableLowerColMass p j

/-- The atomic BKR polynomial, with the terminal zero rows and columns already
omitted from the index sets. -/
noncomputable def finiteTableBKR
    (p : OrderedCell m n → ℝ) : ℝ :=
  ∑ i : Fin m, ∑ j : Fin n,
    finiteTableRowMass p i.castSucc *
      finiteTableColMass p j.castSucc * finiteTableDelta p i j ^ 2

/-- The finite four-draw tau-star polynomial of the same table. -/
noncomputable def finiteTableTauStar
    (p : OrderedCell m n → ℝ) : ℝ :=
  finiteTauStar Prod.fst Prod.snd p

end FiniteTablePolynomial

/-! ## Exact correspondence with the equally weighted rational labels -/

section RationalTableCorrespondence

variable {m n : ℕ}

private theorem rationalTableLabel_card_pos
    (p : OrderedCell m n → ℚ≥0) (hsum : ∑ rc, p rc = 1) :
    0 < Fintype.card (RationalTableLabel p) := by
  rw [card_rationalTableLabel p hsum]
  exact rationalTableDenom_pos p

/-- The cell projection sends uniform label weight to the prescribed rational
cell mass, as a real number. -/
theorem rationalTable_cell_pushforwardWeight
    (p : OrderedCell m n → ℚ≥0) (hsum : ∑ rc, p rc = 1)
    (rc : OrderedCell m n) :
    finitePushforwardWeight (fun x : RationalTableLabel p => x.1)
        (uniformWeight (RationalTableLabel p)) rc = (p rc : ℝ) := by
  letI : Nonempty (RationalTableLabel p) :=
    Fintype.card_pos_iff.mp (rationalTableLabel_card_pos p hsum)
  rw [finitePushforwardWeight_eq_eventMass,
    finiteWeightedEventMass_uniform_eq_normalizedCard]
  rw [show (Finset.univ.filter fun x : RationalTableLabel p => x.1 = rc) =
      Finset.univ.filter fun x : RationalTableLabel p =>
        rationalTableRow p x = rc.1 ∧ rationalTableCol p x = rc.2 by
    ext x
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    constructor
    · intro hx
      simpa [rationalTableRow, rationalTableCol, hx]
    · intro hx
      exact Prod.ext
        (by simpa [rationalTableRow] using hx.1)
        (by simpa [rationalTableCol] using hx.2)]
  exact rationalTable_normalizedCard_cell p hsum rc.1 rc.2

/-- The tau-star of the equally weighted labels is exactly the degree-four
table polynomial with the rational cell masses as coefficients. -/
theorem rationalTable_finiteTauStar_eq
    (p : OrderedCell m n → ℚ≥0) (hsum : ∑ rc, p rc = 1) :
    finiteTauStar (rationalTableRow p) (rationalTableCol p)
        (uniformWeight (RationalTableLabel p)) =
      finiteTableTauStar (fun rc => (p rc : ℝ)) := by
  change
    weightedFourSum (uniformWeight (RationalTableLabel p))
        (fun draw =>
          tauProductKernel (rationalTableRow p) (rationalTableCol p) draw) =
      weightedFourSum (fun rc => (p rc : ℝ))
        (tauProductKernel Prod.fst Prod.snd)
  let π : RationalTableLabel p → OrderedCell m n := fun x => x.1
  have hKernel :
      (fun draw : Four → RationalTableLabel p =>
        tauProductKernel (rationalTableRow p) (rationalTableCol p) draw) =
      (fun draw => tauProductKernel Prod.fst Prod.snd (mapFourDraw π draw)) := by
    funext draw
    rfl
  rw [hKernel, weightedFourSum_mapFourDraw]
  congr 1
  funext rc
  exact rationalTable_cell_pushforwardWeight p hsum rc

/-- Every one-draw event depending only on the cell has the same mass in the
uniform label model and in the rational table. -/
theorem rationalTable_eventMass_eq
    (p : OrderedCell m n → ℚ≥0) (hsum : ∑ rc, p rc = 1)
    (E : OrderedCell m n → Prop) :
    finiteWeightedEventMass (uniformWeight (RationalTableLabel p))
        (fun x => E x.1) =
      finiteWeightedEventMass (fun rc => (p rc : ℝ)) E := by
  rw [finiteWeightedEventMass_map]
  congr 1
  funext rc
  exact rationalTable_cell_pushforwardWeight p hsum rc

/-- Row atom masses in the label path are the row masses of the rational
table. -/
theorem rationalTable_orderedAtomMass_row_eq
    (p : OrderedCell m n → ℚ≥0) (hsum : ∑ rc, p rc = 1)
    (r : Fin (m + 1)) :
    orderedAtomMass (rationalTableRow p) r =
      finiteTableRowMass (fun rc => (p rc : ℝ)) r := by
  letI : Nonempty (RationalTableLabel p) :=
    Fintype.card_pos_iff.mp (rationalTableLabel_card_pos p hsum)
  unfold orderedAtomMass orderedAtomSet finiteTableRowMass
  calc
    QDFull.normalizedCard
        (Finset.univ.filter fun x : RationalTableLabel p =>
          rationalTableRow p x = r) =
        finiteWeightedEventMass (uniformWeight (RationalTableLabel p))
          (fun x => rationalTableRow p x = r) :=
      (finiteWeightedEventMass_uniform_eq_normalizedCard _).symm
    _ = finiteWeightedEventMass (uniformWeight (RationalTableLabel p))
          (fun x => x.1.1 = r) := by rfl
    _ = finiteWeightedEventMass (fun rc => (p rc : ℝ))
          (fun rc => rc.1 = r) :=
      rationalTable_eventMass_eq p hsum (fun rc => rc.1 = r)

/-- Column atom masses in the label path are the column masses of the rational
table. -/
theorem rationalTable_orderedAtomMass_col_eq
    (p : OrderedCell m n → ℚ≥0) (hsum : ∑ rc, p rc = 1)
    (c : Fin (n + 1)) :
    orderedAtomMass (rationalTableCol p) c =
      finiteTableColMass (fun rc => (p rc : ℝ)) c := by
  letI : Nonempty (RationalTableLabel p) :=
    Fintype.card_pos_iff.mp (rationalTableLabel_card_pos p hsum)
  unfold orderedAtomMass orderedAtomSet finiteTableColMass
  calc
    QDFull.normalizedCard
        (Finset.univ.filter fun x : RationalTableLabel p =>
          rationalTableCol p x = c) =
        finiteWeightedEventMass (uniformWeight (RationalTableLabel p))
          (fun x => rationalTableCol p x = c) :=
      (finiteWeightedEventMass_uniform_eq_normalizedCard _).symm
    _ = finiteWeightedEventMass (uniformWeight (RationalTableLabel p))
          (fun x => x.1.2 = c) := by rfl
    _ = finiteWeightedEventMass (fun rc => (p rc : ℝ))
          (fun rc => rc.2 = c) :=
      rationalTable_eventMass_eq p hsum (fun rc => rc.2 = c)

/-- Lower-row cumulative masses in the label path are the corresponding table
polynomials. -/
theorem rationalTable_orderedLowerMass_row_eq
    (p : OrderedCell m n → ℚ≥0) (hsum : ∑ rc, p rc = 1)
    (i : Fin m) :
    orderedLowerMass (rationalTableRow p) i =
      finiteTableLowerRowMass (fun rc => (p rc : ℝ)) i := by
  letI : Nonempty (RationalTableLabel p) :=
    Fintype.card_pos_iff.mp (rationalTableLabel_card_pos p hsum)
  unfold orderedLowerMass orderedLowerSet finiteTableLowerRowMass
  calc
    QDFull.normalizedCard
        (Finset.univ.filter fun x : RationalTableLabel p =>
          rationalTableRow p x ≤ i.castSucc) =
        finiteWeightedEventMass (uniformWeight (RationalTableLabel p))
          (fun x => rationalTableRow p x ≤ i.castSucc) :=
      (finiteWeightedEventMass_uniform_eq_normalizedCard _).symm
    _ = finiteWeightedEventMass (uniformWeight (RationalTableLabel p))
          (fun x => x.1.1 ≤ i.castSucc) := by rfl
    _ = finiteWeightedEventMass (fun rc => (p rc : ℝ))
          (fun rc => rc.1 ≤ i.castSucc) :=
      rationalTable_eventMass_eq p hsum (fun rc => rc.1 ≤ i.castSucc)

/-- Lower-column cumulative masses in the label path are the corresponding
table polynomials. -/
theorem rationalTable_orderedLowerMass_col_eq
    (p : OrderedCell m n → ℚ≥0) (hsum : ∑ rc, p rc = 1)
    (j : Fin n) :
    orderedLowerMass (rationalTableCol p) j =
      finiteTableLowerColMass (fun rc => (p rc : ℝ)) j := by
  letI : Nonempty (RationalTableLabel p) :=
    Fintype.card_pos_iff.mp (rationalTableLabel_card_pos p hsum)
  unfold orderedLowerMass orderedLowerSet finiteTableLowerColMass
  calc
    QDFull.normalizedCard
        (Finset.univ.filter fun x : RationalTableLabel p =>
          rationalTableCol p x ≤ j.castSucc) =
        finiteWeightedEventMass (uniformWeight (RationalTableLabel p))
          (fun x => rationalTableCol p x ≤ j.castSucc) :=
      (finiteWeightedEventMass_uniform_eq_normalizedCard _).symm
    _ = finiteWeightedEventMass (uniformWeight (RationalTableLabel p))
          (fun x => x.1.2 ≤ j.castSucc) := by rfl
    _ = finiteWeightedEventMass (fun rc => (p rc : ℝ))
          (fun rc => rc.2 ≤ j.castSucc) :=
      rationalTable_eventMass_eq p hsum (fun rc => rc.2 ≤ j.castSucc)

/-- Joint lower-left masses in the label paths are the corresponding table
polynomials. -/
theorem rationalTable_orderedJointLowerMass_eq
    (p : OrderedCell m n → ℚ≥0) (hsum : ∑ rc, p rc = 1)
    (i : Fin m) (j : Fin n) :
    orderedJointLowerMass (rationalTableRow p) (rationalTableCol p) i j =
      finiteTableJointLowerMass (fun rc => (p rc : ℝ)) i j := by
  letI : Nonempty (RationalTableLabel p) :=
    Fintype.card_pos_iff.mp (rationalTableLabel_card_pos p hsum)
  unfold orderedJointLowerMass finiteTableJointLowerMass
  rw [show orderedLowerSet (rationalTableRow p) i ∩
        orderedLowerSet (rationalTableCol p) j =
      Finset.univ.filter fun x : RationalTableLabel p =>
        x.1.1 ≤ i.castSucc ∧ x.1.2 ≤ j.castSucc by
    ext x
    simp [orderedLowerSet, rationalTableRow, rationalTableCol]]
  calc
    QDFull.normalizedCard
        (Finset.univ.filter fun x : RationalTableLabel p =>
          x.1.1 ≤ i.castSucc ∧ x.1.2 ≤ j.castSucc) =
        finiteWeightedEventMass (uniformWeight (RationalTableLabel p))
          (fun x => x.1.1 ≤ i.castSucc ∧ x.1.2 ≤ j.castSucc) :=
      (finiteWeightedEventMass_uniform_eq_normalizedCard _).symm
    _ = finiteWeightedEventMass (fun rc => (p rc : ℝ))
          (fun rc => rc.1 ≤ i.castSucc ∧ rc.2 ≤ j.castSucc) :=
      rationalTable_eventMass_eq p hsum
        (fun rc => rc.1 ≤ i.castSucc ∧ rc.2 ≤ j.castSucc)

/-- The path-grid discrepancy is exactly the table CDF discrepancy. -/
theorem rationalTable_orderedGridDelta_eq
    (p : OrderedCell m n → ℚ≥0) (hsum : ∑ rc, p rc = 1)
    (i : Fin m) (j : Fin n) :
    orderedGridDelta (rationalTableRow p) (rationalTableCol p) i j =
      finiteTableDelta (fun rc => (p rc : ℝ)) i j := by
  unfold orderedGridDelta finiteTableDelta
  rw [rationalTable_orderedJointLowerMass_eq p hsum,
    rationalTable_orderedLowerMass_row_eq p hsum,
    rationalTable_orderedLowerMass_col_eq p hsum]

/-- The BKR sum occurring in the path-tree inequality is exactly the atomic
BKR polynomial of the rational table. -/
theorem rationalTable_pathBKR_eq
    (p : OrderedCell m n → ℚ≥0) (hsum : ∑ rc, p rc = 1) :
    (∑ i : Fin m, ∑ j : Fin n,
      orderedAtomMass (rationalTableRow p) i.castSucc *
        orderedAtomMass (rationalTableCol p) j.castSucc *
        orderedGridDelta (rationalTableRow p) (rationalTableCol p) i j ^ 2) =
      finiteTableBKR (fun rc => (p rc : ℝ)) := by
  unfold finiteTableBKR
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro j _
  rw [rationalTable_orderedAtomMass_row_eq p hsum,
    rationalTable_orderedAtomMass_col_eq p hsum,
    rationalTable_orderedGridDelta_eq p hsum]

/-- The path-tree theorem therefore gives the exact finite inequality for
every rational probability table whose listed rows and columns are occupied. -/
theorem rationalTable_tauStar_ge_two_bkr
    (p : OrderedCell m n → ℚ≥0)
    (hsum : ∑ rc, p rc = 1)
    (hrow : ∀ r, 0 < ∑ c, p (r, c))
    (hcol : ∀ c, 0 < ∑ r, p (r, c)) :
    2 * finiteTableBKR (fun rc => (p rc : ℝ)) ≤
      finiteTableTauStar (fun rc => (p rc : ℝ)) := by
  have hrowSurj : Function.Surjective (rationalTableRow p) :=
    rationalTableRow_surjective p hrow
  have hcolSurj : Function.Surjective (rationalTableCol p) :=
    rationalTableCol_surjective p hcol
  have hPath := orderedPath_finiteTauStar_ge_two_bkr
    (rationalTableRow p) (rationalTableCol p) hrowSurj hcolSurj
  rw [rationalTable_pathBKR_eq p hsum,
    rationalTable_finiteTauStar_eq p hsum] at hPath
  exact hPath

end RationalTableCorrespondence

/-! ## Continuity of the two finite-table polynomials -/

section PolynomialContinuity

variable {A : Type*} {l : Filter A} {m n : ℕ}

/-- Every fixed finite one-draw event mass is continuous under pointwise
convergence of the cell weights. -/
theorem tendsto_finiteWeightedEventMass
    {S : Type*} [Fintype S]
    (pA : A → S → ℝ) (p : S → ℝ)
    (hp : ∀ s, Tendsto (fun a => pA a s) l (𝓝 (p s)))
    (E : S → Prop) :
    Tendsto (fun a => finiteWeightedEventMass (pA a) E) l
      (𝓝 (finiteWeightedEventMass p E)) := by
  unfold finiteWeightedEventMass
  apply tendsto_finsetSum Finset.univ
  intro s _
  exact (hp s).mul tendsto_const_nhds

theorem tendsto_finiteTableRowMass
    (pA : A → OrderedCell m n → ℝ) (p : OrderedCell m n → ℝ)
    (hp : ∀ rc, Tendsto (fun a => pA a rc) l (𝓝 (p rc)))
    (r : Fin (m + 1)) :
    Tendsto (fun a => finiteTableRowMass (pA a) r) l
      (𝓝 (finiteTableRowMass p r)) :=
  tendsto_finiteWeightedEventMass pA p hp (fun rc => rc.1 = r)

theorem tendsto_finiteTableColMass
    (pA : A → OrderedCell m n → ℝ) (p : OrderedCell m n → ℝ)
    (hp : ∀ rc, Tendsto (fun a => pA a rc) l (𝓝 (p rc)))
    (c : Fin (n + 1)) :
    Tendsto (fun a => finiteTableColMass (pA a) c) l
      (𝓝 (finiteTableColMass p c)) :=
  tendsto_finiteWeightedEventMass pA p hp (fun rc => rc.2 = c)

theorem tendsto_finiteTableLowerRowMass
    (pA : A → OrderedCell m n → ℝ) (p : OrderedCell m n → ℝ)
    (hp : ∀ rc, Tendsto (fun a => pA a rc) l (𝓝 (p rc)))
    (i : Fin m) :
    Tendsto (fun a => finiteTableLowerRowMass (pA a) i) l
      (𝓝 (finiteTableLowerRowMass p i)) :=
  tendsto_finiteWeightedEventMass pA p hp
    (fun rc => rc.1 ≤ i.castSucc)

theorem tendsto_finiteTableLowerColMass
    (pA : A → OrderedCell m n → ℝ) (p : OrderedCell m n → ℝ)
    (hp : ∀ rc, Tendsto (fun a => pA a rc) l (𝓝 (p rc)))
    (j : Fin n) :
    Tendsto (fun a => finiteTableLowerColMass (pA a) j) l
      (𝓝 (finiteTableLowerColMass p j)) :=
  tendsto_finiteWeightedEventMass pA p hp
    (fun rc => rc.2 ≤ j.castSucc)

theorem tendsto_finiteTableJointLowerMass
    (pA : A → OrderedCell m n → ℝ) (p : OrderedCell m n → ℝ)
    (hp : ∀ rc, Tendsto (fun a => pA a rc) l (𝓝 (p rc)))
    (i : Fin m) (j : Fin n) :
    Tendsto (fun a => finiteTableJointLowerMass (pA a) i j) l
      (𝓝 (finiteTableJointLowerMass p i j)) :=
  tendsto_finiteWeightedEventMass pA p hp
    (fun rc => rc.1 ≤ i.castSucc ∧ rc.2 ≤ j.castSucc)

theorem tendsto_finiteTableDelta
    (pA : A → OrderedCell m n → ℝ) (p : OrderedCell m n → ℝ)
    (hp : ∀ rc, Tendsto (fun a => pA a rc) l (𝓝 (p rc)))
    (i : Fin m) (j : Fin n) :
    Tendsto (fun a => finiteTableDelta (pA a) i j) l
      (𝓝 (finiteTableDelta p i j)) := by
  unfold finiteTableDelta
  exact (tendsto_finiteTableJointLowerMass pA p hp i j).sub
    ((tendsto_finiteTableLowerRowMass pA p hp i).mul
      (tendsto_finiteTableLowerColMass pA p hp j))

/-- The atomic finite BKR expression is a continuous polynomial in the fixed
table entries. -/
theorem tendsto_finiteTableBKR
    (pA : A → OrderedCell m n → ℝ) (p : OrderedCell m n → ℝ)
    (hp : ∀ rc, Tendsto (fun a => pA a rc) l (𝓝 (p rc))) :
    Tendsto (fun a => finiteTableBKR (pA a)) l
      (𝓝 (finiteTableBKR p)) := by
  unfold finiteTableBKR
  apply tendsto_finsetSum Finset.univ
  intro i _
  apply tendsto_finsetSum Finset.univ
  intro j _
  exact ((tendsto_finiteTableRowMass pA p hp i.castSucc).mul
      (tendsto_finiteTableColMass pA p hp j.castSucc)).mul
    ((tendsto_finiteTableDelta pA p hp i j).pow 2)

/-- The finite tau-star expression is a continuous degree-four polynomial in
the fixed table entries. -/
theorem tendsto_finiteTableTauStar
    (pA : A → OrderedCell m n → ℝ) (p : OrderedCell m n → ℝ)
    (hp : ∀ rc, Tendsto (fun a => pA a rc) l (𝓝 (p rc))) :
    Tendsto (fun a => finiteTableTauStar (pA a)) l
      (𝓝 (finiteTableTauStar p)) := by
  unfold finiteTableTauStar finiteTauStar weightedFourSum
  apply tendsto_finsetSum Finset.univ
  intro draw _
  apply Filter.Tendsto.mul
  · unfold fourDrawWeight
    apply tendsto_finsetProd Finset.univ
    intro i _
    exact hp (draw i)
  · exact tendsto_const_nhds

end PolynomialContinuity

/-! ## Passage from rational to arbitrary finite cell masses -/

section ArbitraryFiniteTable

variable {m n : ℕ}

/-- A strictly positive smoothing of a finite probability table.  At level
`N` we keep weight `1 - 1/(N+1)` on the original table and put the remaining
weight uniformly on every cell.  The construction is used only to remove the
auxiliary assumption that every listed row and column has positive mass. -/
noncomputable def smoothedFiniteTable
    (p : OrderedCell m n → ℝ) (N : ℕ) (rc : OrderedCell m n) : ℝ :=
  (1 - 1 / ((N : ℝ) + 1)) * p rc +
    (1 / ((N : ℝ) + 1)) /
      (Fintype.card (OrderedCell m n) : ℝ)

/-- The finite-support inequality for arbitrary real cell masses.  The row and
column positivity assumptions express that the index sets list exactly the
occupied support values, as in the manuscript. -/
theorem finiteTable_tauStar_ge_two_bkr
    (p : OrderedCell m n → ℝ) (s0 : PositiveMassSupport p)
    (hp : ∀ rc, 0 ≤ p rc) (hsum : ∑ rc, p rc = 1)
    (hrow : ∀ r, 0 < ∑ c, p (r, c))
    (hcol : ∀ c, 0 < ∑ r, p (r, c)) :
    2 * finiteTableBKR p ≤ finiteTableTauStar p := by
  let q : ℕ → OrderedCell m n → ℚ≥0 :=
    fun N rc => fullSupportMassApproxNNRat p s0 N rc
  let pA : ℕ → OrderedCell m n → ℝ :=
    fun N rc => (q N rc : ℝ)
  have hpA : ∀ rc, Tendsto (fun N => pA N rc) atTop (𝓝 (p rc)) := by
    intro rc
    exact tendsto_fullSupportMassApproxNNRat p s0 hp hsum rc
  have hMarginals :
      ∀ᶠ N : ℕ in atTop,
        (∀ r, 0 < ∑ c, q N (r, c)) ∧
        (∀ c, 0 < ∑ r, q N (r, c)) := by
    filter_upwards [eventually_fullSupportMassApproxNNRat_marginals_pos
      p s0 hp hsum] with N hN
    exact ⟨fun r => hN.1 r (hrow r), fun c => hN.2 c (hcol c)⟩
  have hIneq :
      ∀ᶠ N : ℕ in atTop,
        2 * finiteTableBKR (pA N) ≤ finiteTableTauStar (pA N) := by
    filter_upwards [hMarginals] with N hN
    exact rationalTable_tauStar_ge_two_bkr (q N)
      (sum_fullSupportMassApproxNNRat p s0 hp hsum N) hN.1 hN.2
  have hBKR : Tendsto (fun N => finiteTableBKR (pA N)) atTop
      (𝓝 (finiteTableBKR p)) :=
    tendsto_finiteTableBKR pA p hpA
  have hTau : Tendsto (fun N => finiteTableTauStar (pA N)) atTop
      (𝓝 (finiteTableTauStar p)) :=
    tendsto_finiteTableTauStar pA p hpA
  have hPair : Tendsto
      (fun N => (2 * finiteTableBKR (pA N), finiteTableTauStar (pA N)))
      atTop (𝓝 (2 * finiteTableBKR p, finiteTableTauStar p)) :=
    (tendsto_const_nhds.mul hBKR).prodMk_nhds hTau
  exact (isClosed_le continuous_fst continuous_snd).mem_of_tendsto hPair hIneq

/-- The finite-support inequality without an occupied-row or occupied-column
assumption.  Zero marginal rows and columns cause no difficulty: approximate
the table by `smoothedFiniteTable`, whose every cell is strictly positive,
apply `finiteTable_tauStar_ge_two_bkr`, and pass to the limit through the two
explicit finite polynomials. -/
theorem finiteTable_tauStar_ge_two_bkr_of_nonneg
    (p : OrderedCell m n → ℝ)
    (hp : ∀ rc, 0 ≤ p rc) (hsum : ∑ rc, p rc = 1) :
    2 * finiteTableBKR p ≤ finiteTableTauStar p := by
  let pA : ℕ → OrderedCell m n → ℝ := smoothedFiniteTable p
  have hcard : 0 < (Fintype.card (OrderedCell m n) : ℝ) := by
    positivity
  have hEpsPos (N : ℕ) : 0 < (1 / ((N : ℝ) + 1) : ℝ) := by
    positivity
  have hEpsLe (N : ℕ) : (1 / ((N : ℝ) + 1) : ℝ) ≤ 1 := by
    apply (div_le_one (by positivity : 0 < (N : ℝ) + 1)).2
    have hN : 0 ≤ (N : ℝ) := by positivity
    linarith
  have hpA_nonneg (N : ℕ) (rc : OrderedCell m n) : 0 ≤ pA N rc := by
    dsimp [pA, smoothedFiniteTable]
    exact add_nonneg
      (mul_nonneg (sub_nonneg.mpr (hEpsLe N)) (hp rc))
      (le_of_lt (div_pos (hEpsPos N) hcard))
  have hpA_pos (N : ℕ) (rc : OrderedCell m n) : 0 < pA N rc := by
    dsimp [pA, smoothedFiniteTable]
    have hUniform :
        0 < (1 / ((N : ℝ) + 1)) /
          (Fintype.card (OrderedCell m n) : ℝ) := by
      positivity
    nlinarith [mul_nonneg (sub_nonneg.mpr (hEpsLe N)) (hp rc)]
  have hpA_sum (N : ℕ) : ∑ rc, pA N rc = 1 := by
    classical
    simp only [pA, smoothedFiniteTable, Finset.sum_add_distrib,
      ← Finset.mul_sum, hsum, Finset.sum_const, Finset.card_univ,
      nsmul_eq_mul]
    field_simp
    ring
  have hpA_row (N : ℕ) : ∀ r, 0 < ∑ c, pA N (r, c) := by
    intro r
    exact Finset.sum_pos (fun c _ => hpA_pos N (r, c))
      ⟨0, Finset.mem_univ _⟩
  have hpA_col (N : ℕ) : ∀ c, 0 < ∑ r, pA N (r, c) := by
    intro c
    exact Finset.sum_pos (fun r _ => hpA_pos N (r, c))
      ⟨0, Finset.mem_univ _⟩
  have hpA_support (N : ℕ) : PositiveMassSupport (pA N) :=
    ⟨(0, 0), hpA_pos N (0, 0)⟩
  have hIneq (N : ℕ) :
      2 * finiteTableBKR (pA N) ≤ finiteTableTauStar (pA N) :=
    finiteTable_tauStar_ge_two_bkr (pA N) (hpA_support N)
      (hpA_nonneg N) (hpA_sum N) (hpA_row N) (hpA_col N)
  have hEps : Tendsto (fun N : ℕ => (1 / ((N : ℝ) + 1) : ℝ))
      atTop (𝓝 0) := tendsto_one_div_add_atTop_nhds_zero_nat
  have hpA_tendsto : ∀ rc, Tendsto (fun N => pA N rc) atTop (𝓝 (p rc)) := by
    intro rc
    dsimp [pA, smoothedFiniteTable]
    have hOne : Tendsto (fun _ : ℕ => (1 : ℝ)) atTop (𝓝 1) :=
      tendsto_const_nhds
    have hCell : Tendsto (fun _ : ℕ => p rc) atTop (𝓝 (p rc)) :=
      tendsto_const_nhds
    simpa using (((hOne.sub hEps).mul hCell).add
      (hEps.div_const (Fintype.card (OrderedCell m n) : ℝ)))
  have hBKR : Tendsto (fun N => finiteTableBKR (pA N)) atTop
      (𝓝 (finiteTableBKR p)) :=
    tendsto_finiteTableBKR pA p hpA_tendsto
  have hTau : Tendsto (fun N => finiteTableTauStar (pA N)) atTop
      (𝓝 (finiteTableTauStar p)) :=
    tendsto_finiteTableTauStar pA p hpA_tendsto
  have hPair : Tendsto
      (fun N => (2 * finiteTableBKR (pA N), finiteTableTauStar (pA N)))
      atTop (𝓝 (2 * finiteTableBKR p, finiteTableTauStar p)) :=
    (tendsto_const_nhds.mul hBKR).prodMk_nhds hTau
  exact (isClosed_le continuous_fst continuous_snd).mem_of_tendsto hPair
    (Filter.Eventually.of_forall hIneq)

end ArbitraryFiniteTable

end QDTauStar
