# Single zero-mass-cell manuscript copyedit

Date: 2026-09-05, after the weighted-draw Lean completion on the same date.

## Authorized change only

In PTRF v8 TeX lines 1773--1774, the original text was:

```tex
to be the ordinal rank of the occupied cell containing $x$; define it
arbitrarily on the union of zero-$F_X$-mass cells.  Define $h_k$ analogously
```

The replacement is:

```tex
to be the ordinal rank of the occupied cell containing $x$; set $g_k(x)=0$
on the union of zero-$F_X$-mass cells.  Define $h_k$ analogously
```

This makes the null-cell extension explicitly measurable. The analogous
definition of `h_k` uses the same zero-value convention. It changes no
positive-probability cell rank, law, almost-sure comparison or limit. It does
not assert global monotonicity of the zero-extended occupied-cell rank.

No other manuscript prose was changed. In particular, the Introduction's
sample-pattern wording, the phrase "Both sides" in the finite-approximation
paragraph, the weighted covariance paragraph, and the Discussion remain
untouched. All Lean source files, including the older quantile-related
comment in `QDTauStar/ZeroCharacterization.lean`, are unchanged.

## Verification

- TeX: exactly the replacement above, with the same 1945 source lines.
- Displays: all 115 display-math blocks identical.
- Numbered statements: all 14 theorem/lemma/corollary/proposition environments identical.
- Labels: every label retains its source line.
- PDF: 27 pages; only pages 23--24 change in rendered appearance.
- Bibliography: `.bib` and regenerated `.bbl` identical to the original.
- Template: `.cls` and `.bst` identical to the original.
- Lean: all 142 files, 53,709 lines, identical to the completed weighted-draw package.
- Toolchain/dependencies/licences: unchanged.

Current manuscript SHA-256:

```text
Grunewald_Huang_PTRF_v8.tex
b691af256df8edb11503ddcc47c01bc88977d97af3b4447b814105517cf9b1ce
Grunewald_Huang_PTRF_v8.pdf
3853df09723be17bfdd2e4709c44ff40e10f84f0c8d5f430013bbbdf28f5c069
Grunewald_Huang_PTRF_v8_References.bib
9082a66ab956dc4abed7c2a478127cb1ea274d9dc0a7eebca674f0e091e18df8
```

The Lean baseline is the complete weighted-draw supplement ZIP with SHA-256
`171ea991fb52f4b1c4b6c7fe0874f375fe1054fadfe0768a48bd603ed86f1e44`,
not the earlier 141-file ESM. The new package retains that full proof set.
The existing successful fresh build and transitive axiom audit therefore
apply to exactly the same Lean sources. This copyedit phase does not claim
that a new mathematical proof or a second fresh Lean build was needed.

Original local files are backed up before replacement. No journal submission
is updated by this operation.
